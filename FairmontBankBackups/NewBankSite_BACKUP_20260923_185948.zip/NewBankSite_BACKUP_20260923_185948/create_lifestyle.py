from pathlib import Path
import re

BASE = Path(".")
APP = BASE / "app.py"
TEMPLATES = BASE / "templates"

if not APP.exists():
    raise SystemExit("ERROR: app.py was not found.")

TEMPLATES.mkdir(exist_ok=True)

app_text = APP.read_text(encoding="utf-8")

# ---------------------------------------------------------
# 1. Create Lifestyle route
# ---------------------------------------------------------

route_marker = '@app.route("/lifestyle"'

if route_marker not in app_text:
    route_code = r'''

@app.route("/lifestyle", methods=["GET", "POST"])
@login_required
def lifestyle():
    customer = current_user

    lifestyle_categories = [
        "Restaurants & Dining",
        "Shopping",
        "Entertainment",
        "Fitness & Wellness",
        "Beauty & Personal Care",
        "Travel & Leisure",
        "Events & Tickets",
        "Other Lifestyle"
    ]

    if request.method == "GET":
        return render_template(
            "lifestyle.html",
            customer=customer,
            categories=lifestyle_categories
        )

    category = request.form.get("category", "").strip()
    merchant = request.form.get("merchant", "").strip()
    account_reference = request.form.get("account_reference", "").strip()
    amount_text = request.form.get("amount", "").strip()
    payment_reference = request.form.get("payment_reference", "").strip()

    errors = []

    if category not in lifestyle_categories:
        errors.append("Please select a lifestyle category.")

    if not merchant:
        errors.append("Please enter the merchant or service name.")

    if not account_reference:
        errors.append("Please enter the customer or order reference.")

    try:
        amount = float(amount_text)
    except (TypeError, ValueError):
        amount = 0

    if amount <= 0:
        errors.append("Please enter a valid payment amount.")

    if amount > float(customer.account_balance):
        errors.append("Insufficient balance for this lifestyle payment.")

    if errors:
        return render_template(
            "lifestyle.html",
            customer=customer,
            categories=lifestyle_categories,
            errors=errors,
            category=category,
            merchant=merchant,
            account_reference=account_reference,
            amount=amount_text,
            payment_reference=payment_reference
        )

    new_balance = float(customer.account_balance) - amount
    transaction_reference = generate_transaction_reference()

    customer.account_balance = new_balance

    transaction = Transaction(
        transaction_reference=transaction_reference,
        customer_id=customer.id,
        transaction_type="Lifestyle Payment",
        direction="Debit",
        amount=amount,
        balance_after=new_balance,
        description=f"{category} payment",
        counterparty=merchant,
        status="Completed"
    )

    db.session.add(transaction)
    db.session.commit()

    return render_template(
        "lifestyle_confirmation.html",
        customer=customer,
        category=category,
        merchant=merchant,
        account_reference=account_reference,
        amount=amount,
        payment_reference=payment_reference,
        transaction_reference=transaction_reference,
        new_balance=new_balance
    )
'''

    # Insert the route immediately before the final app.run block.
    app_run_pattern = r'\nif __name__\s*==\s*[\'"]__main__[\'"]\s*:'

    match = re.search(app_run_pattern, app_text)

    if not match:
        raise SystemExit(
            "ERROR: The final app.run block could not be located. "
            "No changes were made to app.py."
        )

    app_text = app_text[:match.start()] + route_code + app_text[match.start():]

    APP.write_text(app_text, encoding="utf-8")
    print("SUCCESS: /lifestyle route added.")
else:
    print("NOTICE: /lifestyle route already exists.")

# ---------------------------------------------------------
# 2. Create Lifestyle page
# ---------------------------------------------------------

lifestyle_html = r'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lifestyle | Fairmont Bank</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background:
                radial-gradient(circle at top left, rgba(40, 83, 145, 0.28), transparent 35%),
                linear-gradient(145deg, #061426, #0a1d34 55%, #07111f);
            color: #ffffff;
            min-height: 100vh;
        }

        .page {
            width: 100%;
            max-width: 760px;
            margin: 0 auto;
            padding: 22px 16px 40px;
        }

        .back {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: #dceaff;
            text-decoration: none;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .back:hover {
            color: #ffffff;
        }

        .header {
            margin-bottom: 20px;
        }

        .eyebrow {
            color: #8fb7ed;
            font-size: 12px;
            font-weight: 700;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            margin-bottom: 8px;
        }

        h1 {
            margin: 0;
            font-size: 30px;
            letter-spacing: -0.5px;
        }

        .subtitle {
            margin-top: 8px;
            color: #aebed2;
            line-height: 1.5;
            font-size: 14px;
        }

        .balance {
            background: rgba(255, 255, 255, 0.07);
            border: 1px solid rgba(255, 255, 255, 0.10);
            border-radius: 18px;
            padding: 18px;
            margin-bottom: 16px;
            backdrop-filter: blur(14px);
        }

        .balance-label {
            color: #9db0c8;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .balance-value {
            margin-top: 7px;
            font-size: 25px;
            font-weight: 700;
        }

        .card {
            background: rgba(11, 31, 55, 0.82);
            border: 1px solid rgba(255, 255, 255, 0.10);
            border-radius: 22px;
            padding: 20px;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.22);
            backdrop-filter: blur(16px);
        }

        .error {
            background: rgba(180, 45, 55, 0.18);
            border: 1px solid rgba(255, 100, 110, 0.35);
            color: #ffd5d8;
            border-radius: 13px;
            padding: 12px 14px;
            margin-bottom: 14px;
            font-size: 13px;
        }

        .field {
            margin-bottom: 16px;
        }

        label {
            display: block;
            color: #dce8f6;
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 8px;
        }

        input,
        select {
            width: 100%;
            border: 1px solid rgba(255, 255, 255, 0.13);
            background: rgba(255, 255, 255, 0.06);
            color: #ffffff;
            border-radius: 13px;
            padding: 13px 14px;
            font-size: 14px;
            outline: none;
        }

        input:focus,
        select:focus {
            border-color: rgba(123, 177, 244, 0.75);
        }

        select option {
            background: #0b2038;
            color: #ffffff;
        }

        .hint {
            margin-top: 6px;
            color: #8499b2;
            font-size: 11px;
        }

        .button {
            width: 100%;
            border: 0;
            border-radius: 14px;
            padding: 14px;
            background: #2f70c9;
            color: #ffffff;
            font-size: 15px;
            font-weight: 700;
            cursor: pointer;
            margin-top: 4px;
        }

        .button:hover {
            background: #3b80df;
        }

        .secure {
            text-align: center;
            color: #71869f;
            font-size: 11px;
            margin-top: 15px;
        }

        @media (max-width: 520px) {
            .page {
                padding: 18px 13px 30px;
            }

            h1 {
                font-size: 26px;
            }

            .card {
                padding: 17px;
            }
        }
    </style>
</head>

<body>
<div class="page">

    <a href="{{ url_for('dashboard') }}" class="back">← Back to Dashboard</a>

    <div class="header">
        <div class="eyebrow">Fairmont Bank</div>
        <h1>Lifestyle</h1>
        <div class="subtitle">
            Make payments for lifestyle services and purchases directly from your Fairmont Bank account.
        </div>
    </div>

    <div class="balance">
        <div class="balance-label">Available Balance</div>
        <div class="balance-value">£{{ "{:,.2f}".format(customer.account_balance or 0) }}</div>
    </div>

    <div class="card">

        {% if errors %}
            <div class="error">
                {% for error in errors %}
                    <div>{{ error }}</div>
                {% endfor %}
            </div>
        {% endif %}

        <form method="POST">

            <div class="field">
                <label for="category">Lifestyle Category</label>
                <select name="category" id="category" required>
                    <option value="">Select a category</option>

                    {% for item in categories %}
                        <option value="{{ item }}"
                            {% if category == item %}selected{% endif %}>
                            {{ item }}
                        </option>
                    {% endfor %}
                </select>
            </div>

            <div class="field">
                <label for="merchant">Merchant / Service Name</label>
                <input
                    type="text"
                    id="merchant"
                    name="merchant"
                    value="{{ merchant or '' }}"
                    placeholder="Enter merchant or service name"
                    required>
            </div>

            <div class="field">
                <label for="account_reference">Customer / Order Reference</label>
                <input
                    type="text"
                    id="account_reference"
                    name="account_reference"
                    value="{{ account_reference or '' }}"
                    placeholder="Enter reference number"
                    required>
            </div>

            <div class="field">
                <label for="amount">Payment Amount (£)</label>
                <input
                    type="number"
                    id="amount"
                    name="amount"
                    value="{{ amount or '' }}"
                    min="0.01"
                    step="0.01"
                    placeholder="0.00"
                    required>
            </div>

            <div class="field">
                <label for="payment_reference">Payment Reference (Optional)</label>
                <input
                    type="text"
                    id="payment_reference"
                    name="payment_reference"
                    value="{{ payment_reference or '' }}"
                    placeholder="Optional payment reference">
            </div>

            <button type="submit" class="button">
                Make Lifestyle Payment
            </button>

        </form>

        <div class="secure">
            Payments are recorded securely in your Fairmont Bank transaction history.
        </div>

    </div>
</div>
</body>
</html>
'''

(TEMPLATES / "lifestyle.html").write_text(
    lifestyle_html,
    encoding="utf-8"
)

print("SUCCESS: lifestyle.html created.")

# ---------------------------------------------------------
# 3. Create confirmation page
# ---------------------------------------------------------

confirmation_html = r'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Confirmed | Fairmont Bank</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background:
                radial-gradient(circle at top, rgba(40, 83, 145, 0.28), transparent 40%),
                linear-gradient(145deg, #061426, #0a1d34 55%, #07111f);
            color: #ffffff;
            min-height: 100vh;
        }

        .page {
            width: 100%;
            max-width: 650px;
            margin: 0 auto;
            padding: 28px 16px 40px;
        }

        .card {
            background: rgba(11, 31, 55, 0.86);
            border: 1px solid rgba(255, 255, 255, 0.10);
            border-radius: 24px;
            padding: 25px;
            backdrop-filter: blur(16px);
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.25);
        }

        .success {
            width: 58px;
            height: 58px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 17px;
            background: rgba(48, 175, 112, 0.18);
            border: 1px solid rgba(91, 221, 153, 0.35);
            color: #75e0a8;
            font-size: 28px;
        }

        .eyebrow {
            color: #8fb7ed;
            font-size: 12px;
            font-weight: 700;
            letter-spacing: 1.5px;
            text-transform: uppercase;
        }

        h1 {
            margin: 7px 0;
            font-size: 27px;
        }

        .intro {
            color: #aebed2;
            font-size: 14px;
            line-height: 1.5;
            margin-bottom: 22px;
        }

        .details {
            border-top: 1px solid rgba(255,255,255,0.09);
        }

        .row {
            display: flex;
            justify-content: space-between;
            gap: 15px;
            padding: 13px 0;
            border-bottom: 1px solid rgba(255,255,255,0.07);
            font-size: 13px;
        }

        .label {
            color: #91a5bc;
        }

        .value {
            text-align: right;
            color: #f3f7fc;
            font-weight: 600;
            word-break: break-word;
        }

        .status {
            color: #75e0a8;
        }

        .amount {
            font-size: 19px;
        }

        .actions {
            display: grid;
            gap: 10px;
            margin-top: 22px;
        }

        .button {
            display: block;
            text-align: center;
            text-decoration: none;
            padding: 13px;
            border-radius: 13px;
            font-size: 14px;
            font-weight: 700;
            background: #2f70c9;
            color: #ffffff;
        }

        .secondary {
            background: rgba(255,255,255,0.07);
            border: 1px solid rgba(255,255,255,0.10);
        }
    </style>
</head>

<body>
<div class="page">
    <div class="card">

        <div class="success">✓</div>

        <div class="eyebrow">Fairmont Bank</div>

        <h1>Payment Completed</h1>

        <div class="intro">
            Your lifestyle payment has been successfully processed and recorded in your transaction history.
        </div>

        <div class="details">

            <div class="row">
                <div class="label">Category</div>
                <div class="value">{{ category }}</div>
            </div>

            <div class="row">
                <div class="label">Merchant / Service</div>
                <div class="value">{{ merchant }}</div>
            </div>

            <div class="row">
                <div class="label">Customer / Order Reference</div>
                <div class="value">{{ account_reference }}</div>
            </div>

            <div class="row">
                <div class="label">Amount</div>
                <div class="value amount">
                    £{{ "{:,.2f}".format(amount) }}
                </div>
            </div>

            {% if payment_reference %}
            <div class="row">
                <div class="label">Payment Reference</div>
                <div class="value">{{ payment_reference }}</div>
            </div>
            {% endif %}

            <div class="row">
                <div class="label">Transaction Reference</div>
                <div class="value">{{ transaction_reference }}</div>
            </div>

            <div class="row">
                <div class="label">Status</div>
                <div class="value status">Completed</div>
            </div>

            <div class="row">
                <div class="label">New Balance</div>
                <div class="value">
                    £{{ "{:,.2f}".format(new_balance) }}
                </div>
            </div>

        </div>

        <div class="actions">
            <a href="{{ url_for('transactions') }}" class="button">
                View Transactions
            </a>

            <a href="{{ url_for('dashboard') }}" class="button secondary">
                Back to Dashboard
            </a>
        </div>

    </div>
</div>
</body>
</html>
'''

(TEMPLATES / "lifestyle_confirmation.html").write_text(
    confirmation_html,
    encoding="utf-8"
)

print("SUCCESS: lifestyle_confirmation.html created.")

# ---------------------------------------------------------
# 4. Connect existing dashboard Lifestyle card
# ---------------------------------------------------------

dashboard = TEMPLATES / "dashboard.html"

if dashboard.exists():
    text = dashboard.read_text(encoding="utf-8")

    # Only change a Lifestyle card that currently points to dashboard#.
    pattern = r'(<a\b[^>]*href=["\'])/dashboard#(["\'][^>]*>.*?Lifestyles.*?</a>)'

    new_text, count = re.subn(
        pattern,
        r'\1/lifestyle\2',
        text,
        count=1,
        flags=re.IGNORECASE | re.DOTALL
    )

    if count:
        dashboard.write_text(new_text, encoding="utf-8")
        print("SUCCESS: Dashboard Lifestyle card connected to /lifestyle.")
    else:
        if '/lifestyle' in text:
            print("NOTICE: Dashboard Lifestyle link already appears connected.")
        else:
            print("NOTICE: Lifestyle dashboard link was not automatically changed.")
            print("The Lifestyle page itself was still installed successfully.")
else:
    print("NOTICE: dashboard.html was not found. The Lifestyle page was still installed.")

print()
print("=" * 65)
print("LIFESTYLE FEATURE INSTALLATION COMPLETE")
print("=" * 65)
print()
print("Route: /lifestyle")
print("Page: templates/lifestyle.html")
print("Confirmation: templates/lifestyle_confirmation.html")
print()
print("Next step:")
print("Run: python -m py_compile app.py")