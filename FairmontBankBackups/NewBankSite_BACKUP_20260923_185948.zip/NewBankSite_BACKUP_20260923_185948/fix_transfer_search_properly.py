from pathlib import Path
import shutil
import re

BASE = Path(__file__).resolve().parent
TEMPLATES = BASE / "templates"
STATIC_JS = BASE / "static" / "js"
STATIC_CSS = BASE / "static" / "css"

INTERNATIONAL = TEMPLATES / "international_transfer.html"
SEND_MONEY = TEMPLATES / "send_money.html"
TRANSFER_JS = STATIC_JS / "transfer.js"
TRANSFER_CSS = STATIC_CSS / "transfer.css"


# ============================================================
# HELPERS
# ============================================================

def make_backup(path, suffix):
    backup = path.with_name(path.stem + suffix + path.suffix)

    if not backup.exists():
        shutil.copy2(path, backup)
        print("Backup created:", backup.name)


def replace_file_section(text, pattern, replacement, description):
    new_text, count = re.subn(
        pattern,
        replacement,
        text,
        count=1,
        flags=re.IGNORECASE | re.DOTALL
    )

    if count:
        print("Updated:", description)
        return new_text

    print("Not found:", description)
    return text


# ============================================================
# CHECK FILES
# ============================================================

if not INTERNATIONAL.exists():
    raise SystemExit(
        "ERROR: templates\\international_transfer.html was not found."
    )

if not SEND_MONEY.exists():
    raise SystemExit(
        "ERROR: templates\\send_money.html was not found."
    )


# ============================================================
# BACKUPS
# ============================================================

make_backup(
    INTERNATIONAL,
    "_before_search_repair"
)

make_backup(
    SEND_MONEY,
    "_before_search_repair"
)

make_backup(
    TRANSFER_JS,
    "_before_search_repair"
)

make_backup(
    TRANSFER_CSS,
    "_before_search_repair"
)


# ============================================================
# COUNTRY / BANK DATA
# ============================================================

COUNTRY_BANKS = {
    "United Kingdom": [
        "Barclays Bank",
        "HSBC UK",
        "Lloyds Bank",
        "NatWest",
        "Royal Bank of Scotland",
        "Santander UK",
        "Halifax",
        "Nationwide Building Society",
        "Monzo Bank",
        "Starling Bank",
        "Metro Bank",
        "TSB Bank",
        "Virgin Money",
        "Chase UK",
        "Revolut",
        "Bank of Scotland",
        "First Direct",
        "Co-operative Bank",
        "Coutts",
        "Danske Bank",
        "Investec Bank",
        "ClearBank",
        "Zopa Bank",
        "Yorkshire Building Society",
        "Skipton Building Society",
        "Other UK Bank or Building Society"
    ],

    "United States": [
        "JPMorgan Chase",
        "Bank of America",
        "Citibank",
        "Wells Fargo",
        "U.S. Bank",
        "PNC Bank",
        "Truist Bank",
        "Capital One",
        "TD Bank",
        "Goldman Sachs Bank",
        "Other US Bank"
    ],

    "Canada": [
        "Royal Bank of Canada",
        "Toronto-Dominion Bank",
        "Bank of Montreal",
        "Canadian Imperial Bank of Commerce",
        "Bank of Nova Scotia",
        "National Bank of Canada",
        "Desjardins",
        "Other Canadian Bank"
    ],

    "Australia": [
        "Commonwealth Bank",
        "Westpac",
        "ANZ",
        "National Australia Bank",
        "Macquarie Bank",
        "Bank of Queensland",
        "Bendigo Bank",
        "Other Australian Bank"
    ],

    "New Zealand": [
        "ANZ New Zealand",
        "ASB Bank",
        "Bank of New Zealand",
        "Westpac New Zealand",
        "Kiwibank",
        "Other New Zealand Bank"
    ],

    "Germany": [
        "Deutsche Bank",
        "Commerzbank",
        "DZ Bank",
        "KfW",
        "ING Germany",
        "N26",
        "DKB",
        "Other German Bank"
    ],

    "France": [
        "BNP Paribas",
        "Crédit Agricole",
        "Société Générale",
        "BPCE",
        "La Banque Postale",
        "Crédit Mutuel",
        "Other French Bank"
    ],

    "Netherlands": [
        "ING Bank",
        "ABN AMRO",
        "Rabobank",
        "de Volksbank",
        "Other Dutch Bank"
    ],

    "Belgium": [
        "KBC Bank",
        "Belfius Bank",
        "BNP Paribas Fortis",
        "ING Belgium",
        "Other Belgian Bank"
    ],

    "Switzerland": [
        "UBS",
        "Julius Baer",
        "Zürcher Kantonalbank",
        "Banque Cantonale Vaudoise",
        "PostFinance",
        "Other Swiss Bank"
    ],

    "Spain": [
        "Banco Santander",
        "BBVA",
        "CaixaBank",
        "Banco Sabadell",
        "Bankinter",
        "Unicaja Banco",
        "Other Spanish Bank"
    ],

    "Italy": [
        "Intesa Sanpaolo",
        "UniCredit",
        "Banco BPM",
        "BPER Banca",
        "Monte dei Paschi di Siena",
        "Other Italian Bank"
    ],

    "Portugal": [
        "Caixa Geral de Depósitos",
        "Millennium BCP",
        "Novo Banco",
        "Banco Santander Portugal",
        "Other Portuguese Bank"
    ],

    "Ireland": [
        "AIB",
        "Bank of Ireland",
        "Permanent TSB",
        "Revolut Ireland",
        "Other Irish Bank"
    ],

    "Norway": [
        "DNB",
        "SpareBank 1",
        "Nordea Norway",
        "Danske Bank Norway",
        "Other Norwegian Bank"
    ],

    "Sweden": [
        "Swedbank",
        "SEB",
        "Handelsbanken",
        "Nordea Sweden",
        "Other Swedish Bank"
    ],

    "Denmark": [
        "Danske Bank",
        "Nordea Denmark",
        "Jyske Bank",
        "Sydbank",
        "Other Danish Bank"
    ],

    "Finland": [
        "Nordea Finland",
        "OP Financial Group",
        "Danske Bank Finland",
        "Aktia Bank",
        "Other Finnish Bank"
    ],

    "Poland": [
        "PKO Bank Polski",
        "Bank Pekao",
        "Santander Bank Polska",
        "mBank",
        "ING Bank Śląski",
        "Other Polish Bank"
    ],

    "Austria": [
        "Erste Bank",
        "Raiffeisen Bank",
        "Bank Austria",
        "BAWAG",
        "Other Austrian Bank"
    ],

    "South Africa": [
        "Standard Bank",
        "First National Bank",
        "Absa Bank",
        "Nedbank",
        "Capitec Bank",
        "Investec Bank South Africa",
        "Other South African Bank"
    ],

    "Kenya": [
        "KCB Bank Kenya",
        "Equity Bank Kenya",
        "Co-operative Bank of Kenya",
        "Absa Bank Kenya",
        "NCBA Bank Kenya",
        "Stanbic Bank Kenya",
        "I&M Bank",
        "DTB Kenya",
        "Family Bank",
        "Other Kenyan Bank"
    ],

    "Nigeria": [
        "Access Bank",
        "GTBank",
        "Zenith Bank",
        "First Bank of Nigeria",
        "United Bank for Africa",
        "Fidelity Bank",
        "FCMB",
        "Stanbic IBTC Bank",
        "Other Nigerian Bank"
    ],

    "Ghana": [
        "GCB Bank",
        "Ecobank Ghana",
        "Absa Bank Ghana",
        "Stanbic Bank Ghana",
        "Standard Chartered Ghana",
        "Fidelity Bank Ghana",
        "CalBank",
        "Other Ghanaian Bank"
    ],

    "Tanzania": [
        "CRDB Bank",
        "NMB Bank",
        "Absa Bank Tanzania",
        "Stanbic Bank Tanzania",
        "NBC Tanzania",
        "Exim Bank Tanzania",
        "Other Tanzanian Bank"
    ],

    "Uganda": [
        "Stanbic Bank Uganda",
        "Centenary Bank",
        "Absa Bank Uganda",
        "DFCU Bank",
        "Bank of Baroda Uganda",
        "Equity Bank Uganda",
        "Other Ugandan Bank"
    ],

    "Rwanda": [
        "Bank of Kigali",
        "I&M Bank Rwanda",
        "Equity Bank Rwanda",
        "Cogebanque",
        "BK Rwanda",
        "Other Rwandan Bank"
    ],

    "United Arab Emirates": [
        "Emirates NBD",
        "First Abu Dhabi Bank",
        "Abu Dhabi Commercial Bank",
        "Mashreq Bank",
        "Dubai Islamic Bank",
        "Commercial Bank of Dubai",
        "RAKBANK",
        "Other UAE Bank"
    ],

    "Saudi Arabia": [
        "Saudi National Bank",
        "Al Rajhi Bank",
        "Riyad Bank",
        "Saudi Awwal Bank",
        "Banque Saudi Fransi",
        "Arab National Bank",
        "Bank Albilad",
        "Other Saudi Bank"
    ],

    "Qatar": [
        "Qatar National Bank",
        "Qatar Islamic Bank",
        "Commercial Bank of Qatar",
        "Doha Bank",
        "Dukhan Bank",
        "Other Qatari Bank"
    ],

    "India": [
        "State Bank of India",
        "HDFC Bank",
        "ICICI Bank",
        "Axis Bank",
        "Kotak Mahindra Bank",
        "IndusInd Bank",
        "Bank of Baroda",
        "Punjab National Bank",
        "Other Indian Bank"
    ],

    "China": [
        "Industrial and Commercial Bank of China",
        "China Construction Bank",
        "Bank of China",
        "Agricultural Bank of China",
        "Bank of Communications",
        "China Merchants Bank",
        "Other Chinese Bank"
    ],

    "Japan": [
        "MUFG Bank",
        "SMBC",
        "Mizuho Bank",
        "Resona Bank",
        "Japan Post Bank",
        "Other Japanese Bank"
    ],

    "Singapore": [
        "DBS Bank",
        "OCBC Bank",
        "United Overseas Bank",
        "Standard Chartered Singapore",
        "Citibank Singapore",
        "Other Singaporean Bank"
    ],

    "Malaysia": [
        "Maybank",
        "CIMB Bank",
        "Public Bank",
        "RHB Bank",
        "Hong Leong Bank",
        "AmBank",
        "Other Malaysian Bank"
    ],

    "Indonesia": [
        "Bank Mandiri",
        "Bank Central Asia",
        "Bank Rakyat Indonesia",
        "Bank Negara Indonesia",
        "CIMB Niaga",
        "Bank Permata",
        "Other Indonesian Bank"
    ],

    "Brazil": [
        "Banco do Brasil",
        "Itaú Unibanco",
        "Bradesco",
        "Caixa Econômica Federal",
        "Santander Brasil",
        "BTG Pactual",
        "Other Brazilian Bank"
    ],

    "Mexico": [
        "BBVA México",
        "Banorte",
        "Santander México",
        "HSBC México",
        "Citibanamex",
        "Scotiabank México",
        "Other Mexican Bank"
    ],

    "Argentina": [
        "Banco de la Nación Argentina",
        "Banco Galicia",
        "Banco Santander Argentina",
        "BBVA Argentina",
        "Banco Macro",
        "Other Argentine Bank"
    ],

    "Chile": [
        "Banco de Chile",
        "Banco Santander Chile",
        "Banco de Crédito e Inversiones",
        "Scotiabank Chile",
        "BancoEstado",
        "Other Chilean Bank"
    ],

    "Colombia": [
        "Bancolombia",
        "Banco de Bogotá",
        "Davivienda",
        "BBVA Colombia",
        "Banco de Occidente",
        "Other Colombian Bank"
    ],

    "Suriname": [
        "De Surinaamsche Bank N.V.",
        "Republic Bank (Suriname) N.V.",
        "Hakrinbank N.V.",
        "Finabank N.V.",
        "Surinaamse Postspaarbank",
        "Stichting Surinaamse Volkscredietbank",
        "Surichange Bank N.V.",
        "Coöperatieve Spaar- en Kredietbank GODO",
        "Trustbank Amanah",
        "Southern Commercial Bank N.V.",
        "Other Surinamese Bank"
    ],

    "Guyana": [
        "Republic Bank Guyana",
        "Demerara Bank",
        "Guyana Bank for Trade and Industry",
        "Citizens Bank Guyana",
        "Bank of Baroda Guyana",
        "Other Guyanese Bank"
    ],

    "Jamaica": [
        "National Commercial Bank Jamaica",
        "Scotiabank Jamaica",
        "Bank of Nova Scotia Jamaica",
        "Sagicor Bank Jamaica",
        "First Global Bank",
        "Other Jamaican Bank"
    ],

    "Trinidad and Tobago": [
        "Republic Bank",
        "First Citizens Bank",
        "RBC Royal Bank",
        "Scotiabank Trinidad and Tobago",
        "JMMB Bank",
        "Other Trinidadian Bank"
    ],

    "Bahamas": [
        "Royal Bank of Canada Bahamas",
        "Commonwealth Bank",
        "Scotiabank Bahamas",
        "Bank of The Bahamas",
        "CIBC FirstCaribbean",
        "Other Bahamian Bank"
    ],

    "Barbados": [
        "Republic Bank Barbados",
        "CIBC Caribbean",
        "First Citizens Bank Barbados",
        "RBC Royal Bank Barbados",
        "Scotiabank Barbados",
        "Other Barbadian Bank"
    ]
}


CURRENCIES = [
    ("GBP", "British Pound"),
    ("EUR", "Euro"),
    ("USD", "US Dollar"),
    ("CAD", "Canadian Dollar"),
    ("AUD", "Australian Dollar"),
    ("NZD", "New Zealand Dollar"),
    ("CHF", "Swiss Franc"),
    ("JPY", "Japanese Yen"),
    ("CNY", "Chinese Yuan"),
    ("HKD", "Hong Kong Dollar"),
    ("SGD", "Singapore Dollar"),
    ("ZAR", "South African Rand"),
    ("KES", "Kenyan Shilling"),
    ("NGN", "Nigerian Naira"),
    ("GHS", "Ghanaian Cedi"),
    ("TZS", "Tanzanian Shilling"),
    ("UGX", "Ugandan Shilling"),
    ("RWF", "Rwandan Franc"),
    ("INR", "Indian Rupee"),
    ("AED", "UAE Dirham"),
    ("SAR", "Saudi Riyal"),
    ("QAR", "Qatari Riyal"),
    ("BHD", "Bahraini Dinar"),
    ("KWD", "Kuwaiti Dinar"),
    ("OMR", "Omani Rial"),
    ("BRL", "Brazilian Real"),
    ("MXN", "Mexican Peso"),
    ("ARS", "Argentine Peso"),
    ("CLP", "Chilean Peso"),
    ("COP", "Colombian Peso"),
    ("SRD", "Surinamese Dollar")
]


# ============================================================
# INTERNATIONAL TRANSFER HTML
# ============================================================

international_html = INTERNATIONAL.read_text(encoding="utf-8")


country_options = ['<option value="">Select country</option>']

for country in sorted(COUNTRY_BANKS.keys()):
    country_options.append(
        f'<option value="{country}">{country}</option>'
    )

country_select = """
<select
    name="country"
    id="internationalCountry"
    class="quick-select-hidden"
    required
>
    %s
</select>

<div class="search-select-wrapper">
    <input
        type="text"
        id="countrySearch"
        class="transfer-search-input"
        placeholder="Search country..."
        autocomplete="off"
    >
    <div
        id="countrySearchResults"
        class="transfer-search-results"
    ></div>
</div>
""" % "\n        ".join(country_options)


international_html = replace_file_section(
    international_html,
    r'<select[^>]*id=["\']?internationalCountry["\']?[^>]*>.*?</select>',
    country_select,
    "international country selector"
)

if "id=\"internationalCountry\"" not in international_html:
    international_html = replace_file_section(
        international_html,
        r'<select[^>]*name=["\']country["\'][^>]*>.*?</select>',
        country_select,
        "country selector"
    )


# ------------------------------------------------------------
# BANK SELECT
# ------------------------------------------------------------

bank_select = """
<select
    name="bank_name"
    id="internationalBank"
    class="quick-select-hidden"
    required
    disabled
>
    <option value="">Select a country first</option>
</select>

<div class="search-select-wrapper">
    <input
        type="text"
        id="internationalBankSearch"
        class="transfer-search-input"
        placeholder="Select country first..."
        autocomplete="off"
        disabled
    >
    <div
        id="internationalBankSearchResults"
        class="transfer-search-results"
    ></div>
</div>
"""


international_html = replace_file_section(
    international_html,
    r'<select[^>]*id=["\']?internationalBank["\']?[^>]*>.*?</select>',
    bank_select,
    "international bank selector"
)

if "id=\"internationalBank\"" not in international_html:
    international_html = replace_file_section(
        international_html,
        r'<(?:input|select)[^>]*name=["\']bank_name["\'][^>]*>.*?</select>|<input[^>]*name=["\']bank_name["\'][^>]*>',
        bank_select,
        "bank selector"
    )


# ------------------------------------------------------------
# CURRENCY SELECT
# ------------------------------------------------------------

currency_options = ['<option value="">Select currency</option>']

for code, name in CURRENCIES:
    currency_options.append(
        f'<option value="{code}">{code} — {name}</option>'
    )

currency_select = """
<select
    name="currency"
    id="internationalCurrency"
    class="quick-select-hidden"
    required
>
    %s
</select>

<div class="search-select-wrapper">
    <input
        type="text"
        id="currencySearch"
        class="transfer-search-input"
        placeholder="Search currency..."
        autocomplete="off"
    >
    <div
        id="currencySearchResults"
        class="transfer-search-results"
    ></div>
</div>
""" % "\n        ".join(currency_options)


international_html = replace_file_section(
    international_html,
    r'<select[^>]*name=["\']currency["\'][^>]*>.*?</select>',
    currency_select,
    "international currency selector"
)


# ------------------------------------------------------------
# SEARCH JAVASCRIPT
# ------------------------------------------------------------

script_marker = "FAIRMONT_TRANSFER_SEARCH_REPAIR_V2"

search_js = f"""
<script id="{script_marker}">
(function () {{
    "use strict";

    const countryBanks = {COUNTRY_BANKS!r};

    const countrySelect =
        document.getElementById("internationalCountry");

    const countrySearch =
        document.getElementById("countrySearch");

    const countryResults =
        document.getElementById("countrySearchResults");

    const bankSelect =
        document.getElementById("internationalBank");

    const bankSearch =
        document.getElementById("internationalBankSearch");

    const bankResults =
        document.getElementById("internationalBankSearchResults");

    const currencySelect =
        document.getElementById("internationalCurrency");

    const currencySearch =
        document.getElementById("currencySearch");

    const currencyResults =
        document.getElementById("currencySearchResults");


    function hideResults(element) {{
        if (element) {{
            element.style.display = "none";
        }}
    }}


    function showResults(element) {{
        if (element) {{
            element.style.display = "block";
        }}
    }}


    function buildResults(
        input,
        results,
        options,
        select,
        afterSelect
    ) {{

        if (!input || !results || !select) {{
            return;
        }}

        const query =
            input.value.trim().toLowerCase();

        results.innerHTML = "";

        const filtered = options.filter(function (item) {{
            return item.label
                .toLowerCase()
                .includes(query)
            ||
            item.value
                .toLowerCase()
                .includes(query);
        }});

        if (!filtered.length) {{
            const empty =
                document.createElement("div");

            empty.className =
                "transfer-search-empty";

            empty.textContent =
                "No matching results";

            results.appendChild(empty);

            showResults(results);
            return;
        }}

        filtered.slice(0, 15).forEach(function (item) {{

            const button =
                document.createElement("button");

            button.type = "button";

            button.className =
                "transfer-search-option";

            button.textContent =
                item.label;

            button.addEventListener(
                "click",
                function () {{

                    select.value =
                        item.value;

                    input.value =
                        item.label;

                    hideResults(results);

                    if (afterSelect) {{
                        afterSelect(item);
                    }}

                    select.dispatchEvent(
                        new Event(
                            "change",
                            {{ bubbles: true }}
                        )
                    );
                }}
            );

            results.appendChild(button);
        }});

        showResults(results);
    }}


    /*
        COUNTRY
    */

    const countryOptions =
        Object.keys(countryBanks)
        .sort()
        .map(function (country) {{
            return {{
                value: country,
                label: country
            }};
        }});


    if (
        countrySearch &&
        countryResults &&
        countrySelect
    ) {{

        countrySearch.addEventListener(
            "focus",
            function () {{
                buildResults(
                    countrySearch,
                    countryResults,
                    countryOptions,
                    countrySelect
                );
            }}
        );

        countrySearch.addEventListener(
            "input",
            function () {{
                buildResults(
                    countrySearch,
                    countryResults,
                    countryOptions,
                    countrySelect
                );
            }}
        );
    }}


    /*
        COUNTRY -> BANK
    */

    function updateBanks(country) {{

        if (!bankSelect || !bankSearch) {{
            return;
        }}

        bankSelect.innerHTML =
            '<option value="">Select bank</option>';

        bankSelect.value = "";

        bankSearch.value = "";

        if (!country || !countryBanks[country]) {{

            bankSelect.disabled = true;

            bankSearch.disabled = true;

            bankSearch.placeholder =
                "Select country first...";

            if (bankResults) {{
                bankResults.innerHTML = "";
                hideResults(bankResults);
            }}

            return;
        }}


        countryBanks[country]
            .forEach(function (bank) {{

                const option =
                    document.createElement("option");

                option.value = bank;

                option.textContent = bank;

                bankSelect.appendChild(option);
            }});


        bankSelect.disabled = false;

        bankSearch.disabled = false;

        bankSearch.placeholder =
            "Search bank...";
    }}


    if (countrySelect) {{

        countrySelect.addEventListener(
            "change",
            function () {{
                updateBanks(this.value);
            }}
        );
    }}


    /*
        BANK SEARCH
    */

    function getBankOptions() {{

        if (!bankSelect) {{
            return [];
        }}

        return Array.from(
            bankSelect.options
        )
        .filter(function (option) {{
            return option.value;
        }})
        .map(function (option) {{
            return {{
                value: option.value,
                label: option.textContent.trim()
            }};
        }});
    }}


    if (
        bankSearch &&
        bankResults &&
        bankSelect
    ) {{

        bankSearch.addEventListener(
            "focus",
            function () {{

                if (bankSelect.disabled) {{
                    return;
                }}

                buildResults(
                    bankSearch,
                    bankResults,
                    getBankOptions(),
                    bankSelect
                );
            }}
        );

        bankSearch.addEventListener(
            "input",
            function () {{

                if (bankSelect.disabled) {{
                    return;
                }}

                buildResults(
                    bankSearch,
                    bankResults,
                    getBankOptions(),
                    bankSelect
                );
            }}
        );
    }}


    /*
        CURRENCY SEARCH
    */

    function getCurrencyOptions() {{

        if (!currencySelect) {{
            return [];
        }}

        return Array.from(
            currencySelect.options
        )
        .filter(function (option) {{
            return option.value;
        }})
        .map(function (option) {{
            return {{
                value: option.value,
                label: option.textContent.trim()
            }};
        }});
    }}


    if (
        currencySearch &&
        currencyResults &&
        currencySelect
    ) {{

        currencySearch.addEventListener(
            "focus",
            function () {{
                buildResults(
                    currencySearch,
                    currencyResults,
                    getCurrencyOptions(),
                    currencySelect
                );
            }}
        );

        currencySearch.addEventListener(
            "input",
            function () {{
                buildResults(
                    currencySearch,
                    currencyResults,
                    getCurrencyOptions(),
                    currencySelect
                );
            }}
        );
    }}


    /*
        CLOSE SEARCH MENUS WHEN CLICKING OUTSIDE
    */

    document.addEventListener(
        "click",
        function (event) {{

            if (
                !event.target.closest(
                    ".search-select-wrapper"
                )
            ) {{
                hideResults(countryResults);
                hideResults(bankResults);
                hideResults(currencyResults);
            }}
        }}
    );

}})();
</script>
"""


# Remove old repair script if present
international_html = re.sub(
    r'<script id="FAIRMONT_TRANSFER_SEARCH_REPAIR_V2">.*?</script>',
    '',
    international_html,
    flags=re.DOTALL | re.IGNORECASE
)


# Insert the new script before </body>
if re.search(r'</body>', international_html, re.IGNORECASE):

    international_html = re.sub(
        r'</body>',
        search_js + "\n</body>",
        international_html,
        count=1,
        flags=re.IGNORECASE
    )

else:
    international_html += search_js


INTERNATIONAL.write_text(
    international_html,
    encoding="utf-8"
)


# ============================================================
# UK SEND MONEY
# ============================================================

send_html = SEND_MONEY.read_text(encoding="utf-8")


uk_bank_select = """
<select
    name="bank_name"
    id="ukBank"
    class="quick-select-hidden"
    required
>
    <option value="">Select bank</option>
    {% for bank in banks %}
    <option value="{{ bank.name }}">
        {{ bank.name }}
    </option>
    {% endfor %}
</select>

<div class="search-select-wrapper">
    <input
        type="text"
        id="ukBankSearch"
        class="transfer-search-input"
        placeholder="Search UK bank..."
        autocomplete="off"
    >

    <div
        id="ukBankSearchResults"
        class="transfer-search-results"
    ></div>
</div>
"""


send_html = replace_file_section(
    send_html,
    r'<select[^>]*name=["\']bank_name["\'][^>]*>.*?</select>',
    uk_bank_select,
    "UK bank selector"
)


# Add UK bank search script
uk_js = r'''
<script id="FAIRMONT_UK_BANK_SEARCH_V2">
(function () {
    "use strict";

    const select =
        document.getElementById("ukBank");

    const input =
        document.getElementById("ukBankSearch");

    const results =
        document.getElementById("ukBankSearchResults");

    if (!select || !input || !results) {
        return;
    }

    function getBanks() {
        return Array.from(select.options)
            .filter(function (option) {
                return option.value;
            })
            .map(function (option) {
                return {
                    value: option.value,
                    label: option.textContent.trim()
                };
            });
    }

    function render() {

        const query =
            input.value.trim().toLowerCase();

        results.innerHTML = "";

        const banks =
            getBanks().filter(function (bank) {

                return bank.label
                    .toLowerCase()
                    .includes(query)
                    ||
                    bank.value
                    .toLowerCase()
                    .includes(query);
            });

        if (!banks.length) {

            const empty =
                document.createElement("div");

            empty.className =
                "transfer-search-empty";

            empty.textContent =
                "No matching banks found";

            results.appendChild(empty);

            results.style.display = "block";

            return;
        }

        banks.slice(0, 15).forEach(function (bank) {

            const button =
                document.createElement("button");

            button.type = "button";

            button.className =
                "transfer-search-option";

            button.textContent =
                bank.label;

            button.addEventListener(
                "click",
                function () {

                    select.value =
                        bank.value;

                    input.value =
                        bank.label;

                    results.style.display =
                        "none";

                    select.dispatchEvent(
                        new Event(
                            "change",
                            { bubbles: true }
                        )
                    );
                }
            );

            results.appendChild(button);
        });

        results.style.display = "block";
    }


    input.addEventListener(
        "focus",
        render
    );

    input.addEventListener(
        "input",
        render
    );


    document.addEventListener(
        "click",
        function (event) {

            if (
                !event.target.closest(
                    ".search-select-wrapper"
                )
            ) {
                results.style.display =
                    "none";
            }
        }
    );

})();
</script>
'''


send_html = re.sub(
    r'<script id="FAIRMONT_UK_BANK_SEARCH_V2">.*?</script>',
    '',
    send_html,
    flags=re.DOTALL | re.IGNORECASE
)


if re.search(r'</body>', send_html, re.IGNORECASE):

    send_html = re.sub(
        r'</body>',
        uk_js + "\n</body>",
        send_html,
        count=1,
        flags=re.IGNORECASE
    )

else:
    send_html += uk_js


SEND_MONEY.write_text(
    send_html,
    encoding="utf-8"
)


# ============================================================
# CSS
# ============================================================

quick_css = r'''
/* =========================================================
   Fairmont Bank - Transfer Search Controls
   ========================================================= */

.quick-select-hidden {
    position: absolute !important;
    width: 1px !important;
    height: 1px !important;
    opacity: 0 !important;
    pointer-events: none !important;
}

.search-select-wrapper {
    position: relative;
    width: 100%;
}

.transfer-search-input {
    width: 100%;
    box-sizing: border-box;
    min-height: 48px;
    padding: 13px 15px;
    border-radius: 12px;
    border: 1px solid rgba(255,255,255,0.12);
    background: rgba(255,255,255,0.055);
    color: inherit;
    font: inherit;
    outline: none;
}

.transfer-search-input:focus {
    border-color: rgba(255,255,255,0.30);
    background: rgba(255,255,255,0.075);
}

.transfer-search-input::placeholder {
    color: rgba(255,255,255,0.52);
}

.transfer-search-input:disabled {
    opacity: 0.48;
    cursor: not-allowed;
}

.transfer-search-results {
    position: absolute;
    left: 0;
    right: 0;
    top: calc(100% + 5px);
    z-index: 5000;
    display: none;
    max-height: 260px;
    overflow-y: auto;
    padding: 6px;
    border-radius: 14px;
    background: rgba(12, 24, 45, 0.98);
    border: 1px solid rgba(255,255,255,0.13);
    box-shadow: 0 18px 45px rgba(0,0,0,0.40);
    backdrop-filter: blur(18px);
}

.transfer-search-option {
    display: block;
    width: 100%;
    padding: 12px 13px;
    margin: 2px 0;
    border: 0;
    border-radius: 10px;
    background: transparent;
    color: inherit;
    text-align: left;
    font: inherit;
    cursor: pointer;
}

.transfer-search-option:hover,
.transfer-search-option:focus {
    background: rgba(255,255,255,0.09);
    outline: none;
}

.transfer-search-empty {
    padding: 13px;
    text-align: center;
    opacity: 0.60;
}
'''


existing_css = ""

if TRANSFER_CSS.exists():
    existing_css = TRANSFER_CSS.read_text(
        encoding="utf-8"
    )


css_marker = "Fairmont Bank - Transfer Search Controls"

if css_marker not in existing_css:

    TRANSFER_CSS.write_text(
        existing_css
        + "\n\n"
        + quick_css,
        encoding="utf-8"
    )

    print("Updated: transfer.css")


# ============================================================
# DONE
# ============================================================

print()
print("=" * 65)
print("TRANSFER SEARCH REPAIR COMPLETED")
print("=" * 65)
print()
print("International Transfer:")
print("  ✓ Country search")
print("  ✓ Country-specific bank search")
print("  ✓ Currency search")
print()
print("UK Send Money:")
print("  ✓ UK bank search")
print()
print("Existing database: NOT MODIFIED")
print("Existing customer: NOT MODIFIED")
print("Dashboard: NOT MODIFIED")
print()
print("Backups were created before modification.")
print()