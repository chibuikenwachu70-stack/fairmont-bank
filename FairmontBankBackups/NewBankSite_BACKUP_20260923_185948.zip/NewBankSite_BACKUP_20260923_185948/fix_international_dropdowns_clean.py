from pathlib import Path
from datetime import datetime
import re

BASE = Path(__file__).resolve().parent
FILE = BASE / "templates" / "international_transfer.html"

if not FILE.exists():
    print("ERROR: international_transfer.html was not found.")
    raise SystemExit(1)

html = FILE.read_text(encoding="utf-8")

# ------------------------------------------------------------
# BACKUP
# ------------------------------------------------------------

stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = FILE.with_name(
    f"international_transfer_before_clean_{stamp}.html"
)
backup.write_text(html, encoding="utf-8")

print("Backup created:", backup.name)


# ------------------------------------------------------------
# CLEAN FIELD REPLACEMENTS
# ------------------------------------------------------------

COUNTRY_FIELD = r'''
<div class="field fairmont-final-field">

    <label>Destination Country</label>

    <select
        id="internationalCountry"
        name="country"
        class="fairmont-final-real-select"
        required
    >
        <option value="">Select country</option>
    </select>

    <button
        type="button"
        class="fairmont-final-trigger"
        data-final-picker="country"
        aria-expanded="false"
    >
        <span class="fairmont-final-value">Select country</span>
        <span class="fairmont-final-arrow">▾</span>
    </button>

</div>
'''


BANK_FIELD = r'''
<div class="field fairmont-final-field">

    <label>Bank Name</label>

    <select
        id="internationalBank"
        name="bank_name"
        class="fairmont-final-real-select"
        required
    >
        <option value="">Select a bank</option>
    </select>

    <button
        type="button"
        class="fairmont-final-trigger"
        data-final-picker="bank"
        aria-expanded="false"
    >
        <span class="fairmont-final-value">Select a bank</span>
        <span class="fairmont-final-arrow">▾</span>
    </button>

</div>
'''


CURRENCY_FIELD = r'''
<div class="field fairmont-final-field">

    <label>Currency</label>

    <select
        id="internationalCurrency"
        name="currency"
        class="fairmont-final-real-select"
        required
    >
        <option value="">Select currency</option>
        <option value="GBP">GBP — Pound Sterling</option>
        <option value="EUR">EUR — Euro</option>
        <option value="USD">USD — US Dollar</option>
        <option value="CAD">CAD — Canadian Dollar</option>
        <option value="AUD">AUD — Australian Dollar</option>
        <option value="NZD">NZD — New Zealand Dollar</option>
        <option value="CHF">CHF — Swiss Franc</option>
        <option value="JPY">JPY — Japanese Yen</option>
        <option value="CNY">CNY — Chinese Yuan</option>
        <option value="HKD">HKD — Hong Kong Dollar</option>
        <option value="SGD">SGD — Singapore Dollar</option>
        <option value="INR">INR — Indian Rupee</option>
        <option value="AED">AED — UAE Dirham</option>
        <option value="SAR">SAR — Saudi Riyal</option>
        <option value="QAR">QAR — Qatari Riyal</option>
        <option value="ZAR">ZAR — South African Rand</option>
        <option value="KES">KES — Kenyan Shilling</option>
        <option value="NGN">NGN — Nigerian Naira</option>
        <option value="GHS">GHS — Ghanaian Cedi</option>
        <option value="TZS">TZS — Tanzanian Shilling</option>
        <option value="UGX">UGX — Ugandan Shilling</option>
        <option value="RWF">RWF — Rwandan Franc</option>
        <option value="BRL">BRL — Brazilian Real</option>
        <option value="MXN">MXN — Mexican Peso</option>
        <option value="ARS">ARS — Argentine Peso</option>
        <option value="SRD">SRD — Surinamese Dollar</option>
        <option value="THB">THB — Thai Baht</option>
        <option value="MYR">MYR — Malaysian Ringgit</option>
        <option value="IDR">IDR — Indonesian Rupiah</option>
        <option value="KRW">KRW — South Korean Won</option>
        <option value="TRY">TRY — Turkish Lira</option>
        <option value="PLN">PLN — Polish Zloty</option>
        <option value="SEK">SEK — Swedish Krona</option>
        <option value="NOK">NOK — Norwegian Krone</option>
        <option value="DKK">DKK — Danish Krone</option>
        <option value="CZK">CZK — Czech Koruna</option>
        <option value="HUF">HUF — Hungarian Forint</option>
        <option value="RON">RON — Romanian Leu</option>
        <option value="ILS">ILS — Israeli New Shekel</option>
    </select>

    <button
        type="button"
        class="fairmont-final-trigger"
        data-final-picker="currency"
        aria-expanded="false"
    >
        <span class="fairmont-final-value">Select currency</span>
        <span class="fairmont-final-arrow">▾</span>
    </button>

</div>
'''


# ------------------------------------------------------------
# FIND AND REPLACE WHOLE FIELDS
# ------------------------------------------------------------

def replace_field_by_label(source, label_text, replacement, next_label=None):
    pattern = (
        r'<div\s+class="field"[^>]*>\s*'
        r'<label>\s*'
        + re.escape(label_text)
        + r'.*?'
        r'</div>'
    )

    match = re.search(
        pattern,
        source,
        flags=re.IGNORECASE | re.DOTALL
    )

    if not match:
        print("Could not locate field:", label_text)
        return source

    return source[:match.start()] + replacement + source[match.end():]


# Because some old fields contain nested divs, use a safer
# boundary based on the next field label.

def replace_named_field(source, label_pattern, replacement, next_marker):
    start_pattern = (
        r'<div\s+class="field"[^>]*>\s*'
        r'<label[^>]*>\s*'
        + label_pattern
        + r'.*?</label>'
    )

    start = re.search(
        start_pattern,
        source,
        flags=re.IGNORECASE | re.DOTALL
    )

    if not start:
        print("Could not locate:", label_pattern)
        return source

    next_pos = source.find(next_marker, start.end())

    if next_pos == -1:
        print("Could not find next field boundary for:", label_pattern)
        return source

    # Include everything until immediately before next field.
    field_start = start.start()

    # Find the <div class="field"> that begins the next field.
    next_field = source.rfind(
        '<div class="field"',
        start.end(),
        next_pos + 1
    )

    if next_field == -1:
        next_field = next_pos

    return (
        source[:field_start]
        + replacement.rstrip()
        + "\n\n"
        + source[next_field:]
    )


# Destination Country ends before Beneficiary Name.
country_pattern = r'Destination\s+Country'
country_start = re.search(
    r'<div\s+class="field"[^>]*>\s*<label>\s*Destination\s+Country\s*</label>',
    html,
    flags=re.IGNORECASE | re.DOTALL
)

if country_start:
    boundary = re.search(
        r'<div\s+class="field"[^>]*>\s*<label>\s*Beneficiary\s+Name',
        html[country_start.start():],
        flags=re.IGNORECASE | re.DOTALL
    )

    if boundary:
        end = country_start.start() + boundary.start()
        html = (
            html[:country_start.start()]
            + COUNTRY_FIELD
            + "\n\n"
            + html[end:]
        )
else:
    print("WARNING: Destination Country field not found.")


# Bank Name ends before Account Number.
bank_start = re.search(
    r'<div\s+class="field"[^>]*>\s*<label>\s*Bank\s+Name\s*</label>',
    html,
    flags=re.IGNORECASE | re.DOTALL
)

if bank_start:
    boundary = re.search(
        r'<div\s+class="field"[^>]*>\s*<label>\s*Account\s+Number',
        html[bank_start.start():],
        flags=re.IGNORECASE | re.DOTALL
    )

    if boundary:
        end = bank_start.start() + boundary.start()
        html = (
            html[:bank_start.start()]
            + BANK_FIELD
            + "\n\n"
            + html[end:]
        )
else:
    print("WARNING: Bank Name field not found.")


# Currency ends before Amount.
currency_start = re.search(
    r'<div\s+class="field"[^>]*>\s*<label>\s*Currency\s*</label>',
    html,
    flags=re.IGNORECASE | re.DOTALL
)

if currency_start:
    boundary = re.search(
        r'<div\s+class="field"[^>]*>\s*<label>\s*Amount',
        html[currency_start.start():],
        flags=re.IGNORECASE | re.DOTALL
    )

    if boundary:
        end = currency_start.start() + boundary.start()
        html = (
            html[:currency_start.start()]
            + CURRENCY_FIELD
            + "\n\n"
            + html[end:]
        )
else:
    print("WARNING: Currency field not found.")


# ------------------------------------------------------------
# REMOVE OLD PICKER POPUPS / OLD SEARCH UI
# ------------------------------------------------------------

html = re.sub(
    r'<div[^>]*class=["\'][^"\']*(?:quick-search-select|search-select-wrapper)[^"\']*["\'][^>]*>.*?</div>',
    '',
    html,
    flags=re.IGNORECASE | re.DOTALL
)

# Remove old search result containers.
html = re.sub(
    r'<div[^>]*class=["\'][^"\']*(?:quick-search-results|transfer-search-results)[^"\']*["\'][^>]*>.*?</div>',
    '',
    html,
    flags=re.IGNORECASE | re.DOTALL
)


# ------------------------------------------------------------
# FINAL CSS
# ------------------------------------------------------------

css = r'''
<style id="fairmont-final-dropdown-css">

.fairmont-final-real-select {
    display: none !important;
}

.fairmont-final-field {
    position: relative;
}

.fairmont-final-trigger {
    width: 100%;
    min-height: 52px;
    border: 1px solid rgba(255,255,255,.14);
    border-radius: 14px;
    background: rgba(255,255,255,.055);
    color: rgba(255,255,255,.72);
    padding: 0 46px 0 16px;
    font-size: 15px;
    text-align: left;
    cursor: pointer;
    position: relative;
    box-sizing: border-box;
}

.fairmont-final-trigger.selected {
    color: #ffffff;
}

.fairmont-final-arrow {
    position: absolute;
    right: 17px;
    top: 50%;
    transform: translateY(-50%);
    opacity: .75;
}

.fairmont-final-popup {
    position: fixed;
    z-index: 2147483647;
    width: min(430px, calc(100vw - 28px));
    max-height: min(500px, calc(100vh - 28px));
    background: #111b30;
    border: 1px solid rgba(255,255,255,.16);
    border-radius: 16px;
    box-shadow: 0 22px 70px rgba(0,0,0,.60);
    overflow: hidden;
}

.fairmont-final-search {
    display: block;
    width: calc(100% - 24px);
    height: 44px;
    margin: 12px;
    padding: 0 13px;
    box-sizing: border-box;
    border: 1px solid rgba(255,255,255,.16);
    border-radius: 11px;
    background: rgba(255,255,255,.07);
    color: #ffffff;
    outline: none;
    font-size: 14px;
}

.fairmont-final-search::placeholder {
    color: rgba(255,255,255,.50);
}

.fairmont-final-options {
    max-height: 400px;
    overflow-y: auto;
    padding: 6px;
}

.fairmont-final-option {
    display: block;
    width: 100%;
    border: 0;
    background: transparent;
    color: #ffffff;
    padding: 12px 13px;
    border-radius: 10px;
    text-align: left;
    cursor: pointer;
    font-size: 14px;
}

.fairmont-final-option:hover {
    background: rgba(255,255,255,.09);
}

.fairmont-final-empty {
    padding: 20px;
    color: rgba(255,255,255,.5);
    text-align: center;
    font-size: 14px;
}

</style>
'''


# Remove previous final CSS if present.
html = re.sub(
    r'<style[^>]*id=["\']fairmont-final-dropdown-css["\'][^>]*>.*?</style>',
    '',
    html,
    flags=re.IGNORECASE | re.DOTALL
)

head = re.search(r'</head>', html, flags=re.IGNORECASE)

if head:
    html = html[:head.start()] + css + "\n" + html[head.start():]
else:
    html = css + html


# ------------------------------------------------------------
# FINAL JAVASCRIPT
# ------------------------------------------------------------

javascript = r'''
<script id="fairmont-final-dropdown-js">

(function () {

    "use strict";

    const countries = [
        "Afghanistan","Albania","Algeria","Andorra","Angola",
        "Antigua and Barbuda","Argentina","Armenia","Australia",
        "Austria","Azerbaijan","Bahamas","Bahrain","Bangladesh",
        "Barbados","Belarus","Belgium","Belize","Benin","Bhutan",
        "Bolivia","Bosnia and Herzegovina","Botswana","Brazil",
        "Brunei","Bulgaria","Burkina Faso","Burundi","Cambodia",
        "Cameroon","Canada","Cape Verde","Central African Republic",
        "Chad","Chile","China","Colombia","Comoros","Costa Rica",
        "Croatia","Cuba","Cyprus","Czech Republic","Denmark",
        "Djibouti","Dominica","Dominican Republic","Ecuador","Egypt",
        "El Salvador","Equatorial Guinea","Eritrea","Estonia",
        "Eswatini","Ethiopia","Fiji","Finland","France","Gabon",
        "Gambia","Georgia","Germany","Ghana","Greece","Grenada",
        "Guatemala","Guinea","Guinea-Bissau","Guyana","Haiti",
        "Honduras","Hungary","Iceland","India","Indonesia","Iran",
        "Iraq","Ireland","Israel","Italy","Jamaica","Japan",
        "Jordan","Kazakhstan","Kenya","Kiribati","Kuwait",
        "Kyrgyzstan","Laos","Latvia","Lebanon","Lesotho","Liberia",
        "Libya","Liechtenstein","Lithuania","Luxembourg","Madagascar",
        "Malawi","Malaysia","Maldives","Mali","Malta","Marshall Islands",
        "Mauritania","Mauritius","Mexico","Micronesia","Moldova",
        "Monaco","Mongolia","Montenegro","Morocco","Mozambique",
        "Myanmar","Namibia","Nauru","Nepal","Netherlands","New Zealand",
        "Nicaragua","Niger","Nigeria","North Korea","North Macedonia",
        "Norway","Oman","Pakistan","Palau","Panama","Papua New Guinea",
        "Paraguay","Peru","Philippines","Poland","Portugal","Qatar",
        "Romania","Russia","Rwanda","Saint Kitts and Nevis",
        "Saint Lucia","Saint Vincent and the Grenadines","Samoa",
        "San Marino","Sao Tome and Principe","Saudi Arabia","Senegal",
        "Serbia","Seychelles","Sierra Leone","Singapore","Slovakia",
        "Slovenia","Solomon Islands","Somalia","South Africa",
        "South Korea","South Sudan","Spain","Sri Lanka","Sudan",
        "Suriname","Sweden","Switzerland","Syria","Taiwan","Tajikistan",
        "Tanzania","Thailand","Timor-Leste","Togo","Tonga",
        "Trinidad and Tobago","Tunisia","Turkey","Turkmenistan",
        "Tuvalu","Uganda","Ukraine","United Arab Emirates",
        "United Kingdom","United States","Uruguay","Uzbekistan",
        "Vanuatu","Vatican City","Venezuela","Vietnam","Yemen",
        "Zambia","Zimbabwe"
    ];

    const banks = {
        "United Kingdom": [
            "Allied Irish Bank (GB)","Bank of Ireland UK","Bank of Scotland",
            "Barclays Bank","Birmingham Bank","Card One Money","Cashplus Bank",
            "Chase UK","Citibank UK","ClearBank","C. Hoare & Co.",
            "Co-operative Bank","Coutts","Danske Bank","First Direct",
            "Halifax","Handelsbanken UK","HSBC UK","Investec Bank",
            "Lloyds Bank","Metro Bank","Monzo Bank",
            "Nationwide Building Society","NatWest","Revolut",
            "Royal Bank of Scotland","Santander UK","Skipton Building Society",
            "Starling Bank","TSB Bank","Ulster Bank","Virgin Money",
            "Yorkshire Building Society","Zopa Bank",
            "Other UK Bank or Building Society"
        ],

        "United States": [
            "JPMorgan Chase Bank","Bank of America","Wells Fargo Bank",
            "Citibank","U.S. Bank","PNC Bank","Truist Bank",
            "Capital One","TD Bank","Charles Schwab Bank"
        ],

        "Canada": [
            "Royal Bank of Canada","Toronto-Dominion Bank","Bank of Montreal",
            "Bank of Nova Scotia","Canadian Imperial Bank of Commerce",
            "National Bank of Canada","Desjardins"
        ],

        "Australia": [
            "Commonwealth Bank","Westpac","ANZ Bank",
            "National Australia Bank","Macquarie Bank","Bendigo Bank",
            "Bank of Queensland"
        ],

        "New Zealand": [
            "ANZ New Zealand","ASB Bank","Bank of New Zealand",
            "Westpac New Zealand","Kiwibank","Heartland Bank"
        ],

        "Germany": [
            "Deutsche Bank","Commerzbank","DZ Bank","KfW",
            "ING Germany","N26","DKB"
        ],

        "France": [
            "BNP Paribas","Crédit Agricole","Société Générale",
            "BPCE","Crédit Mutuel","La Banque Postale"
        ],

        "Netherlands": [
            "ING Bank","ABN AMRO","Rabobank","de Volksbank","Triodos Bank"
        ],

        "Ireland": [
            "AIB","Bank of Ireland","Permanent TSB",
            "Ulster Bank","EBS","Avant Money"
        ],

        "Switzerland": [
            "UBS","Zürcher Kantonalbank","Banque Cantonale Vaudoise",
            "Raiffeisen Switzerland","PostFinance","Julius Baer"
        ],

        "India": [
            "State Bank of India","HDFC Bank","ICICI Bank",
            "Axis Bank","Kotak Mahindra Bank","IndusInd Bank"
        ],

        "China": [
            "Industrial and Commercial Bank of China",
            "China Construction Bank","Bank of China",
            "Agricultural Bank of China","Bank of Communications"
        ],

        "Japan": [
            "MUFG Bank",
            "Sumitomo Mitsui Banking Corporation",
            "Mizuho Bank","Resona Bank","SBI Shinsei Bank","Aozora Bank"
        ],

        "Singapore": [
            "DBS Bank","OCBC Bank","United Overseas Bank"
        ],

        "South Africa": [
            "Standard Bank","First National Bank","Absa Bank",
            "Nedbank","Capitec Bank"
        ],

        "Kenya": [
            "KCB Bank Kenya","Equity Bank Kenya",
            "Co-operative Bank of Kenya","Absa Bank Kenya",
            "NCBA Bank Kenya","Standard Chartered Bank Kenya",
            "Stanbic Bank Kenya","I&M Bank","DTB Kenya"
        ],

        "Nigeria": [
            "Access Bank","Guaranty Trust Bank","Zenith Bank",
            "First Bank of Nigeria","United Bank for Africa",
            "Fidelity Bank","Stanbic IBTC Bank"
        ],

        "Ghana": [
            "GCB Bank","Ecobank Ghana","Absa Bank Ghana",
            "Standard Chartered Bank Ghana","Stanbic Bank Ghana",
            "Fidelity Bank Ghana"
        ],

        "United Arab Emirates": [
            "Emirates NBD","First Abu Dhabi Bank",
            "Abu Dhabi Commercial Bank","Mashreq Bank",
            "Dubai Islamic Bank"
        ],

        "Saudi Arabia": [
            "Saudi National Bank","Al Rajhi Bank",
            "Riyad Bank","Alinma Bank","Bank Albilad"
        ],

        "Qatar": [
            "Qatar National Bank","Qatar Islamic Bank",
            "Doha Bank","Commercial Bank"
        ],

        "Suriname": [
            "De Surinaamsche Bank",
            "Republic Bank Suriname",
            "Hakrinbank",
            "Surinaamse Volkscredietbank",
            "Finabank",
            "Surichange Bank",
            "GODO",
            "Trustbank Amanah",
            "Postspaarbank"
        ],

        "Brazil": [
            "Banco do Brasil","Itaú Unibanco","Bradesco",
            "Caixa Econômica Federal","Santander Brasil"
        ],

        "Mexico": [
            "BBVA México","Banorte","Santander México",
            "Citibanamex","HSBC México","Scotiabank México"
        ]
    };

    let popup = null;

    function closePopup() {
        if (popup) {
            popup.remove();
            popup = null;
        }

        document
            .querySelectorAll(".fairmont-final-trigger")
            .forEach(function (button) {
                button.setAttribute("aria-expanded", "false");
            });
    }

    function optionsFor(type) {

        if (type === "country") {
            return countries.map(function (country) {
                return {
                    value: country,
                    label: country
                };
            });
        }

        if (type === "bank") {

            const country =
                document.getElementById("internationalCountry").value;

            return (banks[country] || []).map(function (bank) {
                return {
                    value: bank,
                    label: bank
                };
            });
        }

        const currency =
            document.getElementById("internationalCurrency");

        return Array.from(currency.options)
            .filter(function (option) {
                return option.value !== "";
            })
            .map(function (option) {
                return {
                    value: option.value,
                    label: option.textContent
                };
            });
    }

    function openPopup(type, trigger, select) {

        closePopup();

        popup = document.createElement("div");
        popup.className = "fairmont-final-popup";

        const search = document.createElement("input");
        search.type = "search";
        search.className = "fairmont-final-search";
        search.autocomplete = "off";

        if (type === "country") {
            search.placeholder = "Search country...";
        } else if (type === "bank") {
            search.placeholder = "Search bank...";
        } else {
            search.placeholder = "Search currency...";
        }

        const list = document.createElement("div");
        list.className = "fairmont-final-options";

        popup.appendChild(search);
        popup.appendChild(list);

        document.body.appendChild(popup);

        const rect = trigger.getBoundingClientRect();

        let left = rect.left;
        let top = rect.bottom + 8;

        const width = Math.min(
            430,
            window.innerWidth - 28
        );

        if (left + width > window.innerWidth - 14) {
            left = window.innerWidth - width - 14;
        }

        if (left < 14) {
            left = 14;
        }

        popup.style.width = width + "px";

        const popupHeight = Math.min(
            500,
            window.innerHeight - 28
        );

        if (top + popupHeight > window.innerHeight - 14) {
            top = rect.top - popupHeight - 8;
        }

        if (top < 14) {
            top = 14;
        }

        popup.style.left = left + "px";
        popup.style.top = top + "px";

        function render() {

            const query =
                search.value.trim().toLowerCase();

            list.innerHTML = "";

            const filtered =
                optionsFor(type).filter(function (item) {
                    return item.label
                        .toLowerCase()
                        .includes(query);
                });

            if (!filtered.length) {
                const empty = document.createElement("div");
                empty.className = "fairmont-final-empty";
                empty.textContent = "No matches found";
                list.appendChild(empty);
                return;
            }

            filtered.forEach(function (item) {

                const option =
                    document.createElement("button");

                option.type = "button";
                option.className =
                    "fairmont-final-option";

                option.textContent = item.label;

                option.addEventListener("click", function () {

                    select.value = item.value;

                    const value =
                        trigger.querySelector(
                            ".fairmont-final-value"
                        );

                    value.textContent = item.label;

                    trigger.classList.add("selected");

                    select.dispatchEvent(
                        new Event(
                            "change",
                            { bubbles: true }
                        )
                    );

                    closePopup();
                });

                list.appendChild(option);
            });
        }

        search.addEventListener("input", render);

        search.addEventListener("keydown", function (event) {
            if (event.key === "Escape") {
                closePopup();
            }
        });

        trigger.setAttribute("aria-expanded", "true");

        render();

        setTimeout(function () {
            search.focus();
        }, 20);
    }


    function setup() {

        const country =
            document.getElementById("internationalCountry");

        const bank =
            document.getElementById("internationalBank");

        const currency =
            document.getElementById("internationalCurrency");

        if (!country || !bank || !currency) {
            console.error(
                "Fairmont final dropdowns: required fields missing."
            );
            return;
        }

        // Remove any old generated UI surrounding these fields.
        document.querySelectorAll(
            ".quick-search-select, " +
            ".search-select-wrapper, " +
            ".quick-search-results, " +
            ".transfer-search-results, " +
            ".fairmont-picker"
        ).forEach(function (element) {

            if (
                element.contains(country) ||
                element.contains(bank) ||
                element.contains(currency)
            ) {
                return;
            }

            element.remove();
        });


        function populateBankSelect() {

            const current = bank.value;

            bank.innerHTML =
                '<option value="">Select a bank</option>';

            const countryName = country.value;

            (banks[countryName] || []).forEach(function (bankName) {

                const option =
                    document.createElement("option");

                option.value = bankName;
                option.textContent = bankName;

                bank.appendChild(option);
            });

            if (
                current &&
                Array.from(bank.options).some(
                    function (option) {
                        return option.value === current;
                    }
                )
            ) {
                bank.value = current;
            } else {
                bank.value = "";
            }

            updateLabel(
                bank,
                "Select a bank"
            );
        }


        function updateLabel(select, placeholder) {

            const trigger =
                document.querySelector(
                    '[data-final-picker="' +
                    (
                        select.id === "internationalCountry"
                            ? "country"
                            : select.id === "internationalBank"
                                ? "bank"
                                : "currency"
                    ) +
                    '"]'
                );

            if (!trigger) {
                return;
            }

            const value =
                trigger.querySelector(
                    ".fairmont-final-value"
                );

            const selected =
                select.options[select.selectedIndex];

            if (
                selected &&
                selected.value
            ) {
                value.textContent =
                    selected.textContent;

                trigger.classList.add("selected");
            } else {
                value.textContent =
                    placeholder;

                trigger.classList.remove("selected");
            }
        }


        // Initial bank list.
        populateBankSelect();


        country.addEventListener("change", function () {

            populateBankSelect();

        });


        country.addEventListener("change", function () {
            updateLabel(country, "Select country");
        });

        bank.addEventListener("change", function () {
            updateLabel(bank, "Select a bank");
        });

        currency.addEventListener("change", function () {
            updateLabel(currency, "Select currency");
        });


        document
            .querySelectorAll(".fairmont-final-trigger")
            .forEach(function (trigger) {

                trigger.addEventListener(
                    "click",
                    function (event) {

                        event.preventDefault();
                        event.stopPropagation();

                        const type =
                            trigger.dataset.finalPicker;

                        let select;

                        if (type === "country") {
                            select = country;
                        } else if (type === "bank") {
                            select = bank;
                        } else {
                            select = currency;
                        }

                        openPopup(
                            type,
                            trigger,
                            select
                        );
                    }
                );
            });


        updateLabel(
            country,
            "Select country"
        );

        updateLabel(
            bank,
            "Select a bank"
        );

        updateLabel(
            currency,
            "Select currency"
        );


        document.addEventListener(
            "click",
            function (event) {

                if (
                    popup &&
                    !popup.contains(event.target) &&
                    !event.target.closest(
                        ".fairmont-final-trigger"
                    )
                ) {
                    closePopup();
                }
            }
        );


        window.addEventListener(
            "resize",
            closePopup
        );

        window.addEventListener(
            "scroll",
            closePopup,
            true
        );
    }


    if (document.readyState === "loading") {
        document.addEventListener(
            "DOMContentLoaded",
            setup
        );
    } else {
        setup();
    }

})();

</script>
'''


# Remove any previous copy of our final script.
html = re.sub(
    r'<script[^>]*id=["\']fairmont-final-dropdown-js["\'][^>]*>.*?</script>',
    '',
    html,
    flags=re.IGNORECASE | re.DOTALL
)

body = re.search(r'</body>', html, flags=re.IGNORECASE)

if body:
    html = (
        html[:body.start()]
        + javascript
        + "\n"
        + html[body.start():]
    )
else:
    html += javascript


# ------------------------------------------------------------
# SAVE
# ------------------------------------------------------------

FILE.write_text(html, encoding="utf-8")

print()
print("==============================================")
print("CLEAN DROPDOWN FIX INSTALLED")
print("==============================================")
print()
print("Exactly ONE visible country bar.")
print("Search appears only inside the country dropdown.")
print()
print("Exactly ONE visible bank bar.")
print("Search appears only inside the bank dropdown.")
print("Bank list changes with selected country.")
print()
print("Exactly ONE visible currency bar.")
print("Search appears only inside the currency dropdown.")
print()
print("No permanent search bars.")
print("No duplicate Select country controls.")
print("No duplicate Select a bank controls.")
print("No duplicate Select currency controls.")
print()
print("Database was NOT changed.")
print("Dashboard was NOT changed.")
print()
print("Backup:", backup.name)
print()