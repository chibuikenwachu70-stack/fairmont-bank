from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
TEMPLATES = BASE_DIR / "templates"

TEMPLATES.mkdir(exist_ok=True)

template = r'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Create Customer Account | Fairmont Bank</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            font-family: Arial, Helvetica, sans-serif;
            background:
                radial-gradient(
                    circle at top left,
                    rgba(184,149,74,.10),
                    transparent 32%
                ),
                #071525;
            color: #edf3fb;
        }

        .page {
            width: 100%;
            max-width: 1000px;
            margin: 0 auto;
            padding: 30px 20px 60px;
        }

        .topbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            margin-bottom: 25px;
        }

        .brand {
            color: #ffffff;
            font-size: 20px;
            font-weight: 800;
            letter-spacing: 1.5px;
        }

        .brand span {
            color: #d5b467;
        }

        .back {
            color: #aebfd2;
            text-decoration: none;
            font-size: 14px;
            font-weight: 600;
        }

        .back:hover {
            color: #d5b467;
        }

        .hero {
            margin-bottom: 25px;
        }

        .hero h1 {
            margin: 0 0 8px;
            font-size: 30px;
        }

        .hero p {
            margin: 0;
            color: #8fa5bd;
            line-height: 1.6;
        }

        .card {
            background: rgba(12,31,51,.92);
            border: 1px solid rgba(184,149,74,.20);
            border-radius: 20px;
            padding: 28px;
            box-shadow: 0 25px 70px rgba(0,0,0,.28);
        }

        .notice {
            padding: 14px 16px;
            border-radius: 12px;
            background: rgba(184,149,74,.07);
            border: 1px solid rgba(184,149,74,.18);
            color: #b9c8d8;
            font-size: 13px;
            line-height: 1.55;
            margin-bottom: 25px;
        }

        .section {
            padding-bottom: 26px;
            margin-bottom: 26px;
            border-bottom: 1px solid rgba(255,255,255,.08);
        }

        .section:last-of-type {
            border-bottom: 0;
            margin-bottom: 0;
            padding-bottom: 0;
        }

        .section-title {
            margin: 0 0 18px;
            color: #ffffff;
            font-size: 17px;
        }

        .section-title span {
            color: #d5b467;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0,1fr));
            gap: 17px;
        }

        .field {
            display: flex;
            flex-direction: column;
            gap: 7px;
        }

        .field.full {
            grid-column: 1 / -1;
        }

        label {
            color: #a9bbcf;
            font-size: 13px;
            font-weight: 700;
        }

        input,
        select,
        textarea {
            width: 100%;
            border: 1px solid rgba(255,255,255,.10);
            border-radius: 11px;
            background: #091b2d;
            color: #ffffff;
            padding: 13px 14px;
            outline: none;
            font-size: 14px;
        }

        input:focus,
        select:focus,
        textarea:focus {
            border-color: rgba(213,180,103,.65);
            box-shadow: 0 0 0 3px rgba(213,180,103,.08);
        }

        select {
            cursor: pointer;
        }

        .hint {
            color: #7188a1;
            font-size: 12px;
            line-height: 1.45;
        }

        .funding-box {
            padding: 18px;
            border-radius: 14px;
            background: rgba(255,255,255,.025);
            border: 1px solid rgba(255,255,255,.07);
        }

        .funding-box .grid {
            margin-top: 15px;
        }

        .flash {
            padding: 13px 15px;
            border-radius: 11px;
            margin-bottom: 18px;
            font-size: 13px;
            line-height: 1.5;
        }

        .flash.error {
            background: rgba(190,65,65,.12);
            border: 1px solid rgba(220,90,90,.25);
            color: #ffb5b5;
        }

        .actions {
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            margin-top: 25px;
        }

        .button {
            border: 0;
            border-radius: 11px;
            padding: 14px 21px;
            background: #b8954a;
            color: #081625;
            font-size: 14px;
            font-weight: 800;
            cursor: pointer;
        }

        .button:hover {
            background: #d5b467;
        }

        .button.secondary {
            background: rgba(255,255,255,.06);
            border: 1px solid rgba(255,255,255,.10);
            color: #c8d5e3;
            text-decoration: none;
        }

        .button.secondary:hover {
            background: rgba(255,255,255,.10);
        }

        @media (max-width: 700px) {

            .grid {
                grid-template-columns: 1fr;
            }

            .field.full {
                grid-column: auto;
            }

            .topbar {
                align-items: flex-start;
                flex-direction: column;
            }

            .card {
                padding: 20px;
            }

            .actions {
                flex-direction: column;
            }

            .button {
                width: 100%;
                text-align: center;
            }
        }
    </style>
</head>

<body>

<div class="page">

    <div class="topbar">

        <div class="brand">
            FAIRMONT <span>BANK</span>
        </div>

        <a
            class="back"
            href="{{ url_for('admin_dashboard') }}"
        >
            Back to Administration
        </a>

    </div>

    <div class="hero">

        <h1>Create Customer Account</h1>

        <p>
            Create a new Fairmont Bank customer account and optionally provide
            an initial account funding amount.
        </p>

    </div>

    <div class="card">

        {% with messages = get_flashed_messages(with_categories=true) %}
            {% if messages %}
                {% for category, message in messages %}
                    <div class="flash {{ category }}">
                        {{ message }}
                    </div>
                {% endfor %}
            {% endif %}
        {% endwith %}

        <div class="notice">
            Customer ID and account number will be generated automatically.
            Existing customer records are not modified by creating a new
            account.
        </div>

        <form method="POST">

            <div class="section">

                <h2 class="section-title">
                    <span>01</span> Customer Information
                </h2>

                <div class="grid">

                    <div class="field full">

                        <label for="full_name">
                            Full Name
                        </label>

                        <input
                            type="text"
                            id="full_name"
                            name="full_name"
                            maxlength="120"
                            value="{{ form_data.get('full_name', '') }}"
                            required
                        >

                    </div>

                    <div class="field">

                        <label for="email">
                            Email Address
                        </label>

                        <input
                            type="email"
                            id="email"
                            name="email"
                            maxlength="150"
                            value="{{ form_data.get('email', '') }}"
                            required
                        >

                    </div>

                    <div class="field">

                        <label for="phone">
                            Phone Number
                        </label>

                        <input
                            type="text"
                            id="phone"
                            name="phone"
                            maxlength="40"
                            value="{{ form_data.get('phone', '') }}"
                            required
                        >

                    </div>

                    <div class="field">

                        <label for="account_type">
                            Account Type
                        </label>

                        <select
                            id="account_type"
                            name="account_type"
                            required
                        >
                            <option value="">
                                Select account type
                            </option>

                            <option
                                value="savings"
                                {% if form_data.get('account_type') == 'savings' %}selected{% endif %}
                            >
                                Savings
                            </option>

                            <option
                                value="current"
                                {% if form_data.get('account_type') == 'current' %}selected{% endif %}
                            >
                                Current
                            </option>

                        </select>

                    </div>

                    <div class="field">

                        <label for="country">
                            Country
                        </label>

                        <input
                            type="text"
                            id="country"
                            name="country"
                            maxlength="100"
                            value="{{ form_data.get('country', 'United Kingdom') }}"
                            required
                        >

                    </div>

                </div>

            </div>

            <div class="section">

                <h2 class="section-title">
                    <span>02</span> Login Credentials
                </h2>

                <div class="grid">

                    <div class="field">

                        <label for="password">
                            Initial Password
                        </label>

                        <input
                            type="password"
                            id="password"
                            name="password"
                            minlength="6"
                            required
                        >

                        <div class="hint">
                            The customer can change this password later.
                        </div>

                    </div>

                    <div class="field">

                        <label for="confirm_password">
                            Confirm Password
                        </label>

                        <input
                            type="password"
                            id="confirm_password"
                            name="confirm_password"
                            minlength="6"
                            required
                        >

                    </div>

                </div>

            </div>

            <div class="section">

                <h2 class="section-title">
                    <span>03</span> Initial Funding
                </h2>

                <div class="funding-box">

                    <div class="hint">
                        Optional. Leave the amount at 0.00 if the new account
                        should begin with no funds. If an amount is entered,
                        it will be recorded as an Account Funding credit.
                    </div>

                    <div class="grid">

                        <div class="field">

                            <label for="initial_funding">
                                Initial Funding Amount (£)
                            </label>

                            <input
                                type="number"
                                id="initial_funding"
                                name="initial_funding"
                                min="0"
                                step="0.01"
                                value="{{ form_data.get('initial_funding', '0.00') }}"
                            >

                        </div>

                        <div class="field">

                            <label for="funding_reference">
                                Funding Reference
                            </label>

                            <input
                                type="text"
                                id="funding_reference"
                                name="funding_reference"
                                maxlength="255"
                                value="{{ form_data.get('funding_reference', '') }}"
                                placeholder="Optional reference"
                            >

                        </div>

                        <div class="field full">

                            <label for="funding_description">
                                Funding Description
                            </label>

                            <input
                                type="text"
                                id="funding_description"
                                name="funding_description"
                                maxlength="255"
                                value="{{ form_data.get('funding_description', '') }}"
                                placeholder="Optional description"
                            >

                        </div>

                    </div>

                </div>

            </div>

            <div class="actions">

                <a
                    href="{{ url_for('admin_dashboard') }}"
                    class="button secondary"
                >
                    Cancel
                </a>

                <button
                    type="submit"
                    class="button"
                >
                    Create Customer Account
                </button>

            </div>

        </form>

    </div>

</div>

</body>
</html>
'''

output = TEMPLATES / "admin_create_customer.html"

output.write_text(
    template,
    encoding="utf-8"
)

print()
print("=" * 70)
print("ADMIN CUSTOMER ACCOUNT TEMPLATE CREATED")
print("=" * 70)
print()
print(output)
print()
print("The existing database and customer records were not changed.")
print()