from pathlib import Path

BASE_DIR = Path(r"C:\Users\DON J\Documents\NewBankSite")

PROFILE_FILE = BASE_DIR / "templates" / "my_profile.html"

text = PROFILE_FILE.read_text(encoding="utf-8")


old = '''<a href="/login"
                    class="profile-back-button">'''

new = '''<a href="/dashboard"
                    class="profile-back-button">'''


if old in text:

    text = text.replace(
        old,
        new,
        1
    )

    PROFILE_FILE.write_text(
        text,
        encoding="utf-8"
    )

    print("SUCCESS: Profile back arrow now points to /dashboard.")

else:

    # Handle different formatting of the same link.
    if 'class="profile-back-button"' in text:

        import re

        pattern = r'<a\s+href="/[^"]*"\s+class="profile-back-button">'

        replacement = '<a href="/dashboard" class="profile-back-button">'

        updated, count = re.subn(
            pattern,
            replacement,
            text,
            count=1
        )

        if count:

            PROFILE_FILE.write_text(
                updated,
                encoding="utf-8"
            )

            print("SUCCESS: Profile back arrow now points to /dashboard.")

        else:

            print("ERROR: Could not locate the profile back arrow.")

    else:

        print("ERROR: profile-back-button was not found.")


print()
print("Profile navigation check completed.")