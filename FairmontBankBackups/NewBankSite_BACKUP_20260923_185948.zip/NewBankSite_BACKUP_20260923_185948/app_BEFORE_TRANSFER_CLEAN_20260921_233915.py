from flask import Flask, render_template, request, session, redirect, url_for, url_for
from sqlalchemy.exc import IntegrityError
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import secrets
import string
import os
from datetime import datetime


app = Flask(__name__)

app.config["SECRET_KEY"] = "change-this-before-production"

# Keep the authenticated customer session available while
# navigating between protected customer pages.
app.config["SESSION_PERMANENT"] = True


# =========================================================
# DATABASE
# =========================================================

os.makedirs(app.instance_path, exist_ok=True)

app.config["SQLALCHEMY_DATABASE_URI"] = (
    "sqlite:///" + os.path.join(app.instance_path, "fairmont.db")
)

app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)


# =========================================================
# CUSTOMER MODEL
# =========================================================

class Customer(db.Model):

    id = db.Column(
        db.Integer,
        primary_key=True
    )

    customer_id = db.Column(
        db.String(20),
        unique=True,
        nullable=False
    )


    account_number = db.Column(
        db.String(12),
        unique=True,
        nullable=True,
        index=True
    )

    full_name = db.Column(
        db.String(120),
        nullable=False
    )

    email = db.Column(
        db.String(150),
        unique=True,
        nullable=False
    )

    phone = db.Column(
        db.String(40),
        unique=True,
        nullable=False
    )

    account_type = db.Column(
        db.String(30),
        nullable=False
    )

    country = db.Column(
        db.String(100),
        nullable=False
    )

    password_hash = db.Column(
        db.String(255),
        nullable=False
    )

    account_status = db.Column(
        db.String(30),
        nullable=False,
        default="Active"
    )

    account_balance = db.Column(
        db.Float,
        nullable=False,
        default=0.0
    )




# =========================================================
# TRANSACTION MODEL
# =========================================================

class Transaction(db.Model):

    id = db.Column(
        db.Integer,
        primary_key=True
    )

    transaction_reference = db.Column(
        db.String(40),
        unique=True,
        nullable=False
    )

    customer_id = db.Column(
        db.String(20),
        nullable=False,
        index=True
    )

    transaction_type = db.Column(
        db.String(40),
        nullable=False
    )

    direction = db.Column(
        db.String(20),
        nullable=False
    )

    amount = db.Column(
        db.Float,
        nullable=False
    )

    balance_after = db.Column(
        db.Float,
        nullable=False
    )

    description = db.Column(
        db.String(255),
        nullable=False
    )

    counterparty = db.Column(
        db.String(150),
        nullable=True
    )

    status = db.Column(
        db.String(30),
        nullable=False,
        default="Completed"
    )

    created_at = db.Column(
        db.DateTime,
        nullable=False,
        default=datetime.utcnow
    )


# =========================================================


class Bank(db.Model):

    id = db.Column(
        db.Integer,
        primary_key=True
    )

    name = db.Column(
        db.String(150),
        unique=True,
        nullable=False
    )

    country = db.Column(
        db.String(100),
        nullable=False,
        default="United Kingdom"
    )

    active = db.Column(
        db.Boolean,
        nullable=False,
        default=True
    )




class Recipient(db.Model):

    id = db.Column(
        db.Integer,
        primary_key=True
    )

    customer_id = db.Column(
        db.String(20),
        nullable=False,
        index=True
    )

    recipient_name = db.Column(
        db.String(150),
        nullable=False
    )

    bank_name = db.Column(
        db.String(150),
        nullable=False
    )

    account_number = db.Column(
        db.String(40),
        nullable=False
    )

    sort_code = db.Column(
        db.String(20),
        nullable=True
    )

    country = db.Column(
        db.String(100),
        nullable=False,
        default="United Kingdom"
    )

    currency = db.Column(
        db.String(10),
        nullable=False,
        default="GBP"
    )

    created_at = db.Column(
        db.DateTime,
        nullable=False,
        default=datetime.utcnow
    )




class ExternalTransfer(db.Model):

    id = db.Column(
        db.Integer,
        primary_key=True
    )

    transaction_reference = db.Column(
        db.String(40),
        unique=True,
        nullable=False
    )

    customer_id = db.Column(
        db.String(20),
        nullable=False,
        index=True
    )

    transfer_type = db.Column(
        db.String(30),
        nullable=False
    )

    bank_name = db.Column(
        db.String(150),
        nullable=False
    )

    recipient_name = db.Column(
        db.String(150),
        nullable=False
    )

    account_number = db.Column(
        db.String(40),
        nullable=False
    )

    sort_code = db.Column(
        db.String(20),
        nullable=True
    )

    country = db.Column(
        db.String(100),
        nullable=False
    )

    currency = db.Column(
        db.String(10),
        nullable=False
    )

    amount = db.Column(
        db.Float,
        nullable=False
    )

    fee = db.Column(
        db.Float,
        nullable=False,
        default=0.0
    )

    reference = db.Column(
        db.String(255),
        nullable=True
    )

    status = db.Column(
        db.String(30),
        nullable=False,
        default="Pending"
    )

    created_at = db.Column(
        db.DateTime,
        nullable=False,
        default=datetime.utcnow
    )


# CUSTOMER ID GENERATOR
# =========================================================

def generate_customer_id():

    while True:

        numbers = "".join(
            secrets.choice(string.digits)
            for _ in range(8)
        )

        customer_id = "FB" + numbers

        existing = Customer.query.filter_by(
            customer_id=customer_id
        ).first()

        if existing is None:

            return customer_id




# =========================================================
# TRANSACTION REFERENCE GENERATOR
# =========================================================



def generate_account_number():

    while True:

        number = "".join(
            secrets.choice(string.digits)
            for _ in range(10)
        )

        existing = Customer.query.filter_by(
            account_number=number
        ).first()

        if existing is None:
            return number


def generate_transaction_reference():

    while True:

        reference = (
            "FT"
            + datetime.utcnow().strftime("%Y%m%d%H%M%S")
            + secrets.token_hex(3).upper()
        )

        existing = Transaction.query.filter_by(
            transaction_reference=reference
        ).first()

        if existing is None:

            return reference


# =========================================================
# HOME
# =========================================================

@app.route("/")
def home():

    return render_template(
        "index.html"
    )


# =========================================================
# CUSTOMER LOGIN
# =========================================================

@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        customer_id = request.form.get(
            "customer_id",
            ""
        ).strip().upper()

        password = request.form.get(
            "password",
            ""
        )

        customer = Customer.query.filter_by(
            customer_id=customer_id
        ).first()

        if customer is None:

            return render_template(
                "login.html",
                error="Invalid Customer ID or password."
            )

        if customer.account_status != "Active":

            return render_template(
                "login.html",
                error="Your account is currently unavailable. Please contact Fairmont Bank."
            )

        if not check_password_hash(
            customer.password_hash,
            password
        ):

            return render_template(
                "login.html",
                error="Invalid Customer ID or password."
            )

        session.clear()

        session["customer_id"] = customer.customer_id

        return redirect("/dashboard")

    return render_template(
        "login.html"
    )


# =========================================================
# OPEN ACCOUNT
# =========================================================

@app.route("/open-account", methods=["GET", "POST"])
def open_account():

    if request.method == "POST":

        full_name = request.form.get(
            "full_name",
            ""
        ).strip()

        email = request.form.get(
            "email",
            ""
        ).strip().lower()

        phone = request.form.get(
            "phone",
            ""
        ).strip()

        account_type = request.form.get(
            "account_type",
            ""
        ).strip()

        country = request.form.get(
            "country",
            ""
        ).strip()

        password = request.form.get(
            "password",
            ""
        )

        terms = request.form.get(
            "terms"
        )

        if not all([
            full_name,
            email,
            phone,
            account_type,
            country,
            password
        ]):

            return (
                "Please complete all required fields.",
                400
            )

        if not terms:

            return (
                "You must accept the account terms.",
                400
            )

        existing_email = Customer.query.filter_by(
            email=email
        ).first()

        if existing_email:

            return (
                "An account with this email address already exists.",
                400
            )

        existing_phone = Customer.query.filter_by(
            phone=phone
        ).first()

        if existing_phone:

            return (
                "An account with this phone number already exists.",
                400
            )

        customer = Customer(

            customer_id=generate_customer_id(),

            account_number=generate_account_number(),

            full_name=full_name,

            email=email,

            phone=phone,

            account_type=account_type,

            country=country,

            password_hash=generate_password_hash(
                password
            ),

            account_status="Active",

            account_balance=0.0
        )

        db.session.add(customer)

        db.session.commit()

        return render_template(
            "account_created.html",
            customer=customer
        )

    return render_template(
        "open_account.html"
    )


# =========================================================
# LOGOUT
# =========================================================





# =========================================================
# TRANSACTION HISTORY
# =========================================================





@app.route("/send-money", methods=["GET", "POST"])
def send_money():

    customer_id = session.get("customer_id")

    if not customer_id:

        return render_template(
            "login.html",
            error="Please sign in to send money."
        )

    customer = Customer.query.filter_by(
        customer_id=customer_id
    ).first()

    if customer is None:

        session.clear()

        return render_template(
            "login.html",
            error="Your session could not be verified."
        )

    banks = (
        Bank.query
        .filter_by(
            country="United Kingdom",
            active=True
        )
        .order_by(Bank.name.asc())
        .all()
    )

    if request.method == "GET":

        return render_template(
            "send_money.html",
            customer=customer,
            banks=banks
        )

    transfer_type = request.form.get(
        "transfer_type",
        "uk"
    ).strip().lower()

    if transfer_type == "international":

        return redirect("/international-transfer")

    bank_name = request.form.get(
        "bank_name",
        ""
    ).strip()

    recipient_name = request.form.get(
        "recipient_name",
        ""
    ).strip()

    account_number = request.form.get(
        "account_number",
        ""
    ).strip()

    sort_code = request.form.get(
        "sort_code",
        ""
    ).strip()

    amount_text = request.form.get(
        "amount",
        ""
    ).strip()

    payment_reference = request.form.get(
        "payment_reference",
        ""
    ).strip()

    if not bank_name:

        return render_template(
            "send_money.html",
            customer=customer,
            banks=banks,
            error="Please select a bank.",
            form=request.form
        )

    if not recipient_name:

        return render_template(
            "send_money.html",
            customer=customer,
            banks=banks,
            error="Please enter the recipient's account name.",
            form=request.form
        )

    if not account_number:

        return render_template(
            "send_money.html",
            customer=customer,
            banks=banks,
            error="Please enter the recipient account number.",
            form=request.form
        )

    account_number = re.sub(
        r"\s+",
        "",
        account_number
    )

    if not account_number.isdigit():

        return render_template(
            "send_money.html",
            customer=customer,
            banks=banks,
            error="Account number must contain digits only.",
            form=request.form
        )

    if len(account_number) != 8:

        return render_template(
            "send_money.html",
            customer=customer,
            banks=banks,
            error="UK account numbers must contain 8 digits.",
            form=request.form
        )

    if not sort_code:

        return render_template(
            "send_money.html",
            customer=customer,
            banks=banks,
            error="Please enter the recipient sort code.",
            form=request.form
        )

    sort_code = re.sub(
        r"[^0-9]",
        "",
        sort_code
    )

    if len(sort_code) != 6:

        return render_template(
            "send_money.html",
            customer=customer,
            banks=banks,
            error="UK sort codes must contain 6 digits.",
            form=request.form
        )

    if not amount_text:

        return render_template(
            "send_money.html",
            customer=customer,
            banks=banks,
            error="Please enter an amount.",
            form=request.form
        )

    try:

        amount = round(
            float(amount_text),
            2
        )

    except ValueError:

        return render_template(
            "send_money.html",
            customer=customer,
            banks=banks,
            error="Please enter a valid amount.",
            form=request.form
        )

    if amount <= 0:

        return render_template(
            "send_money.html",
            customer=customer,
            banks=banks,
            error="The amount must be greater than £0.00.",
            form=request.form
        )

    balance = round(
        float(customer.account_balance or 0),
        2
    )

    if amount > balance:

        return render_template(
            "send_money.html",
            customer=customer,
            banks=banks,
            error=(
                "Insufficient available balance. "
                f"Your available balance is £{balance:,.2f}."
            ),
            form=request.form
        )

    # -----------------------------------------------------
    # Check whether this is an internal Fairmont account.
    # -----------------------------------------------------

    internal_recipient = Customer.query.filter_by(
        account_number=account_number
    ).first()

    if internal_recipient is not None:

        if internal_recipient.customer_id == customer.customer_id:

            return render_template(
                "send_money.html",
                customer=customer,
                banks=banks,
                error="You cannot send money to your own account.",
                form=request.form
            )

        if internal_recipient.account_status.lower() != "active":

            return render_template(
                "send_money.html",
                customer=customer,
                banks=banks,
                error="The recipient account is not active.",
                form=request.form
            )

        new_sender_balance = round(
            balance - amount,
            2
        )

        recipient_balance = round(
            float(internal_recipient.account_balance or 0),
            2
        )

        new_recipient_balance = round(
            recipient_balance + amount,
            2
        )

        reference = generate_transaction_reference()

        sender_transaction = Transaction(
            transaction_reference=reference,
            customer_id=customer.customer_id,
            transaction_type="UK Bank Transfer",
            direction="Debit",
            amount=amount,
            balance_after=new_sender_balance,
            description=payment_reference or "Bank transfer",
            counterparty=recipient_name,
            status="Completed"
        )

        recipient_transaction = Transaction(
            transaction_reference=generate_transaction_reference(),
            customer_id=internal_recipient.customer_id,
            transaction_type="UK Bank Transfer",
            direction="Credit",
            amount=amount,
            balance_after=new_recipient_balance,
            description=payment_reference or "Bank transfer",
            counterparty=customer.full_name,
            status="Completed"
        )

        customer.account_balance = new_sender_balance
        internal_recipient.account_balance = new_recipient_balance

        db.session.add(sender_transaction)
        db.session.add(recipient_transaction)

        try:

            db.session.commit()

        except Exception:

            db.session.rollback()

            return render_template(
                "send_money.html",
                customer=customer,
                banks=banks,
                error="The transfer could not be completed.",
                form=request.form
            )

        return render_template(
            "transfer_confirmation.html",
            customer=customer,
            recipient_name=recipient_name,
            bank_name=bank_name,
            account_number=account_number,
            sort_code=sort_code,
            transaction=sender_transaction,
            transfer_status="Completed"
        )

    # -----------------------------------------------------
    # External UK bank transfer.
    # -----------------------------------------------------

    reference = generate_transaction_reference()

    transfer = ExternalTransfer(
        transaction_reference=reference,
        customer_id=customer.customer_id,
        transfer_type="UK Bank",
        bank_name=bank_name,
        recipient_name=recipient_name,
        account_number=account_number,
        sort_code=sort_code,
        country="United Kingdom",
        currency="GBP",
        amount=amount,
        fee=0.0,
        reference=payment_reference,
        status="Pending"
    )

    db.session.add(transfer)

    try:

        db.session.commit()

    except Exception:

        db.session.rollback()

        return render_template(
            "send_money.html",
            customer=customer,
            banks=banks,
            error="The transfer request could not be created.",
            form=request.form
        )

    return render_template(
        "transfer_confirmation.html",
        customer=customer,
        recipient_name=recipient_name,
        bank_name=bank_name,
        account_number=account_number,
        sort_code=sort_code,
        transaction=transfer,
        transfer_status="Pending"
    )




@app.route("/international-transfer", methods=["GET", "POST"])
def international_transfer():

    customer_id = session.get("customer_id")

    if not customer_id:

        return render_template(
            "login.html",
            error="Please sign in to make an international transfer."
        )

    customer = Customer.query.filter_by(
        customer_id=customer_id
    ).first()

    if customer is None:

        session.clear()

        return render_template(
            "login.html",
            error="Your session could not be verified."
        )

    if request.method == "GET":

        return render_template(
            "international_transfer.html",
            customer=customer
        )

    country = request.form.get(
        "country",
        ""
    ).strip()

    recipient_name = request.form.get(
        "recipient_name",
        ""
    ).strip()

    bank_name = request.form.get(
        "bank_name",
        ""
    ).strip()

    account_number = request.form.get(
        "account_number",
        ""
    ).strip()

    iban = request.form.get(
        "iban",
        ""
    ).strip().upper()

    bic = request.form.get(
        "bic",
        ""
    ).strip().upper()

    currency = request.form.get(
        "currency",
        ""
    ).strip().upper()

    amount_text = request.form.get(
        "amount",
        ""
    ).strip()

    payment_reference = request.form.get(
        "payment_reference",
        ""
    ).strip()

    if not country:

        return render_template(
            "international_transfer.html",
            customer=customer,
            error="Please select the destination country.",
            form=request.form
        )

    if not recipient_name:

        return render_template(
            "international_transfer.html",
            customer=customer,
            error="Please enter the beneficiary name.",
            form=request.form
        )

    if not bank_name:

        return render_template(
            "international_transfer.html",
            customer=customer,
            error="Please enter the beneficiary bank.",
            form=request.form
        )

    if not account_number and not iban:

        return render_template(
            "international_transfer.html",
            customer=customer,
            error="Please enter an account number or IBAN.",
            form=request.form
        )

    if not bic:

        return render_template(
            "international_transfer.html",
            customer=customer,
            error="Please enter the SWIFT/BIC code.",
            form=request.form
        )

    if not currency:

        return render_template(
            "international_transfer.html",
            customer=customer,
            error="Please select a currency.",
            form=request.form
        )

    try:

        amount = round(
            float(amount_text),
            2
        )

    except ValueError:

        return render_template(
            "international_transfer.html",
            customer=customer,
            error="Please enter a valid amount.",
            form=request.form
        )

    if amount <= 0:

        return render_template(
            "international_transfer.html",
            customer=customer,
            error="The amount must be greater than zero.",
            form=request.form
        )

    balance = round(
        float(customer.account_balance or 0),
        2
    )

    if amount > balance:

        return render_template(
            "international_transfer.html",
            customer=customer,
            error=(
                "Insufficient available balance. "
                f"Your available balance is £{balance:,.2f}."
            ),
            form=request.form
        )

    reference = generate_transaction_reference()

    transfer = ExternalTransfer(
        transaction_reference=reference,
        customer_id=customer.customer_id,
        transfer_type="International",
        bank_name=bank_name,
        recipient_name=recipient_name,
        account_number=account_number or iban,
        sort_code=None,
        country=country,
        currency=currency,
        amount=amount,
        fee=0.0,
        reference=payment_reference,
        status="Pending"
    )

    db.session.add(transfer)

    try:

        db.session.commit()

    except Exception:

        db.session.rollback()

        return render_template(
            "international_transfer.html",
            customer=customer,
            error="The international transfer request could not be created.",
            form=request.form
        )

    return render_template(
        "international_confirmation.html",
        customer=customer,
        transfer=transfer,
        iban=iban,
        bic=bic
    )


@app.route("/transactions")
def transactions():

    customer_id = session.get("customer_id")

    if not customer_id:

        return render_template(
            "login.html",
            error="Please sign in to view your transactions."
        )

    customer = Customer.query.filter_by(
        customer_id=customer_id
    ).first()

    if customer is None:

        session.clear()

        return render_template(
            "login.html",
            error="Your session could not be verified. Please sign in again."
        )

    transaction_list = (
        Transaction.query
        .filter_by(customer_id=customer.customer_id)
        .order_by(Transaction.created_at.desc())
        .all()
    )

    return render_template(
        "transactions.html",
        customer=customer,
        transactions=transaction_list
    )




# =========================================================
# TRANSACTION DETAILS
# =========================================================

@app.route("/transaction/<transaction_reference>")
def transaction_details(transaction_reference):

    customer_id = session.get("customer_id")

    if not customer_id:

        return render_template(
            "login.html",
            error="Please sign in to view this transaction."
        )

    transaction = Transaction.query.filter_by(
        transaction_reference=transaction_reference,
        customer_id=customer_id
    ).first()

    if transaction is None:

        return (
            "Transaction not found.",
            404
        )

    customer = Customer.query.filter_by(
        customer_id=customer_id
    ).first()

    return render_template(
        "transaction_details.html",
        customer=customer,
        transaction=transaction
    )


# =========================================================
# MY PROFILE
# =========================================================



# =========================================================
# CUSTOMER DASHBOARD
# =========================================================

@app.route("/dashboard")
def dashboard():

    customer_id = session.get("customer_id")

    if not customer_id:

        return render_template(
            "login.html",
            error="Please sign in to access your dashboard."
        )

    customer = Customer.query.filter_by(
        customer_id=customer_id
    ).first()

    if customer is None:

        session.clear()

        return render_template(
            "login.html",
            error="Your session could not be verified. Please sign in again."
        )

    return render_template(
        "dashboard.html",
        customer=customer
    )

@app.route("/my-profile")
def my_profile():

    customer_id = session.get("customer_id")

    if not customer_id:

        return render_template(
            "login.html",
            error="Please sign in to access your profile."
        )

    customer = Customer.query.filter_by(
        customer_id=customer_id
    ).first()

    if customer is None:

        session.clear()

        return render_template(
            "login.html",
            error="Your session could not be verified. Please sign in again."
        )

    return render_template(
        "my_profile.html",
        customer=customer
    )

@app.route("/logout")
def logout():

    session.clear()

    return render_template(
        "login.html"
    )


# =========================================================
# APPLICATION START
# =========================================================

if __name__ == "__main__":

    with app.app_context():

        db.create_all()

    app.run(
        debug=True
    )
