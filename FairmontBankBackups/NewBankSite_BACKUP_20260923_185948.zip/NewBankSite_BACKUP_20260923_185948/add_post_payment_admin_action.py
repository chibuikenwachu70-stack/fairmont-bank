from pathlib import Path

TEMPLATE = Path("templates/admin_dashboard.html")

text = TEMPLATE.read_text(encoding="utf-8")

if 'url_for("admin_incoming_payment")' in text:
    print()
    print("Post Incoming Payment is already connected.")
    print()
    raise SystemExit(0)

title_marker = "Account Management"

title_position = text.find(title_marker)

if title_position == -1:
    raise SystemExit(
        "ERROR: Account Management text was not found. "
        "No changes were made."
    )

# Find the opening <a> tag immediately before Account Management.
anchor_start = text.rfind("<a ", 0, title_position)

if anchor_start == -1:
    raise SystemExit(
        "ERROR: The Account Management link could not be located. "
        "No changes were made."
    )

# Find the closing </a> belonging to this action.
anchor_end = text.find("</a>", title_position)

if anchor_end == -1:
    raise SystemExit(
        "ERROR: The Account Management closing tag was not found. "
        "No changes were made."
    )

anchor_end += len("</a>")

existing_action = text[anchor_start:anchor_end]

new_action = existing_action + '''

                      <a href="{{ url_for("admin_incoming_payment") }}" class="action">
                          <div class="action-title">
                              Post Incoming Payment
                          </div>

                          <div class="action-text">
                              Credit an existing customer account with an incoming payment.
                          </div>
                      </a>'''

text = (
    text[:anchor_end]
    + new_action[len(existing_action):]
    + text[anchor_end:]
)

TEMPLATE.write_text(text, encoding="utf-8")

print()
print("=" * 70)
print("POST INCOMING PAYMENT ACTION ADDED")
print("=" * 70)
print()
print("Added to:")
print("  templates/admin_dashboard.html")
print()
print("New action:")
print("  Post Incoming Payment")
print()
print("Route:")
print("  /admin/incoming-payment")
print()
print("Existing Account Management action was preserved.")
print()