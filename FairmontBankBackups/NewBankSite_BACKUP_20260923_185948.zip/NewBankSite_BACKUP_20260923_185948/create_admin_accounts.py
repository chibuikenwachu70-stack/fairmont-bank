from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
APP_FILE = BASE_DIR / "app.py"
TEMPLATE_FILE = BASE_DIR / "templates" / "admin_accounts.html"


# ------------------------------------------------------------
# 1. Add the Account Management route
# ------------------------------------------------------------

app_text = APP_FILE.read_text(encoding="utf-8")

if '@app.route("/admin/accounts")' in app_text:
    print("Admin accounts route already exists.")
else:
    route_code = r'''

@app.route("/admin/accounts")
def admin_accounts():
    admin_id = session.get("admin_id")

    if not admin_id:
        return redirect(url_for("admin_login"))

    admin = db.session.get(AdminUser, admin_id)

    if not admin or not admin.is_active:
        session.pop("admin_id", None)
        return redirect(url_for("admin_login"))

    search = request.args.get("search", "").strip()
    status = request.args.get("status", "").strip()
    account_type = request.args.get("account_type", "").strip()

    query = Customer.query

    if search:
        search_value = f"%{search}%"

        query = query.filter(
            db.or_(
                Customer.customer_id.ilike(search_value),
                Customer.account_number.ilike(search_value),
                Customer.full_name.ilike(search_value),
                Customer.email.ilike(search_value),
                Customer.phone.ilike(search_value),
            )
        )

    if status:
        query = query.filter(Customer.account_status == status)

    if account_type:
        query = query.filter(Customer.account_type == account_type)

    customers = query.order_by(Customer.id.desc()).all()

    return render_template(
        "admin_accounts.html",
        admin=admin,
        customers=customers,
        search=search,
        status=status,
        account_type=account_type,
    )
'''

    marker = 'if __name__ == "__main__":'

    if marker in app_text:
        app_text = app_text.replace(
            marker,
            route_code + "\n\n" + marker,
            1
        )
    else:
        app_text = app_text.rstrip() + "\n\n" + route_code + "\n"

    APP_FILE.write_text(app_text, encoding="utf-8")

    print("Admin accounts route added successfully.")


# ------------------------------------------------------------
# 2. Create the Account Management template
# ------------------------------------------------------------

template = r'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Account Management | Fairmont Bank</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background:
                radial-gradient(circle at top right, rgba(184, 149, 74, 0.08), transparent 30%),
                #07111f;
            color: #eef3f8;
        }

        .page {
            max-width: 1500px;
            margin: 0 auto;
            padding: 30px;
        }

        .topbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            margin-bottom: 28px;
        }

        .brand img {
            width: 190px;
            max-width: 100%;
            height: auto;
            display: block;
        }

        .top-actions {
            display: flex;
            gap: 10px;
        }

        .top-actions a {
            text-decoration: none;
            color: #d8b96a;
            border: 1px solid rgba(184, 149, 74, 0.35);
            padding: 10px 15px;
            border-radius: 9px;
            font-size: 13px;
            font-weight: 700;
        }

        .top-actions a:hover {
            background: rgba(184, 149, 74, 0.10);
        }

        .heading {
            margin-bottom: 22px;
        }

        .heading h1 {
            margin: 0 0 8px;
            font-size: 30px;
            letter-spacing: -0.4px;
        }

        .heading p {
            margin: 0;
            color: #91a3b7;
            font-size: 14px;
        }

        .panel {
            background: rgba(13, 28, 46, 0.88);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 16px;
            padding: 20px;
            box-shadow: 0 18px 45px rgba(0, 0, 0, 0.22);
            margin-bottom: 22px;
        }

        .filters {
            display: grid;
            grid-template-columns: minmax(250px, 1fr) 180px 180px auto;
            gap: 12px;
            align-items: end;
        }

        .field label {
            display: block;
            margin-bottom: 7px;
            color: #9fb0c3;
            font-size: 12px;
            font-weight: 700;
        }

        .field input,
        .field select {
            width: 100%;
            border: 1px solid rgba(255, 255, 255, 0.10);
            background: #091827;
            color: #eef3f8;
            border-radius: 9px;
            padding: 11px 12px;
            outline: none;
        }

        .field input:focus,
        .field select:focus {
            border-color: rgba(216, 185, 106, 0.65);
        }

        .filter-buttons {
            display: flex;
            gap: 8px;
        }

        .btn {
            border: 0;
            border-radius: 9px;
            padding: 11px 16px;
            cursor: pointer;
            font-weight: 700;
            text-decoration: none;
            font-size: 13px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .btn-primary {
            background: #b8954a;
            color: #07111f;
        }

        .btn-secondary {
            background: rgba(255, 255, 255, 0.07);
            color: #d7e0e9;
            border: 1px solid rgba(255, 255, 255, 0.09);
        }

        .summary {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 15px;
        }

        .summary-title {
            font-size: 15px;
            font-weight: 700;
        }

        .summary-count {
            color: #9fb0c3;
            font-size: 13px;
        }

        .table-wrap {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1050px;
        }

        th {
            text-align: left;
            padding: 13px 12px;
            color: #8fa2b7;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            white-space: nowrap;
        }

        td {
            padding: 15px 12px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.055);
            font-size: 13px;
            vertical-align: middle;
        }

        tr:hover td {
            background: rgba(255, 255, 255, 0.018);
        }

        .customer-name {
            font-weight: 700;
            margin-bottom: 4px;
        }

        .customer-id {
            color: #8295aa;
            font-size: 11px;
        }

        .account-number {
            color: #d8b96a;
            font-weight: 700;
            white-space: nowrap;
        }

        .balance {
            font-weight: 700;
            white-space: nowrap;
        }

        .badge {
            display: inline-flex;
            align-items: center;
            padding: 5px 9px;
            border-radius: 999px;
            font-size: 10px;
            font-weight: 800;
            letter-spacing: 0.3px;
            white-space: nowrap;
        }

        .badge-active {
            color: #9ed0ae;
            background: rgba(80, 170, 105, 0.10);
            border: 1px solid rgba(80, 170, 105, 0.20);
        }

        .badge-inactive {
            color: #e3a4a4;
            background: rgba(190, 80, 80, 0.10);
            border: 1px solid rgba(190, 80, 80, 0.20);
        }

        .badge-other {
            color: #d8b96a;
            background: rgba(184, 149, 74, 0.10);
            border: 1px solid rgba(184, 149, 74, 0.20);
        }

        .view-link {
            color: #d8b96a;
            text-decoration: none;
            font-size: 12px;
            font-weight: 700;
            white-space: nowrap;
        }

        .view-link:hover {
            text-decoration: underline;
        }

        .empty {
            text-align: center;
            padding: 55px 20px;
            color: #8ea0b4;
        }

        .empty-title {
            color: #dce5ed;
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 7px;
        }

        .footer-note {
            margin-top: 18px;
            color: #71859a;
            font-size: 11px;
        }

        @media (max-width: 900px) {
            .filters {
                grid-template-columns: 1fr;
            }

            .topbar {
                align-items: flex-start;
                flex-direction: column;
            }
        }

        @media (max-width: 600px) {
            .page {
                padding: 18px;
            }

            .panel {
                padding: 14px;
            }

            .heading h1 {
                font-size: 24px;
            }
        }
    </style>
</head>

<body>

<div class="page">

    <div class="topbar">

        <div class="brand">
            <img
                src="{{ url_for('static', filename='images/fairmont-bank-logo.png') }}"
                alt="Fairmont Bank">
        </div>

        <div class="top-actions">
            <a href="{{ url_for('admin_dashboard') }}">Back to Dashboard</a>
            <a href="{{ url_for('admin_logout') }}">Sign Out</a>
        </div>

    </div>

    <div class="heading">
        <h1>Account Management</h1>
        <p>Manage authorized account information for Fairmont Bank customers.</p>
    </div>

    <div class="panel">

        <form method="GET" action="{{ url_for('admin_accounts') }}">

            <div class="filters">

                <div class="field">
                    <label for="search">Search Accounts</label>
                    <input
                        type="text"
                        id="search"
                        name="search"
                        value="{{ search }}"
                        placeholder="Customer name, ID, account number, email or phone">
                </div>

                <div class="field">
                    <label for="status">Account Status</label>
                    <select id="status" name="status">
                        <option value="">All Statuses</option>
                        <option value="Active" {% if status == "Active" %}selected{% endif %}>Active</option>
                        <option value="Inactive" {% if status == "Inactive" %}selected{% endif %}>Inactive</option>
                        <option value="Suspended" {% if status == "Suspended" %}selected{% endif %}>Suspended</option>
                    </select>
                </div>

                <div class="field">
                    <label for="account_type">Account Type</label>
                    <select id="account_type" name="account_type">
                        <option value="">All Types</option>
                        <option value="savings" {% if account_type == "savings" %}selected{% endif %}>Savings</option>
                        <option value="current" {% if account_type == "current" %}selected{% endif %}>Current</option>
                        <option value="business" {% if account_type == "business" %}selected{% endif %}>Business</option>
                    </select>
                </div>

                <div class="filter-buttons">
                    <button type="submit" class="btn btn-primary">Search</button>
                    <a href="{{ url_for('admin_accounts') }}" class="btn btn-secondary">Reset</a>
                </div>

            </div>

        </form>

    </div>

    <div class="panel">

        <div class="summary">
            <div class="summary-title">Authorized Customer Accounts</div>

            <div class="summary-count">
                {{ customers|length }} account{% if customers|length != 1 %}s{% endif %}
            </div>
        </div>

        <div class="table-wrap">

            {% if customers %}

            <table>

                <thead>
                    <tr>
                        <th>Customer</th>
                        <th>Account Number</th>
                        <th>Account Type</th>
                        <th>Country</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Balance</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>

                    {% for customer in customers %}

                    <tr>

                        <td>
                            <div class="customer-name">
                                {{ customer.full_name }}
                            </div>

                            <div class="customer-id">
                                {{ customer.customer_id }}
                            </div>
                        </td>

                        <td>
                            <span class="account-number">
                                {{ customer.account_number or "Not assigned" }}
                            </span>
                        </td>

                        <td>
                            {{ customer.account_type|title }}
                        </td>

                        <td>
                            {{ customer.country|title }}
                        </td>

                        <td>
                            {{ customer.email }}
                        </td>

                        <td>
                            {{ customer.phone }}
                        </td>

                        <td>
                            <span class="balance">
                                £{{ "%.2f"|format(customer.account_balance or 0) }}
                            </span>
                        </td>

                        <td>

                            {% if customer.account_status == "Active" %}
                                <span class="badge badge-active">ACTIVE</span>
                            {% elif customer.account_status == "Inactive" %}
                                <span class="badge badge-inactive">INACTIVE</span>
                            {% else %}
                                <span class="badge badge-other">
                                    {{ customer.account_status|upper }}
                                </span>
                            {% endif %}

                        </td>

                        <td>
                            <a
                                href="{{ url_for('admin_customer_profile', customer_id=customer.id) }}"
                                class="view-link">
                                View Account
                            </a>
                        </td>

                    </tr>

                    {% endfor %}

                </tbody>

            </table>

            {% else %}

            <div class="empty">
                <div class="empty-title">No accounts found</div>
                <div>
                    No customer accounts match the current search or filters.
                </div>
            </div>

            {% endif %}

        </div>

        <div class="footer-note">
            Account information is displayed from the existing Fairmont Bank customer database.
        </div>

    </div>

</div>

</body>
</html>
'''

TEMPLATE_FILE.write_text(template, encoding="utf-8")

print("Admin account management template created successfully.")

print()
print("=" * 70)
print("ACCOUNT MANAGEMENT SETUP COMPLETE")
print("=" * 70)
print()
print("Created:")
print("  /admin/accounts")
print("  templates/admin_accounts.html")
print()
print("Existing customer and account records were NOT changed.")
print()