from pathlib import Path

FILE = Path("templates") / "international_transfer.html"

if not FILE.exists():
    print("ERROR: File not found:")
    print(FILE.resolve())
    raise SystemExit(1)

text = FILE.read_text(encoding="utf-8")

print("=" * 70)
print("INTERNATIONAL TRANSFER TEMPLATE DIAGNOSTIC")
print("=" * 70)
print()

print("FILE:")
print(FILE.resolve())
print()

print("TOTAL CHARACTERS:", len(text))
print("TOTAL LINES:", len(text.splitlines()))
print()

# ------------------------------------------------------------
# Search for all relevant labels/phrases
# ------------------------------------------------------------

terms = [
    "Destination Country",
    "destination country",
    "Country",
    "Beneficiary Name",
    "Bank Name",
    "Account Number",
    "Currency",
    "Amount",
]

print("=" * 70)
print("TERM COUNTS")
print("=" * 70)

for term in terms:
    print(f"{term!r}: {text.count(term)}")

print()

# ------------------------------------------------------------
# Print context around every Destination Country occurrence
# ------------------------------------------------------------

def show_context(term, radius=1800):
    positions = []
    start = 0

    while True:
        pos = text.find(term, start)

        if pos == -1:
            break

        positions.append(pos)
        start = pos + len(term)

    print("=" * 70)
    print(f"CONTEXT FOR: {term!r}")
    print(f"OCCURRENCES: {len(positions)}")
    print("=" * 70)

    if not positions:
        print("NOT FOUND")
        print()
        return

    for number, pos in enumerate(positions, 1):
        print()
        print("-" * 70)
        print(f"OCCURRENCE {number}")
        print(f"CHARACTER POSITION: {pos}")
        print("-" * 70)

        begin = max(0, pos - radius)
        end = min(len(text), pos + len(term) + radius)

        snippet = text[begin:end]

        print(snippet)

        print()
        print("-" * 70)

show_context("Destination Country", 2500)

# ------------------------------------------------------------
# Show nearby HTML around every select
# ------------------------------------------------------------

print("=" * 70)
print("SELECT ELEMENTS")
print("=" * 70)

import re

selects = list(re.finditer(r"<select\b[^>]*>", text, re.IGNORECASE))

print("SELECT OPENING TAGS FOUND:", len(selects))
print()

for i, match in enumerate(selects, 1):
    print(f"{i}. {match.group(0)}")

print()

# ------------------------------------------------------------
# Show labels
# ------------------------------------------------------------

print("=" * 70)
print("LABEL ELEMENTS")
print("=" * 70)

labels = list(
    re.finditer(
        r"<label\b[^>]*>.*?</label>",
        text,
        re.IGNORECASE | re.DOTALL
    )
)

print("LABELS FOUND:", len(labels))
print()

for i, match in enumerate(labels, 1):
    value = re.sub(r"\s+", " ", match.group(0)).strip()
    print(f"{i}. {value}")

print()

# ------------------------------------------------------------
# Final instructions
# ------------------------------------------------------------

print("=" * 70)
print("END OF DIAGNOSTIC")
print("=" * 70)
print()
print("NO FILE WAS MODIFIED.")
print()
print("Send me the COMPLETE output from this command.")