from pathlib import Path

template_file = Path("templates/transactions.html")

if not template_file.exists():
    raise SystemExit("ERROR: templates/transactions.html was not found.")

html = template_file.read_text(encoding="utf-8")

# Prevent accidental duplicate insertion.
if ".transaction-filters" in html:
    print("INFO: Transaction filter styling already exists.")
    raise SystemExit(0)

css = r"""
<style>
    .transaction-filters {
        margin: 0 0 20px;
    }

    .transaction-filter-form {
        display: flex;
        flex-direction: column;
        gap: 12px;
    }

    .transaction-search-row {
        display: flex;
        gap: 8px;
    }

    .transaction-search-row input {
        flex: 1;
        min-width: 0;
        padding: 13px 14px;
        border-radius: 12px;
        border: 1px solid rgba(255,255,255,0.12);
        background: rgba(255,255,255,0.07);
        color: inherit;
        outline: none;
        box-sizing: border-box;
    }

    .transaction-search-row button {
        padding: 13px 16px;
        border: 0;
        border-radius: 12px;
        cursor: pointer;
        font-weight: 600;
    }

    .transaction-filter-row {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 8px;
    }

    .transaction-filter-row select {
        width: 100%;
        padding: 12px 10px;
        border-radius: 12px;
        border: 1px solid rgba(255,255,255,0.12);
        background: rgba(255,255,255,0.07);
        color: inherit;
        outline: none;
        box-sizing: border-box;
    }

    .transaction-filter-actions {
        text-align: right;
    }

    .transaction-filter-actions a {
        text-decoration: none;
        font-size: 13px;
    }

    @media (max-width: 600px) {
        .transaction-search-row {
            flex-direction: column;
        }

        .transaction-filter-row {
            grid-template-columns: 1fr;
        }
    }
</style>
"""

# Insert the scoped CSS immediately after <head>.
marker = "</head>"

if marker not in html:
    raise SystemExit("ERROR: </head> was not found.")

html = html.replace(
    marker,
    css + "\n" + marker,
    1
)

template_file.write_text(html, encoding="utf-8")

print("SUCCESS: Transaction History filter styling added.")
print("The existing backend changes were not modified.")