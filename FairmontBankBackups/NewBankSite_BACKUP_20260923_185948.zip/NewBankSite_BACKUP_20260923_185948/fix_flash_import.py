from pathlib import Path

app_file = Path("app.py")

text = app_file.read_text(encoding="utf-8")

old = "from flask import Flask, render_template, request, session, redirect, url_for, url_for"

new = "from flask import Flask, render_template, request, session, redirect, url_for, url_for, flash"

if "from flask import" not in text:
    print("ERROR: Flask import line was not found.")
    raise SystemExit(1)

if "from flask import" in text and "flash" in text.split("\n", 5)[0]:
    print("flash is already imported.")
    raise SystemExit(0)

if old in text:
    text = text.replace(old, new, 1)
else:
    # Safely add flash to the existing Flask import line.
    lines = text.splitlines()
    changed = False

    for i, line in enumerate(lines):
        if line.startswith("from flask import "):
            if "flash" not in line:
                lines[i] = line.rstrip() + ", flash"
                changed = True
            break

    if not changed:
        print("ERROR: Could not safely update the Flask import.")
        raise SystemExit(1)

    text = "\n".join(lines) + ("\n" if text.endswith("\n") else "")

app_file.write_text(text, encoding="utf-8")

print("=" * 70)
print("FLASH IMPORT FIXED")
print("=" * 70)
print()
print("Added Flask flash import to app.py.")
print("No database or customer data was changed.")
print()