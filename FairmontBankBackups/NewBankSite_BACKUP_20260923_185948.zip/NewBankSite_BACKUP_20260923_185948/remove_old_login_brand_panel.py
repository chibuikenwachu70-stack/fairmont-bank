from pathlib import Path
import shutil
import re

BASE = Path(r"C:\Users\DON J\Documents\NewBankSite")
FILE = BASE / "static" / "css" / "style.css"

backup = FILE.with_suffix(".css.before_old_login_brand_removal")
shutil.copy2(FILE, backup)

text = FILE.read_text(encoding="utf-8")

pattern = re.compile(
    r"""
    body:has\(\.login-page\)\s+\.login-shell::before\s*\{
    .*?
    \}
    """,
    re.IGNORECASE | re.DOTALL | re.VERBOSE
)

new_text, count = pattern.subn("", text)

if count == 0:
    print("ERROR: Old login branding panel was not found.")
    print("No changes were made.")
    raise SystemExit(1)

FILE.write_text(new_text, encoding="utf-8")

print()
print("=" * 65)
print("OLD LOGIN BRANDING PANEL REMOVED")
print("=" * 65)
print()
print("Removed the CSS-generated old FAIRMONT BANK branding panel.")
print("The actual professional logo in login.html remains untouched.")
print("Customer ID and Password fields were not modified.")
print("Login functionality was not modified.")
print()
print(f"Backup created:")
print(backup)
print()
print("SUCCESS")
print("=" * 65)