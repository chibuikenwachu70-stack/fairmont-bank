from pathlib import Path

BASE_DIR = Path(r"C:\Users\DON J\Documents\NewBankSite")

PROFILE_FILE = BASE_DIR / "templates" / "my_profile.html"


text = PROFILE_FILE.read_text(encoding="utf-8")


text = text.replace(
    'href="/login"\n                class="profile-back-button"',
    'href="/dashboard"\n                class="profile-back-button"'
)

text = text.replace(
    'href="/login"\n                class="profile-dashboard-button"',
    'href="/dashboard"\n                class="profile-dashboard-button"'
)


PROFILE_FILE.write_text(
    text,
    encoding="utf-8"
)


print("SUCCESS: My Profile dashboard links have been updated.")
print("Back arrow -> /dashboard")
print("Return to dashboard -> /dashboard")