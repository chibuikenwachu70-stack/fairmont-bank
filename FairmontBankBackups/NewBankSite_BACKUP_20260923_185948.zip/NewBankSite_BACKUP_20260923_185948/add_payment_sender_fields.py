from pathlib import Path
import sqlite3

BASE_DIR = Path(__file__).resolve().parent
DB_FILE = BASE_DIR / "instance" / "fairmont.db"

conn = sqlite3.connect(DB_FILE)
cursor = conn.cursor()

columns = [
    ("sender_name", "VARCHAR(150)"),
    ("sender_account_number", "VARCHAR(50)"),
    ("sender_bank", "VARCHAR(150)"),
    ("sender_country", "VARCHAR(100)"),
]

existing_columns = {
    row[1]
    for row in cursor.execute('PRAGMA table_info("transaction")').fetchall()
}

for column_name, column_type in columns:
    if column_name in existing_columns:
        print(f"{column_name}: already exists.")
    else:
        cursor.execute(
            f'ALTER TABLE "transaction" ADD COLUMN "{column_name}" {column_type}'
        )
        print(f"{column_name}: added successfully.")

conn.commit()
conn.close()

print()
print("=" * 70)
print("PAYMENT SENDER FIELDS MIGRATION COMPLETE")
print("=" * 70)
print()
print("Existing transaction records were preserved.")