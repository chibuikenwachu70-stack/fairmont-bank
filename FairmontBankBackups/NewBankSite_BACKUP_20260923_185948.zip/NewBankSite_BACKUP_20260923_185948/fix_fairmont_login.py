from pathlib import Path
from datetime import datetime
import re
import shutil
import sys


BASE = Path(r"C:\Users\DON J\Documents\NewBankSite")
APP = BASE / "app.py"
TEMPLATES = BASE / "templates"
LOGIN_TEMPLATE = TEMPLATES / "login.html"


def fail(message):
    print()
    print("=" * 70)
    print("ERROR")
    print("=" * 70)
    print(message)
    print()
    sys.exit(1)


if not APP.exists():
    fail(f"app.py was not found:\n{APP}")

TEMPLATES.mkdir(parents=True, exist_ok=True)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

app_backup = APP.with_name(
    f"app_BEFORE_LOGIN_FIX_{timestamp}.py"
)

login_backup = None

if LOGIN_TEMPLATE.exists():
    login_backup = LOGIN_TEMPLATE.with_name(
        f"login_BEFORE_LOGIN_FIX_{timestamp}.html"
    )


print()
print("=" * 70)
print("FAIRMONT BANK LOGIN / AUTHENTICATION REPAIR")
print("=" * 70)
print()

# ---------------------------------------------------------
# BACKUPS
# ---------------------------------------------------------

shutil.copy2(APP, app_backup)
print(f"App backup created:")
print(f"  {app_backup.name}")

if LOGIN_TEMPLATE.exists():
    shutil.copy2(LOGIN_TEMPLATE, login_backup)
    print(f"Login template backup created:")
    print(f"  {login_backup.name}")

# ---------------------------------------------------------
# READ APP
# ---------------------------------------------------------

text = APP.read_text(encoding="utf-8")

original_text = text


# ---------------------------------------------------------
# 1. ENSURE FLASK-LOGIN IMPORTS
# ---------------------------------------------------------

if "from flask_login import" not in text:

    flask_import_pattern = re.compile(
        r"(^from flask import.*?$)",
        re.MULTILINE
    )

    match = flask_import_pattern.search(text)

    if match:
        insertion = (
            match.group(1)
            + "\n"
            + "from flask_login import "
              "LoginManager, UserMixin, login_user, "
              "login_required, current_user\n"
        )

        text = (
            text[:match.start()]
            + insertion
            + text[match.end():]
        )
    else:
        text = (
            "from flask_login import "
            "LoginManager, UserMixin, login_user, "
            "login_required, current_user\n"
            + text
        )

else:

    # Add any missing names to an existing Flask-Login import.
    import_match = re.search(
        r"from flask_login import ([^\n]+)",
        text
    )

    if import_match:
        existing = import_match.group(1)

        required_names = [
            "LoginManager",
            "UserMixin",
            "login_user",
            "login_required",
            "current_user",
        ]

        names = [
            name.strip()
            for name in existing.split(",")
        ]

        changed = False

        for name in required_names:
            if name not in names:
                names.append(name)
                changed = True

        if changed:
            replacement = (
                "from flask_login import "
                + ", ".join(names)
            )

            text = (
                text[:import_match.start()]
                + replacement
                + text[import_match.end():]
            )


# ---------------------------------------------------------
# 2. ENSURE LOGIN MANAGER SETUP
# ---------------------------------------------------------

if "login_manager = LoginManager()" not in text:

    app_creation = re.search(
        r"(app\s*=\s*Flask\(__name__\)\s*)",
        text
    )

    if not app_creation:
        fail(
            "Could not find 'app = Flask(__name__)'. "
            "The application structure is different than expected."
        )

    setup = """

# =========================================================
# FLASK-LOGIN AUTHENTICATION
# =========================================================

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"

"""

    insert_at = app_creation.end()

    text = (
        text[:insert_at]
        + setup
        + text[insert_at:]
    )

else:

    if "login_manager.login_view" not in text:
        marker = "login_manager.init_app(app)"

        if marker in text:
            text = text.replace(
                marker,
                marker + '\nlogin_manager.login_view = "login"',
                1
            )


# ---------------------------------------------------------
# 3. FIND CUSTOMER MODEL
# ---------------------------------------------------------

customer_match = re.search(
    r"class\s+Customer\s*\(([^)]*)\)\s*:",
    text
)

if not customer_match:
    fail(
        "The Customer model could not be found.\n"
        "Nothing was changed except the backup."
    )

customer_bases = customer_match.group(1)

if "UserMixin" not in customer_bases:

    new_bases = customer_bases.strip()

    if new_bases:
        new_bases = "UserMixin, " + new_bases
    else:
        new_bases = "UserMixin"

    text = (
        text[:customer_match.start(1)]
        + new_bases
        + text[customer_match.end(1):]
    )

    print("Customer model updated to support Flask-Login.")
else:
    print("Customer model already supports Flask-Login.")


# ---------------------------------------------------------
# 4. ENSURE USER LOADER
# ---------------------------------------------------------

if "@login_manager.user_loader" not in text:

    customer_match = re.search(
        r"class\s+Customer\s*\([^)]*\)\s*:",
        text
    )

    if not customer_match:
        fail("Customer model disappeared while repairing the file.")

    # Find the next top-level class after Customer.
    next_class = re.search(
        r"^class\s+",
        text[customer_match.end():],
        re.MULTILINE
    )

    if next_class:
        insertion_point = (
            customer_match.end()
            + next_class.start()
        )
    else:
        insertion_point = len(text)

    loader = """

# =========================================================
# FLASK-LOGIN USER LOADER
# =========================================================

@login_manager.user_loader
def load_user(user_id):
    try:
        return db.session.get(Customer, int(user_id))
    except (TypeError, ValueError):
        return None


"""

    text = (
        text[:insertion_point]
        + loader
        + text[insertion_point:]
    )

    print("Flask-Login user loader added.")
else:
    print("Flask-Login user loader already exists.")


# ---------------------------------------------------------
# 5. REPAIR LOGIN ROUTE
# ---------------------------------------------------------

login_match = re.search(
    r"(@app\.route\(\s*[\"']/login[\"'].*?def\s+login\s*\([^)]*\):)",
    text,
    re.DOTALL
)

if not login_match:
    fail(
        "Could not locate the /login route.\n"
        "The application was backed up but not modified."
    )

login_start = login_match.start()
login_header_end = login_match.end()

# Find the next top-level route after login().
next_route = re.search(
    r"^@app\.route\(",
    text[login_header_end:],
    re.MULTILINE
)

if next_route:
    login_end = login_header_end + next_route.start()
else:
    login_end = len(text)

login_block = text[login_start:login_end]


# ---------------------------------------------------------
# Detect customer lookup
# ---------------------------------------------------------

if "Customer.query" in login_block:

    # Modern SQLAlchemy-style login.
    customer_lookup = """
        customer = Customer.query.filter_by(
            customer_id=customer_id
        ).first()
"""

else:
    customer_lookup = None


# ---------------------------------------------------------
# We do not replace the entire route blindly.
# Instead, repair the important authentication pieces.
# ---------------------------------------------------------

# Ensure next destination is captured.
if "request.args.get(\"next\")" not in login_block:

    anchor = "def login():"

    if anchor in login_block:

        login_block = login_block.replace(
            anchor,
            anchor
            + '\n\n'
            + '    next_url = ('
            + '\n'
            + '        request.args.get("next")'
            + '\n'
            + '        or request.form.get("next")'
            + '\n'
            + '    )',
            1
        )


# Ensure login_user is called after successful authentication.
if "login_user(customer)" not in login_block:

    # Existing session handling from the project.
    if "session.clear()" in login_block:

        login_block = login_block.replace(
            "session.clear()",
            "session.clear()\n\n"
            "        login_user(customer)",
            1
        )

    else:

        # Insert before the first dashboard redirect.
        dashboard_redirect = re.search(
            r"^\s*return\s+redirect\([^\n]*dashboard[^\n]*\)",
            login_block,
            re.MULTILINE
        )

        if dashboard_redirect:

            login_block = (
                login_block[:dashboard_redirect.start()]
                + "        login_user(customer)\n\n"
                + login_block[dashboard_redirect.start():]
            )

        else:

            # Last-resort insertion after password verification.
            success_anchor = re.search(
                r"(if\s+check_password_hash\([^\n]+\):)",
                login_block
            )

            if success_anchor:
                pos = success_anchor.end()
                login_block = (
                    login_block[:pos]
                    + "\n\n        login_user(customer)"
                    + login_block[pos:]
                )
            else:
                fail(
                    "Could not safely locate the successful login "
                    "section. The backup was created and app.py "
                    "was not changed."
                )


# ---------------------------------------------------------
# Repair redirect after login.
# ---------------------------------------------------------

# Replace simple dashboard-only redirect with next-aware redirect.
dashboard_redirect_patterns = [
    r'return\s+redirect\(\s*[\'"]/dashboard[\'"]\s*\)',
    r'return\s+redirect\(\s*url_for\(\s*[\'"]dashboard[\'"]\s*\)\s*\)',
]

replaced_redirect = False

for pattern in dashboard_redirect_patterns:

    if re.search(pattern, login_block):

        replacement = (
            '        if next_url and '
            'next_url.startswith("/") '
            'and not next_url.startswith("//"):\n'
            '            return redirect(next_url)\n\n'
            '        return redirect(url_for("dashboard"))'
        )

        login_block = re.sub(
            pattern,
            replacement,
            login_block,
            count=1
        )

        replaced_redirect = True
        break


# If redirect is already next-aware, leave it alone.
if not replaced_redirect:

    if (
        "redirect(next_url)" not in login_block
        and "redirect(url_for(\"dashboard\"))" not in login_block
        and "redirect('/dashboard')" not in login_block
    ):
        print(
            "Warning: login redirect could not be automatically "
            "replaced. Existing redirect was preserved."
        )


# ---------------------------------------------------------
# Preserve next destination through the login form.
# ---------------------------------------------------------

if (
    "name=\"next\"" not in login_block
    and "name='next'" not in login_block
):
    pass


# Put repaired route back.
text = (
    text[:login_start]
    + login_block
    + text[login_end:]
)


# ---------------------------------------------------------
# 6. ENSURE SECRET KEY EXISTS
# ---------------------------------------------------------

if (
    "app.secret_key" not in text
    and "app.config[\"SECRET_KEY\"]" not in text
    and "app.config['SECRET_KEY']" not in text
):

    app_match = re.search(
        r"app\s*=\s*Flask\(__name__\)",
        text
    )

    if app_match:

        secret = (
            '\n\n'
            '# Session security key for local development.\n'
            'app.secret_key = "fairmont-local-development-key"\n'
        )

        text = (
            text[:app_match.end()]
            + secret
            + text[app_match.end():]
        )

        print("Application secret key added.")


# ---------------------------------------------------------
# 7. WRITE APP ONLY IF CHANGED
# ---------------------------------------------------------

if text != original_text:

    APP.write_text(text, encoding="utf-8")

    print()
    print("app.py authentication changes written.")

else:
    print()
    print("No additional app.py changes were required.")


# ---------------------------------------------------------
# 8. REBUILD LOGIN TEMPLATE
# ---------------------------------------------------------

login_html = r'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Sign In | Fairmont Bank</title>

    <style>
        * {
            box-sizing: border-box;
        }

        html,
        body {
            margin: 0;
            min-height: 100%;
            font-family:
                Inter,
                -apple-system,
                BlinkMacSystemFont,
                "Segoe UI",
                sans-serif;
            background: #071426;
            color: #f7f9fc;
        }

        body {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
            overflow-x: hidden;
            position: relative;
        }

        body::before {
            content: "";
            position: fixed;
            width: 520px;
            height: 520px;
            border-radius: 50%;
            background: rgba(50, 111, 255, 0.18);
            filter: blur(80px);
            top: -180px;
            right: -150px;
            pointer-events: none;
        }

        body::after {
            content: "";
            position: fixed;
            width: 430px;
            height: 430px;
            border-radius: 50%;
            background: rgba(20, 184, 166, 0.10);
            filter: blur(80px);
            bottom: -170px;
            left: -140px;
            pointer-events: none;
        }

        .page {
            width: 100%;
            max-width: 1120px;
            min-height: 680px;
            display: grid;
            grid-template-columns: 0.95fr 1.05fr;
            position: relative;
            z-index: 1;
            overflow: hidden;
            border: 1px solid rgba(255,255,255,0.10);
            border-radius: 30px;
            background:
                linear-gradient(
                    135deg,
                    rgba(18, 35, 61, 0.96),
                    rgba(8, 20, 38, 0.98)
                );
            box-shadow:
                0 35px 90px rgba(0,0,0,0.40);
        }

        .brand-panel {
            padding: 52px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            background:
                linear-gradient(
                    145deg,
                    rgba(20, 54, 101, 0.88),
                    rgba(7, 25, 48, 0.96)
                );
            border-right: 1px solid rgba(255,255,255,0.08);
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 14px;
        }

        .brand-mark {
            width: 48px;
            height: 48px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: Georgia, serif;
            font-size: 25px;
            font-weight: 700;
            color: #ffffff;
            background:
                linear-gradient(145deg, #174b91, #0c2e5b);
            border: 1px solid rgba(255,255,255,0.18);
            box-shadow:
                0 10px 30px rgba(0,0,0,0.22);
        }

        .brand-name {
            font-family: Georgia, "Times New Roman", serif;
            font-size: 23px;
            letter-spacing: 0.03em;
        }

        .brand-subtitle {
            margin-top: 3px;
            color: rgba(255,255,255,0.58);
            font-size: 11px;
            letter-spacing: 0.18em;
            text-transform: uppercase;
        }

        .welcome-copy {
            max-width: 440px;
        }

        .eyebrow {
            color: #9ebbe7;
            font-size: 12px;
            font-weight: 700;
            letter-spacing: 0.16em;
            text-transform: uppercase;
            margin-bottom: 18px;
        }

        .welcome-copy h1 {
            margin: 0;
            font-family: Georgia, "Times New Roman", serif;
            font-size: clamp(42px, 5vw, 64px);
            line-height: 0.98;
            font-weight: 500;
            letter-spacing: -0.035em;
        }

        .welcome-copy p {
            margin: 24px 0 0;
            max-width: 400px;
            color: rgba(255,255,255,0.68);
            font-size: 16px;
            line-height: 1.75;
        }

        .security-note {
            display: flex;
            gap: 12px;
            align-items: flex-start;
            max-width: 390px;
            color: rgba(255,255,255,0.58);
            font-size: 12px;
            line-height: 1.6;
        }

        .security-icon {
            width: 30px;
            height: 30px;
            flex: 0 0 30px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(255,255,255,0.07);
            color: #b8d0f5;
        }

        .login-panel {
            padding: 52px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-card {
            width: 100%;
            max-width: 440px;
        }

        .mobile-brand {
            display: none;
        }

        .login-heading {
            margin-bottom: 30px;
        }

        .login-heading h2 {
            margin: 0;
            font-family: Georgia, "Times New Roman", serif;
            font-size: 35px;
            font-weight: 500;
        }

        .login-heading p {
            margin: 10px 0 0;
            color: rgba(255,255,255,0.58);
            font-size: 14px;
            line-height: 1.6;
        }

        .error {
            margin-bottom: 20px;
            padding: 13px 15px;
            border-radius: 13px;
            border: 1px solid rgba(248,113,113,0.28);
            background: rgba(127,29,29,0.24);
            color: #fecaca;
            font-size: 13px;
            line-height: 1.5;
        }

        .field {
            margin-bottom: 18px;
        }

        .field label {
            display: block;
            margin-bottom: 8px;
            color: rgba(255,255,255,0.82);
            font-size: 13px;
            font-weight: 600;
        }

        .input-wrap {
            position: relative;
        }

        .input {
            width: 100%;
            height: 54px;
            padding: 0 16px;
            border-radius: 14px;
            border: 1px solid rgba(255,255,255,0.12);
            outline: none;
            background: rgba(255,255,255,0.055);
            color: #ffffff;
            font-size: 15px;
            transition: 0.2s ease;
        }

        .input::placeholder {
            color: rgba(255,255,255,0.32);
        }

        .input:focus {
            border-color: rgba(112,157,224,0.75);
            background: rgba(255,255,255,0.075);
            box-shadow: 0 0 0 4px rgba(60,110,180,0.12);
        }

        .password-input {
            padding-right: 70px;
        }

        .show-password {
            position: absolute;
            right: 10px;
            top: 7px;
            height: 40px;
            padding: 0 11px;
            border: 0;
            border-radius: 10px;
            background: rgba(255,255,255,0.07);
            color: #b9cbe6;
            cursor: pointer;
            font-size: 12px;
        }

        .show-password:hover {
            background: rgba(255,255,255,0.12);
        }

        .login-button {
            width: 100%;
            height: 56px;
            margin-top: 8px;
            border: 0;
            border-radius: 15px;
            background: linear-gradient(135deg, #2d67b8, #174785);
            color: #ffffff;
            font-size: 15px;
            font-weight: 700;
            cursor: pointer;
            box-shadow: 0 14px 28px rgba(18,67,125,0.28);
            transition: 0.2s ease;
        }

        .login-button:hover {
            transform: translateY(-1px);
            box-shadow: 0 18px 34px rgba(18,67,125,0.36);
        }

        .login-button:active {
            transform: translateY(0);
        }

        .form-footer {
            margin-top: 20px;
            text-align: center;
            color: rgba(255,255,255,0.48);
            font-size: 12px;
            line-height: 1.6;
        }

        .form-footer a {
            color: #a9c9f4;
            text-decoration: none;
        }

        .form-footer a:hover {
            text-decoration: underline;
        }

        .account-links {
            margin-top: 28px;
            padding-top: 24px;
            border-top: 1px solid rgba(255,255,255,0.08);
            display: flex;
            justify-content: space-between;
            gap: 12px;
            flex-wrap: wrap;
        }

        .account-links a {
            color: rgba(255,255,255,0.68);
            text-decoration: none;
            font-size: 12px;
        }

        .account-links a:hover {
            color: #ffffff;
        }

        .remember {
            display: flex;
            align-items: center;
            gap: 8px;
            margin: 3px 0 18px;
            color: rgba(255,255,255,0.56);
            font-size: 12px;
        }

        .remember input {
            accent-color: #4e83ca;
        }

        @media (max-width: 850px) {

            body {
                padding: 14px;
                align-items: flex-start;
            }

            .page {
                min-height: auto;
                margin: 12px 0;
                grid-template-columns: 1fr;
                border-radius: 24px;
            }

            .brand-panel {
                display: none;
            }

            .login-panel {
                padding: 30px 22px 28px;
            }

            .mobile-brand {
                display: flex;
                align-items: center;
                gap: 12px;
                margin-bottom: 34px;
            }

            .mobile-brand .brand-mark {
                width: 42px;
                height: 42px;
                border-radius: 13px;
                font-size: 22px;
            }

            .mobile-brand .brand-name {
                font-size: 20px;
            }

            .login-heading h2 {
                font-size: 31px;
            }
        }

        @media (max-width: 430px) {

            .login-panel {
                padding: 24px 17px;
            }

            .account-links {
                flex-direction: column;
            }
        }
    </style>
</head>

<body>

<div class="page">

    <section class="brand-panel">

        <div class="brand">
            <div class="brand-mark">F</div>

            <div>
                <div class="brand-name">FAIRMONT BANK</div>
                <div class="brand-subtitle">Customer Banking</div>
            </div>
        </div>

        <div class="welcome-copy">
            <div class="eyebrow">Private banking access</div>

            <h1>
                Welcome<br>
                back.
            </h1>

            <p>
                Sign in securely to access your Fairmont Bank
                account and manage your banking services.
            </p>
        </div>

        <div class="security-note">
            <div class="security-icon">✓</div>

            <div>
                Your connection is protected by secure encryption.
                Never share your password or authentication details
                with anyone.
            </div>
        </div>

    </section>


    <section class="login-panel">

        <div class="login-card">

            <div class="mobile-brand">

                <div class="brand-mark">F</div>

                <div>
                    <div class="brand-name">FAIRMONT BANK</div>
                    <div class="brand-subtitle">Customer Banking</div>
                </div>

            </div>


            <div class="login-heading">

                <div class="eyebrow">Customer access</div>

                <h2>Sign in</h2>

                <p>
                    Enter your customer credentials to continue.
                </p>

            </div>


            {% if error %}
                <div class="error">
                    {{ error }}
                </div>
            {% endif %}


            {% with messages = get_flashed_messages() %}
                {% if messages %}
                    {% for message in messages %}
                        <div class="error">
                            {{ message }}
                        </div>
                    {% endfor %}
                {% endif %}
            {% endwith %}


            <form method="POST" action="{{ url_for('login') }}">

                {% if request.args.get('next') %}
                    <input
                        type="hidden"
                        name="next"
                        value="{{ request.args.get('next') }}"
                    >
                {% endif %}


                <div class="field">

                    <label for="customer_id">
                        Customer ID
                    </label>

                    <input
                        id="customer_id"
                        name="customer_id"
                        class="input"
                        type="text"
                        placeholder="Enter your Customer ID"
                        autocomplete="username"
                        required
                    >

                </div>


                <div class="field">

                    <label for="password">
                        Password
                    </label>

                    <div class="input-wrap">

                        <input
                            id="password"
                            name="password"
                            class="input password-input"
                            type="password"
                            placeholder="Enter your password"
                            autocomplete="current-password"
                            required
                        >

                        <button
                            type="button"
                            class="show-password"
                            onclick="togglePassword()"
                        >
                            Show
                        </button>

                    </div>

                </div>


                <label class="remember">
                    <input type="checkbox" name="remember">
                    Remember me on this device
                </label>


                <button
                    class="login-button"
                    type="submit"
                >
                    Sign in securely
                </button>

            </form>


            <div class="account-links">

                <a href="{{ url_for('index') }}">
                    ← Back to Fairmont Bank
                </a>

                <a href="{{ url_for('open_account') }}">
                    Open an account
                </a>

            </div>


            <div class="form-footer">
                Protected customer access · Fairmont Bank
            </div>

        </div>

    </section>

</div>


<script>
function togglePassword() {

    const input = document.getElementById("password");
    const button = document.querySelector(".show-password");

    if (input.type === "password") {
        input.type = "text";
        button.textContent = "Hide";
    } else {
        input.type = "password";
        button.textContent = "Show";
    }
}
</script>

</body>
</html>
'''


LOGIN_TEMPLATE.write_text(
    login_html,
    encoding="utf-8"
)

print()
print("Fairmont Bank login page rebuilt.")
print("The old login template was backed up first.")


# ---------------------------------------------------------
# 9. VALIDATE PYTHON
# ---------------------------------------------------------

print()
print("=" * 70)
print("VALIDATING APPLICATION")
print("=" * 70)

import py_compile

try:
    py_compile.compile(
        str(APP),
        doraise=True
    )

    print("app.py syntax: OK")

except Exception as exc:

    print()
    print("ERROR: app.py validation failed.")
    print(exc)
    print()
    print("Restoring app.py from backup...")

    shutil.copy2(
        app_backup,
        APP
    )

    print("app.py restored.")
    print(
        "The login template remains backed up as well."
    )

    sys.exit(1)


# ---------------------------------------------------------
# 10. VALIDATE JINJA TEMPLATE
# ---------------------------------------------------------

try:

    from app import app

    with app.app_context():

        app.jinja_env.get_template(
            "login.html"
        )

    print("login.html template: OK")

except Exception as exc:

    print()
    print("ERROR: login.html validation failed.")
    print(exc)
    print()

    if login_backup and login_backup.exists():

        shutil.copy2(
            login_backup,
            LOGIN_TEMPLATE
        )

        print("Previous login.html restored.")

    shutil.copy2(
        app_backup,
        APP
    )

    print("Previous app.py restored.")
    sys.exit(1)


# ---------------------------------------------------------
# 11. FINAL AUTH CHECK
# ---------------------------------------------------------

try:

    from app import app

    rules = [
        rule.rule
        for rule in app.url_map.iter_rules()
    ]

    if "/login" not in rules:
        print(
            "WARNING: /login was not found in the Flask URL map."
        )

    if "/international-transfer" in rules:
        print(
            "International Transfer route: PRESENT"
        )
    else:
        print(
            "WARNING: /international-transfer route "
            "was not found."
        )

except Exception as exc:

    print()
    print("WARNING during final route check:")
    print(exc)


print()
print("=" * 70)
print("SUCCESS")
print("=" * 70)
print()
print("Authentication and login page repair completed.")
print()
print("Backups:")
print(f"  {app_backup.name}")

if login_backup:
    print(f"  {login_backup.name}")

print()
print("Database was NOT modified.")
print("Dashboard was NOT modified.")
print("UK Send Money was NOT modified.")
print("International Transfer was NOT removed.")
print()