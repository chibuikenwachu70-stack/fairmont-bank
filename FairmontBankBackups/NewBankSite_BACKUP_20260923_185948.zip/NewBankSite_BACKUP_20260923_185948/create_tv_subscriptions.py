from pathlib import Path

BASE = Path(__file__).resolve().parent
APP = BASE / "app.py"
TEMPLATES = BASE / "templates"

app_text = APP.read_text(encoding="utf-8")

# ---------------------------------------------------------
# Add TV Subscriptions route
# ---------------------------------------------------------

if '@app.route("/tv-subscriptions"' in app_text:
    print("TV Subscriptions route already exists.")
else:
    marker = '\nif __name__ == "__main__":'

    route = r'''

@app.route("/tv-subscriptions", methods=["GET", "POST"])
@login_required
def tv_subscriptions():
    customer = current_user

    providers = [
        "Sky",
        "Virgin Media",
        "NOW TV",
        "BT TV",
        "EE TV",
        "Other TV Provider"
    ]

    packages = {
        "Sky": [
            {"name": "Sky Entertainment", "amount": 26.00},
            {"name": "Sky Cinema", "amount": 13.00},
            {"name": "Sky Sports", "amount": 25.00},
        ],
        "Virgin Media": [
            {"name": "Mixit TV", "amount": 30.00},
            {"name": "Maxit TV", "amount": 50.00},
            {"name": "Sports TV", "amount": 25.00},
        ],
        "NOW TV": [
            {"name": "Entertainment Membership", "amount": 9.99},
            {"name": "Cinema Membership", "amount": 9.99},
            {"name": "Sports Membership", "amount": 34.99},
        ],
        "BT TV": [
            {"name": "Entertainment", "amount": 18.00},
            {"name": "Big Entertainment", "amount": 25.00},
            {"name": "Sports", "amount": 30.00},
        ],
        "EE TV": [
            {"name": "Entertainment", "amount": 20.00},
            {"name": "Sports", "amount": 30.00},
        ],
        "Other TV Provider": [
            {"name": "Standard Subscription", "amount": 20.00},
            {"name": "Premium Subscription", "amount": 35.00},
        ]
    }

    if request.method == "GET":
        return render_template(
            "tv_subscriptions.html",
            customer=customer,
            providers=providers,
            packages=packages
        )

    provider = request.form.get("provider", "").strip()
    package_name = request.form.get("package_name", "").strip()
    account_reference = request.form.get("account_reference", "").strip()
    payment_reference = request.form.get("payment_reference", "").strip()

    errors = []

    if provider not in providers:
        errors.append("Please select a TV provider.")

    if not account_reference:
        errors.append("Please enter your TV account or customer number.")

    selected_package = None

    if provider in packages:
        for package in packages[provider]:
            if package["name"] == package_name:
                selected_package = package
                break

    if selected_package is None:
        errors.append("Please select a valid TV subscription package.")

    amount = selected_package["amount"] if selected_package else 0.0

    if amount > float(customer.account_balance):
        errors.append("Insufficient balance for this TV subscription payment.")

    if errors:
        return render_template(
            "tv_subscriptions.html",
            customer=customer,
            providers=providers,
            packages=packages,
            errors=errors,
            provider=provider,
            package_name=package_name,
            account_reference=account_reference,
            payment_reference=payment_reference
        )

    new_balance = float(customer.account_balance) - amount

    transaction_reference = generate_transaction_reference()

    customer.account_balance = new_balance

    transaction = Transaction(
        transaction_reference=transaction_reference,
        customer_id=customer.id,
        transaction_type="TV Subscription",
        direction="Debit",
        amount=amount,
        balance_after=new_balance,
        description=f"{provider} - {package_name}",
        counterparty=provider,
        status="Completed"
    )

    db.session.add(transaction)
    db.session.commit()

    return render_template(
        "tv_subscription_confirmation.html",
        customer=customer,
        provider=provider,
        package_name=package_name,
        account_reference=account_reference,
        amount=amount,
        payment_reference=payment_reference,
        transaction_reference=transaction_reference,
        new_balance=new_balance
    )
'''

    if marker not in app_text:
        raise SystemExit(
            "ERROR: Could not find the app.py ending marker. Nothing was changed."
        )

    app_text = app_text.replace(marker, route + marker, 1)
    APP.write_text(app_text, encoding="utf-8")
    print("SUCCESS: TV Subscriptions route added.")


# ---------------------------------------------------------
# TV Subscriptions page
# ---------------------------------------------------------

tv_html = r'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TV Subscriptions | Fairmont Bank</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            font-family: Arial, Helvetica, sans-serif;
            background:
                radial-gradient(circle at top left, rgba(30, 82, 150, .35), transparent 35%),
                linear-gradient(145deg, #06152c, #0a2345 55%, #06152c);
            color: #ffffff;
        }

        .page {
            width: 100%;
            max-width: 760px;
            margin: 0 auto;
            padding: 24px 18px 50px;
        }

        .back {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: #d8e8ff;
            text-decoration: none;
            font-size: 14px;
            margin-bottom: 22px;
        }

        .card {
            background: rgba(10, 31, 61, .78);
            border: 1px solid rgba(255,255,255,.10);
            border-radius: 22px;
            padding: 24px;
            box-shadow: 0 18px 50px rgba(0,0,0,.28);
            backdrop-filter: blur(14px);
        }

        .brand {
            font-size: 13px;
            letter-spacing: 2px;
            color: #9fc7ff;
            margin-bottom: 8px;
            font-weight: 700;
        }

        h1 {
            margin: 0 0 8px;
            font-size: 28px;
        }

        .intro {
            margin: 0 0 22px;
            color: #aebfd7;
            line-height: 1.55;
        }

        .balance {
            padding: 15px 16px;
            border-radius: 15px;
            background: rgba(255,255,255,.055);
            border: 1px solid rgba(255,255,255,.08);
            margin-bottom: 22px;
        }

        .balance-label {
            color: #aebfd7;
            font-size: 13px;
            margin-bottom: 5px;
        }

        .balance-value {
            font-size: 22px;
            font-weight: 700;
        }

        .error {
            background: rgba(180, 35, 55, .18);
            border: 1px solid rgba(255, 90, 110, .30);
            color: #ffd7dc;
            border-radius: 13px;
            padding: 13px 15px;
            margin-bottom: 18px;
        }

        label {
            display: block;
            font-size: 13px;
            color: #c9d9ee;
            margin: 17px 0 8px;
        }

        select,
        input {
            width: 100%;
            padding: 14px 15px;
            border-radius: 13px;
            border: 1px solid rgba(255,255,255,.11);
            background: #0a1d39;
            color: #ffffff;
            outline: none;
            font-size: 15px;
        }

        select:focus,
        input:focus {
            border-color: #5598ed;
        }

        option {
            background: #0a1d39;
            color: #ffffff;
        }

        .button {
            width: 100%;
            margin-top: 24px;
            padding: 15px;
            border: 0;
            border-radius: 14px;
            background: #2e78d1;
            color: white;
            font-size: 15px;
            font-weight: 700;
            cursor: pointer;
        }

        .button:hover {
            background: #3d88e3;
        }

        .note {
            margin-top: 15px;
            color: #899db9;
            font-size: 12px;
            line-height: 1.5;
        }

        @media (max-width: 520px) {
            .page {
                padding: 18px 13px 40px;
            }

            .card {
                padding: 20px 16px;
                border-radius: 19px;
            }

            h1 {
                font-size: 24px;
            }
        }
    </style>
</head>

<body>

<div class="page">

    <a class="back" href="/dashboard">← Back to Dashboard</a>

    <div class="card">

        <div class="brand">FAIRMONT BANK</div>

        <h1>TV Subscriptions</h1>

        <p class="intro">
            Pay your TV subscription directly from your Fairmont Bank account.
        </p>

        <div class="balance">
            <div class="balance-label">Available Balance</div>
            <div class="balance-value">
                £{{ "{:,.2f}".format(customer.account_balance|float) }}
            </div>
        </div>

        {% if errors %}
            <div class="error">
                {% for error in errors %}
                    <div>{{ error }}</div>
                {% endfor %}
            </div>
        {% endif %}

        <form method="POST">

            <label for="provider">TV Provider</label>

            <select name="provider" id="provider" required
                    onchange="updatePackages()">

                <option value="">Select TV provider</option>

                {% for provider_name in providers %}
                    <option value="{{ provider_name }}"
                        {% if provider == provider_name %}selected{% endif %}>
                        {{ provider_name }}
                    </option>
                {% endfor %}

            </select>

            <label for="package_name">Subscription Package</label>

            <select name="package_name" id="package_name" required>
                <option value="">Select subscription package</option>
            </select>

            <label for="account_reference">
                TV Account / Customer Number
            </label>

            <input
                type="text"
                id="account_reference"
                name="account_reference"
                value="{{ account_reference or '' }}"
                placeholder="Enter account or customer number"
                maxlength="100"
                required
            >

            <label for="payment_reference">
                Payment Reference <span style="color:#8295af;">(Optional)</span>
            </label>

            <input
                type="text"
                id="payment_reference"
                name="payment_reference"
                value="{{ payment_reference or '' }}"
                placeholder="Optional reference"
                maxlength="100"
            >

            <button class="button" type="submit">
                Pay TV Subscription
            </button>

        </form>

        <div class="note">
            The subscription amount will be deducted from your available
            balance and recorded in your transaction history.
        </div>

    </div>

</div>

<script>
const packages = {{ packages | tojson }};
const selectedPackage = {{ (package_name or "") | tojson }};

function updatePackages() {
    const provider = document.getElementById("provider").value;
    const packageSelect = document.getElementById("package_name");

    packageSelect.innerHTML =
        '<option value="">Select subscription package</option>';

    if (!provider || !packages[provider]) {
        return;
    }

    packages[provider].forEach(function(item) {
        const option = document.createElement("option");

        option.value = item.name;
        option.textContent =
            item.name + " — £" + Number(item.amount).toFixed(2);

        if (item.name === selectedPackage) {
            option.selected = true;
        }

        packageSelect.appendChild(option);
    });
}

document.addEventListener("DOMContentLoaded", updatePackages);
</script>

</body>
</html>
'''

(TEMPLATES / "tv_subscriptions.html").write_text(
    tv_html,
    encoding="utf-8"
)

print("SUCCESS: templates/tv_subscriptions.html created.")


# ---------------------------------------------------------
# Confirmation page
# ---------------------------------------------------------

confirmation_html = r'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TV Subscription Confirmation | Fairmont Bank</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            font-family: Arial, Helvetica, sans-serif;
            background:
                radial-gradient(circle at top left, rgba(30, 82, 150, .35), transparent 35%),
                linear-gradient(145deg, #06152c, #0a2345 55%, #06152c);
            color: #ffffff;
        }

        .page {
            width: 100%;
            max-width: 650px;
            margin: 0 auto;
            padding: 35px 18px 50px;
        }

        .card {
            background: rgba(10, 31, 61, .80);
            border: 1px solid rgba(255,255,255,.10);
            border-radius: 22px;
            padding: 27px;
            box-shadow: 0 18px 50px rgba(0,0,0,.28);
        }

        .success {
            width: 56px;
            height: 56px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(53, 180, 116, .18);
            border: 1px solid rgba(80, 220, 145, .30);
            color: #73e3a6;
            font-size: 27px;
            margin-bottom: 18px;
        }

        .brand {
            font-size: 13px;
            letter-spacing: 2px;
            color: #9fc7ff;
            font-weight: 700;
            margin-bottom: 8px;
        }

        h1 {
            margin: 0 0 8px;
            font-size: 27px;
        }

        .intro {
            color: #aebfd7;
            margin-bottom: 24px;
        }

        .details {
            border-top: 1px solid rgba(255,255,255,.08);
        }

        .row {
            display: flex;
            justify-content: space-between;
            gap: 20px;
            padding: 14px 0;
            border-bottom: 1px solid rgba(255,255,255,.07);
        }

        .label {
            color: #91a6c2;
            font-size: 13px;
        }

        .value {
            text-align: right;
            font-size: 14px;
            font-weight: 600;
        }

        .status {
            color: #72e0a4;
        }

        .balance {
            margin-top: 20px;
            padding: 16px;
            border-radius: 15px;
            background: rgba(255,255,255,.055);
        }

        .balance-label {
            color: #9eb2cd;
            font-size: 13px;
        }

        .balance-value {
            margin-top: 5px;
            font-size: 23px;
            font-weight: 700;
        }

        .actions {
            display: flex;
            gap: 10px;
            margin-top: 22px;
        }

        .button {
            flex: 1;
            display: block;
            text-align: center;
            padding: 14px;
            border-radius: 13px;
            text-decoration: none;
            background: #2e78d1;
            color: white;
            font-weight: 700;
            font-size: 14px;
        }

        .button.secondary {
            background: rgba(255,255,255,.07);
            border: 1px solid rgba(255,255,255,.09);
        }

        @media (max-width: 520px) {
            .page {
                padding: 20px 13px 40px;
            }

            .card {
                padding: 21px 16px;
            }

            .row {
                align-items: flex-start;
            }

            .actions {
                flex-direction: column;
            }
        }
    </style>
</head>

<body>

<div class="page">

    <div class="card">

        <div class="success">✓</div>

        <div class="brand">FAIRMONT BANK</div>

        <h1>TV Subscription Paid</h1>

        <div class="intro">
            Your TV subscription payment has been successfully completed.
        </div>

        <div class="details">

            <div class="row">
                <span class="label">TV Provider</span>
                <span class="value">{{ provider }}</span>
            </div>

            <div class="row">
                <span class="label">Subscription</span>
                <span class="value">{{ package_name }}</span>
            </div>

            <div class="row">
                <span class="label">Account / Customer Number</span>
                <span class="value">{{ account_reference }}</span>
            </div>

            <div class="row">
                <span class="label">Amount</span>
                <span class="value">
                    £{{ "{:,.2f}".format(amount|float) }}
                </span>
            </div>

            {% if payment_reference %}
            <div class="row">
                <span class="label">Payment Reference</span>
                <span class="value">{{ payment_reference }}</span>
            </div>
            {% endif %}

            <div class="row">
                <span class="label">Transaction Reference</span>
                <span class="value">{{ transaction_reference }}</span>
            </div>

            <div class="row">
                <span class="label">Status</span>
                <span class="value status">Completed</span>
            </div>

        </div>

        <div class="balance">
            <div class="balance-label">New Available Balance</div>
            <div class="balance-value">
                £{{ "{:,.2f}".format(new_balance|float) }}
            </div>
        </div>

        <div class="actions">

            <a class="button" href="/transactions">
                View Transactions
            </a>

            <a class="button secondary" href="/dashboard">
                Dashboard
            </a>

        </div>

    </div>

</div>

</body>
</html>
'''

(TEMPLATES / "tv_subscription_confirmation.html").write_text(
    confirmation_html,
    encoding="utf-8"
)

print("SUCCESS: templates/tv_subscription_confirmation.html created.")


# ---------------------------------------------------------
# Connect dashboard card
# ---------------------------------------------------------

dashboard = TEMPLATES / "dashboard.html"

if dashboard.exists():

    dashboard_text = dashboard.read_text(encoding="utf-8")

    marker = "<!-- TV Subscriptions -->"
    start = dashboard_text.find(marker)

    if start != -1:

        end = dashboard_text.find("</a>", start)

        if end != -1:

            section = dashboard_text[start:end]

            if 'href="/tv-subscriptions"' not in section:

                section = section.replace(
                    'href="#"',
                    'href="/tv-subscriptions"',
                    1
                )

                dashboard_text = (
                    dashboard_text[:start]
                    + section
                    + dashboard_text[end:]
                )

                dashboard.write_text(
                    dashboard_text,
                    encoding="utf-8"
                )

                print(
                    "SUCCESS: Dashboard TV Subscriptions card "
                    "linked to /tv-subscriptions."
                )

            else:
                print(
                    "Dashboard TV Subscriptions card already "
                    "links to /tv-subscriptions."
                )

        else:
            print(
                "WARNING: TV Subscriptions card closing tag "
                "was not found."
            )

    else:
        print(
            "WARNING: TV Subscriptions dashboard card was not found."
        )

else:
    print("WARNING: templates/dashboard.html was not found.")


print()
print("TV SUBSCRIPTIONS INSTALLATION COMPLETE.")
print("Next: python -m py_compile app.py")