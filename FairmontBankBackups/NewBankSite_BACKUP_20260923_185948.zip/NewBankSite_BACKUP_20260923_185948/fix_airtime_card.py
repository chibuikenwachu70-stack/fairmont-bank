from pathlib import Path

file = Path("templates/services.html")

if not file.exists():
    raise SystemExit("ERROR: templates/services.html was not found.")

text = file.read_text(encoding="utf-8")

old = '''            <a
                href="#"
                class="service-card"
                data-service="airtime"
            >'''

new = '''            <a
                href="{{ url_for('airtime') }}"
                class="service-card"
            >'''

if old not in text:
    raise SystemExit(
        "ERROR: The exact Airtime card was not found. "
        "No changes were made."
    )

text = text.replace(old, new, 1)

file.write_text(text, encoding="utf-8")

print("SUCCESS: Airtime card has been connected directly to /airtime.")