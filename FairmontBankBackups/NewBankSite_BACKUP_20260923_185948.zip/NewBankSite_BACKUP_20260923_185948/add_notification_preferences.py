import sqlite3
from pathlib import Path

DB_PATH = Path("instance") / "fairmont.db"

if not DB_PATH.exists():
    print("ERROR: fairmont.db was not found.")
    raise SystemExit(1)

connection = sqlite3.connect(DB_PATH)
cursor = connection.cursor()

columns = cursor.execute("PRAGMA table_info(customer)").fetchall()
column_names = [column[1] for column in columns]

fields = {
    "transaction_notifications": "BOOLEAN NOT NULL DEFAULT 1",
    "security_notifications": "BOOLEAN NOT NULL DEFAULT 1",
    "account_notifications": "BOOLEAN NOT NULL DEFAULT 1",
    "promotional_notifications": "BOOLEAN NOT NULL DEFAULT 0",
}

added = []

for column, definition in fields.items():
    if column not in column_names:
        cursor.execute(
            f"ALTER TABLE customer ADD COLUMN {column} {definition}"
        )
        added.append(column)

connection.commit()
connection.close()

if added:
    print("SUCCESS: Notification preference fields added:")
    for column in added:
        print(f" - {column}")
else:
    print("INFO: Notification preference fields already exist.")

print("Existing customer and notification records were preserved.")