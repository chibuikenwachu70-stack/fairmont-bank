from app import app, db, AdminUser

print("=" * 70)
print("FAIRMONT BANK - ADMIN TABLE SETUP")
print("=" * 70)
print()

with app.app_context():
    db.create_all()

    print("Database tables checked/created successfully.")
    print("Existing customer and account data was NOT deleted or reset.")
    print()

    existing = AdminUser.query.filter_by(username="Mbappe").first()

    if existing:
        print("Admin username 'Mbappe' already exists.")
        print("No duplicate administrator was created.")
    else:
        print("Admin table is now ready.")
        print("You can now run create_admin.py again.")