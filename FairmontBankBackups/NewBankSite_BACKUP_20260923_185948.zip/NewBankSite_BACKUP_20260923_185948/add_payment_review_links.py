from pathlib import Path
import re

FILE = Path("templates/admin_payment_approvals.html")

if not FILE.exists():
    raise RuntimeError("ERROR: admin_payment_approvals.html was not found.")

text = FILE.read_text(encoding="utf-8")

if "admin_review_payment" in text:
    print("INFO: Review links are already installed.")
    raise SystemExit(0)

# Find the main payment table.
table_match = re.search(
    r"(<table\b.*?</table>)",
    text,
    flags=re.IGNORECASE | re.DOTALL
)

if not table_match:
    raise RuntimeError(
        "ERROR: Could not find the payment table in admin_payment_approvals.html."
    )

table = table_match.group(1)

# Add an Action heading after the final table heading.
thead_match = re.search(
    r"(<thead\b.*?</thead>)",
    table,
    flags=re.IGNORECASE | re.DOTALL
)

if not thead_match:
    raise RuntimeError(
        "ERROR: Could not find the table header in admin_payment_approvals.html."
    )

thead = thead_match.group(1)

# Find the last <th> in the header row.
th_matches = list(
    re.finditer(
        r"<th\b[^>]*>.*?</th>",
        thead,
        flags=re.IGNORECASE | re.DOTALL
    )
)

if not th_matches:
    raise RuntimeError(
        "ERROR: No table headings were found."
    )

last_th = th_matches[-1]

new_last_th = (
    last_th.group(0)
    + """
                            <th>Action</th>"""
)

new_thead = (
    thead[:last_th.start()]
    + new_last_th
    + thead[last_th.end():]
)

table = (
    table[:thead_match.start()]
    + new_thead
    + table[thead_match.end():]
)

# Find the table body.
tbody_match = re.search(
    r"(<tbody\b.*?</tbody>)",
    table,
    flags=re.IGNORECASE | re.DOTALL
)

if not tbody_match:
    raise RuntimeError(
        "ERROR: Could not find the payment table body."
    )

tbody = tbody_match.group(1)

# Find every payment row.
rows = list(
    re.finditer(
        r"<tr\b.*?</tr>",
        tbody,
        flags=re.IGNORECASE | re.DOTALL
    )
)

if not rows:
    raise RuntimeError(
        "ERROR: No payment rows were found."
    )

# Work backwards so positions remain valid.
changed = False

for row_match in reversed(rows):

    row = row_match.group(0)

    # Skip a header-like row if one somehow exists in tbody.
    if "<th" in row.lower():
        continue

    # Look for approval.id inside this row.
    if "approval.id" not in row:
        continue

    action_cell = """
                            <td>
                                <a
                                    href="{{ url_for('admin_review_payment', approval_id=approval.id) }}"
                                    style="
                                        display:inline-block;
                                        padding:8px 13px;
                                        border-radius:8px;
                                        background:rgba(216,185,106,0.12);
                                        border:1px solid rgba(216,185,106,0.30);
                                        color:#d8b96a;
                                        text-decoration:none;
                                        font-size:12px;
                                        font-weight:700;
                                    ">
                                    Review
                                </a>
                            </td>"""

    # Insert before the closing row tag.
    row_new = re.sub(
        r"</tr>\s*$",
        action_cell + "\n                        </tr>",
        row,
        count=1,
        flags=re.IGNORECASE
    )

    if row_new == row:
        continue

    tbody = (
        tbody[:row_match.start()]
        + row_new
        + tbody[row_match.end():]
    )

    changed = True

# If there are currently no rendered approval rows, modify the template's
# approval loop instead by adding the action cell before its </tr>.
if not changed:

    loop_match = re.search(
        r"(\{%.*?for\s+approval\s+in\s+approvals.*?%\})(.*?)(</tr>)",
        tbody,
        flags=re.IGNORECASE | re.DOTALL
    )

    if loop_match:
        before_close = loop_match.group(2)

        action_cell = """
                            <td>
                                <a
                                    href="{{ url_for('admin_review_payment', approval_id=approval.id) }}"
                                    style="
                                        display:inline-block;
                                        padding:8px 13px;
                                        border-radius:8px;
                                        background:rgba(216,185,106,0.12);
                                        border:1px solid rgba(216,185,106,0.30);
                                        color:#d8b96a;
                                        text-decoration:none;
                                        font-size:12px;
                                        font-weight:700;
                                    ">
                                    Review
                                </a>
                            </td>
"""

        new_loop = (
            loop_match.group(1)
            + before_close
            + action_cell
            + loop_match.group(3)
        )

        tbody = (
            tbody[:loop_match.start()]
            + new_loop
            + tbody[loop_match.end():]
        )

        changed = True

if not changed:
    raise RuntimeError(
        "ERROR: Could not identify the payment rows. "
        "No changes were saved."
    )

table = (
    table[:tbody_match.start()]
    + tbody
    + table[tbody_match.end():]
)

text = (
    text[:table_match.start()]
    + table
    + text[table_match.end():]
)

FILE.write_text(text, encoding="utf-8")

print("SUCCESS: Review links added to admin Payment Approvals.")