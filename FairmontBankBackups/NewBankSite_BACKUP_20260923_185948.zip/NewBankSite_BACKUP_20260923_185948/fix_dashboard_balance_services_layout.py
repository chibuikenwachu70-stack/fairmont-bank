from pathlib import Path
import re

file = Path("templates/dashboard.html")

if not file.exists():
    raise SystemExit("ERROR: templates/dashboard.html was not found.")

text = file.read_text(encoding="utf-8")

css = """
<style id="fairmont-balance-services-layout-fix">

/* ---------------------------------------------------------
   Fairmont dashboard: compact balance card
   --------------------------------------------------------- */

.balance-card {
    margin-top: 8px !important;
    margin-bottom: 10px !important;
    padding-top: 18px !important;
    padding-bottom: 18px !important;
    min-height: 0 !important;
    height: auto !important;
}

.balance-card .balance-top {
    margin-bottom: 4px !important;
}

.balance-card h2 {
    margin-top: 4px !important;
    margin-bottom: 4px !important;
}

.balance-card .account-reference,
.balance-card .customer-reference {
    margin-top: 4px !important;
    padding-top: 0 !important;
}

/* ---------------------------------------------------------
   Pull Services upward so they are visible sooner
   --------------------------------------------------------- */

.dashboard-section.services-section {
    margin-top: 8px !important;
    padding-top: 0 !important;
}

.dashboard-section.services-section .section-heading {
    margin-top: 0 !important;
    margin-bottom: 10px !important;
}

.dashboard-section.services-section h2 {
    margin-top: 0 !important;
    margin-bottom: 8px !important;
}

.dashboard-section.services-section .services-scroll,
.dashboard-section.services-section .fairmont-services-scroll {
    margin-top: 0 !important;
    padding-top: 2px !important;
}

/* Keep the compact layout on smaller screens too */
@media (max-width: 600px) {

    .balance-card {
        margin-top: 6px !important;
        margin-bottom: 8px !important;
        padding-top: 16px !important;
        padding-bottom: 16px !important;
    }

    .dashboard-section.services-section {
        margin-top: 6px !important;
    }

}

</style>
"""

# Do not add the same fix twice.
if "fairmont-balance-services-layout-fix" in text:
    raise SystemExit(
        "INFO: This balance/services layout fix is already installed."
    )

# Insert the CSS immediately before </head>.
head_match = re.search(r"</head>", text, flags=re.IGNORECASE)

if not head_match:
    raise SystemExit(
        "ERROR: </head> was not found. No changes were made."
    )

text = (
    text[:head_match.start()]
    + css
    + "\n"
    + text[head_match.start():]
)

file.write_text(text, encoding="utf-8")

print()
print("SUCCESS: Balance card made more compact.")
print("SUCCESS: Services section moved upward.")
print("SUCCESS: Existing services and dashboard functionality preserved.")
print("SUCCESS: No images or photos were created.")
print()