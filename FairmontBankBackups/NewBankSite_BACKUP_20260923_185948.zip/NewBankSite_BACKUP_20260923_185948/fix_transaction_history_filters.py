from pathlib import Path

file = Path("templates/transactions.html")

if not file.exists():
    raise SystemExit("ERROR: templates/transactions.html was not found.")

text = file.read_text(encoding="utf-8")

# Do not install the filter form twice.
if 'name="search"' in text and 'name="date_range"' in text:
    print("INFO: Transaction filters already exist.")
    print("No changes were made.")
    raise SystemExit(0)

# Find the existing transaction list section.
marker = """            <section class="transaction-list-section">"""

if marker not in text:
    raise SystemExit(
        "ERROR: The existing transaction list section was not found. "
        "No changes were made."
    )

filter_html = """            <section class="transaction-filters">

                <form
                    method="GET"
                    action="{{ url_for('transactions') }}"
                    class="transaction-filter-form">

                    <div class="transaction-search-row">

                        <input
                            type="text"
                            name="search"
                            value="{{ search }}"
                            placeholder="Search transactions, references or recipients">

                        <button type="submit">
                            Search
                        </button>

                    </div>


                    <div class="transaction-filter-row">

                        <select name="type">

                            <option value="">
                                All transaction types
                            </option>

                            {% for transaction_type in transaction_types %}

                                <option
                                    value="{{ transaction_type }}"
                                    {% if selected_type == transaction_type %}selected{% endif %}>
                                    {{ transaction_type }}
                                </option>

                            {% endfor %}

                        </select>


                        <select name="direction">

                            <option value="">
                                All activity
                            </option>

                            <option
                                value="Credit"
                                {% if selected_direction == "Credit" %}selected{% endif %}>
                                Credits
                            </option>

                            <option
                                value="Debit"
                                {% if selected_direction == "Debit" %}selected{% endif %}>
                                Debits
                            </option>

                        </select>


                        <select name="date_range">

                            <option value="">
                                All dates
                            </option>

                            <option
                                value="today"
                                {% if selected_date_range == "today" %}selected{% endif %}>
                                Today
                            </option>

                            <option
                                value="7"
                                {% if selected_date_range == "7" %}selected{% endif %}>
                                Last 7 days
                            </option>

                            <option
                                value="30"
                                {% if selected_date_range == "30" %}selected{% endif %}>
                                Last 30 days
                            </option>

                        </select>

                    </div>


                    <div class="transaction-filter-actions">

                        <a href="{{ url_for('transactions') }}">
                            Clear filters
                        </a>

                    </div>

                </form>

            </section>


"""

text = text.replace(
    marker,
    filter_html + marker,
    1
)

file.write_text(text, encoding="utf-8")

print("SUCCESS: Transaction History filter controls added.")
print()
print("Filters available:")
print("- Search transactions")
print("- Transaction type")
print("- Credit / Debit")
print("- Today")
print("- Last 7 days")
print("- Last 30 days")
print("- Clear filters")
print()
print("No transaction records were changed.")
print("No customer balances were changed.")
print("The existing Transaction History list was preserved.")