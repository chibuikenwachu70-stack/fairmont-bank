from pathlib import Path
import shutil

FILE = Path("templates/admin_customer_profile.html")

text = FILE.read_text(encoding="utf-8")

backup = Path("templates/admin_customer_profile.html.before_email_sender")
shutil.copy2(FILE, backup)

old = '''                            <div class="record-top">

                                <div class="record-title">
                                    {{ message.subject }}
                                </div>

                                <div class="record-date">
                                    {{ message.created_at.strftime(
                                        '%d %b %Y, %H:%M'
                                    ) }}
                                </div>

                            </div>
'''

new = '''                            <div class="record-top">

                                <div>
                                    <div class="record-title">
                                        {{ message.subject }}
                                    </div>

                                    {% if message.sender_type == "support" %}

                                        <div class="sender-badge sender-support">
                                            FAIRMONT BANK SUPPORT
                                        </div>

                                    {% else %}

                                        <div class="sender-badge sender-customer">
                                            CUSTOMER
                                        </div>

                                    {% endif %}

                                </div>

                                <div class="record-date">
                                    {{ message.created_at.strftime(
                                        '%d %b %Y, %H:%M'
                                    ) }}
                                </div>

                            </div>
'''

if old not in text:
    print("ERROR: Email message header block was not found.")
    print("Backup created:", backup)
    raise SystemExit(1)

text = text.replace(old, new, 1)

css_marker = '''        .record-details {'''

sender_css = '''        .sender-badge {
            display: inline-block;
            margin-top: 6px;
            padding: 4px 7px;
            border-radius: 20px;
            font-size: 8px;
            font-weight: 700;
            letter-spacing: 0.5px;
        }

        .sender-customer {
            color: #9fb3cc;
            background: rgba(159, 179, 204, 0.08);
            border: 1px solid rgba(159, 179, 204, 0.15);
        }

        .sender-support {
            color: #d8b96a;
            background: rgba(184, 149, 74, 0.08);
            border: 1px solid rgba(184, 149, 74, 0.18);
        }

'''

if css_marker not in text:
    print("ERROR: CSS insertion point was not found.")
    print("Backup created:", backup)
    raise SystemExit(1)

text = text.replace(
    css_marker,
    sender_css + css_marker,
    1
)

FILE.write_text(text, encoding="utf-8")

print("=" * 70)
print("CUSTOMER PROFILE EMAIL SENDER LABELS ADDED")
print("=" * 70)
print()
print("Customer messages will show:")
print("CUSTOMER")
print()
print("Bank replies will show:")
print("FAIRMONT BANK SUPPORT")
print()
print("Existing message records were not changed.")
print()
print("Backup created:")
print(backup)