from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DASHBOARD = BASE_DIR / "templates" / "dashboard.html"

if not DASHBOARD.exists():
    print("ERROR: templates\\dashboard.html was not found.")
    raise SystemExit(1)

html = DASHBOARD.read_text(encoding="utf-8")

# ---------------------------------------------------------
# BACKUP
# ---------------------------------------------------------

backup = DASHBOARD.with_name("dashboard_before_services_scroll_fix.html")

if not backup.exists():
    backup.write_text(html, encoding="utf-8")
    print("Backup created:")
    print(backup)
else:
    print("Backup already exists. Existing backup preserved.")


# ---------------------------------------------------------
# CSS
# ---------------------------------------------------------

css = r"""
<style id="fairmont-services-scroll-fix">

/* ========================================================
   FAIRMONT BANK SERVICES HORIZONTAL SCROLLER
   ======================================================== */

.fairmont-services-scroll {
    display: flex !important;
    flex-wrap: nowrap !important;
    overflow-x: auto !important;
    overflow-y: hidden !important;

    width: 100% !important;
    max-width: 100% !important;

    gap: 12px !important;

    padding: 4px 4px 14px 4px !important;

    scroll-behavior: smooth !important;
    scroll-snap-type: x proximity !important;

    -webkit-overflow-scrolling: touch !important;

    scrollbar-width: thin !important;

    touch-action: pan-x !important;

    box-sizing: border-box !important;
}

/* Each service stays its own card */
.fairmont-services-scroll > * {
    flex: 0 0 auto !important;
    scroll-snap-align: start !important;
}

/* Do not allow service links to shrink */
.fairmont-services-scroll a {
    flex-shrink: 0 !important;
}

/* Make the scrollbar usable on desktop */
.fairmont-services-scroll::-webkit-scrollbar {
    height: 6px;
}

.fairmont-services-scroll::-webkit-scrollbar-thumb {
    border-radius: 20px;
}

/* ========================================================
   SCROLL ARROWS
   ======================================================== */

.fairmont-services-wrapper {
    position: relative !important;
    width: 100% !important;
}

.fairmont-services-arrow {
    position: absolute !important;
    top: 50% !important;
    transform: translateY(-50%) !important;

    width: 34px !important;
    height: 34px !important;

    border: 0 !important;
    border-radius: 50% !important;

    display: flex !important;
    align-items: center !important;
    justify-content: center !important;

    cursor: pointer !important;
    z-index: 20 !important;

    font-size: 18px !important;
    line-height: 1 !important;

    box-shadow: 0 5px 18px rgba(0,0,0,.25) !important;

    opacity: .95 !important;
}

.fairmont-services-arrow-left {
    left: 3px !important;
}

.fairmont-services-arrow-right {
    right: 3px !important;
}

.fairmont-services-arrow:hover {
    transform: translateY(-50%) scale(1.05) !important;
}

.fairmont-services-arrow:active {
    transform: translateY(-50%) scale(.96) !important;
}

/* On small screens, keep arrows subtle */
@media (max-width: 600px) {

    .fairmont-services-arrow {
        width: 30px !important;
        height: 30px !important;
        font-size: 16px !important;
    }

}

</style>
"""


# ---------------------------------------------------------
# JAVASCRIPT
# ---------------------------------------------------------

javascript = r"""
<script id="fairmont-services-scroll-fix-js">

document.addEventListener("DOMContentLoaded", function () {

    /*
     * Find the Services heading.
     */
    const headings = Array.from(
        document.querySelectorAll("h1, h2, h3, h4")
    );

    const servicesHeading = headings.find(function (heading) {
        return heading.textContent.trim().toLowerCase() === "services";
    });

    if (!servicesHeading) {
        console.log("Fairmont Services: heading not found.");
        return;
    }

    /*
     * Find the section containing Services.
     */
    const servicesSection =
        servicesHeading.closest("section") ||
        servicesHeading.parentElement;

    if (!servicesSection) {
        console.log("Fairmont Services: section not found.");
        return;
    }

    /*
     * Find links belonging to the Services area.
     */
    const serviceLinks =
        Array.from(servicesSection.querySelectorAll("a"));

    if (!serviceLinks.length) {
        console.log("Fairmont Services: service links not found.");
        return;
    }

    /*
     * Find the common parent containing the service cards.
     */
    let serviceContainer = null;

    for (const link of serviceLinks) {

        let parent = link.parentElement;

        while (
            parent &&
            parent !== servicesSection
        ) {

            const linksInside =
                parent.querySelectorAll("a");

            if (
                linksInside.length >= 3 &&
                linksInside.length <= serviceLinks.length
            ) {
                serviceContainer = parent;
                break;
            }

            parent = parent.parentElement;
        }

        if (serviceContainer) {
            break;
        }
    }

    /*
     * Fallback: use the first element after the Services heading.
     */
    if (!serviceContainer) {

        serviceContainer =
            servicesHeading.nextElementSibling;

    }

    if (!serviceContainer) {
        console.log("Fairmont Services: container not found.");
        return;
    }

    /*
     * Apply the scrolling class.
     */
    serviceContainer.classList.add(
        "fairmont-services-scroll"
    );

    /*
     * Prevent nested scrolling containers.
     */
    serviceContainer.style.overflowX = "auto";
    serviceContainer.style.overflowY = "hidden";

    /*
     * Wrap the services container.
     */
    let wrapper = serviceContainer.parentElement;

    if (!wrapper.classList.contains(
        "fairmont-services-wrapper"
    )) {

        const newWrapper =
            document.createElement("div");

        newWrapper.className =
            "fairmont-services-wrapper";

        serviceContainer.parentNode.insertBefore(
            newWrapper,
            serviceContainer
        );

        newWrapper.appendChild(
            serviceContainer
        );

        wrapper = newWrapper;
    }

    /*
     * Avoid creating duplicate arrows.
     */
    if (
        !wrapper.querySelector(
            ".fairmont-services-arrow-left"
        )
    ) {

        const leftButton =
            document.createElement("button");

        leftButton.type = "button";

        leftButton.className =
            "fairmont-services-arrow " +
            "fairmont-services-arrow-left";

        leftButton.setAttribute(
            "aria-label",
            "Scroll services left"
        );

        leftButton.innerHTML = "‹";

        wrapper.appendChild(leftButton);


        const rightButton =
            document.createElement("button");

        rightButton.type = "button";

        rightButton.className =
            "fairmont-services-arrow " +
            "fairmont-services-arrow-right";

        rightButton.setAttribute(
            "aria-label",
            "Scroll services right"
        );

        rightButton.innerHTML = "›";

        wrapper.appendChild(rightButton);


        /*
         * Scroll left.
         */
        leftButton.addEventListener(
            "click",
            function () {

                serviceContainer.scrollBy({
                    left: -300,
                    behavior: "smooth"
                });

            }
        );


        /*
         * Scroll right.
         */
        rightButton.addEventListener(
            "click",
            function () {

                serviceContainer.scrollBy({
                    left: 300,
                    behavior: "smooth"
                });

            }
        );

    }


    /*
     * Mouse wheel support on desktop.
     * Scrolling the mouse wheel while over
     * Services moves horizontally.
     */
    serviceContainer.addEventListener(
        "wheel",
        function (event) {

            if (Math.abs(event.deltaY) >
                Math.abs(event.deltaX)) {

                event.preventDefault();

                serviceContainer.scrollLeft +=
                    event.deltaY;

            }

        },
        { passive: false }
    );


    /*
     * Mouse drag support.
     */
    let isDragging = false;
    let startX = 0;
    let startScrollLeft = 0;

    serviceContainer.addEventListener(
        "mousedown",
        function (event) {

            isDragging = true;

            startX = event.pageX;

            startScrollLeft =
                serviceContainer.scrollLeft;

            serviceContainer.style.cursor =
                "grabbing";

        }
    );

    document.addEventListener(
        "mouseup",
        function () {

            isDragging = false;

            serviceContainer.style.cursor =
                "";

        }
    );

    serviceContainer.addEventListener(
        "mousemove",
        function (event) {

            if (!isDragging) {
                return;
            }

            const distance =
                event.pageX - startX;

            serviceContainer.scrollLeft =
                startScrollLeft - distance;

        }
    );


    /*
     * Keyboard accessibility.
     */
    serviceContainer.setAttribute(
        "tabindex",
        "0"
    );

    serviceContainer.addEventListener(
        "keydown",
        function (event) {

            if (event.key === "ArrowRight") {

                event.preventDefault();

                serviceContainer.scrollBy({
                    left: 250,
                    behavior: "smooth"
                });

            }

            if (event.key === "ArrowLeft") {

                event.preventDefault();

                serviceContainer.scrollBy({
                    left: -250,
                    behavior: "smooth"
                });

            }

        }
    );


    /*
     * Make sure International Transfer remains
     * reachable and clickable.
     */
    const internationalLink =
        Array.from(
            serviceContainer.querySelectorAll("a")
        ).find(function (link) {

            return link.textContent
                .toLowerCase()
                .includes("international");

        });

    if (internationalLink) {

        internationalLink.href =
            "/international-transfer";

        internationalLink.style.pointerEvents =
            "auto";

        internationalLink.style.cursor =
            "pointer";

    }


    console.log(
        "Fairmont Services: horizontal scrolling enabled."
    );

});

</script>
"""


# ---------------------------------------------------------
# INSERT CSS
# ---------------------------------------------------------

if "fairmont-services-scroll-fix" not in html:

    if "</head>" in html:

        html = html.replace(
            "</head>",
            css + "\n</head>",
            1
        )

    else:

        html = css + "\n" + html


# ---------------------------------------------------------
# INSERT JAVASCRIPT
# ---------------------------------------------------------

if "fairmont-services-scroll-fix-js" not in html:

    if "</body>" in html:

        html = html.replace(
            "</body>",
            javascript + "\n</body>",
            1
        )

    else:

        html += "\n" + javascript


# ---------------------------------------------------------
# SAVE
# ---------------------------------------------------------

DASHBOARD.write_text(
    html,
    encoding="utf-8"
)

print()
print("==============================================")
print("FAIRMONT SERVICES SCROLL FIX COMPLETE")
print("==============================================")
print()
print("Dashboard updated:")
print(DASHBOARD)
print()
print("Backup:")
print(backup)
print()
print("The Services area now supports:")
print("- Horizontal scrolling")
print("- Mouse wheel scrolling")
print("- Mouse dragging")
print("- Touch/swipe scrolling")
print("- Left/right scroll buttons")
print("- Keyboard left/right arrows")
print("- International Transfer remains clickable")
print()