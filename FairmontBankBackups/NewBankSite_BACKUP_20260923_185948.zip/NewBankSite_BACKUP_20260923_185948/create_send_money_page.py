from pathlib import Path

BASE_DIR = Path(r"C:\Users\DON J\Documents\NewBankSite")
TEMPLATES_DIR = BASE_DIR / "templates"

TEMPLATES_DIR.mkdir(
    parents=True,
    exist_ok=True
)


send_money_html = r'''<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Send Money | Fairmont Bank</title>

    <link
        rel="stylesheet"
        href="{{ url_for('static', filename='css/style.css') }}"
    >

</head>

<body class="transaction-page">

<div class="transaction-shell">

    <div class="transaction-header">

        <a
            href="/dashboard"
            class="transaction-back-button"
            aria-label="Back to dashboard"
        >
            ‹
        </a>

        <div>

            <div class="transaction-eyebrow">
                PAYMENTS
            </div>

            <h1>
                Send Money
            </h1>

        </div>

    </div>


    <div class="transaction-account-card">

        <div>

            <p>
                AVAILABLE BALANCE
            </p>

            <h2>
                £{{ "{:,.2f}".format(customer.account_balance) }}
            </h2>

        </div>

        <div class="transaction-customer-reference">

            Customer ID<br>

            <strong>
                {{ customer.customer_id }}
            </strong>

        </div>

    </div>


    {% if error %}

    <div
        class="send-money-error"
        role="alert"
    >
        {{ error }}
    </div>

    {% endif %}


    <form
        method="POST"
        action="/send-money"
        class="send-money-form"
    >

        <div class="send-money-field">

            <label for="recipient_id">
                Recipient Customer ID
            </label>

            <input
                type="text"
                id="recipient_id"
                name="recipient_id"
                value="{{ recipient_id or '' }}"
                placeholder="Example: FB12345678"
                maxlength="20"
                autocomplete="off"
                required
            >

            <small>
                Enter the Customer ID of another active Fairmont Bank customer.
            </small>

        </div>


        <div class="send-money-field">

            <label for="amount">
                Amount
            </label>

            <div class="send-money-amount">

                <span>
                    £
                </span>

                <input
                    type="number"
                    id="amount"
                    name="amount"
                    value="{{ amount or '' }}"
                    placeholder="0.00"
                    min="0.01"
                    step="0.01"
                    inputmode="decimal"
                    required
                >

            </div>

        </div>


        <div class="send-money-field">

            <label for="description">
                Description
                <span>(optional)</span>
            </label>

            <input
                type="text"
                id="description"
                name="description"
                value="{{ description or '' }}"
                placeholder="What is this transfer for?"
                maxlength="255"
            >

        </div>


        <div class="send-money-notice">

            <strong>
                Before you send
            </strong>

            <p>
                Check the recipient Customer ID and amount carefully.
                The transfer will update both customer balances and
                create transaction records for both accounts.
            </p>

        </div>


        <button
            type="submit"
            class="send-money-button"
        >
            Send Money
        </button>

    </form>


    <a
        href="/transactions"
        class="transaction-dashboard-button"
    >
        View Transaction History
    </a>

</div>

</body>

</html>
'''


confirmation_html = r'''<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Transfer Complete | Fairmont Bank</title>

    <link
        rel="stylesheet"
        href="{{ url_for('static', filename='css/style.css') }}"
    >

</head>

<body class="transaction-page">

<div class="transaction-shell">

    <div class="transaction-header">

        <a
            href="/dashboard"
            class="transaction-back-button"
            aria-label="Back to dashboard"
        >
            ‹
        </a>

        <div>

            <div class="transaction-eyebrow">
                PAYMENT COMPLETE
            </div>

            <h1>
                Transfer Complete
            </h1>

        </div>

    </div>


    <div class="transaction-detail-card">

        <div class="transaction-detail-status">

            <div class="transaction-large-icon transaction-credit">
                ✓
            </div>

            <div class="transaction-detail-label">
                Amount Sent
            </div>

            <h2>
                £{{ "{:,.2f}".format(transaction.amount) }}
            </h2>

            <span>
                Completed successfully
            </span>

        </div>


        <div class="transaction-detail-list">

            <div class="transaction-detail-row">

                <span>
                    Recipient
                </span>

                <strong>
                    {{ recipient.full_name }}
                </strong>

            </div>


            <div class="transaction-detail-row">

                <span>
                    Customer ID
                </span>

                <strong>
                    {{ recipient.customer_id }}
                </strong>

            </div>


            <div class="transaction-detail-row">

                <span>
                    Transaction Type
                </span>

                <strong>
                    {{ transaction.transaction_type }}
                </strong>

            </div>


            <div class="transaction-detail-row">

                <span>
                    Direction
                </span>

                <strong>
                    {{ transaction.direction }}
                </strong>

            </div>


            <div class="transaction-detail-row">

                <span>
                    Reference
                </span>

                <strong>
                    {{ transaction.transaction_reference }}
                </strong>

            </div>


            <div class="transaction-detail-row">

                <span>
                    Date & Time
                </span>

                <strong>
                    {{ transaction.created_at.strftime("%d %b %Y, %H:%M") }}
                </strong>

            </div>


            <div class="transaction-detail-row">

                <span>
                    Balance After
                </span>

                <strong>
                    £{{ "{:,.2f}".format(transaction.balance_after) }}
                </strong>

            </div>


            <div class="transaction-detail-row">

                <span>
                    Status
                </span>

                <strong class="transaction-status-value">
                    {{ transaction.status }}
                </strong>

            </div>

        </div>

    </div>


    <a
        href="/dashboard"
        class="transaction-dashboard-button"
    >
        Return to Dashboard
    </a>


    <a
        href="/transactions"
        class="transaction-dashboard-button"
    >
        View Transaction History
    </a>

</div>

</body>

</html>
'''


(TEMPLATES_DIR / "send_money.html").write_text(
    send_money_html,
    encoding="utf-8"
)

(TEMPLATES_DIR / "transfer_confirmation.html").write_text(
    confirmation_html,
    encoding="utf-8"
)

print("SUCCESS: send_money.html created.")
print("SUCCESS: transfer_confirmation.html created.")