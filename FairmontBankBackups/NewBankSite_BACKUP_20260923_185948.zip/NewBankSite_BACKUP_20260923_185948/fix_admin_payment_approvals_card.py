from pathlib import Path

FILE = Path("templates/admin_dashboard.html")

text = FILE.read_text(encoding="utf-8")

start_marker = '<a href="{{ url_for("admin_transactions") }}"'

start = text.find(start_marker)

if start == -1:
    raise RuntimeError(
        "ERROR: Could not find the broken Transaction Management link. "
        "No changes were made."
    )

# The broken section contains the Payment Approvals link nested inside
# the Transaction Management link. Find the second closing </a>.
first_close = text.find("</a>", start)

if first_close == -1:
    raise RuntimeError(
        "ERROR: Could not find the first closing link tag. "
        "No changes were made."
    )

second_close = text.find("</a>", first_close + len("</a>"))

if second_close == -1:
    raise RuntimeError(
        "ERROR: Could not find the second closing link tag. "
        "No changes were made."
    )

end = second_close + len("</a>")

replacement = '''<a href="{{ url_for("admin_payment_approvals") }}" class="action">
                        <div class="action-title">
                            Payment Approvals
                        </div>

                        <div class="action-text">
                            Review and approve pending customer payments.
                        </div>
                    </a>

                    <a href="{{ url_for("admin_transactions") }}" class="action">
                        <div class="action-title">
                            Transaction Management
                        </div>

                        <div class="action-text">
                            Review banking transaction activity.
                        </div>
                    </a>'''

text = text[:start] + replacement + text[end:]

FILE.write_text(text, encoding="utf-8")

print("SUCCESS: Payment Approvals and Transaction Management cards repaired.")