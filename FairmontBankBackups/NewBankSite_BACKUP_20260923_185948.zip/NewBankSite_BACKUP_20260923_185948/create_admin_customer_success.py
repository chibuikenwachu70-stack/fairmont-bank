from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
TEMPLATES = BASE_DIR / "templates"

TEMPLATES.mkdir(exist_ok=True)

template = r'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Customer Account Created | Fairmont Bank</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            font-family: Arial, Helvetica, sans-serif;
            background:
                radial-gradient(
                    circle at top left,
                    rgba(184,149,74,.10),
                    transparent 32%
                ),
                #071525;
            color: #edf3fb;
        }

        .page {
            width: 100%;
            max-width: 850px;
            margin: 0 auto;
            padding: 40px 20px 60px;
        }

        .card {
            background: rgba(12,31,51,.94);
            border: 1px solid rgba(184,149,74,.20);
            border-radius: 22px;
            padding: 34px;
            box-shadow: 0 25px 70px rgba(0,0,0,.30);
        }

        .brand {
            text-align: center;
            color: #ffffff;
            font-size: 20px;
            font-weight: 800;
            letter-spacing: 1.5px;
            margin-bottom: 30px;
        }

        .brand span {
            color: #d5b467;
        }

        .success-icon {
            width: 64px;
            height: 64px;
            margin: 0 auto 20px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(70,190,125,.12);
            border: 1px solid rgba(100,220,155,.30);
            color: #9de7bc;
            font-size: 30px;
            font-weight: 800;
        }

        h1 {
            text-align: center;
            margin: 0 0 9px;
            font-size: 29px;
        }

        .intro {
            text-align: center;
            margin: 0 auto 30px;
            max-width: 600px;
            color: #8fa5bd;
            line-height: 1.6;
            font-size: 14px;
        }

        .section {
            border-top: 1px solid rgba(255,255,255,.08);
            padding-top: 24px;
            margin-top: 24px;
        }

        .section h2 {
            margin: 0 0 16px;
            font-size: 16px;
            color: #ffffff;
        }

        .details {
            display: grid;
            grid-template-columns: repeat(2, minmax(0,1fr));
            gap: 1px;
            background: rgba(255,255,255,.06);
            border: 1px solid rgba(255,255,255,.07);
            border-radius: 13px;
            overflow: hidden;
        }

        .detail {
            padding: 15px;
            background: rgba(7,21,37,.55);
        }

        .label {
            color: #7188a1;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: .7px;
            margin-bottom: 6px;
        }

        .value {
            color: #f1f5f9;
            font-size: 14px;
            font-weight: 700;
            word-break: break-word;
        }

        .funding {
            margin-top: 20px;
            padding: 18px;
            border-radius: 13px;
            background: rgba(184,149,74,.07);
            border: 1px solid rgba(184,149,74,.18);
        }

        .funding-label {
            color: #8499b0;
            font-size: 12px;
            margin-bottom: 7px;
        }

        .funding-value {
            color: #d5b467;
            font-size: 25px;
            font-weight: 800;
        }

        .actions {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 12px;
            margin-top: 30px;
        }

        .button {
            display: inline-block;
            text-decoration: none;
            border-radius: 11px;
            padding: 13px 20px;
            background: #b8954a;
            color: #081625;
            font-size: 14px;
            font-weight: 800;
        }

        .button:hover {
            background: #d5b467;
        }

        .button.secondary {
            background: rgba(255,255,255,.06);
            border: 1px solid rgba(255,255,255,.10);
            color: #c8d5e3;
        }

        .button.secondary:hover {
            background: rgba(255,255,255,.10);
        }

        @media (max-width: 650px) {

            .page {
                padding: 20px 12px 40px;
            }

            .card {
                padding: 24px 17px;
            }

            .details {
                grid-template-columns: 1fr;
            }

            .actions {
                flex-direction: column;
            }

            .button {
                width: 100%;
                text-align: center;
            }
        }
    </style>
</head>

<body>

<div class="page">

    <div class="card">

        <div class="brand">
            FAIRMONT <span>BANK</span>
        </div>

        <div class="success-icon">
            ✓
        </div>

        <h1>Customer Account Created</h1>

        <p class="intro">
            The new Fairmont Bank customer account has been created
            successfully.
        </p>

        <div class="section">

            <h2>Customer Account</h2>

            <div class="details">

                <div class="detail">
                    <div class="label">
                        Account Holder
                    </div>

                    <div class="value">
                        {{ customer.full_name }}
                    </div>
                </div>

                <div class="detail">
                    <div class="label">
                        Customer ID
                    </div>

                    <div class="value">
                        {{ customer.customer_id }}
                    </div>
                </div>

                <div class="detail">
                    <div class="label">
                        Account Number
                    </div>

                    <div class="value">
                        {{ customer.account_number }}
                    </div>
                </div>

                <div class="detail">
                    <div class="label">
                        Account Type
                    </div>

                    <div class="value">
                        {{ customer.account_type|title }}
                    </div>
                </div>

                <div class="detail">
                    <div class="label">
                        Email
                    </div>

                    <div class="value">
                        {{ customer.email }}
                    </div>
                </div>

                <div class="detail">
                    <div class="label">
                        Phone
                    </div>

                    <div class="value">
                        {{ customer.phone }}
                    </div>
                </div>

                <div class="detail">
                    <div class="label">
                        Country
                    </div>

                    <div class="value">
                        {{ customer.country|title }}
                    </div>
                </div>

                <div class="detail">
                    <div class="label">
                        Account Status
                    </div>

                    <div class="value">
                        {{ customer.account_status }}
                    </div>
                </div>

            </div>

            <div class="funding">

                <div class="funding-label">
                    Opening Balance
                </div>

                <div class="funding-value">
                    £{{ "{:,.2f}".format(customer.account_balance|float) }}
                </div>

            </div>

        </div>

        {% if initial_funding|float > 0 %}

        <div class="section">

            <h2>Initial Funding</h2>

            <div class="details">

                <div class="detail">
                    <div class="label">
                        Funding Amount
                    </div>

                    <div class="value">
                        £{{ "{:,.2f}".format(initial_funding|float) }}
                    </div>
                </div>

                <div class="detail">
                    <div class="label">
                        Funding Reference
                    </div>

                    <div class="value">
                        {{ funding_reference or "Not provided" }}
                    </div>
                </div>

                <div class="detail">
                    <div class="label">
                        Transaction Type
                    </div>

                    <div class="value">
                        Account Funding
                    </div>
                </div>

                <div class="detail">
                    <div class="label">
                        Transaction Reference
                    </div>

                    <div class="value">
                        {{ transaction_reference }}
                    </div>
                </div>

                <div
                    class="detail"
                    style="grid-column: 1 / -1;"
                >
                    <div class="label">
                        Description
                    </div>

                    <div class="value">
                        {{ funding_description or "Initial account funding" }}
                    </div>
                </div>

            </div>

        </div>

        {% endif %}

        <div class="actions">

            <a
                href="{{ url_for('admin_create_customer') }}"
                class="button"
            >
                Create Another Customer
            </a>

            <a
                href="{{ url_for('admin_accounts') }}"
                class="button secondary"
            >
                Account Management
            </a>

            <a
                href="{{ url_for('admin_customer_profile', customer_id=customer.id) }}"
                class="button secondary"
            >
                View Customer
            </a>

        </div>

    </div>

</div>

</body>
</html>
'''

output = TEMPLATES / "admin_create_customer_success.html"

output.write_text(
    template,
    encoding="utf-8"
)

print()
print("=" * 70)
print("CUSTOMER ACCOUNT SUCCESS PAGE CREATED")
print("=" * 70)
print()
print(output)
print()
print("Existing customer records were not changed.")
print()