from pathlib import Path

BASE_DIR = Path(r"C:\Users\DON J\Documents\NewBankSite")
APP_FILE = BASE_DIR / "app.py"

text = APP_FILE.read_text(encoding="utf-8")


# Add permanent session configuration after SECRET_KEY
old_config = '''app.config["SECRET_KEY"] = "change-this-before-production"
'''

new_config = '''app.config["SECRET_KEY"] = "change-this-before-production"

# Keep the authenticated customer session available while
# navigating between protected customer pages.
app.config["SESSION_PERMANENT"] = True
'''


if "app.config[\"SESSION_PERMANENT\"]" not in text:

    if old_config not in text:

        print("ERROR: Could not find SECRET_KEY configuration.")
        raise SystemExit(1)

    text = text.replace(
        old_config,
        new_config,
        1
    )

    APP_FILE.write_text(
        text,
        encoding="utf-8"
    )

    print("SUCCESS: Session configuration added.")

else:

    print("Session configuration already exists.")


print()
print("==============================================")
print("SESSION FIX COMPLETED")
print("==============================================")