from pathlib import Path
import re

file = Path("templates/dashboard.html")

if not file.exists():
    raise SystemExit("ERROR: templates/dashboard.html was not found.")

text = file.read_text(encoding="utf-8")

# Add the visible "Email the Bank" label to the existing
# Email Bank header button.
pattern = (
    r'(<a\s+href=["\']/email-bank["\']'
    r'[^>]*class=["\']dashboard-email-button["\'][^>]*>.*?)'
    r'(</a>)'
)

match = re.search(pattern, text, flags=re.IGNORECASE | re.DOTALL)

if not match:
    raise SystemExit(
        "ERROR: Existing Email Bank header button was not found."
    )

button_content = match.group(1)

# Do not add the label twice.
if "Email the Bank" not in button_content:

    label = """
                        <span class="dashboard-email-label">
                            Email the Bank
                        </span>
"""

    button_content += label

    text = (
        text[:match.start(1)]
        + button_content
        + text[match.end(1):]
    )

# Add styling for the visible label.
if "dashboard-email-label" not in text:

    css = """
<style id="email-bank-visible-label-css">

.dashboard-email-button {
    gap: 8px;
    white-space: nowrap;
}

.dashboard-email-label {
    font-size: 14px;
    font-weight: 600;
    line-height: 1;
    color: inherit;
}

</style>
"""

    head = re.search(r"</head>", text, flags=re.IGNORECASE)

    if not head:
        raise SystemExit(
            "ERROR: </head> was not found. No changes were saved."
        )

    text = (
        text[:head.start()]
        + css
        + "\n"
        + text[head.start():]
    )

file.write_text(text, encoding="utf-8")

print()
print("SUCCESS: 'Email the Bank' is now visible beside the envelope.")
print("SUCCESS: Envelope remains beside the notification bell.")
print("SUCCESS: The existing /email-bank link was preserved.")
print("SUCCESS: No other dashboard services were changed.")
print()