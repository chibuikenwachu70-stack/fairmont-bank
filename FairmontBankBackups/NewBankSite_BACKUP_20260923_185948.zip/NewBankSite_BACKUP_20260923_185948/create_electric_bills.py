from pathlib import Path

APP = Path("app.py")
SERVICES = Path("templates/services.html")
DASHBOARD = Path("templates/dashboard.html")

app_text = APP.read_text(encoding="utf-8")

route_marker = '''# ============================================================
# START APPLICATION
# ============================================================
'''

if route_marker not in app_text:
    print("ERROR: START APPLICATION marker was not found in app.py.")
    raise SystemExit(1)

if '@app.route("/electric-bills"' in app_text:
    print("Electric Bills route already exists. No app.py change made.")
else:
    route_code = '''

# ============================================================
# ELECTRIC BILLS
# ============================================================

@app.route("/electric-bills", methods=["GET", "POST"])
@login_required
def electric_bills():

    customer = current_user

    if request.method == "GET":
        return render_template(
            "electric_bills.html",
            customer=customer
        )

    provider = request.form.get(
        "provider",
        ""
    ).strip()

    meter_number = request.form.get(
        "meter_number",
        ""
    ).strip()

    amount_text = request.form.get(
        "amount",
        ""
    ).strip()

    payment_reference = request.form.get(
        "payment_reference",
        ""
    ).strip()

    errors = []

    if not provider:
        errors.append("Please enter the electricity provider.")

    if not meter_number:
        errors.append("Please enter the meter or account number.")

    try:
        amount = float(amount_text)
    except (TypeError, ValueError):
        amount = 0

    if amount <= 0:
        errors.append("Please enter a valid payment amount.")

    if amount > float(customer.account_balance):
        errors.append("Insufficient balance for this payment.")

    if errors:
        return render_template(
            "electric_bills.html",
            customer=customer,
            errors=errors,
            provider=provider,
            meter_number=meter_number,
            amount=amount_text,
            payment_reference=payment_reference
        )

    new_balance = float(customer.account_balance) - amount

    transaction_reference = generate_transaction_reference()

    customer.account_balance = new_balance

    transaction = Transaction(
        transaction_reference=transaction_reference,
        customer_id=customer.id,
        transaction_type="Electricity Bill",
        direction="Debit",
        amount=amount,
        balance_after=new_balance,
        description="Electricity bill payment",
        counterparty=provider,
        status="Completed"
    )

    db.session.add(transaction)
    db.session.commit()

    return render_template(
        "electric_bill_confirmation.html",
        customer=customer,
        provider=provider,
        meter_number=meter_number,
        amount=amount,
        payment_reference=payment_reference,
        transaction_reference=transaction_reference,
        new_balance=new_balance
    )

'''

    app_text = app_text.replace(
        route_marker,
        route_code + "\n" + route_marker,
        1
    )

    APP.write_text(app_text, encoding="utf-8")
    print("SUCCESS: Electric Bills route added to app.py.")


electric_template = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Electric Bills | Fairmont Bank</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            font-family: Arial, Helvetica, sans-serif;
            background:
                radial-gradient(circle at top right, rgba(43, 83, 145, 0.28), transparent 38%),
                linear-gradient(145deg, #061426, #0b1d34 55%, #071426);
            color: #ffffff;
        }

        .page {
            width: min(100%, 720px);
            margin: 0 auto;
            padding: 24px 18px 45px;
        }

        .back {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: #dbe9ff;
            text-decoration: none;
            margin-bottom: 28px;
            font-size: 14px;
        }

        .brand {
            text-align: center;
            margin-bottom: 28px;
        }

        .brand-mark {
            font-size: 25px;
            font-weight: 800;
            letter-spacing: 2px;
        }

        .brand-subtitle {
            margin-top: 6px;
            color: #91a7c5;
            font-size: 12px;
            letter-spacing: 1.4px;
        }

        .card {
            background: rgba(16, 36, 62, 0.78);
            border: 1px solid rgba(159, 190, 229, 0.16);
            border-radius: 24px;
            padding: 25px 20px;
            box-shadow: 0 18px 45px rgba(0, 0, 0, 0.28);
            backdrop-filter: blur(15px);
        }

        h1 {
            margin: 0 0 10px;
            font-size: 29px;
        }

        .intro {
            color: #9fb1c9;
            line-height: 1.6;
            margin: 0 0 22px;
        }

        .balance {
            background: rgba(7, 22, 40, 0.75);
            border: 1px solid rgba(159, 190, 229, 0.12);
            border-radius: 17px;
            padding: 17px;
            margin-bottom: 22px;
        }

        .balance-label {
            color: #91a7c5;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 7px;
        }

        .balance-value {
            font-size: 25px;
            font-weight: 700;
        }

        .error-box {
            background: rgba(132, 35, 45, 0.25);
            border: 1px solid rgba(235, 100, 115, 0.35);
            color: #ffd8dc;
            border-radius: 15px;
            padding: 13px 15px;
            margin-bottom: 18px;
        }

        .error-box div {
            margin: 4px 0;
        }

        label {
            display: block;
            margin: 18px 0 8px;
            font-size: 13px;
            color: #dbe6f5;
            font-weight: 600;
        }

        input,
        select {
            width: 100%;
            padding: 14px 15px;
            border-radius: 13px;
            border: 1px solid rgba(160, 188, 222, 0.18);
            background: rgba(6, 20, 38, 0.82);
            color: #ffffff;
            outline: none;
            font-size: 15px;
        }

        input:focus,
        select:focus {
            border-color: rgba(121, 169, 232, 0.65);
        }

        select option {
            background: #0b1d34;
            color: #ffffff;
        }

        .hint {
            color: #8297b4;
            font-size: 12px;
            margin-top: 7px;
        }

        button {
            width: 100%;
            margin-top: 24px;
            padding: 15px;
            border: 0;
            border-radius: 14px;
            background: #e8eef8;
            color: #071426;
            font-size: 15px;
            font-weight: 700;
            cursor: pointer;
        }

        button:hover {
            background: #ffffff;
        }

        .secure {
            text-align: center;
            color: #7187a4;
            font-size: 12px;
            margin-top: 18px;
            line-height: 1.5;
        }
    </style>
</head>

<body>

<div class="page">

    <a class="back" href="/services">← Services</a>

    <div class="brand">
        <div class="brand-mark">F FAIRMONT BANK</div>
        <div class="brand-subtitle">EVERYDAY BANKING</div>
    </div>

    <div class="card">

        <h1>Electric Bills</h1>

        <p class="intro">
            Pay your electricity bill directly from your Fairmont Bank account.
        </p>

        <div class="balance">
            <div class="balance-label">Available balance</div>
            <div class="balance-value">
                £{{ "%.2f"|format(customer.account_balance) }}
            </div>
        </div>

        {% if errors %}
        <div class="error-box">
            {% for error in errors %}
                <div>{{ error }}</div>
            {% endfor %}
        </div>
        {% endif %}

        <form method="POST">

            <label for="provider">Electricity provider</label>

            <input
                type="text"
                id="provider"
                name="provider"
                placeholder="Enter electricity provider"
                value="{{ provider|default('') }}"
                required
            >

            <label for="meter_number">Meter / account number</label>

            <input
                type="text"
                id="meter_number"
                name="meter_number"
                placeholder="Enter meter or account number"
                value="{{ meter_number|default('') }}"
                required
            >

            <label for="amount">Payment amount</label>

            <input
                type="number"
                id="amount"
                name="amount"
                min="0.01"
                step="0.01"
                placeholder="0.00"
                value="{{ amount|default('') }}"
                required
            >

            <label for="payment_reference">
                Payment reference (optional)
            </label>

            <input
                type="text"
                id="payment_reference"
                name="payment_reference"
                placeholder="Optional reference"
                value="{{ payment_reference|default('') }}"
            >

            <button type="submit">
                Continue Payment
            </button>

        </form>

        <div class="secure">
            Successful electricity payments are recorded in your
            Fairmont transaction history.
        </div>

    </div>

</div>

</body>
</html>
'''

Path("templates/electric_bills.html").write_text(
    electric_template,
    encoding="utf-8"
)

confirmation_template = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Electric Bill Payment | Fairmont Bank</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            font-family: Arial, Helvetica, sans-serif;
            background:
                radial-gradient(circle at top right, rgba(43, 83, 145, 0.28), transparent 38%),
                linear-gradient(145deg, #061426, #0b1d34 55%, #071426);
            color: #ffffff;
        }

        .page {
            width: min(100%, 680px);
            margin: 0 auto;
            padding: 35px 18px 45px;
        }

        .card {
            background: rgba(16, 36, 62, 0.82);
            border: 1px solid rgba(159, 190, 229, 0.16);
            border-radius: 24px;
            padding: 28px 20px;
            box-shadow: 0 18px 45px rgba(0, 0, 0, 0.28);
            text-align: center;
        }

        .success {
            font-size: 42px;
            margin-bottom: 12px;
        }

        h1 {
            margin: 0 0 10px;
            font-size: 27px;
        }

        .intro {
            color: #9fb1c9;
            line-height: 1.6;
            margin-bottom: 25px;
        }

        .details {
            text-align: left;
            background: rgba(7, 22, 40, 0.72);
            border-radius: 17px;
            padding: 5px 16px;
        }

        .row {
            display: flex;
            justify-content: space-between;
            gap: 20px;
            padding: 15px 0;
            border-bottom: 1px solid rgba(159, 190, 229, 0.1);
        }

        .row:last-child {
            border-bottom: 0;
        }

        .label {
            color: #8297b4;
            font-size: 13px;
        }

        .value {
            text-align: right;
            font-weight: 600;
            word-break: break-word;
        }

        .amount {
            font-size: 21px;
        }

        .actions {
            display: grid;
            gap: 10px;
            margin-top: 22px;
        }

        .button {
            display: block;
            text-decoration: none;
            padding: 14px;
            border-radius: 13px;
            font-weight: 700;
        }

        .primary {
            background: #e8eef8;
            color: #071426;
        }

        .secondary {
            background: rgba(255,255,255,0.06);
            color: #dbe6f5;
            border: 1px solid rgba(159, 190, 229, 0.15);
        }
    </style>
</head>

<body>

<div class="page">

    <div class="card">

        <div class="success">✓</div>

        <h1>Electric Bill Payment Complete</h1>

        <p class="intro">
            Your electricity payment has been recorded successfully.
        </p>

        <div class="details">

            <div class="row">
                <span class="label">Provider</span>
                <span class="value">{{ provider }}</span>
            </div>

            <div class="row">
                <span class="label">Meter / account number</span>
                <span class="value">{{ meter_number }}</span>
            </div>

            <div class="row">
                <span class="label">Amount</span>
                <span class="value amount">
                    £{{ "%.2f"|format(amount) }}
                </span>
            </div>

            {% if payment_reference %}
            <div class="row">
                <span class="label">Payment reference</span>
                <span class="value">{{ payment_reference }}</span>
            </div>
            {% endif %}

            <div class="row">
                <span class="label">Transaction reference</span>
                <span class="value">{{ transaction_reference }}</span>
            </div>

            <div class="row">
                <span class="label">Status</span>
                <span class="value">Completed</span>
            </div>

            <div class="row">
                <span class="label">New balance</span>
                <span class="value">
                    £{{ "%.2f"|format(new_balance) }}
                </span>
            </div>

        </div>

        <div class="actions">

            <a
                class="button primary"
                href="/transaction/{{ transaction_reference }}">
                View Transaction
            </a>

            <a
                class="button secondary"
                href="/transactions">
                Transaction History
            </a>

            <a
                class="button secondary"
                href="/services">
                Back to Services
            </a>

        </div>

    </div>

</div>

</body>
</html>
'''

Path("templates/electric_bill_confirmation.html").write_text(
    confirmation_template,
    encoding="utf-8"
)

print("SUCCESS: Electric Bills templates created.")


def update_link(path, old_targets):
    if not path.exists():
        return

    text = path.read_text(encoding="utf-8")

    changed = False

    for old in old_targets:
        if old in text:
            text = text.replace(
                old,
                'href="/electric-bills"',
                1
            )
            changed = True
            break

    if changed:
        path.write_text(text, encoding="utf-8")
        print(f"SUCCESS: Electric Bills link updated in {path}.")
    else:
        print(f"NOTICE: Electric Bills link pattern not found in {path}.")


update_link(
    SERVICES,
    [
        'href="#"',
        'href="/services#electric-bills"',
        'href="/dashboard#"'
    ]
)

update_link(
    DASHBOARD,
    [
        'href="/dashboard#"'
    ]
)

print()
print("Electric Bills feature installation complete.")