from pathlib import Path
import re
import shutil
import json

BASE_DIR = Path(__file__).resolve().parent
TEMPLATE = BASE_DIR / "templates" / "international_transfer.html"

if not TEMPLATE.exists():
    print("ERROR: templates\\international_transfer.html not found.")
    raise SystemExit(1)

# Backup
backup = BASE_DIR / "templates" / "international_transfer_before_clean_dropdowns.html"

if not backup.exists():
    shutil.copy2(TEMPLATE, backup)

html = TEMPLATE.read_text(encoding="utf-8")


# ============================================================
# COUNTRY DATA
# ============================================================

countries = [
    "Afghanistan","Albania","Algeria","Andorra","Angola",
    "Antigua and Barbuda","Argentina","Armenia","Australia","Austria",
    "Azerbaijan","Bahamas","Bahrain","Bangladesh","Barbados",
    "Belarus","Belgium","Belize","Benin","Bhutan","Bolivia",
    "Bosnia and Herzegovina","Botswana","Brazil","Brunei","Bulgaria",
    "Burkina Faso","Burundi","Cabo Verde","Cambodia","Cameroon",
    "Canada","Central African Republic","Chad","Chile","China",
    "Colombia","Comoros","Congo","Costa Rica","Croatia","Cuba",
    "Cyprus","Czech Republic","Denmark","Djibouti","Dominica",
    "Dominican Republic","Ecuador","Egypt","El Salvador",
    "Equatorial Guinea","Eritrea","Estonia","Eswatini","Ethiopia",
    "Fiji","Finland","France","Gabon","Gambia","Georgia","Germany",
    "Ghana","Greece","Grenada","Guatemala","Guinea","Guinea-Bissau",
    "Guyana","Haiti","Honduras","Hungary","Iceland","India",
    "Indonesia","Iran","Iraq","Ireland","Israel","Italy","Jamaica",
    "Japan","Jordan","Kazakhstan","Kenya","Kiribati","Kuwait",
    "Kyrgyzstan","Laos","Latvia","Lebanon","Lesotho","Liberia",
    "Libya","Liechtenstein","Lithuania","Luxembourg","Madagascar",
    "Malawi","Malaysia","Maldives","Mali","Malta","Marshall Islands",
    "Mauritania","Mauritius","Mexico","Micronesia","Moldova",
    "Monaco","Mongolia","Montenegro","Morocco","Mozambique",
    "Myanmar","Namibia","Nauru","Nepal","Netherlands","New Zealand",
    "Nicaragua","Niger","Nigeria","North Korea","North Macedonia",
    "Norway","Oman","Pakistan","Palau","Palestine","Panama",
    "Papua New Guinea","Paraguay","Peru","Philippines","Poland",
    "Portugal","Qatar","Romania","Russia","Rwanda",
    "Saint Kitts and Nevis","Saint Lucia",
    "Saint Vincent and the Grenadines","Samoa","San Marino",
    "Sao Tome and Principe","Saudi Arabia","Senegal","Serbia",
    "Seychelles","Sierra Leone","Singapore","Slovakia","Slovenia",
    "Solomon Islands","Somalia","South Africa","South Korea",
    "South Sudan","Spain","Sri Lanka","Sudan","Suriname","Sweden",
    "Switzerland","Syria","Taiwan","Tajikistan","Tanzania",
    "Thailand","Timor-Leste","Togo","Tonga","Trinidad and Tobago",
    "Tunisia","Turkey","Turkmenistan","Tuvalu","Uganda","Ukraine",
    "United Arab Emirates","United Kingdom","United States","Uruguay",
    "Uzbekistan","Vanuatu","Vatican City","Venezuela","Vietnam",
    "Yemen","Zambia","Zimbabwe"
]


# ============================================================
# BANK DATA
# ============================================================

banks = {
    "United Kingdom": [
        "Allied Irish Bank (GB)",
        "Bank of Ireland UK",
        "Bank of Scotland",
        "Barclays Bank",
        "Birmingham Bank",
        "Card One Money",
        "Cashplus Bank",
        "Chase UK",
        "Citibank UK",
        "ClearBank",
        "C. Hoare & Co.",
        "Co-operative Bank",
        "Coutts",
        "Danske Bank",
        "First Direct",
        "Halifax",
        "Handelsbanken UK",
        "HSBC UK",
        "Investec Bank",
        "Lloyds Bank",
        "Metro Bank",
        "Monzo Bank",
        "Nationwide Building Society",
        "NatWest",
        "Revolut",
        "Royal Bank of Scotland",
        "Santander UK",
        "Skipton Building Society",
        "Starling Bank",
        "TSB Bank",
        "Ulster Bank",
        "Virgin Money",
        "Yorkshire Building Society",
        "Zopa Bank",
        "Other UK Bank or Building Society"
    ],

    "Suriname": [
        "De Surinaamsche Bank (DSB)",
        "Republic Bank Suriname",
        "Hakrinbank",
        "Surinaamse Volkscredietbank",
        "Finabank",
        "Surichange Bank",
        "GODO",
        "Trustbank Amanah",
        "Postspaarbank",
        "Other Surinamese Bank"
    ],

    "United States": [
        "Bank of America",
        "JPMorgan Chase Bank",
        "Wells Fargo Bank",
        "Citibank",
        "U.S. Bank",
        "PNC Bank",
        "Truist Bank",
        "Capital One",
        "TD Bank",
        "Other US Bank"
    ],

    "Canada": [
        "Royal Bank of Canada",
        "Toronto-Dominion Bank",
        "Bank of Montreal",
        "Bank of Nova Scotia",
        "Canadian Imperial Bank of Commerce",
        "National Bank of Canada",
        "Desjardins",
        "Other Canadian Bank"
    ],

    "Australia": [
        "Commonwealth Bank",
        "Westpac",
        "ANZ",
        "National Australia Bank",
        "Macquarie Bank",
        "Bank of Queensland",
        "Bendigo Bank",
        "Other Australian Bank"
    ],

    "Germany": [
        "Deutsche Bank",
        "Commerzbank",
        "DZ Bank",
        "ING Germany",
        "N26",
        "Sparkasse",
        "Volksbank",
        "Other German Bank"
    ],

    "France": [
        "BNP Paribas",
        "Crédit Agricole",
        "Société Générale",
        "BPCE",
        "Crédit Mutuel",
        "La Banque Postale",
        "Other French Bank"
    ],

    "Ireland": [
        "AIB",
        "Bank of Ireland",
        "Permanent TSB",
        "Revolut Bank Ireland",
        "Other Irish Bank"
    ],

    "Netherlands": [
        "ING Bank",
        "ABN AMRO",
        "Rabobank",
        "de Volksbank",
        "Other Dutch Bank"
    ],

    "Switzerland": [
        "UBS",
        "Credit Suisse",
        "Zürcher Kantonalbank",
        "Raiffeisen Switzerland",
        "Julius Baer",
        "Other Swiss Bank"
    ],

    "India": [
        "State Bank of India",
        "HDFC Bank",
        "ICICI Bank",
        "Axis Bank",
        "Kotak Mahindra Bank",
        "Punjab National Bank",
        "Bank of Baroda",
        "Canara Bank",
        "Other Indian Bank"
    ],

    "China": [
        "Industrial and Commercial Bank of China",
        "China Construction Bank",
        "Agricultural Bank of China",
        "Bank of China",
        "Bank of Communications",
        "China Merchants Bank",
        "Other Chinese Bank"
    ],

    "Japan": [
        "MUFG Bank",
        "SMBC Bank",
        "Mizuho Bank",
        "Resona Bank",
        "Japan Post Bank",
        "Other Japanese Bank"
    ],

    "Singapore": [
        "DBS Bank",
        "OCBC Bank",
        "United Overseas Bank",
        "Standard Chartered Singapore",
        "Citibank Singapore",
        "Other Singaporean Bank"
    ],

    "South Africa": [
        "Standard Bank",
        "First National Bank",
        "Absa Bank",
        "Nedbank",
        "Capitec Bank",
        "Investec Bank",
        "Other South African Bank"
    ],

    "Kenya": [
        "KCB Bank Kenya",
        "Equity Bank Kenya",
        "Co-operative Bank of Kenya",
        "Absa Bank Kenya",
        "Standard Chartered Bank Kenya",
        "NCBA Bank Kenya",
        "I&M Bank",
        "Stanbic Bank Kenya",
        "DTB Kenya",
        "Family Bank",
        "Other Kenyan Bank"
    ],

    "Nigeria": [
        "Access Bank",
        "First Bank of Nigeria",
        "Guaranty Trust Bank",
        "United Bank for Africa",
        "Zenith Bank",
        "Fidelity Bank",
        "Stanbic IBTC Bank",
        "Ecobank Nigeria",
        "Other Nigerian Bank"
    ],

    "Ghana": [
        "GCB Bank",
        "Ecobank Ghana",
        "Absa Bank Ghana",
        "Stanbic Bank Ghana",
        "Standard Chartered Bank Ghana",
        "Fidelity Bank Ghana",
        "CalBank",
        "Other Ghanaian Bank"
    ],

    "United Arab Emirates": [
        "Emirates NBD",
        "First Abu Dhabi Bank",
        "Abu Dhabi Commercial Bank",
        "Dubai Islamic Bank",
        "Mashreq Bank",
        "RAKBANK",
        "Other UAE Bank"
    ],

    "Saudi Arabia": [
        "Saudi National Bank",
        "Al Rajhi Bank",
        "Riyad Bank",
        "Saudi Awwal Bank",
        "Bank Albilad",
        "Bank AlJazira",
        "Other Saudi Bank"
    ],

    "Qatar": [
        "Qatar National Bank",
        "Qatar Islamic Bank",
        "Commercial Bank of Qatar",
        "Doha Bank",
        "Masraf Al Rayan",
        "Other Qatari Bank"
    ],

    "Brazil": [
        "Banco do Brasil",
        "Itaú Unibanco",
        "Bradesco",
        "Caixa Econômica Federal",
        "Santander Brasil",
        "BTG Pactual",
        "Other Brazilian Bank"
    ],

    "Mexico": [
        "BBVA México",
        "Banorte",
        "Santander México",
        "Citibanamex",
        "HSBC México",
        "Scotiabank México",
        "Other Mexican Bank"
    ]
}


# ============================================================
# CURRENCIES
# ============================================================

currencies = [
    ("GBP", "GBP — Pound Sterling"),
    ("EUR", "EUR — Euro"),
    ("USD", "USD — US Dollar"),
    ("CAD", "CAD — Canadian Dollar"),
    ("AUD", "AUD — Australian Dollar"),
    ("NZD", "NZD — New Zealand Dollar"),
    ("CHF", "CHF — Swiss Franc"),
    ("JPY", "JPY — Japanese Yen"),
    ("CNY", "CNY — Chinese Yuan"),
    ("HKD", "HKD — Hong Kong Dollar"),
    ("SGD", "SGD — Singapore Dollar"),
    ("INR", "INR — Indian Rupee"),
    ("AED", "AED — UAE Dirham"),
    ("SAR", "SAR — Saudi Riyal"),
    ("QAR", "QAR — Qatari Riyal"),
    ("ZAR", "ZAR — South African Rand"),
    ("KES", "KES — Kenyan Shilling"),
    ("NGN", "NGN — Nigerian Naira"),
    ("GHS", "GHS — Ghanaian Cedi"),
    ("TZS", "TZS — Tanzanian Shilling"),
    ("UGX", "UGX — Ugandan Shilling"),
    ("RWF", "RWF — Rwandan Franc"),
    ("BRL", "BRL — Brazilian Real"),
    ("MXN", "MXN — Mexican Peso"),
    ("ARS", "ARS — Argentine Peso"),
    ("SRD", "SRD — Surinamese Dollar"),
    ("THB", "THB — Thai Baht"),
    ("MYR", "MYR — Malaysian Ringgit"),
    ("IDR", "IDR — Indonesian Rupiah"),
    ("KRW", "KRW — South Korean Won"),
    ("TRY", "TRY — Turkish Lira"),
    ("PLN", "PLN — Polish Zloty"),
    ("SEK", "SEK — Swedish Krona"),
    ("NOK", "NOK — Norwegian Krone"),
    ("DKK", "DKK — Danish Krone"),
    ("CZK", "CZK — Czech Koruna"),
    ("HUF", "HUF — Hungarian Forint"),
    ("RON", "RON — Romanian Leu"),
    ("ILS", "ILS — Israeli New Shekel")
]


# ============================================================
# REMOVE ALL OLD PICKER CODE
# ============================================================

patterns = [
    r'<style[^>]*id=["\']fairmont-picker-v2-style["\'][^>]*>.*?</style>',
    r'<script[^>]*id=["\']fairmont-picker-v2-script["\'][^>]*>.*?</script>',
    r'<style[^>]*id=["\']fairmont-picker-style["\'][^>]*>.*?</style>',
    r'<script[^>]*id=["\']fairmont-picker-script["\'][^>]*>.*?</script>',
    r'<style[^>]*id=["\']fairmont-country-select-restore["\'][^>]*>.*?</style>',
    r'<style[^>]*id=["\']fairmont-remove-native-selects["\'][^>]*>.*?</style>',
    r'<script[^>]*id=["\']fairmont-country-list-script["\'][^>]*>.*?</script>',
    r'<script[^>]*id=["\']fairmont-clean-picker-init["\'][^>]*>.*?</script>'
]

for pattern in patterns:
    html = re.sub(
        pattern,
        "",
        html,
        flags=re.IGNORECASE | re.DOTALL
    )


# ============================================================
# REMOVE OLD GENERATED BUTTONS
# ============================================================

html = re.sub(
    r'<button[^>]*class=["\'][^"\']*fairmont-picker-trigger[^"\']*["\'][^>]*>.*?</button>',
    "",
    html,
    flags=re.IGNORECASE | re.DOTALL
)


# ============================================================
# REPLACE THE THREE SELECTS
# ============================================================

country_pattern = re.compile(
    r'<select\b[^>]*id=["\']internationalCountry["\'][^>]*>.*?</select>',
    re.IGNORECASE | re.DOTALL
)

bank_pattern = re.compile(
    r'<select\b[^>]*id=["\']internationalBank["\'][^>]*>.*?</select>',
    re.IGNORECASE | re.DOTALL
)

currency_pattern = re.compile(
    r'<select\b[^>]*id=["\']internationalCurrency["\'][^>]*>.*?</select>',
    re.IGNORECASE | re.DOTALL
)

country_options = '<option value="">Select country</option>'

for c in countries:
    country_options += (
        '<option value="' +
        c.replace('"', '&quot;') +
        '">' +
        c +
        '</option>'
    )

country_html = """
<select id="internationalCountry"
        name="country"
        class="fairmont-real-select"
        required>
    COUNTRY_OPTIONS
</select>
""".replace("COUNTRY_OPTIONS", country_options)

bank_html = """
<select id="internationalBank"
        name="bank_name"
        class="fairmont-real-select"
        required>
    <option value="">Select a bank</option>
</select>
"""

currency_options = '<option value="">Select currency</option>'

for code, label in currencies:
    currency_options += (
        '<option value="' +
        code +
        '">' +
        label +
        '</option>'
    )

currency_html = """
<select id="internationalCurrency"
        name="currency"
        class="fairmont-real-select"
        required>
    CURRENCY_OPTIONS
</select>
""".replace("CURRENCY_OPTIONS", currency_options)

html = country_pattern.sub(country_html, html, count=1)
html = bank_pattern.sub(bank_html, html, count=1)
html = currency_pattern.sub(currency_html, html, count=1)


# ============================================================
# CUSTOM DROPDOWN CSS
# ============================================================

css = r"""
<style id="fairmont-clean-dropdown-style">

.fairmont-real-select {
    display: none !important;
}

.fairmont-clean-field {
    width: 100%;
    position: relative;
}

.fairmont-clean-trigger {
    width: 100%;
    min-height: 52px;
    box-sizing: border-box;
    border-radius: 14px;
    border: 1px solid rgba(255,255,255,0.14);
    background: rgba(255,255,255,0.055);
    color: rgba(255,255,255,0.72);
    padding: 0 46px 0 16px;
    font-size: 15px;
    text-align: left;
    cursor: pointer;
    position: relative;
}

.fairmont-clean-trigger::after {
    content: "▾";
    position: absolute;
    right: 17px;
    top: 50%;
    transform: translateY(-50%);
    font-size: 16px;
}

.fairmont-clean-trigger.selected {
    color: #ffffff;
}

.fairmont-clean-popup {
    position: fixed;
    z-index: 999999;
    width: min(430px, calc(100vw - 28px));
    background: #111b30;
    border: 1px solid rgba(255,255,255,0.16);
    border-radius: 16px;
    box-shadow: 0 20px 60px rgba(0,0,0,0.55);
    overflow: hidden;
    display: none;
}

.fairmont-clean-popup.open {
    display: block;
}

.fairmont-clean-search {
    width: calc(100% - 24px);
    height: 44px;
    margin: 12px;
    box-sizing: border-box;
    border: 1px solid rgba(255,255,255,0.15);
    border-radius: 11px;
    background: rgba(255,255,255,0.07);
    color: #ffffff;
    padding: 0 13px;
    outline: none;
    font-size: 15px;
}

.fairmont-clean-search::placeholder {
    color: rgba(255,255,255,0.45);
}

.fairmont-clean-list {
    max-height: 360px;
    overflow-y: auto;
}

.fairmont-clean-option {
    padding: 13px 16px;
    color: #ffffff;
    border-top: 1px solid rgba(255,255,255,0.055);
    cursor: pointer;
    font-size: 14px;
}

.fairmont-clean-option:hover {
    background: rgba(255,255,255,0.09);
}

.fairmont-clean-empty {
    padding: 20px 16px;
    text-align: center;
    color: rgba(255,255,255,0.5);
    font-size: 14px;
}

</style>
"""


# ============================================================
# CUSTOM DROPDOWN JAVASCRIPT
# ============================================================

data_json = json.dumps({
    "countries": countries,
    "banks": banks,
    "currencies": currencies
}, ensure_ascii=False)

script = r"""
<script id="fairmont-clean-dropdown-script">

(function () {

    "use strict";

    var DATA = DATA_PLACEHOLDER;
    var currentPopup = null;

    function closePopup() {

        if (currentPopup) {
            currentPopup.remove();
            currentPopup = null;
        }
    }


    function positionPopup(button, popup) {

        var rect = button.getBoundingClientRect();

        var width = Math.min(
            430,
            window.innerWidth - 28
        );

        popup.style.width = width + "px";

        var left = rect.left;

        if (left + width > window.innerWidth - 14) {
            left = window.innerWidth - width - 14;
        }

        if (left < 14) {
            left = 14;
        }

        popup.style.left = left + "px";

        var top = rect.bottom + 8;

        var popupHeight = Math.min(
            480,
            window.innerHeight - 28
        );

        if (top + popupHeight > window.innerHeight - 14) {
            top = rect.top - popupHeight - 8;
        }

        if (top < 14) {
            top = 14;
        }

        popup.style.top = top + "px";
    }


    function getOptions(type, select) {

        if (type === "country") {
            return DATA.countries.map(function (value) {
                return {
                    value: value,
                    label: value
                };
            });
        }


        if (type === "currency") {
            return DATA.currencies.map(function (item) {
                return {
                    value: item[0],
                    label: item[1]
                };
            });
        }


        if (type === "bank") {

            var country =
                document.getElementById(
                    "internationalCountry"
                ).value;

            if (!country) {
                return [];
            }

            var list = DATA.banks[country];

            if (!list) {
                list = [
                    "Other bank or financial institution in " +
                    country
                ];
            }

            return list.map(function (value) {
                return {
                    value: value,
                    label: value
                };
            });
        }

        return [];
    }


    function syncSelectOptions(select, options) {

        var oldValue = select.value;

        select.innerHTML = "";

        var placeholder =
            select.id === "internationalCountry"
                ? "Select country"
                : select.id === "internationalBank"
                    ? "Select a bank"
                    : "Select currency";

        var first = document.createElement("option");

        first.value = "";
        first.textContent = placeholder;

        select.appendChild(first);

        options.forEach(function (item) {

            var option =
                document.createElement("option");

            option.value = item.value;
            option.textContent = item.label;

            select.appendChild(option);
        });

        if (oldValue) {
            select.value = oldValue;
        }
    }


    function createPicker(type, selectId, placeholder, searchPlaceholder) {

        var select =
            document.getElementById(selectId);

        if (!select) {
            return;
        }


        var wrapper =
            document.createElement("div");

        wrapper.className =
            "fairmont-clean-field";


        select.parentNode.insertBefore(
            wrapper,
            select
        );

        wrapper.appendChild(select);


        var button =
            document.createElement("button");

        button.type = "button";

        button.className =
            "fairmont-clean-trigger";


        function updateButton() {

            if (!select.value) {

                button.textContent =
                    placeholder;

                button.classList.remove(
                    "selected"
                );

                return;
            }

            var selected =
                select.options[
                    select.selectedIndex
                ];

            button.textContent =
                selected.textContent;

            button.classList.add(
                "selected"
            );
        }


        updateButton();


        button.addEventListener(
            "click",
            function (event) {

                event.preventDefault();

                closePopup();


                var popup =
                    document.createElement("div");

                popup.className =
                    "fairmont-clean-popup open";


                var search =
                    document.createElement("input");

                search.type = "search";

                search.className =
                    "fairmont-clean-search";

                search.placeholder =
                    searchPlaceholder;

                search.autocomplete =
                    "off";


                var list =
                    document.createElement("div");

                list.className =
                    "fairmont-clean-list";


                popup.appendChild(search);
                popup.appendChild(list);

                document.body.appendChild(
                    popup
                );


                function render() {

                    list.innerHTML = "";

                    var options =
                        getOptions(
                            type,
                            select
                        );

                    var term =
                        search.value
                            .trim()
                            .toLowerCase();


                    options =
                        options.filter(
                            function (item) {

                                return (
                                    item.label
                                        .toLowerCase()
                                        .indexOf(
                                            term
                                        ) !== -1
                                );
                            }
                        );


                    if (!options.length) {

                        var empty =
                            document.createElement(
                                "div"
                            );

                        empty.className =
                            "fairmont-clean-empty";

                        if (
                            type === "bank" &&
                            !document.getElementById(
                                "internationalCountry"
                            ).value
                        ) {
                            empty.textContent =
                                "Select a country first.";
                        } else {
                            empty.textContent =
                                "No matches found.";
                        }

                        list.appendChild(empty);

                        return;
                    }


                    options.forEach(
                        function (item) {

                            var row =
                                document.createElement(
                                    "div"
                                );

                            row.className =
                                "fairmont-clean-option";

                            row.textContent =
                                item.label;


                            row.addEventListener(
                                "click",
                                function () {

                                    select.value =
                                        item.value;

                                    select.dispatchEvent(
                                        new Event(
                                            "change",
                                            {
                                                bubbles: true
                                            }
                                        )
                                    );

                                    updateButton();

                                    closePopup();
                                }
                            );

                            list.appendChild(row);
                        }
                    );
                }


                search.addEventListener(
                    "input",
                    render
                );


                positionPopup(
                    button,
                    popup
                );


                render();


                currentPopup =
                    popup;


                setTimeout(
                    function () {
                        search.focus();
                    },
                    10
                );
            }
        );


        select.addEventListener(
            "change",
            updateButton
        );


        wrapper.appendChild(button);
    }


    function initialize() {

        var country =
            document.getElementById(
                "internationalCountry"
            );

        var bank =
            document.getElementById(
                "internationalBank"
            );

        var currency =
            document.getElementById(
                "internationalCurrency"
            );


        if (
            !country ||
            !bank ||
            !currency
        ) {
            console.error(
                "Fairmont dropdown fields not found."
            );

            return;
        }


        /*
         * Populate the hidden real selects.
         */

        syncSelectOptions(
            country,
            DATA.countries.map(
                function (item) {
                    return {
                        value: item,
                        label: item
                    };
                }
            )
        );


        syncSelectOptions(
            currency,
            DATA.currencies.map(
                function (item) {
                    return {
                        value: item[0],
                        label: item[1]
                    };
                }
            )
        );


        syncSelectOptions(
            bank,
            []
        );


        /*
         * Create exactly ONE visible control
         * for each field.
         */

        createPicker(
            "country",
            "internationalCountry",
            "Select country",
            "Search country..."
        );


        createPicker(
            "bank",
            "internationalBank",
            "Select a bank",
            "Search bank..."
        );


        createPicker(
            "currency",
            "internationalCurrency",
            "Select currency",
            "Search currency..."
        );


        /*
         * Country controls the available banks.
         */

        country.addEventListener(
            "change",
            function () {

                syncSelectOptions(
                    bank,
                    getOptions(
                        "bank",
                        bank
                    )
                );

                bank.value = "";

                bank.dispatchEvent(
                    new Event(
                        "change",
                        {
                            bubbles: true
                        }
                    )
                );
            }
        );


        /*
         * Close when clicking outside.
         */

        document.addEventListener(
            "click",
            function (event) {

                if (
                    currentPopup &&
                    !currentPopup.contains(
                        event.target
                    ) &&
                    !event.target.classList.contains(
                        "fairmont-clean-trigger"
                    )
                ) {
                    closePopup();
                }
            }
        );


        document.addEventListener(
            "keydown",
            function (event) {

                if (
                    event.key === "Escape"
                ) {
                    closePopup();
                }
            }
        );


        window.addEventListener(
            "resize",
            function () {

                if (
                    currentPopup
                ) {

                    var buttons =
                        document.querySelectorAll(
                            ".fairmont-clean-trigger"
                        );

                    buttons.forEach(
                        function (button) {

                            if (
                                currentPopup
                                    .previousElementSibling
                            ) {
                                positionPopup(
                                    button,
                                    currentPopup
                                );
                            }
                        }
                    );
                }
            }
        );

    }


    if (
        document.readyState ===
        "loading"
    ) {

        document.addEventListener(
            "DOMContentLoaded",
            initialize
        );

    } else {

        initialize();

    }

})();

</script>
""".replace(
    "DATA_PLACEHOLDER",
    data_json
)


# ============================================================
# REMOVE OLD CLEAN VERSION IF PRESENT
# ============================================================

html = re.sub(
    r'<style[^>]*id=["\']fairmont-clean-dropdown-style["\'][^>]*>.*?</style>',
    "",
    html,
    flags=re.IGNORECASE | re.DOTALL
)

html = re.sub(
    r'<script[^>]*id=["\']fairmont-clean-dropdown-script["\'][^>]*>.*?</script>',
    "",
    html,
    flags=re.IGNORECASE | re.DOTALL
)


# ============================================================
# INSERT NEW VERSION
# ============================================================

html = html.replace(
    "</head>",
    css + "\n</head>",
    1
)

html = html.replace(
    "</body>",
    script + "\n</body>",
    1
)


# ============================================================
# SAVE
# ============================================================

TEMPLATE.write_text(
    html,
    encoding="utf-8"
)

print()
print("==============================================")
print("CLEAN DROPDOWN SYSTEM INSTALLED")
print("==============================================")
print()
print("There will now be ONE visible field for:")
print()
print("  Country")
print("  Bank")
print("  Currency")
print()
print("Clicking Country opens:")
print("  Search country...")
print("  Country list")
print()
print("Clicking Bank opens:")
print("  Search bank...")
print("  Banks for the selected country")
print()
print("Clicking Currency opens:")
print("  Search currency...")
print("  Currency list")
print()
print("The underlying native selects remain hidden")
print("so Flask still receives the correct form values.")
print()
print("Backup:")
print(backup)
print()
print("Restart Flask and press Ctrl + F5.")
print()