from pathlib import Path
import re
import shutil

BASE_DIR = Path(__file__).resolve().parent
TEMPLATE = BASE_DIR / "templates" / "international_transfer.html"

if not TEMPLATE.exists():
    print("ERROR: international_transfer.html was not found.")
    raise SystemExit(1)

backup = TEMPLATE.with_name(
    "international_transfer_before_country_restore.html"
)

if not backup.exists():
    shutil.copy2(TEMPLATE, backup)

html = TEMPLATE.read_text(encoding="utf-8")


# ------------------------------------------------------------
# REMOVE THE PREVIOUS CLEANUP SCRIPT
# ------------------------------------------------------------

html = re.sub(
    r'<script[^>]*id=["\']fairmont-clean-picker-init["\'][^>]*>.*?</script>',
    '',
    html,
    flags=re.IGNORECASE | re.DOTALL
)


# ------------------------------------------------------------
# REMOVE THE PREVIOUS CSS THAT HID THE SELECTS
# ------------------------------------------------------------

html = re.sub(
    r'<style[^>]*id=["\']fairmont-remove-native-selects["\'][^>]*>.*?</style>',
    '',
    html,
    flags=re.IGNORECASE | re.DOTALL
)


# ------------------------------------------------------------
# RESTORE COUNTRY SELECT VISIBILITY
# ------------------------------------------------------------

restore_css = """
<style id="fairmont-country-select-restore">

/* Keep the normal Country field visible. */
#internationalCountry {
    position: relative !important;
    width: 100% !important;
    height: 52px !important;
    min-height: 52px !important;
    max-height: none !important;
    opacity: 1 !important;
    visibility: visible !important;
    pointer-events: auto !important;
    display: block !important;
    clip: auto !important;
    clip-path: none !important;
    overflow: visible !important;
}

/*
   The search box should ONLY appear when the Country
   dropdown is opened by the user.
*/
.fairmont-country-search-box {
    display: none;
}

.fairmont-country-search-box.open {
    display: block;
}

</style>
"""

html = html.replace("</head>", restore_css + "\n</head>", 1)


# ------------------------------------------------------------
# REMOVE DUPLICATE CUSTOM COUNTRY BUTTONS
# ------------------------------------------------------------

html = re.sub(
    r'<button[^>]*class=["\'][^"\']*fairmont-picker-trigger[^"\']*["\'][^>]*>.*?</button>',
    '',
    html,
    flags=re.IGNORECASE | re.DOTALL
)


# ------------------------------------------------------------
# REMOVE OLD COUNTRY SEARCH BOXES
# ------------------------------------------------------------

html = re.sub(
    r'<div[^>]*class=["\'][^"\']*fairmont-country-search[^"\']*["\'][^>]*>.*?</div>',
    '',
    html,
    flags=re.IGNORECASE | re.DOTALL
)

html = re.sub(
    r'<input[^>]*class=["\'][^"\']*fairmont-country-search[^"\']*["\'][^>]*>',
    '',
    html,
    flags=re.IGNORECASE | re.DOTALL
)


# ------------------------------------------------------------
# REMOVE OLD V2 SCRIPT
# ------------------------------------------------------------

html = re.sub(
    r'<script[^>]*id=["\']fairmont-picker-v2-script["\'][^>]*>.*?</script>',
    '',
    html,
    flags=re.IGNORECASE | re.DOTALL
)


# ------------------------------------------------------------
# IMPORTANT:
# MAKE SURE COUNTRY SELECT IS A NORMAL SELECT
# ------------------------------------------------------------

country_pattern = re.compile(
    r'<select\b[^>]*id=["\']internationalCountry["\'][^>]*>.*?</select>',
    re.IGNORECASE | re.DOTALL
)

country_select = """
<select
    id="internationalCountry"
    name="country"
    required
>
    <option value="">Select country</option>
</select>
"""

html, count = country_pattern.subn(
    country_select,
    html,
    count=1
)

if count == 0:
    print("WARNING: Could not find internationalCountry.")


# ------------------------------------------------------------
# INSERT COUNTRY LIST
# ------------------------------------------------------------

countries = [
    "Afghanistan",
    "Albania",
    "Algeria",
    "Andorra",
    "Angola",
    "Antigua and Barbuda",
    "Argentina",
    "Armenia",
    "Australia",
    "Austria",
    "Azerbaijan",
    "Bahamas",
    "Bahrain",
    "Bangladesh",
    "Barbados",
    "Belarus",
    "Belgium",
    "Belize",
    "Benin",
    "Bhutan",
    "Bolivia",
    "Bosnia and Herzegovina",
    "Botswana",
    "Brazil",
    "Brunei",
    "Bulgaria",
    "Burkina Faso",
    "Burundi",
    "Cabo Verde",
    "Cambodia",
    "Cameroon",
    "Canada",
    "Central African Republic",
    "Chad",
    "Chile",
    "China",
    "Colombia",
    "Comoros",
    "Congo",
    "Costa Rica",
    "Croatia",
    "Cuba",
    "Cyprus",
    "Czech Republic",
    "Denmark",
    "Djibouti",
    "Dominica",
    "Dominican Republic",
    "Ecuador",
    "Egypt",
    "El Salvador",
    "Equatorial Guinea",
    "Eritrea",
    "Estonia",
    "Eswatini",
    "Ethiopia",
    "Fiji",
    "Finland",
    "France",
    "Gabon",
    "Gambia",
    "Georgia",
    "Germany",
    "Ghana",
    "Greece",
    "Grenada",
    "Guatemala",
    "Guinea",
    "Guinea-Bissau",
    "Guyana",
    "Haiti",
    "Honduras",
    "Hungary",
    "Iceland",
    "India",
    "Indonesia",
    "Iran",
    "Iraq",
    "Ireland",
    "Israel",
    "Italy",
    "Jamaica",
    "Japan",
    "Jordan",
    "Kazakhstan",
    "Kenya",
    "Kiribati",
    "Kuwait",
    "Kyrgyzstan",
    "Laos",
    "Latvia",
    "Lebanon",
    "Lesotho",
    "Liberia",
    "Libya",
    "Liechtenstein",
    "Lithuania",
    "Luxembourg",
    "Madagascar",
    "Malawi",
    "Malaysia",
    "Maldives",
    "Mali",
    "Malta",
    "Marshall Islands",
    "Mauritania",
    "Mauritius",
    "Mexico",
    "Micronesia",
    "Moldova",
    "Monaco",
    "Mongolia",
    "Montenegro",
    "Morocco",
    "Mozambique",
    "Myanmar",
    "Namibia",
    "Nauru",
    "Nepal",
    "Netherlands",
    "New Zealand",
    "Nicaragua",
    "Niger",
    "Nigeria",
    "North Korea",
    "North Macedonia",
    "Norway",
    "Oman",
    "Pakistan",
    "Palau",
    "Palestine",
    "Panama",
    "Papua New Guinea",
    "Paraguay",
    "Peru",
    "Philippines",
    "Poland",
    "Portugal",
    "Qatar",
    "Romania",
    "Russia",
    "Rwanda",
    "Saint Kitts and Nevis",
    "Saint Lucia",
    "Saint Vincent and the Grenadines",
    "Samoa",
    "San Marino",
    "Sao Tome and Principe",
    "Saudi Arabia",
    "Senegal",
    "Serbia",
    "Seychelles",
    "Sierra Leone",
    "Singapore",
    "Slovakia",
    "Slovenia",
    "Solomon Islands",
    "Somalia",
    "South Africa",
    "South Korea",
    "South Sudan",
    "Spain",
    "Sri Lanka",
    "Sudan",
    "Suriname",
    "Sweden",
    "Switzerland",
    "Syria",
    "Taiwan",
    "Tajikistan",
    "Tanzania",
    "Thailand",
    "Timor-Leste",
    "Togo",
    "Tonga",
    "Trinidad and Tobago",
    "Tunisia",
    "Turkey",
    "Turkmenistan",
    "Tuvalu",
    "Uganda",
    "Ukraine",
    "United Arab Emirates",
    "United Kingdom",
    "United States",
    "Uruguay",
    "Uzbekistan",
    "Vanuatu",
    "Vatican City",
    "Venezuela",
    "Vietnam",
    "Yemen",
    "Zambia",
    "Zimbabwe"
]

country_options = '<option value="">Select country</option>'

for country in countries:
    country_options += (
        '<option value="' +
        country.replace('"', '&quot;') +
        '">' +
        country +
        '</option>'
    )

country_options_script = """
<script id="fairmont-country-list-script">
document.addEventListener("DOMContentLoaded", function () {

    var country = document.getElementById("internationalCountry");

    if (!country) {
        return;
    }

    country.innerHTML = COUNTRY_OPTIONS_PLACEHOLDER;

});
</script>
"""

country_options_script = country_options_script.replace(
    "COUNTRY_OPTIONS_PLACEHOLDER",
    repr(country_options)
)

html = html.replace(
    "</body>",
    country_options_script + "\n</body>",
    1
)


# ------------------------------------------------------------
# SAVE
# ------------------------------------------------------------

TEMPLATE.write_text(html, encoding="utf-8")

print()
print("==============================================")
print("COUNTRY FIELD RESTORED")
print("==============================================")
print()
print("The visible 'Select country' field has been restored.")
print()
print("The extra permanent country search bar has been removed.")
print()
print("You should now have:")
print()
print("Destination Country")
print("    Select country")
print()
print("When you click Select country:")
print("    -> country list opens")
print("    -> search can be placed INSIDE the opened dropdown")
print()
print("Backup:")
print(backup)
print()
print("Restart Flask and press Ctrl + F5.")
print()