from pathlib import Path
import sqlite3

DB_PATH = Path("instance") / "fairmont.db"

if not DB_PATH.exists():
    print("ERROR: fairmont.db was not found.")
    raise SystemExit(1)

connection = sqlite3.connect(DB_PATH)
cursor = connection.cursor()

columns = cursor.execute("PRAGMA table_info(customer)").fetchall()
column_names = [column[1] for column in columns]

if "bank_statements_locked" in column_names:
    print("INFO: bank_statements_locked already exists.")
else:
    cursor.execute("""
        ALTER TABLE customer
        ADD COLUMN bank_statements_locked BOOLEAN NOT NULL DEFAULT 0
    """)

    connection.commit()

    print("SUCCESS: bank_statements_locked was added.")
    print("Existing customer accounts were preserved.")
    print("Existing bank statement transactions were preserved.")

connection.close()