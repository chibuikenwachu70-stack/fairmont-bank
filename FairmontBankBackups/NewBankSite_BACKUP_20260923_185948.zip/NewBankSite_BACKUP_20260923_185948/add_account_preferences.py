from pathlib import Path
import shutil

BASE = Path(r"C:\Users\DON J\Documents\NewBankSite")
APP = BASE / "app.py"

# ---------------------------------------------------------
# BACKUP
# ---------------------------------------------------------

backup = APP.with_suffix(".py.account_preferences_backup")
shutil.copy2(APP, backup)

text = APP.read_text(encoding="utf-8")

# ---------------------------------------------------------
# 1. ADD ACCOUNT PREFERENCE COLUMNS
# ---------------------------------------------------------

model_marker = '''    account_status = db.Column(
        db.String(30),
        nullable=False,
        default="Active"
    )

'''

new_model_fields = '''    account_status = db.Column(
        db.String(30),
        nullable=False,
        default="Active"
    )

    preferred_language = db.Column(
        db.String(20),
        nullable=False,
        default="English"
    )

    preferred_currency_display = db.Column(
        db.String(10),
        nullable=False,
        default="GBP"
    )

    preferred_date_format = db.Column(
        db.String(30),
        nullable=False,
        default="DD/MM/YYYY"
    )

    account_display_preference = db.Column(
        db.String(30),
        nullable=False,
        default="Standard"
    )

'''

if "preferred_language = db.Column(" not in text:

    if model_marker not in text:
        print("ERROR: Customer account_status section was not found.")
        print("No changes were made.")
        raise SystemExit(1)

    text = text.replace(
        model_marker,
        new_model_fields,
        1
    )

    print("SUCCESS: Account preference fields added to Customer model.")

else:
    print("Account preference fields already exist.")


# ---------------------------------------------------------
# 2. ADD MIGRATION FUNCTION
# ---------------------------------------------------------

migration_marker = '''# =========================================================
# CUSTOMER DASHBOARD
# =========================================================
'''

migration_code = '''# =========================================================
# ACCOUNT PREFERENCE DATABASE MIGRATION
# =========================================================

def ensure_account_preference_columns():

    inspector = db.inspect(db.engine)

    columns = [
        column["name"]
        for column in inspector.get_columns("customer")
    ]

    migrations = {
        "preferred_language":
            "VARCHAR(20) NOT NULL DEFAULT 'English'",

        "preferred_currency_display":
            "VARCHAR(10) NOT NULL DEFAULT 'GBP'",

        "preferred_date_format":
            "VARCHAR(30) NOT NULL DEFAULT 'DD/MM/YYYY'",

        "account_display_preference":
            "VARCHAR(30) NOT NULL DEFAULT 'Standard'"
    }

    for column_name, definition in migrations.items():

        if column_name not in columns:

            with db.engine.begin() as connection:

                connection.exec_driver_sql(
                    f"""
                    ALTER TABLE customer
                    ADD COLUMN {column_name}
                    {definition}
                    """
                )


'''

if "def ensure_account_preference_columns():" not in text:

    if migration_marker not in text:
        print("ERROR: Customer Dashboard section was not found.")
        print("No changes were made.")
        raise SystemExit(1)

    text = text.replace(
        migration_marker,
        migration_code + migration_marker,
        1
    )

    print("SUCCESS: Account preference migration added.")

else:
    print("Account preference migration already exists.")


# ---------------------------------------------------------
# 3. ADD ACCOUNT PREFERENCES ROUTE
# ---------------------------------------------------------

route_marker = '''@app.route("/settings/security-session")
@login_required
def security_session_settings():
    customer = current_user

    return render_template(
        "security_session_settings.html",
        customer=customer
    )

'''

route_code = '''@app.route(
    "/settings/account-preferences",
    methods=["GET", "POST"]
)
@login_required
def account_preferences():

    customer = current_user

    if request.method == "POST":

        preferred_language = request.form.get(
            "preferred_language",
            "English"
        ).strip()

        preferred_currency_display = request.form.get(
            "preferred_currency_display",
            "GBP"
        ).strip().upper()

        preferred_date_format = request.form.get(
            "preferred_date_format",
            "DD/MM/YYYY"
        ).strip()

        account_display_preference = request.form.get(
            "account_display_preference",
            "Standard"
        ).strip()

        allowed_languages = {
            "English"
        }

        allowed_currencies = {
            "GBP",
            "USD",
            "EUR"
        }

        allowed_date_formats = {
            "DD/MM/YYYY",
            "MM/DD/YYYY",
            "YYYY-MM-DD"
        }

        allowed_display_preferences = {
            "Standard",
            "Compact"
        }

        if preferred_language not in allowed_languages:
            preferred_language = "English"

        if preferred_currency_display not in allowed_currencies:
            preferred_currency_display = "GBP"

        if preferred_date_format not in allowed_date_formats:
            preferred_date_format = "DD/MM/YYYY"

        if account_display_preference not in allowed_display_preferences:
            account_display_preference = "Standard"

        customer.preferred_language = preferred_language
        customer.preferred_currency_display = (
            preferred_currency_display
        )
        customer.preferred_date_format = (
            preferred_date_format
        )
        customer.account_display_preference = (
            account_display_preference
        )

        db.session.commit()

        flash(
            "Your account preferences have been saved.",
            "success"
        )

        return redirect(
            url_for("account_preferences")
        )

    return render_template(
        "account_preferences.html",
        customer=customer
    )


'''

if 'def account_preferences():' not in text:

    if route_marker not in text:
        print("ERROR: Security & Session Settings route was not found.")
        print("No changes were made.")
        raise SystemExit(1)

    text = text.replace(
        route_marker,
        route_marker + route_code,
        1
    )

    print("SUCCESS: Account Preferences route added.")

else:
    print("Account Preferences route already exists.")


# ---------------------------------------------------------
# 4. INITIALIZE MIGRATION WHEN APP CONTEXT STARTS
# ---------------------------------------------------------

run_marker = '''if __name__ == "__main__":
'''

if "ensure_account_preference_columns()" not in text.split(run_marker)[-1]:

    if run_marker in text:

        replacement = '''if __name__ == "__main__":
    with app.app_context():
        db.create_all()
        ensure_account_preference_columns()

'''

        text = text.replace(
            run_marker,
            replacement,
            1
        )

        print("SUCCESS: Account preference migration connected to startup.")

    else:
        print("WARNING: app.run startup section was not found.")

# ---------------------------------------------------------
# SAVE
# ---------------------------------------------------------

APP.write_text(text, encoding="utf-8")

print()
print("ACCOUNT PREFERENCES INSTALLATION COMPLETE.")
print()
print(f"Backup created: {backup.name}")