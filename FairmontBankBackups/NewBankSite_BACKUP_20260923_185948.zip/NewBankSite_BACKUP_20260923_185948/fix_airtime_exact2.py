from pathlib import Path
import re

file = Path("templates/dashboard.html")
text = file.read_text(encoding="utf-8")

pattern = re.compile(
    r'(<a\s+href=")#("'
    r'\s+class="service-item">.*?'
    r'<span\s+class="service-name">\s*Airtime\s*</span>',
    re.DOTALL
)

match = pattern.search(text)

if not match:
    raise SystemExit(
        "ERROR: Could not locate the Airtime card. Nothing was changed."
    )

replacement = match.group(0).replace(
    'href="#"',
    'href="/airtime"',
    1
)

text = text[:match.start()] + replacement + text[match.end():]

file.write_text(text, encoding="utf-8")

print("SUCCESS: Airtime card changed from # to /airtime.")