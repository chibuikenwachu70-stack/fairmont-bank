from pathlib import Path
import re
import shutil

BASE = Path(__file__).resolve().parent
TEMPLATES = BASE / "templates"
STATIC_JS = BASE / "static" / "js"
STATIC_CSS = BASE / "static" / "css"

SEND_MONEY = TEMPLATES / "send_money.html"
INTERNATIONAL = TEMPLATES / "international_transfer.html"
TRANSFER_JS = STATIC_JS / "transfer.js"
TRANSFER_CSS = STATIC_CSS / "transfer.css"


def backup_file(path, suffix):
    backup = path.with_name(path.stem + suffix + path.suffix)
    if not backup.exists():
        shutil.copy2(path, backup)
        print(f"BACKUP CREATED: {backup.name}")


def replace_first(pattern, replacement, text, label):
    new_text, count = re.subn(
        pattern,
        replacement,
        text,
        count=1,
        flags=re.DOTALL | re.IGNORECASE
    )

    if count:
        print(f"UPDATED: {label}")
        return new_text

    print(f"SKIPPED: {label} - pattern not found")
    return text


# ---------------------------------------------------------
# 1. BACKUPS
# ---------------------------------------------------------

if not SEND_MONEY.exists():
    raise SystemExit("ERROR: templates/send_money.html was not found.")

if not INTERNATIONAL.exists():
    raise SystemExit("ERROR: templates/international_transfer.html was not found.")

backup_file(
    SEND_MONEY,
    "_before_quick_search"
)

backup_file(
    INTERNATIONAL,
    "_before_quick_search"
)


# ---------------------------------------------------------
# 2. SEARCHABLE COUNTRY SELECT
# ---------------------------------------------------------

international_html = INTERNATIONAL.read_text(encoding="utf-8")

country_replacement = r'''
<div class="quick-search-select" data-search-select>
    <input
        type="text"
        class="quick-search-input"
        id="countrySearch"
        placeholder="Search country..."
        autocomplete="off"
        aria-label="Search country"
    >

    <select
        name="country"
        id="internationalCountry"
        class="quick-search-native-select"
        required
    >
        <option value="">Select country</option>
    </select>

    <div class="quick-search-results" id="countrySearchResults"></div>
</div>
'''

country_pattern = r'<select[^>]*name=["\']country["\'][^>]*>.*?</select>'

if re.search(country_pattern, international_html, flags=re.DOTALL | re.IGNORECASE):
    international_html = re.sub(
        country_pattern,
        country_replacement,
        international_html,
        count=1,
        flags=re.DOTALL | re.IGNORECASE
    )
    print("UPDATED: International country selector")
else:
    print("WARNING: Existing country selector was not found.")


# ---------------------------------------------------------
# 3. SEARCHABLE INTERNATIONAL BANK SELECT
# ---------------------------------------------------------

bank_replacement = r'''
<div class="quick-search-select" data-search-select>
    <input
        type="text"
        class="quick-search-input"
        id="internationalBankSearch"
        placeholder="Search bank..."
        autocomplete="off"
        aria-label="Search bank"
    >

    <select
        name="bank_name"
        id="internationalBank"
        class="quick-search-native-select"
        required
        disabled
    >
        <option value="">Select country first</option>
    </select>

    <div class="quick-search-results" id="internationalBankSearchResults"></div>
</div>
'''

bank_pattern = r'<(?:input|select)[^>]*(?:name=["\']bank_name["\'])[^>]*>.*?</select>|<input[^>]*(?:name=["\']bank_name["\'])[^>]*>'

if re.search(bank_pattern, international_html, flags=re.DOTALL | re.IGNORECASE):
    international_html = re.sub(
        bank_pattern,
        bank_replacement,
        international_html,
        count=1,
        flags=re.DOTALL | re.IGNORECASE
    )
    print("UPDATED: International bank selector")
else:
    print("WARNING: International bank selector was not found.")


# ---------------------------------------------------------
# 4. SEARCHABLE CURRENCY SELECT
# ---------------------------------------------------------

currency_replacement = r'''
<div class="quick-search-select" data-search-select>
    <input
        type="text"
        class="quick-search-input"
        id="currencySearch"
        placeholder="Search currency..."
        autocomplete="off"
        aria-label="Search currency"
    >

    <select
        name="currency"
        id="internationalCurrency"
        class="quick-search-native-select"
        required
    >
        <option value="">Select currency</option>
        <option value="GBP">GBP — British Pound</option>
        <option value="EUR">EUR — Euro</option>
        <option value="USD">USD — US Dollar</option>
        <option value="CAD">CAD — Canadian Dollar</option>
        <option value="AUD">AUD — Australian Dollar</option>
        <option value="NZD">NZD — New Zealand Dollar</option>
        <option value="CHF">CHF — Swiss Franc</option>
        <option value="JPY">JPY — Japanese Yen</option>
        <option value="CNY">CNY — Chinese Yuan</option>
        <option value="HKD">HKD — Hong Kong Dollar</option>
        <option value="SGD">SGD — Singapore Dollar</option>
        <option value="ZAR">ZAR — South African Rand</option>
        <option value="KES">KES — Kenyan Shilling</option>
        <option value="NGN">NGN — Nigerian Naira</option>
        <option value="GHS">GHS — Ghanaian Cedi</option>
        <option value="TZS">TZS — Tanzanian Shilling</option>
        <option value="UGX">UGX — Ugandan Shilling</option>
        <option value="INR">INR — Indian Rupee</option>
        <option value="AED">AED — UAE Dirham</option>
        <option value="SAR">SAR — Saudi Riyal</option>
        <option value="QAR">QAR — Qatari Riyal</option>
        <option value="BHD">BHD — Bahraini Dinar</option>
        <option value="KWD">KWD — Kuwaiti Dinar</option>
        <option value="OMR">OMR — Omani Rial</option>
        <option value="SGD">SGD — Singapore Dollar</option>
        <option value="BRL">BRL — Brazilian Real</option>
        <option value="MXN">MXN — Mexican Peso</option>
        <option value="ARS">ARS — Argentine Peso</option>
        <option value="CLP">CLP — Chilean Peso</option>
        <option value="COP">COP — Colombian Peso</option>
        <option value="SRD">SRD — Surinamese Dollar</option>
    </select>

    <div class="quick-search-results" id="currencySearchResults"></div>
</div>
'''

currency_pattern = r'<select[^>]*name=["\']currency["\'][^>]*>.*?</select>'

if re.search(currency_pattern, international_html, flags=re.DOTALL | re.IGNORECASE):
    international_html = re.sub(
        currency_pattern,
        currency_replacement,
        international_html,
        count=1,
        flags=re.DOTALL | re.IGNORECASE
    )
    print("UPDATED: International currency selector")
else:
    print("WARNING: International currency selector was not found.")


INTERNATIONAL.write_text(international_html, encoding="utf-8")


# ---------------------------------------------------------
# 5. UK BANK SEARCH
# ---------------------------------------------------------

send_html = SEND_MONEY.read_text(encoding="utf-8")
backup_file(SEND_MONEY, "_before_quick_search") if False else None

uk_bank_replacement = r'''
<div class="quick-search-select" data-search-select>
    <input
        type="text"
        class="quick-search-input"
        id="ukBankSearch"
        placeholder="Search UK bank..."
        autocomplete="off"
        aria-label="Search UK bank"
    >

    <select
        name="bank_name"
        id="ukBank"
        class="quick-search-native-select"
        required
    >
        <option value="">Select bank</option>

        {% for bank in banks %}
        <option value="{{ bank.name }}">{{ bank.name }}</option>
        {% endfor %}
    </select>

    <div class="quick-search-results" id="ukBankSearchResults"></div>
</div>
'''

uk_bank_pattern = r'<select[^>]*name=["\']bank_name["\'][^>]*>.*?</select>'

if re.search(uk_bank_pattern, send_html, flags=re.DOTALL | re.IGNORECASE):
    send_html = re.sub(
        uk_bank_pattern,
        uk_bank_replacement,
        send_html,
        count=1,
        flags=re.DOTALL | re.IGNORECASE
    )
    print("UPDATED: UK bank selector")
else:
    print("WARNING: UK bank selector was not found.")


SEND_MONEY.write_text(send_html, encoding="utf-8")


# ---------------------------------------------------------
# 6. QUICK SEARCH JAVASCRIPT
# ---------------------------------------------------------

js_code = r'''
/*
    Fairmont Bank
    Transfer Quick Search
*/

(function () {
    "use strict";

    function setupSearchableSelect(searchId, selectId, resultsId) {
        const search = document.getElementById(searchId);
        const select = document.getElementById(selectId);
        const results = document.getElementById(resultsId);

        if (!search || !select || !results) {
            return null;
        }

        function getOptions() {
            return Array.from(select.options).filter(
                option => option.value && option.textContent.trim()
            );
        }

        function renderResults() {
            const query = search.value.trim().toLowerCase();
            const options = getOptions();

            results.innerHTML = "";

            if (select.disabled) {
                results.style.display = "none";
                return;
            }

            const filtered = options.filter(option => {
                const text = option.textContent.toLowerCase();
                const value = option.value.toLowerCase();

                return !query ||
                    text.includes(query) ||
                    value.includes(query);
            });

            if (!filtered.length) {
                const empty = document.createElement("div");
                empty.className = "quick-search-empty";
                empty.textContent = "No matching options found";
                results.appendChild(empty);
                results.style.display = "block";
                return;
            }

            filtered.slice(0, 12).forEach(option => {
                const item = document.createElement("button");

                item.type = "button";
                item.className = "quick-search-option";
                item.textContent = option.textContent.trim();

                item.addEventListener("click", function () {
                    select.value = option.value;

                    search.value = option.textContent.trim();

                    results.innerHTML = "";
                    results.style.display = "none";

                    select.dispatchEvent(
                        new Event("change", { bubbles: true })
                    );
                });

                results.appendChild(item);
            });

            results.style.display = "block";
        }

        search.addEventListener("focus", renderResults);
        search.addEventListener("input", renderResults);

        select.addEventListener("change", function () {
            const selected = select.options[select.selectedIndex];

            if (selected && selected.value) {
                search.value = selected.textContent.trim();
            }
        });

        document.addEventListener("click", function (event) {
            if (
                !event.target.closest(".quick-search-select") ||
                event.target === select
            ) {
                results.style.display = "none";
            }
        });

        return {
            search,
            select,
            results,
            renderResults
        };
    }


    /*
        UK BANK
    */

    setupSearchableSelect(
        "ukBankSearch",
        "ukBank",
        "ukBankSearchResults"
    );


    /*
        INTERNATIONAL COUNTRY
    */

    const countrySearch = setupSearchableSelect(
        "countrySearch",
        "internationalCountry",
        "countrySearchResults"
    );


    /*
        INTERNATIONAL BANK
    */

    const bankSearch = setupSearchableSelect(
        "internationalBankSearch",
        "internationalBank",
        "internationalBankSearchResults"
    );


    /*
        INTERNATIONAL CURRENCY
    */

    setupSearchableSelect(
        "currencySearch",
        "internationalCurrency",
        "currencySearchResults"
    );


    /*
        COUNTRY -> BANK
        Rebuild the searchable bank selector
        whenever the country changes.
    */

    const countrySelect = document.getElementById("internationalCountry");
    const internationalBank = document.getElementById("internationalBank");
    const internationalBankSearch =
        document.getElementById("internationalBankSearch");

    if (countrySelect && internationalBank) {

        countrySelect.addEventListener("change", function () {

            const selectedCountry = this.value;

            if (!selectedCountry) {
                internationalBank.disabled = true;

                if (internationalBankSearch) {
                    internationalBankSearch.disabled = true;
                    internationalBankSearch.value = "";
                    internationalBankSearch.placeholder =
                        "Select country first...";
                }

                return;
            }

            internationalBank.disabled = false;

            if (internationalBankSearch) {
                internationalBankSearch.disabled = false;
                internationalBankSearch.value = "";
                internationalBankSearch.placeholder =
                    "Search bank...";
            }

            /*
                Allow the existing country-bank system
                to rebuild the bank options.
            */

            setTimeout(function () {

                if (internationalBankSearch) {
                    internationalBankSearch.value = "";
                }

                const event = new Event(
                    "internationalBanksUpdated"
                );

                internationalBank.dispatchEvent(event);

            }, 50);
        });
    }

})();
'''


# ---------------------------------------------------------
# 7. APPEND SEARCH JS
# ---------------------------------------------------------

existing_js = ""

if TRANSFER_JS.exists():
    existing_js = TRANSFER_JS.read_text(encoding="utf-8")

marker = "/* FAIRMOnt_TRANSFER_QUICK_SEARCH_V1 */"

if marker not in existing_js:
    TRANSFER_JS.write_text(
        existing_js
        + "\n\n"
        + marker
        + "\n"
        + js_code,
        encoding="utf-8"
    )
    print("UPDATED: static/js/transfer.js")
else:
    print("SKIPPED: Quick-search JavaScript already exists.")


# ---------------------------------------------------------
# 8. QUICK SEARCH CSS
# ---------------------------------------------------------

css_code = r'''
/* =========================================================
   Fairmont Bank - Transfer Quick Search
   ========================================================= */

.quick-search-select {
    position: relative;
    width: 100%;
}

.quick-search-input {
    width: 100%;
    box-sizing: border-box;
    margin-bottom: 8px;
}

.quick-search-native-select {
    width: 100%;
    box-sizing: border-box;
}

.quick-search-results {
    position: absolute;
    left: 0;
    right: 0;
    top: calc(100% - 2px);
    z-index: 1000;
    display: none;
    max-height: 240px;
    overflow-y: auto;
    border-radius: 14px;
    padding: 6px;
    background: rgba(16, 27, 48, 0.98);
    border: 1px solid rgba(255, 255, 255, 0.12);
    box-shadow: 0 16px 40px rgba(0, 0, 0, 0.35);
    backdrop-filter: blur(18px);
}

.quick-search-option {
    display: block;
    width: 100%;
    border: 0;
    border-radius: 10px;
    padding: 11px 12px;
    margin: 2px 0;
    text-align: left;
    font: inherit;
    color: inherit;
    background: transparent;
    cursor: pointer;
}

.quick-search-option:hover,
.quick-search-option:focus {
    background: rgba(255, 255, 255, 0.08);
    outline: none;
}

.quick-search-empty {
    padding: 12px;
    text-align: center;
    opacity: 0.65;
}

.quick-search-input:disabled {
    opacity: 0.5;
    cursor: not-allowed;
}
'''

existing_css = ""

if TRANSFER_CSS.exists():
    existing_css = TRANSFER_CSS.read_text(encoding="utf-8")

css_marker = "/* Fairmont Bank - Transfer Quick Search */"

if css_marker not in existing_css:
    TRANSFER_CSS.write_text(
        existing_css
        + "\n\n"
        + css_code,
        encoding="utf-8"
    )
    print("UPDATED: static/css/transfer.css")
else:
    print("SKIPPED: Quick-search CSS already exists.")


print()
print("=" * 60)
print("QUICK SEARCH UPGRADE COMPLETE")
print("=" * 60)
print()
print("Added searchable controls for:")
print("  - UK bank")
print("  - International country")
print("  - International bank")
print("  - International currency")
print()
print("Existing dashboard was NOT modified.")
print("Existing database was NOT modified.")
print("Existing customer data was NOT modified.")
print()
print("Next:")
print("  python -m py_compile app.py")
print("  python app.py")
print()