from pathlib import Path
from datetime import datetime
import re
import html
import json

BASE = Path(__file__).resolve().parent
TEMPLATE = BASE / "templates" / "international_transfer.html"

if not TEMPLATE.exists():
    print("ERROR: international_transfer.html was not found.")
    raise SystemExit(1)

original = TEMPLATE.read_text(encoding="utf-8")

# ---------------------------------------------------------
# BACKUP
# ---------------------------------------------------------

stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = TEMPLATE.with_name(
    f"international_transfer_BEFORE_V3_{stamp}.html"
)

backup.write_text(original, encoding="utf-8")

print("Backup created:", backup.name)


# ---------------------------------------------------------
# HELPER: remove only STYLE/SCRIPT blocks containing
# the old picker markers.
# ---------------------------------------------------------

OLD_MARKERS = [
    "quick-search-select",
    "quick-search-input",
    "quick-search-results",
    "search-select-wrapper",
    "transfer-search-input",
    "transfer-search-results",
    "fairmont-picker-popup",
    "fairmont-picker-options",
    "fairmont-picker-trigger",
    "fairmont-picker-real-select",
    "fairmont-real-select",
    "countrySearchResults",
    "internationalBankSearchResults",
    "currencySearchResults",
]


def remove_old_blocks(text, tag):
    pattern = re.compile(
        rf"<{tag}\b[^>]*>.*?</{tag}>",
        re.IGNORECASE | re.DOTALL
    )

    removed = 0

    def replace(match):
        nonlocal removed

        block = match.group(0)

        if any(marker in block for marker in OLD_MARKERS):
            removed += 1
            return ""

        return block

    result = pattern.sub(replace, text)

    return result, removed


source, removed_styles = remove_old_blocks(original, "style")
source, removed_scripts = remove_old_blocks(source, "script")

print("Old picker style blocks removed:", removed_styles)
print("Old picker script blocks removed:", removed_scripts)


# ---------------------------------------------------------
# COUNTRY LIST
# ---------------------------------------------------------

COUNTRIES = [
    "Afghanistan",
    "Albania",
    "Algeria",
    "Andorra",
    "Angola",
    "Antigua and Barbuda",
    "Argentina",
    "Armenia",
    "Australia",
    "Austria",
    "Azerbaijan",
    "Bahamas",
    "Bahrain",
    "Bangladesh",
    "Barbados",
    "Belarus",
    "Belgium",
    "Belize",
    "Benin",
    "Bhutan",
    "Bolivia",
    "Bosnia and Herzegovina",
    "Botswana",
    "Brazil",
    "Brunei",
    "Bulgaria",
    "Burkina Faso",
    "Burundi",
    "Cabo Verde",
    "Cambodia",
    "Cameroon",
    "Canada",
    "Central African Republic",
    "Chad",
    "Chile",
    "China",
    "Colombia",
    "Comoros",
    "Congo",
    "Costa Rica",
    "Croatia",
    "Cuba",
    "Cyprus",
    "Czech Republic",
    "Denmark",
    "Djibouti",
    "Dominica",
    "Dominican Republic",
    "Ecuador",
    "Egypt",
    "El Salvador",
    "Equatorial Guinea",
    "Eritrea",
    "Estonia",
    "Eswatini",
    "Ethiopia",
    "Fiji",
    "Finland",
    "France",
    "Gabon",
    "Gambia",
    "Georgia",
    "Germany",
    "Ghana",
    "Greece",
    "Grenada",
    "Guatemala",
    "Guinea",
    "Guinea-Bissau",
    "Guyana",
    "Haiti",
    "Honduras",
    "Hungary",
    "Iceland",
    "India",
    "Indonesia",
    "Iran",
    "Iraq",
    "Ireland",
    "Israel",
    "Italy",
    "Jamaica",
    "Japan",
    "Jordan",
    "Kazakhstan",
    "Kenya",
    "Kiribati",
    "Kuwait",
    "Kyrgyzstan",
    "Laos",
    "Latvia",
    "Lebanon",
    "Lesotho",
    "Liberia",
    "Libya",
    "Liechtenstein",
    "Lithuania",
    "Luxembourg",
    "Madagascar",
    "Malawi",
    "Malaysia",
    "Maldives",
    "Mali",
    "Malta",
    "Marshall Islands",
    "Mauritania",
    "Mauritius",
    "Mexico",
    "Micronesia",
    "Moldova",
    "Monaco",
    "Mongolia",
    "Montenegro",
    "Morocco",
    "Mozambique",
    "Myanmar",
    "Namibia",
    "Nauru",
    "Nepal",
    "Netherlands",
    "New Zealand",
    "Nicaragua",
    "Niger",
    "Nigeria",
    "North Korea",
    "North Macedonia",
    "Norway",
    "Oman",
    "Pakistan",
    "Palau",
    "Palestine",
    "Panama",
    "Papua New Guinea",
    "Paraguay",
    "Peru",
    "Philippines",
    "Poland",
    "Portugal",
    "Qatar",
    "Romania",
    "Russia",
    "Rwanda",
    "Saint Kitts and Nevis",
    "Saint Lucia",
    "Saint Vincent and the Grenadines",
    "Samoa",
    "San Marino",
    "Sao Tome and Principe",
    "Saudi Arabia",
    "Senegal",
    "Serbia",
    "Seychelles",
    "Sierra Leone",
    "Singapore",
    "Slovakia",
    "Slovenia",
    "Somalia",
    "South Africa",
    "South Korea",
    "South Sudan",
    "Spain",
    "Sri Lanka",
    "Sudan",
    "Suriname",
    "Sweden",
    "Switzerland",
    "Syria",
    "Taiwan",
    "Tajikistan",
    "Tanzania",
    "Thailand",
    "Timor-Leste",
    "Togo",
    "Tonga",
    "Trinidad and Tobago",
    "Tunisia",
    "Turkey",
    "Turkmenistan",
    "Tuvalu",
    "Uganda",
    "Ukraine",
    "United Arab Emirates",
    "United Kingdom",
    "United States",
    "Uruguay",
    "Uzbekistan",
    "Vanuatu",
    "Vatican City",
    "Venezuela",
    "Vietnam",
    "Yemen",
    "Zambia",
    "Zimbabwe",
]


# ---------------------------------------------------------
# BANKS
# ---------------------------------------------------------

BANKS = {
    "United Kingdom": [
        "Barclays Bank",
        "HSBC UK",
        "Lloyds Bank",
        "NatWest",
        "Royal Bank of Scotland",
        "Santander UK",
        "Halifax",
        "Nationwide Building Society",
        "TSB Bank",
        "Metro Bank",
        "Monzo Bank",
        "Starling Bank",
        "Virgin Money",
        "First Direct",
        "Bank of Scotland",
        "Other UK Bank"
    ],

    "United States": [
        "JPMorgan Chase Bank",
        "Bank of America",
        "Wells Fargo Bank",
        "Citibank",
        "U.S. Bank",
        "PNC Bank",
        "Truist Bank",
        "Capital One",
        "TD Bank",
        "Other US Bank"
    ],

    "Canada": [
        "Royal Bank of Canada",
        "Toronto-Dominion Bank",
        "Bank of Nova Scotia",
        "Bank of Montreal",
        "Canadian Imperial Bank of Commerce",
        "National Bank of Canada",
        "Desjardins",
        "Other Canadian Bank"
    ],

    "Kenya": [
        "KCB Bank Kenya",
        "Equity Bank Kenya",
        "Co-operative Bank of Kenya",
        "Absa Bank Kenya",
        "NCBA Bank Kenya",
        "Stanbic Bank Kenya",
        "I&M Bank",
        "DTB Kenya",
        "Standard Chartered Kenya",
        "Family Bank",
        "Other Kenyan Bank"
    ],

    "Nigeria": [
        "Access Bank",
        "First Bank of Nigeria",
        "United Bank for Africa",
        "Guaranty Trust Bank",
        "Zenith Bank",
        "Fidelity Bank",
        "Ecobank Nigeria",
        "Stanbic IBTC Bank",
        "Union Bank of Nigeria",
        "Other Nigerian Bank"
    ],

    "Ghana": [
        "GCB Bank",
        "Ecobank Ghana",
        "Absa Bank Ghana",
        "Stanbic Bank Ghana",
        "Standard Chartered Ghana",
        "Fidelity Bank Ghana",
        "CalBank",
        "Republic Bank Ghana",
        "Other Ghanaian Bank"
    ],

    "South Africa": [
        "Standard Bank",
        "First National Bank",
        "Absa Bank",
        "Nedbank",
        "Capitec Bank",
        "Investec Bank",
        "African Bank",
        "Other South African Bank"
    ],

    "Suriname": [
        "De Surinaamsche Bank",
        "Hakrinbank",
        "Republic Bank Suriname",
        "Finabank",
        "Surichange Bank",
        "GODO",
        "Trustbank Amanah",
        "Other Surinamese Bank"
    ],

    "India": [
        "State Bank of India",
        "HDFC Bank",
        "ICICI Bank",
        "Axis Bank",
        "Kotak Mahindra Bank",
        "IndusInd Bank",
        "Punjab National Bank",
        "Bank of Baroda",
        "Canara Bank",
        "Union Bank of India",
        "Other Indian Bank"
    ],

    "Australia": [
        "Commonwealth Bank",
        "Westpac",
        "ANZ Bank",
        "National Australia Bank",
        "Macquarie Bank",
        "Bendigo Bank",
        "Other Australian Bank"
    ],

    "Germany": [
        "Deutsche Bank",
        "Commerzbank",
        "DZ Bank",
        "ING Germany",
        "N26",
        "DKB",
        "Other German Bank"
    ],

    "France": [
        "BNP Paribas",
        "Crédit Agricole",
        "Société Générale",
        "BPCE",
        "Crédit Mutuel",
        "La Banque Postale",
        "Other French Bank"
    ],

    "Netherlands": [
        "ING Bank",
        "ABN AMRO",
        "Rabobank",
        "de Volksbank",
        "Triodos Bank",
        "Other Dutch Bank"
    ],

    "Ireland": [
        "AIB",
        "Bank of Ireland",
        "Permanent TSB",
        "EBS",
        "Other Irish Bank"
    ],

    "Switzerland": [
        "UBS",
        "Zürcher Kantonalbank",
        "Banque Cantonale Vaudoise",
        "Raiffeisen Switzerland",
        "PostFinance",
        "Julius Baer",
        "Other Swiss Bank"
    ],

    "United Arab Emirates": [
        "Emirates NBD",
        "First Abu Dhabi Bank",
        "Abu Dhabi Commercial Bank",
        "Dubai Islamic Bank",
        "Mashreq Bank",
        "Commercial Bank of Dubai",
        "RAKBANK",
        "HSBC UAE",
        "Standard Chartered UAE",
        "Other UAE Bank"
    ],

    "Saudi Arabia": [
        "Saudi National Bank",
        "Al Rajhi Bank",
        "Riyad Bank",
        "Alinma Bank",
        "Bank Albilad",
        "Arab National Bank",
        "Banque Saudi Fransi",
        "Other Saudi Bank"
    ],

    "Qatar": [
        "Qatar National Bank",
        "Qatar Islamic Bank",
        "Doha Bank",
        "Commercial Bank of Qatar",
        "Dukhan Bank",
        "Ahli Bank Qatar",
        "Other Qatari Bank"
    ],

    "Singapore": [
        "DBS Bank",
        "OCBC Bank",
        "United Overseas Bank",
        "Standard Chartered Singapore",
        "HSBC Singapore",
        "Citibank Singapore",
        "Maybank Singapore",
        "Other Singapore Bank"
    ],

    "Japan": [
        "MUFG Bank",
        "Sumitomo Mitsui Banking Corporation",
        "Mizuho Bank",
        "Resona Bank",
        "Japan Post Bank",
        "Other Japanese Bank"
    ],

    "China": [
        "Industrial and Commercial Bank of China",
        "China Construction Bank",
        "Agricultural Bank of China",
        "Bank of China",
        "Bank of Communications",
        "China Merchants Bank",
        "Other Chinese Bank"
    ],

    "Brazil": [
        "Banco do Brasil",
        "Itaú Unibanco",
        "Bradesco",
        "Caixa Econômica Federal",
        "Santander Brasil",
        "BTG Pactual",
        "Other Brazilian Bank"
    ],

    "Mexico": [
        "BBVA México",
        "Banorte",
        "Santander México",
        "Citibanamex",
        "HSBC México",
        "Scotiabank México",
        "Banco Azteca",
        "Other Mexican Bank"
    ],
}


# ---------------------------------------------------------
# CREATE HTML OPTIONS
# ---------------------------------------------------------

country_options = "\n".join(
    f'                        <option value="{html.escape(c, quote=True)}">'
    f'{html.escape(c)}</option>'
    for c in COUNTRIES
)


currency_options = [
    ("GBP", "GBP — Pound Sterling"),
    ("EUR", "EUR — Euro"),
    ("USD", "USD — US Dollar"),
    ("CAD", "CAD — Canadian Dollar"),
    ("AUD", "AUD — Australian Dollar"),
    ("NZD", "NZD — New Zealand Dollar"),
    ("CHF", "CHF — Swiss Franc"),
    ("JPY", "JPY — Japanese Yen"),
    ("CNY", "CNY — Chinese Yuan"),
    ("HKD", "HKD — Hong Kong Dollar"),
    ("SGD", "SGD — Singapore Dollar"),
    ("INR", "INR — Indian Rupee"),
    ("AED", "AED — UAE Dirham"),
    ("SAR", "SAR — Saudi Riyal"),
    ("QAR", "QAR — Qatari Riyal"),
    ("ZAR", "ZAR — South African Rand"),
    ("KES", "KES — Kenyan Shilling"),
    ("NGN", "NGN — Nigerian Naira"),
    ("GHS", "GHS — Ghanaian Cedi"),
    ("TZS", "TZS — Tanzanian Shilling"),
    ("UGX", "UGX — Ugandan Shilling"),
    ("RWF", "RWF — Rwandan Franc"),
    ("BRL", "BRL — Brazilian Real"),
    ("MXN", "MXN — Mexican Peso"),
    ("ARS", "ARS — Argentine Peso"),
    ("SRD", "SRD — Surinamese Dollar"),
    ("THB", "THB — Thai Baht"),
    ("MYR", "MYR — Malaysian Ringgit"),
    ("IDR", "IDR — Indonesian Rupiah"),
    ("KRW", "KRW — South Korean Won"),
    ("TRY", "TRY — Turkish Lira"),
    ("PLN", "PLN — Polish Zloty"),
    ("SEK", "SEK — Swedish Krona"),
    ("NOK", "NOK — Norwegian Krone"),
    ("DKK", "DKK — Danish Krone"),
    ("CZK", "CZK — Czech Koruna"),
    ("HUF", "HUF — Hungarian Forint"),
    ("RON", "RON — Romanian Leu"),
    ("ILS", "ILS — Israeli New Shekel"),
]

currency_options_html = "\n".join(
    f'                        <option value="{code}">{label}</option>'
    for code, label in currency_options
)


# ---------------------------------------------------------
# THREE CLEAN FIELD BLOCKS
# ---------------------------------------------------------

country_block = f'''
            <div class="field">
                <label>Destination Country</label>

                <div class="fairmont-one-picker" data-picker-type="country">

                    <select
                        id="internationalCountry"
                        name="country"
                        class="fairmont-hidden-select"
                        required
                    >
                        <option value="">Select country</option>
{country_options}
                    </select>

                    <button
                        type="button"
                        class="fairmont-one-trigger"
                        data-picker-trigger="country"
                        aria-expanded="false"
                    >
                        <span>Select country</span>
                        <span class="fairmont-one-arrow">▾</span>
                    </button>

                </div>
            </div>
'''


bank_block = '''
            <div class="field">
                <label>Bank Name</label>

                <div class="fairmont-one-picker" data-picker-type="bank">

                    <select
                        id="internationalBank"
                        name="bank_name"
                        class="fairmont-hidden-select"
                        required
                        disabled
                    >
                        <option value="">Select a bank</option>
                    </select>

                    <button
                        type="button"
                        class="fairmont-one-trigger"
                        data-picker-trigger="bank"
                        aria-expanded="false"
                    >
                        <span>Select a bank</span>
                        <span class="fairmont-one-arrow">▾</span>
                    </button>

                </div>
            </div>
'''


currency_block = f'''
            <div class="field">
                <label>Currency</label>

                <div class="fairmont-one-picker" data-picker-type="currency">

                    <select
                        id="internationalCurrency"
                        name="currency"
                        class="fairmont-hidden-select"
                        required
                    >
                        <option value="">Select currency</option>
{currency_options_html}
                    </select>

                    <button
                        type="button"
                        class="fairmont-one-trigger"
                        data-picker-trigger="currency"
                        aria-expanded="false"
                    >
                        <span>Select currency</span>
                        <span class="fairmont-one-arrow">▾</span>
                    </button>

                </div>
            </div>
'''


# ---------------------------------------------------------
# REPLACE FIELD USING LABEL BOUNDARIES
# ---------------------------------------------------------

def replace_between_fields(text, current_label, next_label, replacement):
    pattern = re.compile(
        r'<div\s+class\s*=\s*["\']field["\'][^>]*>'
        r'\s*'
        r'<label>\s*'
        + re.escape(current_label)
        + r'\s*</label>'
        r'.*?'
        r'(?='
        r'<div\s+class\s*=\s*["\']field["\'][^>]*>'
        r'\s*'
        r'<label>\s*'
        + re.escape(next_label)
        + r'\s*</label>'
        r')',
        re.IGNORECASE | re.DOTALL
    )

    result, count = pattern.subn(
        replacement.strip() + "\n\n",
        text,
        count=1
    )

    return result, count


source, count_country = replace_between_fields(
    source,
    "Destination Country",
    "Beneficiary Name",
    country_block
)

if count_country != 1:
    print()
    print("ERROR: Destination Country field could not be located.")
    print("NO FILE WAS CHANGED.")
    raise SystemExit(1)


source, count_bank = replace_between_fields(
    source,
    "Bank Name",
    "Account Number",
    bank_block
)

if count_bank != 1:
    print()
    print("ERROR: Bank Name field could not be located.")
    print("NO FILE WAS CHANGED.")
    raise SystemExit(1)


source, count_currency = replace_between_fields(
    source,
    "Currency",
    "Amount",
    currency_block
)

if count_currency != 1:
    print()
    print("ERROR: Currency field could not be located.")
    print("NO FILE WAS CHANGED.")
    raise SystemExit(1)


# ---------------------------------------------------------
# ONE CLEAN CSS BLOCK
# ---------------------------------------------------------

picker_css = r'''
<style id="fairmont-one-picker-css">

.fairmont-one-picker {
    position: relative;
    width: 100%;
}

.fairmont-hidden-select {
    position: absolute !important;
    width: 1px !important;
    height: 1px !important;
    opacity: 0 !important;
    pointer-events: none !important;
    overflow: hidden !important;
}

.fairmont-one-trigger {
    width: 100%;
    min-height: 52px;
    padding: 0 16px;
    border-radius: 14px;
    border: 1px solid rgba(255,255,255,0.14);
    background: rgba(255,255,255,0.055);
    color: rgba(255,255,255,0.72);
    display: flex;
    align-items: center;
    justify-content: space-between;
    text-align: left;
    font-size: 15px;
    cursor: pointer;
    box-sizing: border-box;
}

.fairmont-one-trigger.selected {
    color: #ffffff;
}

.fairmont-one-trigger:focus {
    outline: none;
    border-color: rgba(255,255,255,0.35);
}

.fairmont-one-arrow {
    margin-left: 12px;
}

.fairmont-one-popup {
    position: fixed;
    z-index: 999999;
    display: none;
    background: #101a2d;
    border: 1px solid rgba(255,255,255,0.16);
    border-radius: 15px;
    box-shadow: 0 22px 60px rgba(0,0,0,0.55);
    overflow: hidden;
}

.fairmont-one-popup.open {
    display: block;
}

.fairmont-one-search {
    display: block;
    width: calc(100% - 24px);
    height: 44px;
    margin: 12px;
    padding: 0 13px;
    box-sizing: border-box;
    border-radius: 10px;
    border: 1px solid rgba(255,255,255,0.14);
    background: rgba(255,255,255,0.07);
    color: #ffffff;
    font-size: 14px;
    outline: none;
}

.fairmont-one-search::placeholder {
    color: rgba(255,255,255,0.45);
}

.fairmont-one-list {
    max-height: 340px;
    overflow-y: auto;
}

.fairmont-one-option {
    display: block;
    width: 100%;
    padding: 13px 16px;
    border: 0;
    border-top: 1px solid rgba(255,255,255,0.055);
    background: transparent;
    color: #ffffff;
    text-align: left;
    font-size: 14px;
    cursor: pointer;
}

.fairmont-one-option:hover {
    background: rgba(255,255,255,0.08);
}

.fairmont-one-empty {
    padding: 18px;
    color: rgba(255,255,255,0.5);
    text-align: center;
    font-size: 14px;
}

</style>
'''


# ---------------------------------------------------------
# ONE CLEAN JAVASCRIPT BLOCK
# ---------------------------------------------------------

bank_json = json.dumps(
    BANKS,
    ensure_ascii=False
)

picker_js = r'''
<script id="fairmont-one-picker-js">
(function () {

    "use strict";

    const BANKS = __BANK_DATA__;

    let activePicker = null;
    let popup = null;

    const countrySelect =
        document.getElementById("internationalCountry");

    const bankSelect =
        document.getElementById("internationalBank");

    const currencySelect =
        document.getElementById("internationalCurrency");

    const countryTrigger =
        document.querySelector(
            '[data-picker-trigger="country"]'
        );

    const bankTrigger =
        document.querySelector(
            '[data-picker-trigger="bank"]'
        );

    const currencyTrigger =
        document.querySelector(
            '[data-picker-trigger="currency"]'
        );


    function setTrigger(trigger, text, selected) {

        if (!trigger) {
            return;
        }

        const label = trigger.querySelector("span");

        if (label) {
            label.textContent = text;
        }

        trigger.classList.toggle(
            "selected",
            selected
        );
    }


    function closePicker() {

        if (popup) {
            popup.remove();
            popup = null;
        }

        if (
            activePicker &&
            activePicker.trigger
        ) {
            activePicker.trigger.setAttribute(
                "aria-expanded",
                "false"
            );
        }

        activePicker = null;
    }


    function positionPopup() {

        if (!popup || !activePicker) {
            return;
        }

        const rect =
            activePicker.trigger.getBoundingClientRect();

        const width =
            Math.min(
                420,
                window.innerWidth - 28
            );

        let left = rect.left;

        if (
            left + width >
            window.innerWidth - 14
        ) {
            left =
                window.innerWidth -
                width -
                14;
        }

        if (left < 14) {
            left = 14;
        }

        popup.style.width =
            width + "px";

        popup.style.left =
            left + "px";

        let top =
            rect.bottom + 8;

        const popupHeight =
            Math.min(
                410,
                window.innerHeight - 28
            );

        if (
            top + popupHeight >
            window.innerHeight - 14
        ) {
            top =
                rect.top -
                popupHeight -
                8;
        }

        if (top < 14) {
            top = 14;
        }

        popup.style.top =
            top + "px";

        popup.style.maxHeight =
            popupHeight + "px";
    }


    function countryOptions() {

        return Array.from(
            countrySelect.options
        )
        .filter(function (option) {
            return option.value !== "";
        })
        .map(function (option) {
            return {
                value: option.value,
                label: option.textContent.trim()
            };
        });
    }


    function currencyOptions() {

        return Array.from(
            currencySelect.options
        )
        .filter(function (option) {
            return option.value !== "";
        })
        .map(function (option) {
            return {
                value: option.value,
                label: option.textContent.trim()
            };
        });
    }


    function bankOptions() {

        const country =
            countrySelect.value;

        if (!country) {
            return [];
        }

        return (
            BANKS[country] || []
        ).map(function (bank) {
            return {
                value: bank,
                label: bank
            };
        });
    }


    function renderOptions(
        type,
        searchText
    ) {

        const list =
            popup.querySelector(
                ".fairmont-one-list"
            );

        if (!list) {
            return;
        }

        let options = [];

        if (type === "country") {
            options =
                countryOptions();
        }

        if (type === "bank") {
            options =
                bankOptions();
        }

        if (type === "currency") {
            options =
                currencyOptions();
        }

        const search =
            (searchText || "")
                .trim()
                .toLowerCase();

        if (search) {
            options =
                options.filter(
                    function (item) {
                        return item.label
                            .toLowerCase()
                            .includes(search);
                    }
                );
        }

        list.innerHTML = "";

        if (!options.length) {

            const empty =
                document.createElement("div");

            empty.className =
                "fairmont-one-empty";

            empty.textContent =
                type === "bank" &&
                !countrySelect.value
                    ? "Select a country first."
                    : "No results found.";

            list.appendChild(empty);

            return;
        }

        options.forEach(
            function (item) {

                const option =
                    document.createElement("button");

                option.type = "button";

                option.className =
                    "fairmont-one-option";

                option.textContent =
                    item.label;

                option.addEventListener(
                    "click",
                    function () {

                        chooseOption(
                            type,
                            item.value,
                            item.label
                        );

                    }
                );

                list.appendChild(option);
            }
        );
    }


    function chooseOption(
        type,
        value,
        label
    ) {

        if (type === "country") {

            countrySelect.value =
                value;

            setTrigger(
                countryTrigger,
                label,
                true
            );

            bankSelect.innerHTML =
                '<option value="">Select a bank</option>';

            const banks =
                bankOptions();

            banks.forEach(
                function (item) {

                    const option =
                        document.createElement("option");

                    option.value =
                        item.value;

                    option.textContent =
                        item.label;

                    bankSelect.appendChild(
                        option
                    );

                }
            );

            bankSelect.disabled =
                banks.length === 0;

            setTrigger(
                bankTrigger,
                "Select a bank",
                false
            );

            countrySelect.dispatchEvent(
                new Event(
                    "change",
                    { bubbles: true }
                )
            );
        }


        if (type === "bank") {

            bankSelect.value =
                value;

            setTrigger(
                bankTrigger,
                label,
                true
            );

            bankSelect.dispatchEvent(
                new Event(
                    "change",
                    { bubbles: true }
                )
            );
        }


        if (type === "currency") {

            currencySelect.value =
                value;

            setTrigger(
                currencyTrigger,
                label,
                true
            );

            currencySelect.dispatchEvent(
                new Event(
                    "change",
                    { bubbles: true }
                )
            );
        }

        closePicker();
    }


    function openPicker(
        type,
        trigger
    ) {

        if (
            activePicker &&
            activePicker.type === type
        ) {
            closePicker();
            return;
        }

        closePicker();

        if (
            type === "bank" &&
            !countrySelect.value
        ) {
            return;
        }

        popup =
            document.createElement("div");

        popup.className =
            "fairmont-one-popup open";

        const search =
            document.createElement("input");

        search.type = "search";

        search.className =
            "fairmont-one-search";

        search.placeholder =
            type === "country"
                ? "Search country..."
                : type === "bank"
                    ? "Search bank..."
                    : "Search currency...";

        search.autocomplete =
            "off";

        const list =
            document.createElement("div");

        list.className =
            "fairmont-one-list";

        popup.appendChild(search);
        popup.appendChild(list);

        document.body.appendChild(
            popup
        );

        activePicker = {
            type: type,
            trigger: trigger
        };

        trigger.setAttribute(
            "aria-expanded",
            "true"
        );

        renderOptions(
            type,
            ""
        );

        positionPopup();

        setTimeout(
            function () {
                search.focus();
            },
            0
        );

        search.addEventListener(
            "input",
            function () {

                renderOptions(
                    type,
                    search.value
                );

            }
        );
    }


    if (countryTrigger) {

        countryTrigger.addEventListener(
            "click",
            function () {

                openPicker(
                    "country",
                    countryTrigger
                );

            }
        );

    }


    if (bankTrigger) {

        bankTrigger.addEventListener(
            "click",
            function () {

                openPicker(
                    "bank",
                    bankTrigger
                );

            }
        );

    }


    if (currencyTrigger) {

        currencyTrigger.addEventListener(
            "click",
            function () {

                openPicker(
                    "currency",
                    currencyTrigger
                );

            }
        );

    }


    document.addEventListener(
        "click",
        function (event) {

            if (!activePicker) {
                return;
            }

            if (
                popup &&
                popup.contains(event.target)
            ) {
                return;
            }

            if (
                activePicker.trigger &&
                activePicker.trigger.contains(
                    event.target
                )
            ) {
                return;
            }

            closePicker();

        }
    );


    document.addEventListener(
        "keydown",
        function (event) {

            if (event.key === "Escape") {
                closePicker();
            }

        }
    );


    window.addEventListener(
        "resize",
        positionPopup
    );


    window.addEventListener(
        "scroll",
        positionPopup,
        true
    );


    if (bankSelect) {
        bankSelect.disabled = true;
    }


})();
</script>
'''.replace(
    "__BANK_DATA__",
    bank_json
)


# ---------------------------------------------------------
# INSERT NEW CSS + JS
# ---------------------------------------------------------

if "fairmont-one-picker-css" in source:
    print("ERROR: New picker CSS already exists.")
    print("NO FILE WAS CHANGED.")
    raise SystemExit(1)

if "fairmont-one-picker-js" in source:
    print("ERROR: New picker JS already exists.")
    print("NO FILE WAS CHANGED.")
    raise SystemExit(1)


if "</head>" not in source:
    print("ERROR: </head> was not found.")
    print("NO FILE WAS CHANGED.")
    raise SystemExit(1)


if "</body>" not in source:
    print("ERROR: </body> was not found.")
    print("NO FILE WAS CHANGED.")
    raise SystemExit(1)


source = source.replace(
    "</head>",
    picker_css + "\n</head>",
    1
)

source = source.replace(
    "</body>",
    picker_js + "\n</body>",
    1
)


# ---------------------------------------------------------
# FINAL SAFETY CHECKS
# ---------------------------------------------------------

def count_pattern(pattern):
    return len(
        re.findall(
            pattern,
            source,
            re.IGNORECASE | re.DOTALL
        )
    )


checks = {
    "country select":
        count_pattern(
            r'<select\b[^>]*\bname\s*=\s*["\']country["\']'
        ),

    "bank select":
        count_pattern(
            r'<select\b[^>]*\bname\s*=\s*["\']bank_name["\']'
        ),

    "currency select":
        count_pattern(
            r'<select\b[^>]*\bname\s*=\s*["\']currency["\']'
        ),

    "country trigger":
        count_pattern(
            r'data-picker-trigger\s*=\s*["\']country["\']'
        ),

    "bank trigger":
        count_pattern(
            r'data-picker-trigger\s*=\s*["\']bank["\']'
        ),

    "currency trigger":
        count_pattern(
            r'data-picker-trigger\s*=\s*["\']currency["\']'
        ),

    "new CSS":
        source.count(
            'id="fairmont-one-picker-css"'
        ),

    "new JS":
        source.count(
            'id="fairmont-one-picker-js"'
        ),
}


print()
print("FINAL SAFETY CHECK")
print("==================")

for name, value in checks.items():
    print(f"{name}: {value}")


expected = {
    "country select": 1,
    "bank select": 1,
    "currency select": 1,
    "country trigger": 1,
    "bank trigger": 1,
    "currency trigger": 1,
    "new CSS": 1,
    "new JS": 1,
}


for name, required in expected.items():

    if checks[name] != required:

        print()
        print(
            f"ERROR: {name} expected {required}, "
            f"found {checks[name]}."
        )

        print("NO FINAL FILE WAS WRITTEN.")

        raise SystemExit(1)


# Make sure the old picker wrappers are no longer present.
old_html_markers = [
    'class="quick-search-select"',
    'class="search-select-wrapper"',
    'class="quick-search-input"',
    'class="quick-search-results"',
    'class="fairmont-real-select"',
    'class="fairmont-picker-real-select"',
    'class="fairmont-picker-popup"',
    'class="fairmont-picker-options"',
]


remaining_old = [
    marker
    for marker in old_html_markers
    if marker in source
]


if remaining_old:

    print()
    print("ERROR: Old picker HTML still exists:")
    for marker in remaining_old:
        print("  ", marker)

    print()
    print("NO FINAL FILE WAS WRITTEN.")

    raise SystemExit(1)


# ---------------------------------------------------------
# WRITE ONLY AFTER EVERY CHECK PASSES
# ---------------------------------------------------------

TEMPLATE.write_text(
    source,
    encoding="utf-8"
)


print()
print("==============================================")
print("SUCCESS")
print("==============================================")
print()
print("Exactly ONE Country control.")
print("Exactly ONE Bank control.")
print("Exactly ONE Currency control.")
print()
print("Search is INSIDE the opened dropdown.")
print("There is NO permanent search bar.")
print("Banks change according to selected country.")
print("Suriname is included.")
print()
print("Database: NOT TOUCHED")
print("app.py: NOT TOUCHED")
print("Dashboard: NOT TOUCHED")
print()
print("Backup:", backup.name)