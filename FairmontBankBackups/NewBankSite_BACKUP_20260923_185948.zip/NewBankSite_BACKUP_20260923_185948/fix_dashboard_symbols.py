from pathlib import Path

file = Path("templates/dashboard.html")

if not file.exists():
    raise SystemExit("ERROR: templates/dashboard.html was not found.")

text = file.read_text(encoding="utf-8")

# Backup the current dashboard before changing anything.
backup = Path("templates/dashboard_encoding_backup.html")
backup.write_text(text, encoding="utf-8")

# Targeted repair of the mojibake visible in the dashboard.
replacements = {
    "Â£": "£",

    "â†‘": "↑",
    "â†“": "↓",
    "â†’": "→",
    "â†": "←",
    "â†”": "↔",

    "â‰¡": "≡",
    "â–¡": "□",
    "â– ": "■",

    "âœˆ": "✈",
    "â˜Ž": "☎",
    "âš¡": "⚡",

    "â—‡": "◇",
    "â—†": "◆",
    "â—¯": "●",
    "â€¢": "•",

    "â€¹": "‹",
    "â€º": "›",
    "â€”": "—",
    "â€“": "–",

    "â€œ": "“",
    "â€": "”",
    "â€˜": "‘",
    "â€™": "’",

    "Ã—": "×",
    "Ã·": "÷",
}

changed = []

for bad, good in replacements.items():
    count = text.count(bad)

    if count:
        text = text.replace(bad, good)
        changed.append(f"{bad} -> {good} ({count})")

if not changed:
    print("NOTICE: No known corrupted dashboard symbols were found.")
else:
    file.write_text(text, encoding="utf-8")

    print("SUCCESS: Dashboard symbols repaired.")
    print()
    print("Changes made:")
    for item in changed:
        print(" - " + item)

print()
print("BACKUP:")
print(backup)