from pathlib import Path

FILE = Path(
    r"C:\Users\DON J\Documents\NewBankSite\templates\dashboard.html"
)

text = FILE.read_text(encoding="utf-8")

old = '''<!-- International Transfer -->
'''

if old not in text:
    print("ERROR: International Transfer section was not found.")
    raise SystemExit(1)

section_start = text.find(old)

href_start = text.find('href="', section_start)

if href_start == -1:
    print("ERROR: International Transfer link was not found.")
    raise SystemExit(1)

href_end = text.find('"', href_start + 6)

if href_end == -1:
    print("ERROR: International Transfer link could not be read.")
    raise SystemExit(1)

current_href = text[href_start + 6:href_end]

if current_href == "/international-transfer":

    print("SUCCESS: International Transfer is already connected.")

else:

    text = (
        text[:href_start]
        + 'href="/international-transfer"'
        + text[href_end + 1:]
    )

    FILE.write_text(
        text,
        encoding="utf-8"
    )

    print("SUCCESS: International Transfer connected.")
    print(f"Previous link: {current_href}")
    print("New link:      /international-transfer")