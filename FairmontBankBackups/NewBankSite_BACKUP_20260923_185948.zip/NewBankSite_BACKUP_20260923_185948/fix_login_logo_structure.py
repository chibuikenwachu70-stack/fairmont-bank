from pathlib import Path
import shutil

BASE = Path(r"C:\Users\DON J\Documents\NewBankSite")
FILE = BASE / "templates" / "login.html"

# Backup current file before changing it
backup = FILE.with_suffix(".html.before_logo_structure_fix")
shutil.copy2(FILE, backup)

text = FILE.read_text(encoding="utf-8")

# Remove the temporary CSS that the previous fixer added.
style_start = text.find('<style id="fairmont-login-logo-fix">')

if style_start != -1:
    style_end = text.find("</style>", style_start)

    if style_end == -1:
        print("ERROR: Could not find the end of the temporary logo CSS.")
        raise SystemExit(1)

    style_end += len("</style>")

    text = text[:style_start] + text[style_end:]


# Locate the login branding area.
brand_start = text.find('<div class="login-brand">')

if brand_start == -1:
    print("ERROR: login-brand section was not found.")
    raise SystemExit(1)


# The old branding section ends immediately before the error block.
error_marker = "{% if error %}"

brand_end = text.find(error_marker, brand_start)

if brand_end == -1:
    print("ERROR: Could not find the login error section.")
    raise SystemExit(1)


# Replace the entire old branding area with one clean logo.
new_brand = """<div class="login-brand">

                <img
                    src="{{ url_for('static', filename='images/fairmont-bank-logo.png') }}"
                    alt="Fairmont Bank"
                    class="login-fairmont-logo">

            </div>


            """


text = text[:brand_start] + new_brand + text[brand_end:]


# Add only the necessary logo sizing.
# This is deliberately small and does not alter the login layout.
head_marker = "</head>"

logo_css = """
<style id="fairmont-login-logo">
.login-brand {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    margin-bottom: 22px;
}

.login-fairmont-logo {
    display: block;
    width: 210px;
    max-width: 80%;
    height: auto;
    object-fit: contain;
}
</style>

"""

if "fairmont-login-logo" not in text:
    head_position = text.find(head_marker)

    if head_position == -1:
        print("ERROR: </head> was not found.")
        raise SystemExit(1)

    text = text[:head_position] + logo_css + text[head_position:]


FILE.write_text(text, encoding="utf-8")

print("SUCCESS: Login logo structure repaired.")
print("The old duplicate branding and extra closing tag were removed.")
print(f"Backup created: {backup.name}")