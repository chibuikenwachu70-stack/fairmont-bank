from pathlib import Path

file = Path("templates/dashboard.html")

if not file.exists():
    raise SystemExit("ERROR: templates/dashboard.html was not found.")

text = file.read_text(encoding="utf-8")

old = """<!-- Lifestyles -->

                    <a
                        href="#"
                        class="service-item">

                        <span class="service-icon">
                            ◆
                        </span>

                        <span class="service-name">
                            Lifestyles
                        </span>

                    </a>"""

new = """<!-- Lifestyles -->

                    <a
                        href="/lifestyle"
                        class="service-item">

                        <span class="service-icon">
                            ◆
                        </span>

                        <span class="service-name">
                            Lifestyles
                        </span>

                    </a>"""

if old not in text:
    raise SystemExit(
        "ERROR: The exact Lifestyle card was not found. "
        "No changes were made."
    )

text = text.replace(old, new, 1)

file.write_text(text, encoding="utf-8")

print("SUCCESS: Lifestyle dashboard card now opens /lifestyle.")
print("Only the Lifestyle card was changed.")