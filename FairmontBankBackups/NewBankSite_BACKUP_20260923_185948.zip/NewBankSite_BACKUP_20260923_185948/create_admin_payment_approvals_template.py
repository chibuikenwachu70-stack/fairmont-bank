from pathlib import Path

path = Path("templates/admin_payment_approvals.html")

html = r'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Approvals - Fairmont Bank</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background:
                radial-gradient(circle at top right, rgba(184,149,74,0.10), transparent 30%),
                #07111f;
            color: #eef3f8;
            min-height: 100vh;
        }

        .page {
            max-width: 1400px;
            margin: 0 auto;
            padding: 28px;
        }

        .topbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            margin-bottom: 28px;
        }

        .brand {
            display: flex;
            align-items: center;
        }

        .brand img {
            width: 190px;
            max-width: 100%;
            height: auto;
            display: block;
        }

        .back-link {
            color: #d8b96a;
            text-decoration: none;
            font-size: 14px;
            font-weight: 700;
        }

        .back-link:hover {
            text-decoration: underline;
        }

        .heading {
            margin-bottom: 24px;
        }

        .heading h1 {
            margin: 0 0 8px;
            font-size: 30px;
            letter-spacing: -0.5px;
        }

        .heading p {
            margin: 0;
            color: #9fb0c2;
            font-size: 14px;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 16px;
            margin-bottom: 24px;
        }

        .stat-card {
            background: rgba(15, 29, 46, 0.82);
            border: 1px solid rgba(255,255,255,0.08);
            border-radius: 16px;
            padding: 20px;
        }

        .stat-label {
            color: #9fb0c2;
            font-size: 13px;
            margin-bottom: 8px;
        }

        .stat-value {
            font-size: 28px;
            font-weight: 800;
        }

        .pending-value {
            color: #d8b96a;
        }

        .content-card {
            background: rgba(10, 24, 39, 0.90);
            border: 1px solid rgba(255,255,255,0.08);
            border-radius: 18px;
            overflow: hidden;
        }

        .filters {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 18px;
            border-bottom: 1px solid rgba(255,255,255,0.08);
            flex-wrap: wrap;
        }

        .filter-link {
            display: inline-block;
            padding: 9px 14px;
            border-radius: 9px;
            text-decoration: none;
            color: #aebdcd;
            border: 1px solid rgba(255,255,255,0.08);
            font-size: 13px;
            font-weight: 700;
        }

        .filter-link:hover,
        .filter-link.active {
            color: #07111f;
            background: #d8b96a;
            border-color: #d8b96a;
        }

        .table-wrap {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1050px;
        }

        th,
        td {
            padding: 15px 16px;
            text-align: left;
            border-bottom: 1px solid rgba(255,255,255,0.06);
            vertical-align: middle;
        }

        th {
            color: #8fa2b6;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.7px;
            font-weight: 700;
        }

        td {
            font-size: 13px;
            color: #e8eef5;
        }

        tr:hover td {
            background: rgba(255,255,255,0.025);
        }

        .reference {
            font-weight: 700;
            color: #d8b96a;
        }

        .customer-name {
            font-weight: 700;
        }

        .customer-id {
            color: #8fa2b6;
            font-size: 11px;
            margin-top: 3px;
        }

        .amount {
            font-weight: 800;
            white-space: nowrap;
        }

        .status {
            display: inline-flex;
            align-items: center;
            padding: 6px 10px;
            border-radius: 999px;
            font-size: 11px;
            font-weight: 800;
            white-space: nowrap;
        }

        .status-pending {
            color: #d8b96a;
            background: rgba(184,149,74,0.12);
            border: 1px solid rgba(184,149,74,0.28);
        }

        .status-approved {
            color: #8dd7b1;
            background: rgba(76,175,120,0.10);
            border: 1px solid rgba(76,175,120,0.22);
        }

        .status-rejected {
            color: #e8a0a0;
            background: rgba(210,80,80,0.10);
            border: 1px solid rgba(210,80,80,0.22);
        }

        .empty {
            text-align: center;
            padding: 60px 20px;
            color: #8fa2b6;
        }

        .empty strong {
            display: block;
            color: #e8eef5;
            font-size: 16px;
            margin-bottom: 8px;
        }

        .amount-cell {
            white-space: nowrap;
        }

        .type {
            color: #b9c6d4;
        }

        @media (max-width: 800px) {
            .page {
                padding: 18px;
            }

            .topbar {
                align-items: flex-start;
                flex-direction: column;
            }

            .stats {
                grid-template-columns: 1fr;
            }

            .heading h1 {
                font-size: 25px;
            }
        }
    </style>
</head>

<body>
    <main class="page">

        <div class="topbar">
            <div class="brand">
                <img
                    src="{{ url_for('static', filename='images/fairmont-bank-logo.png') }}"
                    alt="Fairmont Bank">
            </div>

            <a href="{{ url_for('admin_dashboard') }}" class="back-link">
                Back to Administration
            </a>
        </div>

        <section class="heading">
            <h1>Payment Approvals</h1>
            <p>
                Review customer payment requests before funds are posted to an account.
            </p>
        </section>

        <section class="stats">
            <div class="stat-card">
                <div class="stat-label">Pending Approval</div>
                <div class="stat-value pending-value">{{ pending_count }}</div>
            </div>

            <div class="stat-card">
                <div class="stat-label">Approved</div>
                <div class="stat-value">{{ approved_count }}</div>
            </div>

            <div class="stat-card">
                <div class="stat-label">Rejected</div>
                <div class="stat-value">{{ rejected_count }}</div>
            </div>
        </section>

        <section class="content-card">

            <div class="filters">
                <a
                    href="{{ url_for('admin_payment_approvals', status='Pending Approval') }}"
                    class="filter-link {% if status_filter == 'Pending Approval' %}active{% endif %}">
                    Pending
                </a>

                <a
                    href="{{ url_for('admin_payment_approvals', status='Approved') }}"
                    class="filter-link {% if status_filter == 'Approved' %}active{% endif %}">
                    Approved
                </a>

                <a
                    href="{{ url_for('admin_payment_approvals', status='Rejected') }}"
                    class="filter-link {% if status_filter == 'Rejected' %}active{% endif %}">
                    Rejected
                </a>

                <a
                    href="{{ url_for('admin_payment_approvals', status='All') }}"
                    class="filter-link {% if status_filter == 'All' %}active{% endif %}">
                    All Payments
                </a>
            </div>

            {% if approvals %}

            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Reference</th>
                            <th>Customer</th>
                            <th>Payment Type</th>
                            <th>Amount</th>
                            <th>Description</th>
                            <th>Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>

                    <tbody>
                        {% for approval in approvals %}
                        {% set customer = customer_map.get(approval.customer_id) %}

                        <tr>
                            <td>
                                <div class="reference">
                                    {{ approval.payment_reference }}
                                </div>
                            </td>

                            <td>
                                <div class="customer-name">
                                    {{ customer.full_name if customer else approval.customer_id }}
                                </div>

                                <div class="customer-id">
                                    {{ approval.customer_id }}
                                </div>
                            </td>

                            <td>
                                <span class="type">
                                    {{ approval.payment_type }}
                                </span>
                            </td>

                            <td class="amount-cell">
                                <span class="amount">
                                    £{{ "{:,.2f}".format(approval.amount) }}
                                </span>
                            </td>

                            <td>
                                {{ approval.description }}
                            </td>

                            <td>
                                {{ approval.created_at.strftime("%d %b %Y, %H:%M") }}
                            </td>

                            <td>
                                {% if approval.status == "Pending Approval" %}
                                    <span class="status status-pending">
                                        Pending Approval
                                    </span>
                                {% elif approval.status == "Approved" %}
                                    <span class="status status-approved">
                                        Approved
                                    </span>
                                {% elif approval.status == "Rejected" %}
                                    <span class="status status-rejected">
                                        Rejected
                                    </span>
                                {% else %}
                                    <span class="status">
                                        {{ approval.status }}
                                    </span>
                                {% endif %}
                            </td>
                        </tr>

                        {% endfor %}
                    </tbody>
                </table>
            </div>

            {% else %}

            <div class="empty">
                <strong>No payment requests found</strong>
                There are currently no payments matching this status.
            </div>

            {% endif %}

        </section>

    </main>
</body>
</html>
'''

path.write_text(html, encoding="utf-8")

print("SUCCESS: admin_payment_approvals.html created.")