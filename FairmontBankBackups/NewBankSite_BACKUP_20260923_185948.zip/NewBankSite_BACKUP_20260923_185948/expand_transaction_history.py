from pathlib import Path


app_file = Path("app.py")
template_file = Path("templates/transactions.html")

if not app_file.exists():
    raise SystemExit("ERROR: app.py was not found.")

if not template_file.exists():
    raise SystemExit("ERROR: templates/transactions.html was not found.")


# =========================================================
# UPDATE TRANSACTION HISTORY ROUTE
# =========================================================

app_text = app_file.read_text(encoding="utf-8")

old_route = '''@app.route("/transactions")
def transactions():

    customer_id = session.get("customer_id")

    if not customer_id:

        return render_template(
            "login.html",
            error="Please sign in to view your transactions."
        )

    customer = Customer.query.filter_by(
        customer_id=customer_id
    ).first()

    if customer is None:

        session.clear()

        return render_template(
            "login.html",
            error="Your session could not be verified. Please sign in again."
        )

    transaction_list = (
        Transaction.query
        .filter_by(customer_id=customer.customer_id)
        .order_by(Transaction.created_at.desc())
        .all()
    )

    return render_template(
        "transactions.html",
        customer=customer,
        transactions=transaction_list
    )
'''

new_route = '''@app.route("/transactions")
def transactions():

    customer_id = session.get("customer_id")

    if not customer_id:

        return render_template(
            "login.html",
            error="Please sign in to view your transactions."
        )

    customer = Customer.query.filter_by(
        customer_id=customer_id
    ).first()

    if customer is None:

        session.clear()

        return render_template(
            "login.html",
            error="Your session could not be verified. Please sign in again."
        )

    search = request.args.get("search", "").strip()
    transaction_type = request.args.get("type", "").strip()
    direction = request.args.get("direction", "").strip()
    date_range = request.args.get("date_range", "").strip()

    query = Transaction.query.filter_by(
        customer_id=customer.customer_id
    )

    if search:
        search_value = f"%{search}%"

        query = query.filter(
            db.or_(
                Transaction.description.ilike(search_value),
                Transaction.counterparty.ilike(search_value),
                Transaction.transaction_reference.ilike(search_value)
            )
        )

    if transaction_type:
        query = query.filter(
            Transaction.transaction_type == transaction_type
        )

    if direction in ("Credit", "Debit"):
        query = query.filter(
            Transaction.direction == direction
        )

    if date_range in ("today", "7", "30"):

        from datetime import timedelta

        now = datetime.now()

        if date_range == "today":
            start_date = now.replace(
                hour=0,
                minute=0,
                second=0,
                microsecond=0
            )

        elif date_range == "7":
            start_date = now - timedelta(days=7)

        else:
            start_date = now - timedelta(days=30)

        query = query.filter(
            Transaction.created_at >= start_date
        )

    transaction_list = (
        query
        .order_by(Transaction.created_at.desc())
        .all()
    )

    transaction_types = (
        db.session.query(Transaction.transaction_type)
        .filter_by(customer_id=customer.customer_id)
        .distinct()
        .order_by(Transaction.transaction_type.asc())
        .all()
    )

    transaction_types = [
        item[0]
        for item in transaction_types
        if item[0]
    ]

    return render_template(
        "transactions.html",
        customer=customer,
        transactions=transaction_list,
        transaction_types=transaction_types,
        search=search,
        selected_type=transaction_type,
        selected_direction=direction,
        selected_date_range=date_range
    )
'''

if old_route not in app_text:
    raise SystemExit(
        "ERROR: The existing /transactions route was not found exactly. "
        "No changes were made."
    )

app_text = app_text.replace(old_route, new_route, 1)

app_file.write_text(app_text, encoding="utf-8")

print("SUCCESS: Transaction History backend filters added.")


# =========================================================
# UPDATE TRANSACTION HISTORY PAGE
# =========================================================

html = template_file.read_text(encoding="utf-8")

marker = '''            <section class="transaction-list-section">
'''

if marker not in html:
    raise SystemExit(
        "ERROR: Transaction list section was not found. "
        "No template changes were made."
    )

filter_block = '''            <section class="transaction-filters">

                <form method="GET"
                      action="{{ url_for('transactions') }}"
                      class="transaction-filter-form">

                    <div class="transaction-search-row">

                        <input
                            type="search"
                            name="search"
                            value="{{ search }}"
                            placeholder="Search transactions"
                            autocomplete="off"
                        >

                        <button type="submit">
                            Search
                        </button>

                    </div>

                    <div class="transaction-filter-row">

                        <select name="type">

                            <option value="">
                                All transaction types
                            </option>

                            {% for item in transaction_types %}

                                <option
                                    value="{{ item }}"
                                    {% if selected_type == item %}selected{% endif %}
                                >
                                    {{ item }}
                                </option>

                            {% endfor %}

                        </select>


                        <select name="direction">

                            <option value="">
                                All transactions
                            </option>

                            <option
                                value="Credit"
                                {% if selected_direction == "Credit" %}selected{% endif %}
                            >
                                Money In
                            </option>

                            <option
                                value="Debit"
                                {% if selected_direction == "Debit" %}selected{% endif %}
                            >
                                Money Out
                            </option>

                        </select>


                        <select name="date_range">

                            <option value="">
                                All dates
                            </option>

                            <option
                                value="today"
                                {% if selected_date_range == "today" %}selected{% endif %}
                            >
                                Today
                            </option>

                            <option
                                value="7"
                                {% if selected_date_range == "7" %}selected{% endif %}
                            >
                                Last 7 days
                            </option>

                            <option
                                value="30"
                                {% if selected_date_range == "30" %}selected{% endif %}
                            >
                                Last 30 days
                            </option>

                        </select>

                    </div>

                    {% if search or selected_type or selected_direction or selected_date_range %}

                        <div class="transaction-filter-actions">

                            <a href="{{ url_for('transactions') }}">
                                Clear filters
                            </a>

                        </div>

                    {% endif %}

                </form>

            </section>


'''

html = html.replace(
    marker,
    filter_block + marker,
    1
)


# =========================================================
# ADD LIGHTWEIGHT FILTER STYLING
# =========================================================

style_marker = '''    </style>
'''

filter_css = '''
        .transaction-filters {
            margin: 0 0 20px;
        }

        .transaction-filter-form {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .transaction-search-row {
            display: flex;
            gap: 8px;
        }

        .transaction-search-row input {
            flex: 1;
            min-width: 0;
            padding: 13px 14px;
            border-radius: 12px;
            border: 1px solid rgba(255,255,255,0.12);
            background: rgba(255,255,255,0.07);
            color: inherit;
            outline: none;
        }

        .transaction-search-row button {
            padding: 13px 16px;
            border: 0;
            border-radius: 12px;
            cursor: pointer;
            font-weight: 600;
        }

        .transaction-filter-row {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 8px;
        }

        .transaction-filter-row select {
            width: 100%;
            padding: 12px 10px;
            border-radius: 12px;
            border: 1px solid rgba(255,255,255,0.12);
            background: rgba(255,255,255,0.07);
            color: inherit;
            outline: none;
        }

        .transaction-filter-actions {
            text-align: right;
        }

        .transaction-filter-actions a {
            text-decoration: none;
            font-size: 13px;
        }

        @media (max-width: 600px) {

            .transaction-search-row {
                flex-direction: column;
            }

            .transaction-filter-row {
                grid-template-columns: 1fr;
            }

        }

'''

if style_marker not in html:
    raise SystemExit(
        "ERROR: The template style section could not be located."
    )

html = html.replace(
    style_marker,
    filter_css + style_marker,
    1
)

template_file.write_text(html, encoding="utf-8")

print("SUCCESS: Transaction History filters added to the page.")
print("Added: search, type, direction, date range, and clear filters.")
print("Existing transaction details and dashboard were not changed.")