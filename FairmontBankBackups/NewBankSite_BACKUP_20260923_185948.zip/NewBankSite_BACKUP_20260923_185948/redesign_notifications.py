from pathlib import Path

file = Path("templates/notifications.html")

if not file.exists():
    raise SystemExit(
        "ERROR: templates/notifications.html was not found."
    )

# Preserve the current page before replacing the design.
backup = Path("templates/notifications.html.before_dark_redesign")
backup.write_text(
    file.read_text(encoding="utf-8"),
    encoding="utf-8"
)

new_template = r'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Notifications | Fairmont Bank</title>

    <style>
        * {
            box-sizing: border-box;
        }

        html,
        body {
            margin: 0;
            min-height: 100%;
        }

        body {
            font-family:
                Inter,
                -apple-system,
                BlinkMacSystemFont,
                "Segoe UI",
                sans-serif;

            color: #eef4ff;

            background:
                radial-gradient(
                    circle at 15% 0%,
                    rgba(43, 105, 180, 0.28),
                    transparent 34%
                ),
                radial-gradient(
                    circle at 90% 15%,
                    rgba(62, 93, 180, 0.18),
                    transparent 30%
                ),
                linear-gradient(
                    145deg,
                    #061426 0%,
                    #0a1b31 48%,
                    #07182c 100%
                );

            min-height: 100vh;
        }

        a {
            color: inherit;
            text-decoration: none;
        }

        .notifications-page {
            width: 100%;
            min-height: 100vh;
            padding: 22px;
        }

        .notifications-shell {
            width: min(1180px, 100%);
            margin: 0 auto;
        }

        /* TOP BAR */

        .topbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;

            padding: 16px 20px;

            border: 1px solid rgba(150, 190, 235, 0.13);
            border-radius: 22px;

            background:
                linear-gradient(
                    135deg,
                    rgba(18, 44, 73, 0.88),
                    rgba(8, 27, 49, 0.76)
                );

            box-shadow:
                0 18px 55px rgba(0, 0, 0, 0.28),
                inset 0 1px 0 rgba(255, 255, 255, 0.05);

            backdrop-filter: blur(18px);
        }

        .brand-area {
            display: flex;
            align-items: center;
            gap: 13px;
        }

        .brand-mark {
            width: 42px;
            height: 42px;

            display: flex;
            align-items: center;
            justify-content: center;

            border-radius: 13px;

            background:
                linear-gradient(
                    145deg,
                    #d8bd73,
                    #9d8241
                );

            color: #071425;

            font-size: 19px;
            font-weight: 800;

            box-shadow:
                0 8px 22px rgba(0, 0, 0, 0.25);
        }

        .brand-name {
            font-family: Georgia, "Times New Roman", serif;
            letter-spacing: 3px;
            font-size: 15px;
            color: #f5f1df;
        }

        .brand-subtitle {
            margin-top: 3px;
            color: #8fa5c0;
            font-size: 11px;
        }

        .top-actions {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .icon-button {
            width: 42px;
            height: 42px;

            display: flex;
            align-items: center;
            justify-content: center;

            border-radius: 13px;

            border: 1px solid rgba(157, 194, 234, 0.14);

            background:
                rgba(16, 43, 72, 0.72);

            color: #dceaff;

            font-size: 18px;
        }

        .profile-chip {
            display: flex;
            align-items: center;
            gap: 10px;

            padding: 7px 12px 7px 7px;

            border: 1px solid rgba(157, 194, 234, 0.14);
            border-radius: 15px;

            background: rgba(16, 43, 72, 0.72);
        }

        .avatar {
            width: 34px;
            height: 34px;

            display: flex;
            align-items: center;
            justify-content: center;

            border-radius: 50%;

            background:
                linear-gradient(
                    145deg,
                    #2c75b9,
                    #193d70
                );

            color: white;
            font-weight: 700;
            font-size: 13px;
        }

        .profile-name {
            font-size: 13px;
            font-weight: 600;
        }

        .profile-type {
            margin-top: 2px;
            color: #829ab6;
            font-size: 10px;
        }

        /* MAIN */

        .main-content {
            padding: 38px 4px 60px;
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;

            color: #9db6d2;
            font-size: 13px;

            margin-bottom: 22px;
        }

        .back-link:hover {
            color: #ffffff;
        }

        .heading-row {
            display: flex;
            align-items: flex-end;
            justify-content: space-between;
            gap: 25px;

            margin-bottom: 25px;
        }

        .eyebrow {
            margin: 0 0 9px;

            color: #c7ad65;

            font-family: Georgia, "Times New Roman", serif;

            font-size: 11px;
            letter-spacing: 4px;
        }

        h1 {
            margin: 0;

            font-family: Georgia, "Times New Roman", serif;

            font-size: clamp(32px, 5vw, 48px);
            font-weight: 500;

            color: #f5f7fb;
        }

        .subtitle {
            max-width: 590px;

            margin: 10px 0 0;

            color: #91a8c2;

            font-size: 14px;
            line-height: 1.7;
        }

        /* HERO */

        .notification-hero {
            position: relative;
            overflow: hidden;

            min-height: 180px;

            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 25px;

            padding: 30px;

            border-radius: 25px;

            border: 1px solid rgba(104, 165, 224, 0.16);

            background:
                radial-gradient(
                    circle at 85% 50%,
                    rgba(43, 105, 180, 0.26),
                    transparent 35%
                ),
                linear-gradient(
                    135deg,
                    rgba(17, 48, 80, 0.94),
                    rgba(8, 28, 50, 0.88)
                );

            box-shadow:
                0 24px 65px rgba(0, 0, 0, 0.28),
                inset 0 1px 0 rgba(255, 255, 255, 0.045);
        }

        .notification-hero::after {
            content: "";

            position: absolute;

            width: 420px;
            height: 140px;

            right: -80px;
            bottom: -65px;

            border-top: 1px solid rgba(103, 163, 222, 0.18);
            border-radius: 50%;

            transform: rotate(-7deg);
        }

        .hero-copy {
            position: relative;
            z-index: 2;
        }

        .hero-title {
            margin: 0 0 8px;

            font-size: 20px;
            font-weight: 650;

            color: #edf5ff;
        }

        .hero-text {
            max-width: 560px;

            margin: 0;

            color: #91a9c4;

            line-height: 1.65;
            font-size: 13px;
        }

        .hero-icon {
            position: relative;
            z-index: 2;

            flex: 0 0 auto;

            width: 86px;
            height: 86px;

            display: flex;
            align-items: center;
            justify-content: center;

            border-radius: 25px;

            border: 1px solid rgba(134, 186, 235, 0.17);

            background:
                linear-gradient(
                    145deg,
                    rgba(47, 112, 181, 0.65),
                    rgba(25, 58, 105, 0.72)
                );

            box-shadow:
                0 18px 40px rgba(0, 0, 0, 0.22);

            font-size: 34px;
        }

        /* FILTERS */

        .filter-row {
            display: flex;
            align-items: center;
            gap: 9px;

            margin: 24px 0 18px;

            overflow-x: auto;
            padding-bottom: 3px;
        }

        .filter {
            flex: 0 0 auto;

            padding: 10px 16px;

            border-radius: 999px;

            border: 1px solid rgba(135, 177, 218, 0.13);

            background:
                rgba(13, 38, 64, 0.72);

            color: #91a8c0;

            font-size: 12px;
        }

        .filter.active {
            border-color: rgba(83, 151, 215, 0.55);

            background:
                linear-gradient(
                    135deg,
                    rgba(38, 112, 188, 0.95),
                    rgba(31, 76, 137, 0.95)
                );

            color: #ffffff;

            box-shadow:
                0 8px 22px rgba(23, 83, 143, 0.25);
        }

        /* CONTENT CARD */

        .notifications-card {
            position: relative;
            overflow: hidden;

            min-height: 390px;

            border-radius: 27px;

            border: 1px solid rgba(119, 169, 216, 0.13);

            background:
                linear-gradient(
                    145deg,
                    rgba(13, 38, 64, 0.95),
                    rgba(7, 25, 45, 0.96)
                );

            box-shadow:
                0 25px 70px rgba(0, 0, 0, 0.30),
                inset 0 1px 0 rgba(255, 255, 255, 0.035);
        }

        .notification-list {
            padding: 14px;
        }

        .notification-item {
            display: flex;
            gap: 14px;

            padding: 18px;

            margin-bottom: 10px;

            border-radius: 18px;

            border: 1px solid rgba(128, 173, 216, 0.10);

            background:
                rgba(18, 49, 80, 0.58);
        }

        .notification-dot {
            flex: 0 0 auto;

            width: 42px;
            height: 42px;

            display: flex;
            align-items: center;
            justify-content: center;

            border-radius: 14px;

            background:
                rgba(47, 111, 179, 0.35);

            color: #bcdcff;
        }

        .notification-title {
            margin: 0 0 5px;

            color: #edf5ff;

            font-size: 14px;
            font-weight: 650;
        }

        .notification-message {
            margin: 0;

            color: #91a8c0;

            font-size: 12px;
            line-height: 1.6;
        }

        .notification-time {
            margin-top: 7px;

            color: #637d99;

            font-size: 10px;
        }

        /* EMPTY STATE */

        .empty-state {
            min-height: 390px;

            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;

            text-align: center;

            padding: 55px 25px;
        }

        .empty-icon {
            width: 78px;
            height: 78px;

            display: flex;
            align-items: center;
            justify-content: center;

            margin-bottom: 22px;

            border-radius: 50%;

            border: 1px solid rgba(93, 157, 216, 0.18);

            background:
                radial-gradient(
                    circle,
                    rgba(39, 105, 175, 0.48),
                    rgba(12, 39, 67, 0.8)
                );

            box-shadow:
                0 15px 40px rgba(0, 0, 0, 0.25);

            font-size: 30px;
        }

        .empty-state h2 {
            margin: 0 0 10px;

            color: #f2f6fc;

            font-family: Georgia, "Times New Roman", serif;

            font-size: 25px;
            font-weight: 500;
        }

        .empty-state p {
            max-width: 510px;

            margin: 0;

            color: #829bb6;

            font-size: 13px;
            line-height: 1.75;
        }

        .refresh-button {
            margin-top: 25px;

            border: 1px solid rgba(110, 171, 225, 0.20);

            border-radius: 13px;

            padding: 11px 18px;

            background:
                rgba(23, 60, 95, 0.78);

            color: #d9e9fb;

            cursor: pointer;

            font-size: 12px;
        }

        .refresh-button:hover {
            background:
                rgba(31, 82, 128, 0.9);
        }

        /* FOOTER */

        .security-note {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 7px;

            margin-top: 22px;

            color: #637d98;

            font-size: 10px;
            letter-spacing: 0.3px;
        }

        /* MOBILE */

        @media (max-width: 700px) {

            .notifications-page {
                padding: 12px;
            }

            .topbar {
                padding: 13px;
                border-radius: 18px;
            }

            .brand-subtitle,
            .profile-type {
                display: none;
            }

            .brand-name {
                font-size: 12px;
                letter-spacing: 2px;
            }

            .profile-chip {
                padding-right: 7px;
            }

            .profile-name {
                display: none;
            }

            .main-content {
                padding: 28px 2px 40px;
            }

            .heading-row {
                display: block;
            }

            .notification-hero {
                min-height: auto;
                padding: 23px;
            }

            .hero-icon {
                width: 66px;
                height: 66px;
                font-size: 27px;
            }

            .hero-title {
                font-size: 17px;
            }

            .hero-text {
                font-size: 12px;
            }

            .notifications-card {
                border-radius: 21px;
            }

            .empty-state {
                min-height: 340px;
                padding: 45px 18px;
            }

            .empty-state h2 {
                font-size: 22px;
            }
        }
    </style>
</head>

<body>

<main class="notifications-page">

    <div class="notifications-shell">

        <header class="topbar">

            <div class="brand-area">

                <div class="brand-mark">
                    F
                </div>

                <div>
                    <div class="brand-name">
                        FAIRMONT BANK
                    </div>

                    <div class="brand-subtitle">
                        Banking for a brighter tomorrow
                    </div>
                </div>

            </div>

            <div class="top-actions">

                <a
                    href="/notifications"
                    class="icon-button"
                    aria-label="Notifications">
                    ♢
                </a>

                <a
                    href="/my-profile"
                    class="profile-chip">

                    <div class="avatar">
                        {% if customer is defined and customer.full_name %}
                            {{ customer.full_name[0]|upper }}
                        {% else %}
                            F
                        {% endif %}
                    </div>

                    <div>
                        <div class="profile-name">
                            {% if customer is defined %}
                                {{ customer.full_name }}
                            {% else %}
                                Customer
                            {% endif %}
                        </div>

                        <div class="profile-type">
                            Customer
                        </div>
                    </div>

                </a>

            </div>

        </header>


        <section class="main-content">

            <a
                href="/dashboard"
                class="back-link">
                ← Back to Dashboard
            </a>


            <div class="heading-row">

                <div>

                    <p class="eyebrow">
                        FAIRMONT BANK
                    </p>

                    <h1>
                        Notifications
                    </h1>

                    <p class="subtitle">
                        Stay updated with your account activity,
                        payment updates and important messages.
                    </p>

                </div>

            </div>


            <section class="notification-hero">

                <div class="hero-copy">

                    <h2 class="hero-title">
                        Important updates, always within reach
                    </h2>

                    <p class="hero-text">
                        Your Fairmont Bank notifications will appear
                        here when there is important account activity,
                        payment information, security notices or
                        messages for you.
                    </p>

                </div>

                <div class="hero-icon">
                    ♢
                </div>

            </section>


            <div class="filter-row">

                <span class="filter active">
                    All
                </span>

                <span class="filter">
                    Account
                </span>

                <span class="filter">
                    Payments
                </span>

                <span class="filter">
                    Security
                </span>

                <span class="filter">
                    Messages
                </span>

            </div>


            <section class="notifications-card">

                {% if notifications is defined and notifications %}

                    <div class="notification-list">

                        {% for notification in notifications %}

                            <article class="notification-item">

                                <div class="notification-dot">
                                    ♢
                                </div>

                                <div>

                                    <h3 class="notification-title">
                                        {{ notification.title|default("Fairmont Bank Update") }}
                                    </h3>

                                    <p class="notification-message">
                                        {{ notification.message|default(notification.text|default("You have a new notification from Fairmont Bank.")) }}
                                    </p>

                                    {% if notification.created_at is defined %}
                                        <div class="notification-time">
                                            {{ notification.created_at }}
                                        </div>
                                    {% endif %}

                                </div>

                            </article>

                        {% endfor %}

                    </div>

                {% else %}

                    <div class="empty-state">

                        <div class="empty-icon">
                            ♢
                        </div>

                        <h2>
                            You're all caught up
                        </h2>

                        <p>
                            Important account activity, payment updates,
                            security notices and messages from Fairmont
                            Bank will appear here.
                        </p>

                        <button
                            type="button"
                            class="refresh-button"
                            onclick="window.location.reload()">
                            ↻ &nbsp; Refresh
                        </button>

                    </div>

                {% endif %}

            </section>


            <div class="security-note">
                ◆ &nbsp; Your banking notifications are protected.
            </div>

        </section>

    </div>

</main>

</body>
</html>
'''

file.write_text(
    new_template,
    encoding="utf-8"
)

print("SUCCESS: Notifications page redesigned.")
print("The Customer Account card was removed.")
print("The page now uses the Fairmont dark/glass banking design.")
print("The existing notifications route and backend were not changed.")
print(
    "Original template backup:"
    " templates/notifications.html.before_dark_redesign"
)