from pathlib import Path
import re
import shutil
from datetime import datetime

BASE = Path(r"C:\Users\DON J\Documents\NewBankSite")
APP = BASE / "app.py"
SETTINGS = BASE / "templates" / "settings.html"
OTP_PAGE = BASE / "templates" / "login_otp.html"

# =========================================================
# BACKUP
# =========================================================

backup_dir = BASE / "login_otp_backup"
backup_dir.mkdir(exist_ok=True)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

shutil.copy2(
    APP,
    backup_dir / f"app.py_{timestamp}.bak"
)

shutil.copy2(
    SETTINGS,
    backup_dir / f"settings.html_{timestamp}.bak"
)

print()
print("Backup created.")
print()

# =========================================================
# READ APP
# =========================================================

app_text = APP.read_text(encoding="utf-8")

# =========================================================
# ADD LOGIN OTP COLUMN TO CUSTOMER MODEL
# =========================================================

if "login_otp_enabled" not in app_text:

    # Find the Customer model class.
    customer_match = re.search(
        r'class\s+Customer\s*\([^:]+:\s*(.*?)(?=\nclass\s+|\n@login_manager|\n@app\.route|\nif\s+__name__)',
        app_text,
        re.DOTALL
    )

    if not customer_match:
        raise RuntimeError(
            "Could not locate the Customer model in app.py."
        )

    customer_block = customer_match.group(0)

    # Find the end of the existing Customer model fields.
    # We insert immediately before the next class/decorator.
    insertion_point = customer_match.end()

    otp_column = (
        '\n\n'
        '    login_otp_enabled = db.Column('
        'db.Boolean, '
        'nullable=False, '
        'default=False'
        ')\n'
    )

    app_text = (
        app_text[:insertion_point]
        + otp_column
        + app_text[insertion_point:]
    )

    print("Added login_otp_enabled to Customer model.")

else:
    print("login_otp_enabled already exists in app.py.")

# =========================================================
# DATABASE MIGRATION
# =========================================================

migration_code = r'''
# =========================================================
# LOGIN OTP DATABASE MIGRATION
# =========================================================

def ensure_login_otp_column():

    inspector = db.inspect(db.engine)

    tables = inspector.get_table_names()

    if "customer" not in tables:
        return

    columns = [
        column["name"]
        for column in inspector.get_columns("customer")
    ]

    if "login_otp_enabled" not in columns:

        with db.engine.begin() as connection:

            connection.exec_driver_sql(
                """
                ALTER TABLE customer
                ADD COLUMN login_otp_enabled
                BOOLEAN NOT NULL DEFAULT 0
                """
            )

'''

if "def ensure_login_otp_column()" not in app_text:

    marker = '\nif __name__ == "__main__":'

    if marker not in app_text:
        raise RuntimeError(
            "Could not find the final app startup section."
        )

    app_text = app_text.replace(
        marker,
        migration_code + marker,
        1
    )

    print("Added database migration.")

else:
    print("Database migration already exists.")

# =========================================================
# LOGIN OTP SETTINGS ROUTE
# =========================================================

route = r'''
@app.route("/settings/login-otp", methods=["GET", "POST"])
@login_required
def login_otp_settings():

    customer = current_user

    if request.method == "POST":

        otp_value = request.form.get(
            "login_otp_enabled",
            ""
        )

        customer.login_otp_enabled = (
            otp_value == "on"
        )

        db.session.commit()

        if customer.login_otp_enabled:

            flash(
                "Login OTP has been turned on.",
                "success"
            )

        else:

            flash(
                "Login OTP has been turned off.",
                "success"
            )

        return redirect(
            url_for("login_otp_settings")
        )

    return render_template(
        "login_otp.html",
        customer=customer
    )

'''

if "def login_otp_settings()" not in app_text:

    marker = '\nif __name__ == "__main__":'

    if marker not in app_text:
        raise RuntimeError(
            "Could not find the final app startup section."
        )

    app_text = app_text.replace(
        marker,
        route + marker,
        1
    )

    print("Added Login OTP route.")

else:
    print("Login OTP route already exists.")

# =========================================================
# FIX APP STARTUP
# =========================================================

old_startup = '''if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True)
'''

new_startup = '''if __name__ == "__main__":
    with app.app_context():
        db.create_all()
        ensure_login_otp_column()
    app.run(debug=True)
'''

if "ensure_login_otp_column()" in app_text:

    if old_startup in app_text:

        app_text = app_text.replace(
            old_startup,
            new_startup,
            1
        )

        print("Updated database startup migration.")

    elif (
        "db.create_all()" in app_text
        and "ensure_login_otp_column()" not in
        app_text.split('if __name__ == "__main__":')[-1]
    ):

        # Handle slightly different formatting.
        startup_match = re.search(
            r'if\s+__name__\s*==\s*["\']__main__["\']:\s*'
            r'with\s+app\.app_context\(\):\s*'
            r'db\.create_all\(\)\s*'
            r'app\.run\(debug=True\)',
            app_text
        )

        if startup_match:

            app_text = (
                app_text[:startup_match.start()]
                + new_startup
                + app_text[startup_match.end():]
            )

            print("Updated database startup migration.")

# =========================================================
# WRITE APP
# =========================================================

APP.write_text(
    app_text,
    encoding="utf-8"
)

# =========================================================
# CREATE LOGIN OTP PAGE
# =========================================================

otp_html = r'''<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0">

<title>Login OTP - Fairmont Bank</title>

<style>

* {
    box-sizing: border-box;
}

body {

    margin: 0;

    min-height: 100vh;

    background:
        radial-gradient(
            circle at top left,
            rgba(35, 76, 125, 0.28),
            transparent 38%
        ),
        linear-gradient(
            180deg,
            #07182d 0%,
            #061426 100%
        );

    color: #ffffff;

    font-family:
        Arial,
        Helvetica,
        sans-serif;
}

.otp-page {

    width: 100%;

    max-width: 620px;

    margin: 0 auto;

    padding:
        22px 18px 45px;
}

.otp-header {

    display: flex;

    align-items: center;

    gap: 14px;

    margin-bottom: 25px;
}

.back-button {

    width: 42px;

    height: 42px;

    border-radius: 12px;

    display: flex;

    align-items: center;

    justify-content: center;

    text-decoration: none;

    color: #ffffff;

    background:
        rgba(255,255,255,0.07);

    border:
        1px solid
        rgba(255,255,255,0.10);

    font-size: 22px;
}

.otp-title {

    margin: 0;

    font-size: 24px;

    font-weight: 700;
}

.otp-subtitle {

    margin: 4px 0 0;

    color:
        rgba(255,255,255,0.60);

    font-size: 13px;
}

.otp-card {

    background:
        rgba(13, 34, 59, 0.84);

    border:
        1px solid
        rgba(255,255,255,0.09);

    border-radius: 18px;

    padding: 22px;

    box-shadow:
        0 12px 30px
        rgba(0,0,0,0.18);
}

.otp-card-title {

    margin: 0 0 7px;

    font-size: 17px;

    font-weight: 600;
}

.otp-description {

    margin: 0 0 22px;

    color:
        rgba(255,255,255,0.55);

    font-size: 12px;

    line-height: 1.55;
}

.otp-status {

    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 15px;

    padding: 17px;

    margin-bottom: 20px;

    border-radius: 14px;

    background:
        rgba(255,255,255,0.045);

    border:
        1px solid
        rgba(255,255,255,0.07);
}

.status-title {

    margin: 0 0 4px;

    font-size: 14px;

    font-weight: 600;
}

.status-text {

    margin: 0;

    color:
        rgba(255,255,255,0.50);

    font-size: 11px;
}

.toggle {

    position: relative;

    width: 54px;

    height: 30px;

    flex-shrink: 0;
}

.toggle input {

    opacity: 0;

    width: 0;

    height: 0;
}

.slider {

    position: absolute;

    inset: 0;

    cursor: pointer;

    border-radius: 30px;

    background:
        rgba(255,255,255,0.16);

    transition:
        0.2s;
}

.slider:before {

    content: "";

    position: absolute;

    width: 22px;

    height: 22px;

    left: 4px;

    top: 4px;

    border-radius: 50%;

    background: #ffffff;

    transition:
        0.2s;
}

.toggle input:checked + .slider {

    background:
        #2672ad;
}

.toggle input:checked + .slider:before {

    transform:
        translateX(24px);
}

.save-button {

    width: 100%;

    height: 48px;

    border: none;

    border-radius: 12px;

    background:
        #1f5d96;

    color: #ffffff;

    font-size: 14px;

    font-weight: 700;

    cursor: pointer;
}

.save-button:hover {

    background:
        #276da9;
}

.message {

    margin-bottom: 18px;

    padding: 13px 14px;

    border-radius: 11px;

    font-size: 12px;

    line-height: 1.45;
}

.success-message {

    background:
        rgba(65,155,105,0.15);

    border:
        1px solid
        rgba(90,190,130,0.22);

    color:
        #9de0b7;
}

</style>

</head>

<body>

<div class="otp-page">

    <div class="otp-header">

        <a
            href="{{ url_for('settings') }}"
            class="back-button">

            ‹

        </a>

        <div>

            <h1 class="otp-title">
                Login OTP
            </h1>

            <p class="otp-subtitle">
                Manage one-time password protection
            </p>

        </div>

    </div>


    <div class="otp-card">

        {% with messages =
            get_flashed_messages(
                with_categories=true
            )
        %}

            {% if messages %}

                {% for category, message in messages %}

                    <div class="message success-message">
                        {{ message }}
                    </div>

                {% endfor %}

            {% endif %}

        {% endwith %}


        <h2 class="otp-card-title">
            Login OTP Verification
        </h2>

        <p class="otp-description">
            Enable or disable an additional one-time
            password verification step for your account.
        </p>


        <form
            method="POST"
            action="{{ url_for('login_otp_settings') }}">

            <div class="otp-status">

                <div>

                    <p class="status-title">
                        Login OTP
                    </p>

                    <p class="status-text">

                        {% if customer.login_otp_enabled %}
                            Currently enabled
                        {% else %}
                            Currently disabled
                        {% endif %}

                    </p>

                </div>


                <label class="toggle">

                    <input
                        type="checkbox"
                        name="login_otp_enabled"
                        {% if customer.login_otp_enabled %}
                            checked
                        {% endif %}>

                    <span class="slider"></span>

                </label>

            </div>


            <button
                type="submit"
                class="save-button">

                Save Login OTP Setting

            </button>

        </form>

    </div>

</div>

</body>

</html>
'''

OTP_PAGE.write_text(
    otp_html,
    encoding="utf-8"
)

print("Created login_otp.html.")

# =========================================================
# MAKE SETTINGS CARD CLICKABLE
# =========================================================

settings_text = SETTINGS.read_text(
    encoding="utf-8"
)

# Look for the Login OTP card without depending
# on exact formatting.
login_otp_pattern = re.compile(
    r'<div[^>]*class="settings-card"[^>]*>'
    r'(?:(?!</div>).)*?'
    r'Login OTP'
    r'(?:(?!</div>).)*?'
    r'</div>',
    re.DOTALL
)

match = login_otp_pattern.search(settings_text)

if match:

    card = match.group(0)

    if not card.lstrip().startswith("<a"):

        new_card = (
            '<a href="{{ url_for(\'login_otp_settings\') }}" '
            'class="settings-card" '
            'style="text-decoration:none; color:inherit;">'
            + re.sub(
                r'^<div[^>]*class="settings-card"[^>]*>',
                '',
                card,
                count=1
            )
        )

        new_card = new_card.rsplit(
            "</div>",
            1
        )[0] + "</a>"

        settings_text = (
            settings_text[:match.start()]
            + new_card
            + settings_text[match.end():]
        )

        SETTINGS.write_text(
            settings_text,
            encoding="utf-8"
        )

        print("Made Login OTP card clickable.")

    else:

        print("Login OTP card is already clickable.")

else:

    print(
        "WARNING: Could not automatically locate "
        "the Login OTP card."
    )

# =========================================================
# FINISHED
# =========================================================

print()
print("==============================================")
print("LOGIN OTP SETTING INSTALLED SUCCESSFULLY")
print("==============================================")
print()
print("The existing login process was NOT changed.")
print("OTP is initially OFF.")
print()
print("Database migration will run when the app starts.")
print()
print("Backup folder:")
print(backup_dir)
print()
print("Next:")
print("  python app.py")
print()