from pathlib import Path
import re

BASE_DIR = Path(__file__).resolve().parent
TEMPLATE = BASE_DIR / "templates" / "international_transfer.html"

if not TEMPLATE.exists():
    print("ERROR: templates\\international_transfer.html was not found.")
    raise SystemExit(1)

html = TEMPLATE.read_text(encoding="utf-8")


# =========================================================
# BACKUP
# =========================================================

backup = BASE_DIR / "templates" / "international_transfer_before_country_bank_upgrade.html"

if not backup.exists():
    backup.write_text(html, encoding="utf-8")
    print("Backup created:")
    print(backup)
else:
    print("Existing backup preserved.")


# =========================================================
# COUNTRY + BANK DATA
# =========================================================

country_banks = {
    "United Kingdom": [
        "Barclays Bank",
        "HSBC UK",
        "Lloyds Bank",
        "NatWest",
        "Royal Bank of Scotland",
        "Santander UK",
        "Halifax",
        "Nationwide Building Society",
        "TSB Bank",
        "Metro Bank",
        "Monzo Bank",
        "Starling Bank",
        "Virgin Money",
        "First Direct",
        "Bank of Scotland",
        "Other UK Bank"
    ],

    "United States": [
        "JPMorgan Chase Bank",
        "Bank of America",
        "Wells Fargo Bank",
        "Citibank",
        "U.S. Bank",
        "PNC Bank",
        "Truist Bank",
        "Capital One",
        "TD Bank",
        "Charles Schwab Bank",
        "Other US Bank"
    ],

    "Canada": [
        "Royal Bank of Canada",
        "Toronto-Dominion Bank",
        "Bank of Montreal",
        "Bank of Nova Scotia",
        "Canadian Imperial Bank of Commerce",
        "National Bank of Canada",
        "Desjardins",
        "Other Canadian Bank"
    ],

    "Australia": [
        "Commonwealth Bank",
        "Westpac",
        "ANZ Bank",
        "National Australia Bank",
        "Macquarie Bank",
        "Bendigo Bank",
        "Bank of Queensland",
        "Other Australian Bank"
    ],

    "New Zealand": [
        "ANZ New Zealand",
        "ASB Bank",
        "Bank of New Zealand",
        "Westpac New Zealand",
        "Kiwibank",
        "Heartland Bank",
        "Other New Zealand Bank"
    ],

    "Germany": [
        "Deutsche Bank",
        "Commerzbank",
        "DZ Bank",
        "KfW",
        "ING Germany",
        "N26",
        "DKB",
        "Other German Bank"
    ],

    "France": [
        "BNP Paribas",
        "Crédit Agricole",
        "Société Générale",
        "BPCE",
        "Crédit Mutuel",
        "La Banque Postale",
        "HSBC Continental Europe",
        "Other French Bank"
    ],

    "Netherlands": [
        "ING Bank",
        "ABN AMRO",
        "Rabobank",
        "de Volksbank",
        "Triodos Bank",
        "Other Dutch Bank"
    ],

    "Belgium": [
        "KBC Bank",
        "Belfius Bank",
        "BNP Paribas Fortis",
        "ING Belgium",
        "Argenta",
        "Other Belgian Bank"
    ],

    "Switzerland": [
        "UBS",
        "Zürcher Kantonalbank",
        "Banque Cantonale Vaudoise",
        "Raiffeisen Switzerland",
        "PostFinance",
        "Julius Baer",
        "Other Swiss Bank"
    ],

    "Ireland": [
        "AIB",
        "Bank of Ireland",
        "Permanent TSB",
        "EBS",
        "Revolut Bank Ireland",
        "Other Irish Bank"
    ],

    "Spain": [
        "Banco Santander",
        "BBVA",
        "CaixaBank",
        "Banco Sabadell",
        "Bankinter",
        "Unicaja Banco",
        "Abanca",
        "Other Spanish Bank"
    ],

    "Portugal": [
        "Caixa Geral de Depósitos",
        "Millennium bcp",
        "Novo Banco",
        "Banco Santander Totta",
        "Banco BPI",
        "Other Portuguese Bank"
    ],

    "Italy": [
        "Intesa Sanpaolo",
        "UniCredit",
        "Banco BPM",
        "BPER Banca",
        "Mediobanca",
        "Monte dei Paschi di Siena",
        "Other Italian Bank"
    ],

    "Sweden": [
        "Swedbank",
        "SEB",
        "Handelsbanken",
        "Nordea",
        "Danske Bank Sweden",
        "Other Swedish Bank"
    ],

    "Norway": [
        "DNB Bank",
        "SpareBank 1",
        "Nordea Norway",
        "Danske Bank Norway",
        "Handelsbanken Norway",
        "Other Norwegian Bank"
    ],

    "Denmark": [
        "Danske Bank",
        "Jyske Bank",
        "Sydbank",
        "Nordea Denmark",
        "Nykredit Bank",
        "Other Danish Bank"
    ],

    "Finland": [
        "Nordea Bank",
        "OP Financial Group",
        "Danske Bank Finland",
        "S-Bank",
        "Ålandsbanken",
        "Other Finnish Bank"
    ],

    "South Africa": [
        "Standard Bank",
        "First National Bank",
        "Absa Bank",
        "Nedbank",
        "Capitec Bank",
        "Investec Bank",
        "African Bank",
        "Other South African Bank"
    ],

    "Kenya": [
        "KCB Bank Kenya",
        "Equity Bank Kenya",
        "Co-operative Bank of Kenya",
        "Absa Bank Kenya",
        "NCBA Bank Kenya",
        "Stanbic Bank Kenya",
        "I&M Bank",
        "DTB Kenya",
        "Standard Chartered Kenya",
        "Family Bank",
        "Other Kenyan Bank"
    ],

    "Nigeria": [
        "Access Bank",
        "First Bank of Nigeria",
        "United Bank for Africa",
        "Guaranty Trust Bank",
        "Zenith Bank",
        "Fidelity Bank",
        "Ecobank Nigeria",
        "Stanbic IBTC Bank",
        "Union Bank of Nigeria",
        "Other Nigerian Bank"
    ],

    "Ghana": [
        "GCB Bank",
        "Ecobank Ghana",
        "Absa Bank Ghana",
        "Stanbic Bank Ghana",
        "Standard Chartered Ghana",
        "Fidelity Bank Ghana",
        "CalBank",
        "Republic Bank Ghana",
        "Other Ghanaian Bank"
    ],

    "Uganda": [
        "Stanbic Bank Uganda",
        "Centenary Bank",
        "Absa Bank Uganda",
        "Bank of Baroda Uganda",
        "DFCU Bank",
        "Standard Chartered Uganda",
        "Equity Bank Uganda",
        "Other Ugandan Bank"
    ],

    "Tanzania": [
        "CRDB Bank",
        "NMB Bank",
        "NBC Tanzania",
        "Stanbic Bank Tanzania",
        "Absa Bank Tanzania",
        "Standard Chartered Tanzania",
        "Exim Bank Tanzania",
        "Equity Bank Tanzania",
        "Other Tanzanian Bank"
    ],

    "Rwanda": [
        "Bank of Kigali",
        "I&M Bank Rwanda",
        "Equity Bank Rwanda",
        "KCB Bank Rwanda",
        "Access Bank Rwanda",
        "Ecobank Rwanda",
        "Other Rwandan Bank"
    ],

    "United Arab Emirates": [
        "Emirates NBD",
        "First Abu Dhabi Bank",
        "Abu Dhabi Commercial Bank",
        "Dubai Islamic Bank",
        "Mashreq Bank",
        "Commercial Bank of Dubai",
        "RAKBANK",
        "HSBC UAE",
        "Standard Chartered UAE",
        "Other UAE Bank"
    ],

    "Saudi Arabia": [
        "Saudi National Bank",
        "Al Rajhi Bank",
        "Riyad Bank",
        "Alinma Bank",
        "Bank Albilad",
        "Arab National Bank",
        "Banque Saudi Fransi",
        "Other Saudi Bank"
    ],

    "Qatar": [
        "Qatar National Bank",
        "Qatar Islamic Bank",
        "Doha Bank",
        "Commercial Bank of Qatar",
        "Dukhan Bank",
        "Ahli Bank Qatar",
        "Other Qatari Bank"
    ],

    "India": [
        "State Bank of India",
        "HDFC Bank",
        "ICICI Bank",
        "Axis Bank",
        "Kotak Mahindra Bank",
        "IndusInd Bank",
        "Punjab National Bank",
        "Bank of Baroda",
        "Canara Bank",
        "Union Bank of India",
        "Other Indian Bank"
    ],

    "China": [
        "Industrial and Commercial Bank of China",
        "China Construction Bank",
        "Agricultural Bank of China",
        "Bank of China",
        "Bank of Communications",
        "China Merchants Bank",
        "China CITIC Bank",
        "Other Chinese Bank"
    ],

    "Japan": [
        "MUFG Bank",
        "Sumitomo Mitsui Banking Corporation",
        "Mizuho Bank",
        "Resona Bank",
        "Japan Post Bank",
        "Nomura Bank",
        "Other Japanese Bank"
    ],

    "Singapore": [
        "DBS Bank",
        "OCBC Bank",
        "United Overseas Bank",
        "Standard Chartered Singapore",
        "HSBC Singapore",
        "Citibank Singapore",
        "Maybank Singapore",
        "Other Singapore Bank"
    ],

    "Malaysia": [
        "Maybank",
        "CIMB Bank",
        "Public Bank",
        "RHB Bank",
        "Hong Leong Bank",
        "AmBank",
        "Bank Islam Malaysia",
        "Other Malaysian Bank"
    ],

    "Indonesia": [
        "Bank Mandiri",
        "Bank Central Asia",
        "Bank Rakyat Indonesia",
        "Bank Negara Indonesia",
        "CIMB Niaga",
        "Bank Permata",
        "Bank Danamon",
        "Other Indonesian Bank"
    ],

    "Brazil": [
        "Banco do Brasil",
        "Itaú Unibanco",
        "Bradesco",
        "Caixa Econômica Federal",
        "Santander Brasil",
        "BTG Pactual",
        "Safra",
        "Other Brazilian Bank"
    ],

    "Mexico": [
        "BBVA México",
        "Banorte",
        "Santander México",
        "Citibanamex",
        "HSBC México",
        "Scotiabank México",
        "Banco Azteca",
        "Other Mexican Bank"
    ],

    "Argentina": [
        "Banco de la Nación Argentina",
        "Banco Santander Argentina",
        "BBVA Argentina",
        "Banco Galicia",
        "Banco Macro",
        "ICBC Argentina",
        "Banco Patagonia",
        "Other Argentine Bank"
    ],

    "Chile": [
        "Banco de Chile",
        "Banco Santander Chile",
        "Banco de Crédito e Inversiones",
        "Scotiabank Chile",
        "BancoEstado",
        "Itaú Chile",
        "Other Chilean Bank"
    ],

    "Colombia": [
        "Bancolombia",
        "Banco de Bogotá",
        "Davivienda",
        "BBVA Colombia",
        "Banco de Occidente",
        "Scotiabank Colpatria",
        "Banco Popular",
        "Other Colombian Bank"
    ],

    "Guyana": [
        "Republic Bank Guyana",
        "Guyana Bank for Trade and Industry",
        "Demerara Bank",
        "Bank of Baroda Guyana",
        "Citizens Bank Guyana",
        "New Building Society",
        "Other Guyanese Bank"
    ],

    # =====================================================
    # SURINAME
    # =====================================================

    "Suriname": [
        "De Surinaamsche Bank N.V.",
        "Republic Bank (Suriname) N.V.",
        "Hakrinbank N.V.",
        "Finabank N.V.",
        "Surinaamse Postspaarbank",
        "Stichting Surinaamse Volkscredietbank",
        "Surichange Bank N.V.",
        "Coöperatieve Spaar- en Kredietbank GODO",
        "Trustbank Amanah",
        "Southern Commercial Bank N.V.",
        "Other Surinamese Bank"
    ],

    "Trinidad and Tobago": [
        "Republic Bank",
        "First Citizens Bank",
        "RBC Royal Bank",
        "Scotiabank Trinidad and Tobago",
        "CIBC Caribbean",
        "JMMB Bank",
        "Other Trinidad and Tobago Bank"
    ],

    "Jamaica": [
        "National Commercial Bank Jamaica",
        "Scotiabank Jamaica",
        "JMMB Bank Jamaica",
        "Sagicor Bank Jamaica",
        "CIBC Caribbean Jamaica",
        "First Global Bank",
        "Other Jamaican Bank"
    ],

    "Bahamas": [
        "Commonwealth Bank",
        "Royal Bank of Canada",
        "Scotiabank Bahamas",
        "FirstCaribbean International Bank",
        "CIBC Caribbean",
        "Bank of The Bahamas",
        "Other Bahamian Bank"
    ],

    "Barbados": [
        "Republic Bank Barbados",
        "CIBC Caribbean",
        "First Citizens Bank Barbados",
        "RBC Royal Bank Barbados",
        "Scotiabank Barbados",
        "Other Barbadian Bank"
    ],

    "Suriname": [
        "De Surinaamsche Bank N.V.",
        "Republic Bank (Suriname) N.V.",
        "Hakrinbank N.V.",
        "Finabank N.V.",
        "Surinaamse Postspaarbank",
        "Stichting Surinaamse Volkscredietbank",
        "Surichange Bank N.V.",
        "Coöperatieve Spaar- en Kredietbank GODO",
        "Trustbank Amanah",
        "Southern Commercial Bank N.V.",
        "Other Surinamese Bank"
    ]
}


# Remove duplicate Suriname entry while preserving order.
country_banks = dict(country_banks)


# =========================================================
# COUNTRY LIST
# =========================================================

countries = [
    "United Kingdom",
    "United States",
    "Canada",
    "Australia",
    "New Zealand",
    "Germany",
    "France",
    "Netherlands",
    "Belgium",
    "Switzerland",
    "Ireland",
    "Spain",
    "Portugal",
    "Italy",
    "Sweden",
    "Norway",
    "Denmark",
    "Finland",
    "South Africa",
    "Kenya",
    "Nigeria",
    "Ghana",
    "Uganda",
    "Tanzania",
    "Rwanda",
    "United Arab Emirates",
    "Saudi Arabia",
    "Qatar",
    "India",
    "China",
    "Japan",
    "Singapore",
    "Malaysia",
    "Indonesia",
    "Brazil",
    "Mexico",
    "Argentina",
    "Chile",
    "Colombia",
    "Guyana",
    "Suriname",
    "Trinidad and Tobago",
    "Jamaica",
    "Bahamas",
    "Barbados"
]


# =========================================================
# BUILD COUNTRY OPTIONS
# =========================================================

country_options = [
    '<option value="">Select destination country</option>'
]

for country in countries:
    country_options.append(
        f'<option value="{country}">{country}</option>'
    )

country_options_html = "\n".join(country_options)


# =========================================================
# BUILD BANK DATA FOR JAVASCRIPT
# =========================================================

import json

bank_data_json = json.dumps(
    country_banks,
    ensure_ascii=False,
    indent=4
)


# =========================================================
# REPLACE COUNTRY SELECT
# =========================================================

country_select_pattern = re.compile(
    r'<select([^>]*name=["\']country["\'][^>]*)>.*?</select>',
    re.IGNORECASE | re.DOTALL
)

country_match = country_select_pattern.search(html)

if country_match:

    old_select = country_match.group(0)

    new_select = f'''<select{country_match.group(1)} id="internationalCountry">
{country_options_html}
</select>'''

    html = html.replace(
        old_select,
        new_select,
        1
    )

    print("Destination country selector updated.")

else:

    print(
        "WARNING: Existing country <select> was not found."
    )

    print(
        "The JavaScript upgrade will still be inserted."
    )


# =========================================================
# REPLACE BANK INPUT / SELECT
# =========================================================

bank_input_pattern = re.compile(
    r'<input([^>]*name=["\']bank_name["\'][^>]*)>',
    re.IGNORECASE
)

bank_match = bank_input_pattern.search(html)

if bank_match:

    attributes = bank_match.group(1)

    new_bank_select = f'''
<select{attributes} id="internationalBank" name="bank_name">
    <option value="">Select a bank</option>
</select>
'''

    html = html.replace(
        bank_match.group(0),
        new_bank_select,
        1
    )

    print("Bank field converted to a country-specific selector.")

else:

    # Try an existing select.
    bank_select_pattern = re.compile(
        r'<select([^>]*name=["\']bank_name["\'][^>]*)>.*?</select>',
        re.IGNORECASE | re.DOTALL
    )

    bank_select_match = bank_select_pattern.search(html)

    if bank_select_match:

        new_bank_select = f'''
<select{bank_select_match.group(1)} id="internationalBank">
    <option value="">Select a bank</option>
</select>
'''

        html = html.replace(
            bank_select_match.group(0),
            new_bank_select,
            1
        )

        print("Existing bank selector upgraded.")

    else:

        print(
            "WARNING: bank_name field was not automatically found."
        )


# =========================================================
# JAVASCRIPT
# =========================================================

script = f'''
<script id="fairmont-country-bank-selector">

document.addEventListener("DOMContentLoaded", function () {{

    const countrySelect =
        document.getElementById("internationalCountry");

    const bankSelect =
        document.getElementById("internationalBank");

    if (!countrySelect || !bankSelect) {{
        console.log(
            "Fairmont International Transfer: "
            + "country/bank selectors not found."
        );
        return;
    }}

    const countryBanks = {bank_data_json};

    function updateBanks() {{

        const country =
            countrySelect.value;

        bankSelect.innerHTML =
            '<option value="">Select a bank</option>';

        if (!country) {{
            bankSelect.disabled = true;
            return;
        }}

        const banks =
            countryBanks[country] || [];

        if (!banks.length) {{

            const option =
                document.createElement("option");

            option.value = "Other";
            option.textContent =
                "Other / Bank not listed";

            bankSelect.appendChild(option);

            bankSelect.disabled = false;

            return;
        }}

        banks.forEach(function (bank) {{

            const option =
                document.createElement("option");

            option.value = bank;
            option.textContent = bank;

            bankSelect.appendChild(option);

        }});

        bankSelect.disabled = false;
    }}


    countrySelect.addEventListener(
        "change",
        updateBanks
    );


    /*
     * Start with bank selector disabled until
     * the customer chooses a destination.
     */
    bankSelect.disabled = true;

    updateBanks();

    console.log(
        "Fairmont country-specific bank selector ready."
    );

}});

</script>
'''


# =========================================================
# REMOVE PREVIOUS VERSION IF PRESENT
# =========================================================

html = re.sub(
    r'<script id="fairmont-country-bank-selector">.*?</script>',
    '',
    html,
    flags=re.IGNORECASE | re.DOTALL
)


# =========================================================
# INSERT NEW SCRIPT
# =========================================================

if "</body>" in html:

    html = html.replace(
        "</body>",
        script + "\n</body>",
        1
    )

else:

    html += "\n" + script


# =========================================================
# SAVE
# =========================================================

TEMPLATE.write_text(
    html,
    encoding="utf-8"
)

print()
print("==============================================")
print("INTERNATIONAL COUNTRY/BANK UPGRADE COMPLETE")
print("==============================================")
print()
print("Updated:")
print(TEMPLATE)
print()
print("Countries available:", len(countries))
print()
print("Country-specific bank selection enabled.")
print()
print("Example:")
print("Suriname")
print("  - De Surinaamsche Bank N.V.")
print("  - Republic Bank (Suriname) N.V.")
print("  - Hakrinbank N.V.")
print("  - Finabank N.V.")
print("  - Surinaamse Postspaarbank")
print("  - Stichting Surinaamse Volkscredietbank")
print("  - Surichange Bank N.V.")
print("  - GODO")
print("  - Trustbank Amanah")
print("  - Southern Commercial Bank N.V.")
print()
print("Existing international transfer design preserved.")