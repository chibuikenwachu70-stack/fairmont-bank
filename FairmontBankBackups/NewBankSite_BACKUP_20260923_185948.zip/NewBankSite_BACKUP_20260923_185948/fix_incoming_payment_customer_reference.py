from pathlib import Path

APP_FILE = Path("app.py")

text = APP_FILE.read_text(encoding="utf-8")

old = '''            customer_id=receiver.id,
            transaction_type="Payment Received",'''

new = '''            customer_id=receiver.customer_id,
            transaction_type="Payment Received",'''

if old not in text:
    raise SystemExit(
        "ERROR: The incoming payment transaction block was not found. "
        "No changes were made."
    )

text = text.replace(old, new, 1)

APP_FILE.write_text(text, encoding="utf-8")

print()
print("=" * 70)
print("INCOMING PAYMENT CUSTOMER REFERENCE FIXED")
print("=" * 70)
print()
print("Incoming payments will now be recorded against the")
print("Fairmont Customer ID, matching the existing transaction system.")
print()
print("No customer balances or database records were changed.")
print()