from pathlib import Path


BASE_DIR = Path(r"C:\Users\DON J\Documents\NewBankSite")

TEMPLATES_DIR = BASE_DIR / "templates"

TEMPLATES_DIR.mkdir(
    parents=True,
    exist_ok=True
)


# =========================================================
# TRANSACTION HISTORY PAGE
# =========================================================

transactions_html = """<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0">

    <title>Transaction History | Fairmont Bank</title>

    <link
        rel="stylesheet"
        href="{{ url_for('static', filename='css/style.css') }}">

</head>

<body>

    <main class="transaction-page">

        <div class="transaction-shell">

            <header class="transaction-header">

                <a
                    href="/dashboard"
                    class="transaction-back-button">

                    ←

                </a>

                <div>

                    <p class="transaction-eyebrow">
                        FAIRMONT BANK
                    </p>

                    <h1>
                        Transaction History
                    </h1>

                </div>

            </header>


            <section class="transaction-account-card">

                <div>

                    <p>
                        AVAILABLE BALANCE
                    </p>

                    <h2>
                        £{{ "{:,.2f}".format(customer.account_balance) }}
                    </h2>

                </div>

                <div class="transaction-customer-reference">

                    {{ customer.customer_id }}

                </div>

            </section>


            <section class="transaction-list-section">

                <div class="transaction-section-heading">

                    <h2>
                        Transactions
                    </h2>

                    <span>
                        {{ transactions|length }}
                    </span>

                </div>


                {% if transactions %}

                    <div class="transaction-list">

                        {% for transaction in transactions %}

                            <a
                                href="{{ url_for('transaction_details', transaction_reference=transaction.transaction_reference) }}"
                                class="transaction-item">

                                <div
                                    class="transaction-icon
                                    {% if transaction.direction == 'Credit' %}
                                        transaction-credit
                                    {% else %}
                                        transaction-debit
                                    {% endif %}">

                                    {% if transaction.direction == "Credit" %}
                                        ↓
                                    {% else %}
                                        ↑
                                    {% endif %}

                                </div>


                                <div class="transaction-main">

                                    <strong>
                                        {{ transaction.description }}
                                    </strong>

                                    <span>

                                        {{ transaction.created_at.strftime("%d %b %Y, %H:%M") }}

                                    </span>

                                    {% if transaction.counterparty %}

                                        <small>
                                            {{ transaction.counterparty }}
                                        </small>

                                    {% endif %}

                                </div>


                                <div
                                    class="transaction-amount
                                    {% if transaction.direction == 'Credit' %}
                                        amount-credit
                                    {% else %}
                                        amount-debit
                                    {% endif %}">

                                    {% if transaction.direction == "Credit" %}
                                        +
                                    {% else %}
                                        -
                                    {% endif %}

                                    £{{ "{:,.2f}".format(transaction.amount) }}

                                </div>

                            </a>

                        {% endfor %}

                    </div>

                {% else %}

                    <div class="transaction-empty">

                        <div class="transaction-empty-icon">
                            —
                        </div>

                        <h3>
                            No transactions yet
                        </h3>

                        <p>
                            Your completed banking activity will appear here.
                        </p>

                    </div>

                {% endif %}

            </section>


            <a
                href="/dashboard"
                class="transaction-dashboard-button">

                Return to dashboard

            </a>

        </div>

    </main>

</body>

</html>
"""


# =========================================================
# TRANSACTION DETAILS PAGE
# =========================================================

transaction_details_html = """<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0">

    <title>Transaction Details | Fairmont Bank</title>

    <link
        rel="stylesheet"
        href="{{ url_for('static', filename='css/style.css') }}">

</head>

<body>

    <main class="transaction-page">

        <div class="transaction-shell">

            <header class="transaction-header">

                <a
                    href="/transactions"
                    class="transaction-back-button">

                    ←

                </a>

                <div>

                    <p class="transaction-eyebrow">
                        FAIRMONT BANK
                    </p>

                    <h1>
                        Transaction Details
                    </h1>

                </div>

            </header>


            <section class="transaction-detail-card">

                <div class="transaction-detail-status">

                    {% if transaction.direction == "Credit" %}

                        <div class="transaction-large-icon transaction-credit">
                            ↓
                        </div>

                    {% else %}

                        <div class="transaction-large-icon transaction-debit">
                            ↑
                        </div>

                    {% endif %}


                    <p class="transaction-detail-label">
                        {{ transaction.status }}
                    </p>

                    <h2>

                        {% if transaction.direction == "Credit" %}
                            +
                        {% else %}
                            -
                        {% endif %}

                        £{{ "{:,.2f}".format(transaction.amount) }}

                    </h2>

                    <span>
                        {{ transaction.description }}
                    </span>

                </div>


                <div class="transaction-detail-list">


                    <div class="transaction-detail-row">

                        <span>
                            Transaction reference
                        </span>

                        <strong>
                            {{ transaction.transaction_reference }}
                        </strong>

                    </div>


                    <div class="transaction-detail-row">

                        <span>
                            Transaction type
                        </span>

                        <strong>
                            {{ transaction.transaction_type }}
                        </strong>

                    </div>


                    <div class="transaction-detail-row">

                        <span>
                            Direction
                        </span>

                        <strong>
                            {{ transaction.direction }}
                        </strong>

                    </div>


                    <div class="transaction-detail-row">

                        <span>
                            Date and time
                        </span>

                        <strong>
                            {{ transaction.created_at.strftime("%d %B %Y, %H:%M") }}
                        </strong>

                    </div>


                    {% if transaction.counterparty %}

                    <div class="transaction-detail-row">

                        <span>
                            Other party
                        </span>

                        <strong>
                            {{ transaction.counterparty }}
                        </strong>

                    </div>

                    {% endif %}


                    <div class="transaction-detail-row">

                        <span>
                            Balance after transaction
                        </span>

                        <strong>
                            £{{ "{:,.2f}".format(transaction.balance_after) }}
                        </strong>

                    </div>


                    <div class="transaction-detail-row">

                        <span>
                            Status
                        </span>

                        <strong class="transaction-status-value">
                            {{ transaction.status }}
                        </strong>

                    </div>


                </div>

            </section>


            <a
                href="/transactions"
                class="transaction-dashboard-button">

                Back to transaction history

            </a>


        </div>

    </main>

</body>

</html>
"""


(TEMPLATES_DIR / "transactions.html").write_text(
    transactions_html,
    encoding="utf-8"
)

(TEMPLATES_DIR / "transaction_details.html").write_text(
    transaction_details_html,
    encoding="utf-8"
)


print("SUCCESS: transactions.html created.")
print("SUCCESS: transaction_details.html created.")