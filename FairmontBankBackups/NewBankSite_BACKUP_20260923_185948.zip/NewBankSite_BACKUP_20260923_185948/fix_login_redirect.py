from pathlib import Path
import shutil
from datetime import datetime

app = Path("app.py")

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = Path(f"app_BEFORE_LOGIN_REDIRECT_FIX_{timestamp}.py")

shutil.copy2(app, backup)
print(f"Backup created: {backup.name}")

text = app.read_text(encoding="utf-8")

old = '''        session["customer_id"] = customer.customer_id

        return redirect("/dashboard")
'''

new = '''        session["customer_id"] = customer.customer_id

        next_url = request.form.get("next") or request.args.get("next")

        if next_url and next_url.startswith("/") and not next_url.startswith("//"):
            return redirect(next_url)

        return redirect("/dashboard")
'''

if old not in text:
    print("TARGET_NOT_FOUND")
    print("No changes were made.")
    print("Backup was created safely.")
    raise SystemExit(1)

text = text.replace(old, new, 1)

app.write_text(text, encoding="utf-8")

print("LOGIN_REDIRECT_FIX_APPLIED")
print("app.py updated successfully.")
print(f"Backup: {backup.name}")