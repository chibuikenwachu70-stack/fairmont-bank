from pathlib import Path

APP_FILE = Path(r"C:\Users\DON J\Documents\NewBankSite\app.py")

text = APP_FILE.read_text(encoding="utf-8")

old = """        customer = Customer(

            customer_id=generate_customer_id(),

            full_name=full_name,"""

new = """        customer = Customer(

            customer_id=generate_customer_id(),

            account_number=generate_account_number(),

            full_name=full_name,"""

if "account_number=generate_account_number()," in text:
    print("SUCCESS: New account creation already includes Account Number.")

elif old in text:
    text = text.replace(old, new, 1)

    APP_FILE.write_text(
        text,
        encoding="utf-8"
    )

    print("SUCCESS: Account Number generation added to new accounts.")

else:
    print("ERROR: Exact Customer creation block was not found.")
    print("No changes were made.")