from pathlib import Path
import json
import re
import shutil

BASE_DIR = Path(__file__).resolve().parent
TEMPLATE = BASE_DIR / "templates" / "international_transfer.html"

if not TEMPLATE.exists():
    print("ERROR: templates\\international_transfer.html was not found.")
    raise SystemExit(1)

# ------------------------------------------------------------
# BACKUP
# ------------------------------------------------------------

backup = TEMPLATE.with_name("international_transfer_before_picker_v2.html")

if not backup.exists():
    shutil.copy2(TEMPLATE, backup)
    print("Backup created:")
    print(backup)
else:
    print("Backup already exists:")
    print(backup)

html = TEMPLATE.read_text(encoding="utf-8")


# ------------------------------------------------------------
# COUNTRY LIST
# ------------------------------------------------------------

countries = [
    "Afghanistan",
    "Albania",
    "Algeria",
    "Andorra",
    "Angola",
    "Antigua and Barbuda",
    "Argentina",
    "Armenia",
    "Australia",
    "Austria",
    "Azerbaijan",
    "Bahamas",
    "Bahrain",
    "Bangladesh",
    "Barbados",
    "Belarus",
    "Belgium",
    "Belize",
    "Benin",
    "Bhutan",
    "Bolivia",
    "Bosnia and Herzegovina",
    "Botswana",
    "Brazil",
    "Brunei",
    "Bulgaria",
    "Burkina Faso",
    "Burundi",
    "Cabo Verde",
    "Cambodia",
    "Cameroon",
    "Canada",
    "Central African Republic",
    "Chad",
    "Chile",
    "China",
    "Colombia",
    "Comoros",
    "Congo",
    "Costa Rica",
    "Croatia",
    "Cuba",
    "Cyprus",
    "Czech Republic",
    "Denmark",
    "Djibouti",
    "Dominica",
    "Dominican Republic",
    "Ecuador",
    "Egypt",
    "El Salvador",
    "Equatorial Guinea",
    "Eritrea",
    "Estonia",
    "Eswatini",
    "Ethiopia",
    "Fiji",
    "Finland",
    "France",
    "Gabon",
    "Gambia",
    "Georgia",
    "Germany",
    "Ghana",
    "Greece",
    "Grenada",
    "Guatemala",
    "Guinea",
    "Guinea-Bissau",
    "Guyana",
    "Haiti",
    "Honduras",
    "Hungary",
    "Iceland",
    "India",
    "Indonesia",
    "Iran",
    "Iraq",
    "Ireland",
    "Israel",
    "Italy",
    "Jamaica",
    "Japan",
    "Jordan",
    "Kazakhstan",
    "Kenya",
    "Kiribati",
    "Kuwait",
    "Kyrgyzstan",
    "Laos",
    "Latvia",
    "Lebanon",
    "Lesotho",
    "Liberia",
    "Libya",
    "Liechtenstein",
    "Lithuania",
    "Luxembourg",
    "Madagascar",
    "Malawi",
    "Malaysia",
    "Maldives",
    "Mali",
    "Malta",
    "Marshall Islands",
    "Mauritania",
    "Mauritius",
    "Mexico",
    "Micronesia",
    "Moldova",
    "Monaco",
    "Mongolia",
    "Montenegro",
    "Morocco",
    "Mozambique",
    "Myanmar",
    "Namibia",
    "Nauru",
    "Nepal",
    "Netherlands",
    "New Zealand",
    "Nicaragua",
    "Niger",
    "Nigeria",
    "North Korea",
    "North Macedonia",
    "Norway",
    "Oman",
    "Pakistan",
    "Palau",
    "Palestine",
    "Panama",
    "Papua New Guinea",
    "Paraguay",
    "Peru",
    "Philippines",
    "Poland",
    "Portugal",
    "Qatar",
    "Romania",
    "Russia",
    "Rwanda",
    "Saint Kitts and Nevis",
    "Saint Lucia",
    "Saint Vincent and the Grenadines",
    "Samoa",
    "San Marino",
    "Sao Tome and Principe",
    "Saudi Arabia",
    "Senegal",
    "Serbia",
    "Seychelles",
    "Sierra Leone",
    "Singapore",
    "Slovakia",
    "Slovenia",
    "Solomon Islands",
    "Somalia",
    "South Africa",
    "South Korea",
    "South Sudan",
    "Spain",
    "Sri Lanka",
    "Sudan",
    "Suriname",
    "Sweden",
    "Switzerland",
    "Syria",
    "Taiwan",
    "Tajikistan",
    "Tanzania",
    "Thailand",
    "Timor-Leste",
    "Togo",
    "Tonga",
    "Trinidad and Tobago",
    "Tunisia",
    "Turkey",
    "Turkmenistan",
    "Tuvalu",
    "Uganda",
    "Ukraine",
    "United Arab Emirates",
    "United Kingdom",
    "United States",
    "Uruguay",
    "Uzbekistan",
    "Vanuatu",
    "Vatican City",
    "Venezuela",
    "Vietnam",
    "Yemen",
    "Zambia",
    "Zimbabwe"
]


# ------------------------------------------------------------
# BANK LISTS
# ------------------------------------------------------------

country_banks = {
    "United Kingdom": [
        "Allied Irish Bank (GB)",
        "Bank of Ireland UK",
        "Bank of Scotland",
        "Barclays Bank",
        "Birmingham Bank",
        "Card One Money",
        "Cashplus Bank",
        "Chase UK",
        "Citibank UK",
        "ClearBank",
        "C. Hoare & Co.",
        "Co-operative Bank",
        "Coutts",
        "Danske Bank",
        "First Direct",
        "Halifax",
        "Handelsbanken UK",
        "HSBC UK",
        "Investec Bank",
        "Lloyds Bank",
        "Metro Bank",
        "Monzo Bank",
        "Nationwide Building Society",
        "NatWest",
        "Revolut",
        "Royal Bank of Scotland",
        "Santander UK",
        "Skipton Building Society",
        "Starling Bank",
        "TSB Bank",
        "Ulster Bank",
        "Virgin Money",
        "Yorkshire Building Society",
        "Zopa Bank",
        "Other UK Bank or Building Society"
    ],

    "Suriname": [
        "De Surinaamsche Bank (DSB)",
        "Republic Bank Suriname",
        "Hakrinbank",
        "Surinaamse Volkscredietbank",
        "Finabank",
        "Surichange Bank",
        "GODO",
        "Trustbank Amanah",
        "Postspaarbank",
        "Other Surinamese Bank"
    ],

    "United States": [
        "Bank of America",
        "JPMorgan Chase Bank",
        "Wells Fargo Bank",
        "Citibank",
        "U.S. Bank",
        "PNC Bank",
        "Truist Bank",
        "Capital One",
        "TD Bank",
        "Goldman Sachs Bank",
        "Other US Bank"
    ],

    "Canada": [
        "Royal Bank of Canada",
        "Toronto-Dominion Bank",
        "Bank of Montreal",
        "Bank of Nova Scotia",
        "Canadian Imperial Bank of Commerce",
        "National Bank of Canada",
        "Desjardins",
        "Other Canadian Bank"
    ],

    "Australia": [
        "Commonwealth Bank",
        "Westpac",
        "ANZ",
        "National Australia Bank",
        "Macquarie Bank",
        "Bank of Queensland",
        "Bendigo Bank",
        "Other Australian Bank"
    ],

    "New Zealand": [
        "ANZ New Zealand",
        "ASB Bank",
        "Bank of New Zealand",
        "Westpac New Zealand",
        "Kiwibank",
        "Heartland Bank",
        "Other New Zealand Bank"
    ],

    "Germany": [
        "Deutsche Bank",
        "Commerzbank",
        "DZ Bank",
        "KfW",
        "ING Germany",
        "DKB",
        "N26",
        "Sparkasse",
        "Volksbank",
        "Other German Bank"
    ],

    "France": [
        "BNP Paribas",
        "Crédit Agricole",
        "Société Générale",
        "BPCE",
        "Crédit Mutuel",
        "La Banque Postale",
        "HSBC Continental Europe",
        "Other French Bank"
    ],

    "Ireland": [
        "AIB",
        "Bank of Ireland",
        "Permanent TSB",
        "Revolut Bank Ireland",
        "Other Irish Bank"
    ],

    "Netherlands": [
        "ING Bank",
        "ABN AMRO",
        "Rabobank",
        "de Volksbank",
        "N26",
        "Other Dutch Bank"
    ],

    "Belgium": [
        "KBC Bank",
        "Belfius Bank",
        "BNP Paribas Fortis",
        "ING Belgium",
        "Argenta",
        "Other Belgian Bank"
    ],

    "Switzerland": [
        "UBS",
        "Credit Suisse",
        "Zürcher Kantonalbank",
        "Raiffeisen Switzerland",
        "Julius Baer",
        "Other Swiss Bank"
    ],

    "Sweden": [
        "Swedbank",
        "SEB",
        "Handelsbanken",
        "Nordea",
        "Danske Bank Sweden",
        "Other Swedish Bank"
    ],

    "Norway": [
        "DNB Bank",
        "Nordea Norway",
        "SpareBank 1",
        "Handelsbanken Norway",
        "Danske Bank Norway",
        "Other Norwegian Bank"
    ],

    "Denmark": [
        "Danske Bank",
        "Nordea Denmark",
        "Jyske Bank",
        "Sydbank",
        "Spar Nord",
        "Other Danish Bank"
    ],

    "Finland": [
        "Nordea Finland",
        "OP Financial Group",
        "Danske Bank Finland",
        "Aktia Bank",
        "S-Bank",
        "Other Finnish Bank"
    ],

    "Spain": [
        "Banco Santander",
        "BBVA",
        "CaixaBank",
        "Banco Sabadell",
        "Bankinter",
        "Unicaja Banco",
        "Other Spanish Bank"
    ],

    "Italy": [
        "Intesa Sanpaolo",
        "UniCredit",
        "Banco BPM",
        "BPER Banca",
        "Monte dei Paschi di Siena",
        "Mediobanca",
        "Other Italian Bank"
    ],

    "Portugal": [
        "Caixa Geral de Depósitos",
        "Millennium BCP",
        "Novo Banco",
        "Banco Santander Totta",
        "Banco BPI",
        "Other Portuguese Bank"
    ],

    "Austria": [
        "Erste Bank",
        "Raiffeisen Bank Austria",
        "Bank Austria",
        "BAWAG",
        "Volksbank",
        "Other Austrian Bank"
    ],

    "Poland": [
        "PKO Bank Polski",
        "Bank Pekao",
        "Santander Bank Polska",
        "mBank",
        "ING Bank Śląski",
        "Alior Bank",
        "Other Polish Bank"
    ],

    "India": [
        "State Bank of India",
        "HDFC Bank",
        "ICICI Bank",
        "Axis Bank",
        "Kotak Mahindra Bank",
        "IndusInd Bank",
        "Punjab National Bank",
        "Bank of Baroda",
        "Canara Bank",
        "Other Indian Bank"
    ],

    "China": [
        "Industrial and Commercial Bank of China",
        "China Construction Bank",
        "Agricultural Bank of China",
        "Bank of China",
        "Bank of Communications",
        "China Merchants Bank",
        "Other Chinese Bank"
    ],

    "Japan": [
        "MUFG Bank",
        "SMBC Bank",
        "Mizuho Bank",
        "Resona Bank",
        "Japan Post Bank",
        "Other Japanese Bank"
    ],

    "Singapore": [
        "DBS Bank",
        "OCBC Bank",
        "United Overseas Bank",
        "Standard Chartered Singapore",
        "Citibank Singapore",
        "Other Singaporean Bank"
    ],

    "Malaysia": [
        "Maybank",
        "CIMB Bank",
        "Public Bank",
        "RHB Bank",
        "Hong Leong Bank",
        "AmBank",
        "Other Malaysian Bank"
    ],

    "Indonesia": [
        "Bank Mandiri",
        "Bank Central Asia",
        "Bank Rakyat Indonesia",
        "Bank Negara Indonesia",
        "CIMB Niaga",
        "Bank Danamon",
        "Other Indonesian Bank"
    ],

    "South Africa": [
        "Standard Bank",
        "First National Bank",
        "Absa Bank",
        "Nedbank",
        "Capitec Bank",
        "Investec Bank",
        "Other South African Bank"
    ],

    "Kenya": [
        "KCB Bank Kenya",
        "Equity Bank Kenya",
        "Co-operative Bank of Kenya",
        "Absa Bank Kenya",
        "Standard Chartered Bank Kenya",
        "NCBA Bank Kenya",
        "I&M Bank",
        "Stanbic Bank Kenya",
        "DTB Kenya",
        "Family Bank",
        "Other Kenyan Bank"
    ],

    "Nigeria": [
        "Access Bank",
        "First Bank of Nigeria",
        "Guaranty Trust Bank",
        "United Bank for Africa",
        "Zenith Bank",
        "Fidelity Bank",
        "Stanbic IBTC Bank",
        "Ecobank Nigeria",
        "Other Nigerian Bank"
    ],

    "Ghana": [
        "GCB Bank",
        "Ecobank Ghana",
        "Absa Bank Ghana",
        "Stanbic Bank Ghana",
        "Standard Chartered Bank Ghana",
        "Fidelity Bank Ghana",
        "CalBank",
        "Other Ghanaian Bank"
    ],

    "Uganda": [
        "Stanbic Bank Uganda",
        "Centenary Bank",
        "Absa Bank Uganda",
        "DFCU Bank",
        "Standard Chartered Bank Uganda",
        "Equity Bank Uganda",
        "Other Ugandan Bank"
    ],

    "Tanzania": [
        "CRDB Bank",
        "NMB Bank",
        "NBC Tanzania",
        "Absa Bank Tanzania",
        "Stanbic Bank Tanzania",
        "Standard Chartered Bank Tanzania",
        "Other Tanzanian Bank"
    ],

    "Rwanda": [
        "Bank of Kigali",
        "I&M Bank Rwanda",
        "Ecobank Rwanda",
        "KCB Bank Rwanda",
        "Access Bank Rwanda",
        "Other Rwandan Bank"
    ],

    "United Arab Emirates": [
        "Emirates NBD",
        "First Abu Dhabi Bank",
        "Abu Dhabi Commercial Bank",
        "Dubai Islamic Bank",
        "Mashreq Bank",
        "RAKBANK",
        "Other UAE Bank"
    ],

    "Saudi Arabia": [
        "Saudi National Bank",
        "Al Rajhi Bank",
        "Riyad Bank",
        "Saudi Awwal Bank",
        "Bank Albilad",
        "Bank AlJazira",
        "Other Saudi Bank"
    ],

    "Qatar": [
        "Qatar National Bank",
        "Qatar Islamic Bank",
        "Commercial Bank of Qatar",
        "Doha Bank",
        "Masraf Al Rayan",
        "Other Qatari Bank"
    ],

    "Brazil": [
        "Banco do Brasil",
        "Itaú Unibanco",
        "Bradesco",
        "Caixa Econômica Federal",
        "Santander Brasil",
        "BTG Pactual",
        "Other Brazilian Bank"
    ],

    "Mexico": [
        "BBVA México",
        "Banorte",
        "Santander México",
        "Citibanamex",
        "HSBC México",
        "Scotiabank México",
        "Other Mexican Bank"
    ],

    "Argentina": [
        "Banco Nación",
        "Banco Galicia",
        "Banco Santander Argentina",
        "BBVA Argentina",
        "Banco Macro",
        "Other Argentine Bank"
    ]
}


# ------------------------------------------------------------
# CURRENCIES
# ------------------------------------------------------------

currencies = [
    ("GBP", "GBP — Pound Sterling"),
    ("EUR", "EUR — Euro"),
    ("USD", "USD — US Dollar"),
    ("CAD", "CAD — Canadian Dollar"),
    ("AUD", "AUD — Australian Dollar"),
    ("NZD", "NZD — New Zealand Dollar"),
    ("CHF", "CHF — Swiss Franc"),
    ("JPY", "JPY — Japanese Yen"),
    ("CNY", "CNY — Chinese Yuan"),
    ("HKD", "HKD — Hong Kong Dollar"),
    ("SGD", "SGD — Singapore Dollar"),
    ("INR", "INR — Indian Rupee"),
    ("AED", "AED — UAE Dirham"),
    ("SAR", "SAR — Saudi Riyal"),
    ("QAR", "QAR — Qatari Riyal"),
    ("ZAR", "ZAR — South African Rand"),
    ("KES", "KES — Kenyan Shilling"),
    ("NGN", "NGN — Nigerian Naira"),
    ("GHS", "GHS — Ghanaian Cedi"),
    ("TZS", "TZS — Tanzanian Shilling"),
    ("UGX", "UGX — Ugandan Shilling"),
    ("RWF", "RWF — Rwandan Franc"),
    ("BRL", "BRL — Brazilian Real"),
    ("MXN", "MXN — Mexican Peso"),
    ("ARS", "ARS — Argentine Peso"),
    ("SRD", "SRD — Surinamese Dollar"),
    ("THB", "THB — Thai Baht"),
    ("MYR", "MYR — Malaysian Ringgit"),
    ("IDR", "IDR — Indonesian Rupiah"),
    ("KRW", "KRW — South Korean Won"),
    ("TRY", "TRY — Turkish Lira"),
    ("PLN", "PLN — Polish Zloty"),
    ("SEK", "SEK — Swedish Krona"),
    ("NOK", "NOK — Norwegian Krone"),
    ("DKK", "DKK — Danish Krone"),
    ("CZK", "CZK — Czech Koruna"),
    ("HUF", "HUF — Hungarian Forint"),
    ("RON", "RON — Romanian Leu"),
    ("ILS", "ILS — Israeli New Shekel")
]


countries_json = json.dumps(countries, ensure_ascii=False)
banks_json = json.dumps(country_banks, ensure_ascii=False)
currencies_json = json.dumps(currencies, ensure_ascii=False)


# ------------------------------------------------------------
# REPLACE COUNTRY SELECT
# ------------------------------------------------------------

country_pattern = re.compile(
    r'<select\b[^>]*id=["\']internationalCountry["\'][^>]*>.*?</select>',
    re.IGNORECASE | re.DOTALL
)

country_select = """
<select
    id="internationalCountry"
    name="country"
    class="fairmont-hidden-select"
    required
>
    <option value="">Select country</option>
</select>
"""

html, country_count = country_pattern.subn(country_select, html, count=1)


# ------------------------------------------------------------
# REPLACE BANK SELECT
# ------------------------------------------------------------

bank_pattern = re.compile(
    r'<select\b[^>]*id=["\']internationalBank["\'][^>]*>.*?</select>',
    re.IGNORECASE | re.DOTALL
)

bank_select = """
<select
    id="internationalBank"
    name="bank_name"
    class="fairmont-hidden-select"
    required
>
    <option value="">Select a bank</option>
</select>
"""

html, bank_count = bank_pattern.subn(bank_select, html, count=1)


# ------------------------------------------------------------
# REPLACE CURRENCY SELECT
# ------------------------------------------------------------

currency_pattern = re.compile(
    r'<select\b[^>]*id=["\']internationalCurrency["\'][^>]*>.*?</select>',
    re.IGNORECASE | re.DOTALL
)

currency_select = """
<select
    id="internationalCurrency"
    name="currency"
    class="fairmont-hidden-select"
    required
>
    <option value="">Select currency</option>
</select>
"""

html, currency_count = currency_pattern.subn(currency_select, html, count=1)


if country_count == 0:
    print("WARNING: internationalCountry select was not found.")

if bank_count == 0:
    print("WARNING: internationalBank select was not found.")

if currency_count == 0:
    print("WARNING: internationalCurrency select was not found.")


# ------------------------------------------------------------
# REMOVE PREVIOUS FAIRMONТ PICKER CODE
# ------------------------------------------------------------

html = re.sub(
    r'<style[^>]*id=["\']fairmont-picker-v2-style["\'][^>]*>.*?</style>',
    '',
    html,
    flags=re.IGNORECASE | re.DOTALL
)

html = re.sub(
    r'<script[^>]*id=["\']fairmont-picker-v2-script["\'][^>]*>.*?</script>',
    '',
    html,
    flags=re.IGNORECASE | re.DOTALL
)

html = re.sub(
    r'<style[^>]*id=["\']fairmont-picker-style["\'][^>]*>.*?</style>',
    '',
    html,
    flags=re.IGNORECASE | re.DOTALL
)

html = re.sub(
    r'<script[^>]*id=["\']fairmont-picker-script["\'][^>]*>.*?</script>',
    '',
    html,
    flags=re.IGNORECASE | re.DOTALL
)


# ------------------------------------------------------------
# CSS
# ------------------------------------------------------------

css = r"""
<style id="fairmont-picker-v2-style">
.fairmont-hidden-select {
    position: absolute !important;
    width: 1px !important;
    height: 1px !important;
    opacity: 0 !important;
    pointer-events: none !important;
    overflow: hidden !important;
}

.fairmont-picker-trigger {
    width: 100%;
    min-height: 52px;
    box-sizing: border-box;
    border: 1px solid rgba(255,255,255,0.14);
    border-radius: 14px;
    background: rgba(255,255,255,0.055);
    color: #ffffff;
    padding: 0 46px 0 16px;
    text-align: left;
    font-size: 15px;
    position: relative;
    cursor: pointer;
    outline: none;
}

.fairmont-picker-trigger::after {
    content: "▾";
    position: absolute;
    right: 16px;
    top: 50%;
    transform: translateY(-50%);
    opacity: 0.75;
    font-size: 16px;
}

.fairmont-picker-trigger.open::after {
    content: "▴";
}

.fairmont-picker-trigger.placeholder {
    color: rgba(255,255,255,0.58);
}

.fairmont-picker-popup {
    position: fixed;
    z-index: 2147483647;
    width: min(430px, calc(100vw - 28px));
    max-height: min(520px, calc(100vh - 40px));
    background: #101a2d;
    border: 1px solid rgba(255,255,255,0.16);
    border-radius: 16px;
    box-shadow: 0 20px 60px rgba(0,0,0,0.55);
    overflow: hidden;
    display: none;
}

.fairmont-picker-popup.visible {
    display: block;
}

.fairmont-picker-search-wrap {
    padding: 12px;
    border-bottom: 1px solid rgba(255,255,255,0.10);
    background: #101a2d;
    position: sticky;
    top: 0;
    z-index: 2;
}

.fairmont-picker-search {
    width: 100%;
    height: 44px;
    box-sizing: border-box;
    border-radius: 11px;
    border: 1px solid rgba(255,255,255,0.14);
    outline: none;
    background: rgba(255,255,255,0.07);
    color: white;
    padding: 0 13px;
    font-size: 15px;
}

.fairmont-picker-search::placeholder {
    color: rgba(255,255,255,0.48);
}

.fairmont-picker-options {
    max-height: 410px;
    overflow-y: auto;
    overscroll-behavior: contain;
}

.fairmont-picker-option {
    padding: 13px 16px;
    color: #ffffff;
    font-size: 14px;
    line-height: 1.3;
    cursor: pointer;
    border-bottom: 1px solid rgba(255,255,255,0.055);
}

.fairmont-picker-option:last-child {
    border-bottom: 0;
}

.fairmont-picker-option:hover,
.fairmont-picker-option:active {
    background: rgba(255,255,255,0.10);
}

.fairmont-picker-empty {
    padding: 20px 16px;
    color: rgba(255,255,255,0.55);
    font-size: 14px;
    text-align: center;
}

.fairmont-picker-title {
    padding: 11px 14px 0;
    color: rgba(255,255,255,0.45);
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.08em;
}
</style>
"""


# ------------------------------------------------------------
# JAVASCRIPT
# ------------------------------------------------------------

js_template = r"""
<script id="fairmont-picker-v2-script">
(function () {
    "use strict";

    var COUNTRIES = __COUNTRIES__;
    var COUNTRY_BANKS = __BANKS__;
    var CURRENCIES = __CURRENCIES__;

    var popup = null;
    var activePicker = null;

    function ready(fn) {
        if (document.readyState === "loading") {
            document.addEventListener("DOMContentLoaded", fn);
        } else {
            fn();
        }
    }

    function makeOption(select, value, text) {
        var option = document.createElement("option");
        option.value = value;
        option.textContent = text;
        select.appendChild(option);
    }

    function fillCountrySelect(select) {
        select.innerHTML = "";
        makeOption(select, "", "Select country");

        COUNTRIES.forEach(function (country) {
            makeOption(select, country, country);
        });
    }

    function fillCurrencySelect(select) {
        select.innerHTML = "";
        makeOption(select, "", "Select currency");

        CURRENCIES.forEach(function (item) {
            makeOption(select, item[0], item[1]);
        });
    }

    function fillBankSelect(select, country) {
        var previousValue = select.value;

        select.innerHTML = "";
        makeOption(select, "", "Select a bank");

        if (!country) {
            return;
        }

        var banks = COUNTRY_BANKS[country];

        if (!banks || !banks.length) {
            banks = [
                "Other bank or financial institution in " + country
            ];
        }

        banks.forEach(function (bank) {
            makeOption(select, bank, bank);
        });

        if (previousValue) {
            var found = false;

            Array.prototype.forEach.call(select.options, function (option) {
                if (option.value === previousValue) {
                    found = true;
                }
            });

            if (found) {
                select.value = previousValue;
            }
        }
    }

    function removePopup() {
        if (popup) {
            popup.remove();
            popup = null;
        }

        if (activePicker) {
            activePicker.button.classList.remove("open");
            activePicker = null;
        }
    }

    function positionPopup(button) {
        if (!popup) {
            return;
        }

        var rect = button.getBoundingClientRect();
        var popupWidth = Math.min(430, window.innerWidth - 28);

        popup.style.width = popupWidth + "px";

        var left = rect.left;

        if (left + popupWidth > window.innerWidth - 14) {
            left = window.innerWidth - popupWidth - 14;
        }

        if (left < 14) {
            left = 14;
        }

        var popupHeight = Math.min(
            520,
            window.innerHeight - 40
        );

        popup.style.maxHeight = popupHeight + "px";

        var top = rect.bottom + 8;

        if (top + popupHeight > window.innerHeight - 14) {
            top = rect.top - popupHeight - 8;
        }

        if (top < 14) {
            top = 14;
        }

        popup.style.left = left + "px";
        popup.style.top = top + "px";
    }

    function createPopup(picker) {
        removePopup();

        activePicker = picker;

        picker.button.classList.add("open");

        popup = document.createElement("div");
        popup.className = "fairmont-picker-popup visible";

        var title = document.createElement("div");
        title.className = "fairmont-picker-title";
        title.textContent = picker.title;

        var searchWrap = document.createElement("div");
        searchWrap.className = "fairmont-picker-search-wrap";

        var search = document.createElement("input");
        search.type = "search";
        search.className = "fairmont-picker-search";
        search.placeholder = "Search " + picker.searchName + "...";
        search.autocomplete = "off";
        search.spellcheck = false;

        searchWrap.appendChild(search);

        var options = document.createElement("div");
        options.className = "fairmont-picker-options";

        popup.appendChild(title);
        popup.appendChild(searchWrap);
        popup.appendChild(options);

        document.body.appendChild(popup);

        function renderOptions() {
            options.innerHTML = "";

            var term = search.value.trim().toLowerCase();

            var sourceOptions = Array.prototype.filter.call(
                picker.select.options,
                function (option) {
                    return option.value !== "";
                }
            );

            var matches = sourceOptions.filter(function (option) {
                return (
                    option.textContent.toLowerCase().indexOf(term) !== -1 ||
                    option.value.toLowerCase().indexOf(term) !== -1
                );
            });

            if (!matches.length) {
                var empty = document.createElement("div");
                empty.className = "fairmont-picker-empty";

                if (picker.select.id === "internationalBank" &&
                    !picker.select.dataset.countrySelected) {

                    empty.textContent = "Select a country first.";
                } else {
                    empty.textContent = "No matches found.";
                }

                options.appendChild(empty);
                return;
            }

            matches.forEach(function (option) {
                var item = document.createElement("div");
                item.className = "fairmont-picker-option";
                item.textContent = option.textContent;

                item.addEventListener("mousedown", function (event) {
                    event.preventDefault();
                });

                item.addEventListener("click", function () {
                    picker.select.value = option.value;

                    picker.select.dispatchEvent(
                        new Event("change", {
                            bubbles: true
                        })
                    );

                    updateButtonText(picker);

                    removePopup();

                    picker.select.focus();
                });

                options.appendChild(item);
            });
        }

        search.addEventListener("input", renderOptions);

        search.addEventListener("keydown", function (event) {
            if (event.key === "Escape") {
                event.preventDefault();
                removePopup();
                picker.button.focus();
            }
        });

        positionPopup(picker.button);
        renderOptions();

        setTimeout(function () {
            search.focus();
        }, 0);
    }

    function updateButtonText(picker) {
        var selected = picker.select.options[
            picker.select.selectedIndex
        ];

        if (!selected || !selected.value) {
            picker.button.textContent = picker.placeholder;
            picker.button.classList.add("placeholder");
            return;
        }

        picker.button.textContent = selected.textContent;
        picker.button.classList.remove("placeholder");
    }

    function createPicker(select, title, searchName, placeholder) {
        if (!select) {
            return null;
        }

        if (select.dataset.fairmontPickerReady === "1") {
            return null;
        }

        select.dataset.fairmontPickerReady = "1";
        select.classList.add("fairmont-hidden-select");

        var button = document.createElement("button");
        button.type = "button";
        button.className = "fairmont-picker-trigger placeholder";
        button.textContent = placeholder;

        select.parentNode.insertBefore(button, select.nextSibling);

        var picker = {
            select: select,
            button: button,
            title: title,
            searchName: searchName,
            placeholder: placeholder
        };

        button.addEventListener("click", function (event) {
            event.preventDefault();
            event.stopPropagation();

            if (activePicker === picker && popup) {
                removePopup();
            } else {
                createPopup(picker);
            }
        });

        select.addEventListener("change", function () {
            updateButtonText(picker);
        });

        updateButtonText(picker);

        return picker;
    }

    function setup() {
        var country = document.getElementById("internationalCountry");
        var bank = document.getElementById("internationalBank");
        var currency = document.getElementById("internationalCurrency");

        if (!country || !bank || !currency) {
            console.error(
                "Fairmont picker: required select fields were not found."
            );
            return;
        }

        fillCountrySelect(country);
        fillCurrencySelect(currency);

        country.dataset.countrySelected = "";

        fillBankSelect(bank, "");

        var countryPicker = createPicker(
            country,
            "Destination Country",
            "country",
            "Select country"
        );

        var bankPicker = createPicker(
            bank,
            "Bank Name",
            "bank",
            "Select a bank"
        );

        var currencyPicker = createPicker(
            currency,
            "Currency",
            "currency",
            "Select currency"
        );

        country.addEventListener("change", function () {
            country.dataset.countrySelected = country.value || "";

            fillBankSelect(bank, country.value);

            bank.value = "";

            if (bankPicker) {
                updateButtonText(bankPicker);
            }
        });

        window.addEventListener("resize", function () {
            if (activePicker && popup) {
                positionPopup(activePicker.button);
            }
        });

        window.addEventListener("scroll", function () {
            if (activePicker && popup) {
                positionPopup(activePicker.button);
            }
        }, true);

        document.addEventListener("click", function (event) {
            if (!activePicker || !popup) {
                return;
            }

            if (
                event.target === activePicker.button ||
                activePicker.button.contains(event.target) ||
                popup.contains(event.target)
            ) {
                return;
            }

            removePopup();
        });

        document.addEventListener("keydown", function (event) {
            if (event.key === "Escape" && activePicker) {
                removePopup();
            }
        });

        console.log(
            "Fairmont custom dropdowns initialized successfully."
        );
    }

    ready(setup);
})();
</script>
"""

js = (
    js_template
    .replace("__COUNTRIES__", countries_json)
    .replace("__BANKS__", banks_json)
    .replace("__CURRENCIES__", currencies_json)
)


# ------------------------------------------------------------
# INSERT CSS + JS
# ------------------------------------------------------------

html = html.replace("</head>", css + "\n</head>", 1)

if "</body>" in html:
    html = html.replace("</body>", js + "\n</body>", 1)
else:
    html += "\n" + js


# ------------------------------------------------------------
# WRITE FILE
# ------------------------------------------------------------

TEMPLATE.write_text(html, encoding="utf-8")


# ------------------------------------------------------------
# RESULT
# ------------------------------------------------------------

print()
print("==============================================")
print("INTERNATIONAL TRANSFER PICKER FIX COMPLETE")
print("==============================================")
print()
print("Template updated:")
print(TEMPLATE)
print()
print("Country select replaced:", country_count)
print("Bank select replaced:", bank_count)
print("Currency select replaced:", currency_count)
print()
print("Features installed:")
print("  - Full country list")
print("  - Search inside Country dropdown")
print("  - Country-dependent Bank dropdown")
print("  - Search inside Bank dropdown")
print("  - Currency dropdown")
print("  - Search inside Currency dropdown")
print("  - Correct Flask form names")
print("  - Mobile-friendly popup")
print("  - Mouse/touch support")
print("  - Escape/outside-click closing")
print()
print("Backup:")
print(backup)
print()
print("IMPORTANT:")
print("Restart Flask after this fix.")
print("Then hard-refresh the browser.")
print()