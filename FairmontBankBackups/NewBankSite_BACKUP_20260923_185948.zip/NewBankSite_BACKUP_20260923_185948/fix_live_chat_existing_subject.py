from pathlib import Path
import shutil

FILE = Path("templates/live_chat.html")

text = FILE.read_text(encoding="utf-8")

backup = Path("templates/live_chat.html.before_existing_subject")
shutil.copy2(FILE, backup)

marker = '''        <section class="conversation">'''

if marker not in text:
    print("ERROR: Conversation section was not found.")
    print("Backup created:", backup)
    raise SystemExit(1)

subject_display = '''        {% if conversation %}
            <div class="chat-subject-display">
                <span class="chat-subject-label">Subject</span>
                <span class="chat-subject-value">
                    {{ conversation.subject }}
                </span>
            </div>
        {% endif %}

'''

if "chat-subject-display" in text:
    print("Subject display already exists.")
    raise SystemExit(0)

text = text.replace(
    marker,
    subject_display + marker,
    1
)

css_marker = '''        .subject-field {'''

subject_css = '''        .chat-subject-display {
            width: 100%;
            margin-bottom: 14px;
            padding: 12px 14px;
            display: flex;
            align-items: center;
            gap: 10px;
            border: 1px solid rgba(184, 149, 74, 0.20);
            border-radius: 10px;
            background: rgba(184, 149, 74, 0.055);
        }

        .chat-subject-label {
            color: #d8b96a;
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.6px;
        }

        .chat-subject-value {
            color: #cbd8e5;
            font-size: 12px;
            font-weight: 600;
            overflow-wrap: anywhere;
        }

'''

if css_marker not in text:
    print("ERROR: Subject CSS section was not found.")
    print("Backup created:", backup)
    raise SystemExit(1)

text = text.replace(
    css_marker,
    subject_css + css_marker,
    1
)

FILE.write_text(text, encoding="utf-8")

print("=" * 70)
print("LIVE CHAT EXISTING SUBJECT DISPLAY ADDED")
print("=" * 70)
print()
print("Existing conversations will now show their subject.")
print()
print("Backup created:")
print(backup)