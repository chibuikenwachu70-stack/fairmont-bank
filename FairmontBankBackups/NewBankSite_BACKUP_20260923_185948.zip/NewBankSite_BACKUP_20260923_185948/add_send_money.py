from pathlib import Path

BASE_DIR = Path(r"C:\Users\DON J\Documents\NewBankSite")
APP_FILE = BASE_DIR / "app.py"

text = APP_FILE.read_text(encoding="utf-8")


# ---------------------------------------------------------
# 1. Add IntegrityError import
# ---------------------------------------------------------

if "from sqlalchemy.exc import IntegrityError" not in text:

    marker = "from flask import"

    if marker in text:
        lines = text.splitlines()

        insert_at = 0

        for i, line in enumerate(lines):
            if line.startswith("from sqlalchemy"):
                insert_at = i + 1

        if insert_at == 0:
            for i, line in enumerate(lines):
                if line.startswith("from flask"):
                    insert_at = i + 1
                    break

        lines.insert(
            insert_at,
            "from sqlalchemy.exc import IntegrityError"
        )

        text = "\n".join(lines) + "\n"


# ---------------------------------------------------------
# 2. Add Send Money route
# ---------------------------------------------------------

route_marker = "@app.route(\"/transactions\")"


send_money_route = r'''

@app.route("/send-money", methods=["GET", "POST"])
def send_money():

    customer_id = session.get("customer_id")

    if not customer_id:
        return render_template(
            "login.html",
            error="Please sign in to send money."
        )

    customer = Customer.query.filter_by(
        customer_id=customer_id
    ).first()

    if customer is None:
        session.clear()

        return render_template(
            "login.html",
            error="Your session could not be verified. Please sign in again."
        )

    if request.method == "GET":

        return render_template(
            "send_money.html",
            customer=customer
        )

    recipient_id = request.form.get(
        "recipient_id",
        ""
    ).strip().upper()

    amount_text = request.form.get(
        "amount",
        ""
    ).strip()

    description = request.form.get(
        "description",
        ""
    ).strip()

    if not recipient_id:

        return render_template(
            "send_money.html",
            customer=customer,
            error="Please enter the recipient Customer ID.",
            recipient_id=recipient_id,
            amount=amount_text,
            description=description
        )

    if not amount_text:

        return render_template(
            "send_money.html",
            customer=customer,
            error="Please enter the amount to send.",
            recipient_id=recipient_id,
            amount=amount_text,
            description=description
        )

    try:

        amount = float(amount_text)

    except ValueError:

        return render_template(
            "send_money.html",
            customer=customer,
            error="Please enter a valid amount.",
            recipient_id=recipient_id,
            amount=amount_text,
            description=description
        )

    if amount <= 0:

        return render_template(
            "send_money.html",
            customer=customer,
            error="The transfer amount must be greater than £0.00.",
            recipient_id=recipient_id,
            amount=amount_text,
            description=description
        )

    amount = round(amount, 2)

    if amount <= 0:

        return render_template(
            "send_money.html",
            customer=customer,
            error="Please enter a valid amount.",
            recipient_id=recipient_id,
            amount=amount_text,
            description=description
        )

    if recipient_id == customer.customer_id.upper():

        return render_template(
            "send_money.html",
            customer=customer,
            error="You cannot send money to your own account.",
            recipient_id=recipient_id,
            amount=amount_text,
            description=description
        )

    recipient = Customer.query.filter_by(
        customer_id=recipient_id
    ).first()

    if recipient is None:

        return render_template(
            "send_money.html",
            customer=customer,
            error="Recipient Customer ID was not found.",
            recipient_id=recipient_id,
            amount=amount_text,
            description=description
        )

    if recipient.account_status.lower() != "active":

        return render_template(
            "send_money.html",
            customer=customer,
            error="The recipient account is not active.",
            recipient_id=recipient_id,
            amount=amount_text,
            description=description
        )

    sender_balance = round(
        float(customer.account_balance or 0),
        2
    )

    if amount > sender_balance:

        return render_template(
            "send_money.html",
            customer=customer,
            error=(
                "Insufficient available balance. "
                f"Your available balance is £{sender_balance:,.2f}."
            ),
            recipient_id=recipient_id,
            amount=amount_text,
            description=description
        )

    if not description:

        description = "Fairmont Bank transfer"

    if len(description) > 255:

        description = description[:255]

    old_sender_balance = sender_balance

    old_recipient_balance = round(
        float(recipient.account_balance or 0),
        2
    )

    new_sender_balance = round(
        old_sender_balance - amount,
        2
    )

    new_recipient_balance = round(
        old_recipient_balance + amount,
        2
    )

    transfer_reference = generate_transaction_reference()

    sender_transaction = Transaction(
        transaction_reference=transfer_reference,
        customer_id=customer.customer_id,
        transaction_type="Customer Transfer",
        direction="Debit",
        amount=amount,
        balance_after=new_sender_balance,
        description=description,
        counterparty=recipient.full_name,
        status="Completed"
    )

    recipient_reference = generate_transaction_reference()

    recipient_transaction = Transaction(
        transaction_reference=recipient_reference,
        customer_id=recipient.customer_id,
        transaction_type="Customer Transfer",
        direction="Credit",
        amount=amount,
        balance_after=new_recipient_balance,
        description=description,
        counterparty=customer.full_name,
        status="Completed"
    )

    try:

        customer.account_balance = new_sender_balance
        recipient.account_balance = new_recipient_balance

        db.session.add(sender_transaction)
        db.session.add(recipient_transaction)

        db.session.commit()

    except Exception:

        db.session.rollback()

        return render_template(
            "send_money.html",
            customer=customer,
            error=(
                "The transfer could not be completed. "
                "No account balance was changed."
            ),
            recipient_id=recipient_id,
            amount=amount_text,
            description=description
        )

    return render_template(
        "transfer_confirmation.html",
        customer=customer,
        recipient=recipient,
        transaction=sender_transaction
    )


'''


if 'def send_money():' not in text:

    if route_marker not in text:

        raise SystemExit(
            "ERROR: Transaction route marker was not found."
        )

    text = text.replace(
        route_marker,
        send_money_route + route_marker,
        1
    )

else:

    print("Send Money route already exists.")


# ---------------------------------------------------------
# 3. Save
# ---------------------------------------------------------

APP_FILE.write_text(
    text,
    encoding="utf-8"
)

print("SUCCESS: Send Money backend added.")
print("SUCCESS: Customer-to-customer transfer logic added.")
print("SUCCESS: Balance validation added.")
print("SUCCESS: Debit and credit transaction records added.")
print("SUCCESS: Atomic rollback protection added.")