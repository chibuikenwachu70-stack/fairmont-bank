from pathlib import Path

path = Path("app.py")
text = path.read_text(encoding="utf-8")

if "class PaymentApproval(db.Model):" in text:
    print("PaymentApproval model already exists.")
    raise SystemExit(0)

marker = "\n\nclass Transaction(db.Model):"

if marker not in text:
    print("ERROR: Could not find the Transaction model.")
    print("No changes were made.")
    raise SystemExit(1)

model = r'''

class PaymentApproval(db.Model):
    __tablename__ = "payment_approvals"

    id = db.Column(db.Integer, primary_key=True)

    payment_reference = db.Column(
        db.String(40),
        unique=True,
        nullable=False,
        index=True
    )

    customer_id = db.Column(
        db.String(20),
        nullable=False,
        index=True
    )

    payment_type = db.Column(
        db.String(80),
        nullable=False
    )

    direction = db.Column(
        db.String(20),
        nullable=False
    )

    amount = db.Column(
        db.Float,
        nullable=False
    )

    description = db.Column(
        db.String(255),
        nullable=False
    )

    counterparty = db.Column(
        db.String(150),
        nullable=True
    )

    status = db.Column(
        db.String(30),
        nullable=False,
        default="Pending Approval",
        index=True
    )

    sender_name = db.Column(
        db.String(150),
        nullable=True
    )

    sender_account_number = db.Column(
        db.String(50),
        nullable=True
    )

    sender_bank = db.Column(
        db.String(150),
        nullable=True
    )

    sender_country = db.Column(
        db.String(100),
        nullable=True
    )

    recipient_customer_id = db.Column(
        db.String(20),
        nullable=True
    )

    recipient_name = db.Column(
        db.String(150),
        nullable=True
    )

    recipient_account_number = db.Column(
        db.String(50),
        nullable=True
    )

    original_transaction_reference = db.Column(
        db.String(40),
        nullable=True
    )

    created_at = db.Column(
        db.DateTime,
        nullable=False,
        default=datetime.utcnow
    )

    reviewed_at = db.Column(
        db.DateTime,
        nullable=True
    )

    reviewed_by = db.Column(
        db.String(80),
        nullable=True
    )

    rejection_reason = db.Column(
        db.String(500),
        nullable=True
    )
'''

text = text.replace(marker, model + marker, 1)

path.write_text(text, encoding="utf-8")

print("SUCCESS: PaymentApproval model added to app.py.")