from pathlib import Path
import re

BASE_DIR = Path(__file__).resolve().parent
TEMPLATES = BASE_DIR / "templates"

INTERNATIONAL_FILE = TEMPLATES / "international_transfer.html"
SEND_MONEY_FILE = TEMPLATES / "send_money.html"

if not INTERNATIONAL_FILE.exists():
    print(f"ERROR: {INTERNATIONAL_FILE} was not found.")
    raise SystemExit(1)

if not SEND_MONEY_FILE.exists():
    print(f"ERROR: {SEND_MONEY_FILE} was not found.")
    raise SystemExit(1)


# ============================================================
# BACKUPS
# ============================================================

def backup_file(path, suffix):
    backup = path.with_name(path.stem + suffix + path.suffix)
    if not backup.exists():
        backup.write_text(
            path.read_text(encoding="utf-8"),
            encoding="utf-8"
        )
    return backup


backup_file(
    INTERNATIONAL_FILE,
    "_before_dropdown_search_fix"
)

backup_file(
    SEND_MONEY_FILE,
    "_before_dropdown_search_fix"
)


# ============================================================
# COUNTRY LIST
# ============================================================

COUNTRIES = [
    "Afghanistan",
    "Albania",
    "Algeria",
    "Andorra",
    "Angola",
    "Antigua and Barbuda",
    "Argentina",
    "Armenia",
    "Australia",
    "Austria",
    "Azerbaijan",
    "Bahamas",
    "Bahrain",
    "Bangladesh",
    "Barbados",
    "Belarus",
    "Belgium",
    "Belize",
    "Benin",
    "Bhutan",
    "Bolivia",
    "Bosnia and Herzegovina",
    "Botswana",
    "Brazil",
    "Brunei",
    "Bulgaria",
    "Burkina Faso",
    "Burundi",
    "Cabo Verde",
    "Cambodia",
    "Cameroon",
    "Canada",
    "Central African Republic",
    "Chad",
    "Chile",
    "China",
    "Colombia",
    "Comoros",
    "Congo",
    "Costa Rica",
    "Côte d'Ivoire",
    "Croatia",
    "Cuba",
    "Cyprus",
    "Czech Republic",
    "Democratic Republic of the Congo",
    "Denmark",
    "Djibouti",
    "Dominica",
    "Dominican Republic",
    "Ecuador",
    "Egypt",
    "El Salvador",
    "Equatorial Guinea",
    "Eritrea",
    "Estonia",
    "Eswatini",
    "Ethiopia",
    "Fiji",
    "Finland",
    "France",
    "Gabon",
    "Gambia",
    "Georgia",
    "Germany",
    "Ghana",
    "Greece",
    "Grenada",
    "Guatemala",
    "Guinea",
    "Guinea-Bissau",
    "Guyana",
    "Haiti",
    "Honduras",
    "Hungary",
    "Iceland",
    "India",
    "Indonesia",
    "Iran",
    "Iraq",
    "Ireland",
    "Israel",
    "Italy",
    "Jamaica",
    "Japan",
    "Jordan",
    "Kazakhstan",
    "Kenya",
    "Kiribati",
    "Kuwait",
    "Kyrgyzstan",
    "Laos",
    "Latvia",
    "Lebanon",
    "Lesotho",
    "Liberia",
    "Libya",
    "Liechtenstein",
    "Lithuania",
    "Luxembourg",
    "Madagascar",
    "Malawi",
    "Malaysia",
    "Maldives",
    "Mali",
    "Malta",
    "Marshall Islands",
    "Mauritania",
    "Mauritius",
    "Mexico",
    "Micronesia",
    "Moldova",
    "Monaco",
    "Mongolia",
    "Montenegro",
    "Morocco",
    "Mozambique",
    "Myanmar",
    "Namibia",
    "Nauru",
    "Nepal",
    "Netherlands",
    "New Zealand",
    "Nicaragua",
    "Niger",
    "Nigeria",
    "North Korea",
    "North Macedonia",
    "Norway",
    "Oman",
    "Pakistan",
    "Palau",
    "Palestine",
    "Panama",
    "Papua New Guinea",
    "Paraguay",
    "Peru",
    "Philippines",
    "Poland",
    "Portugal",
    "Qatar",
    "Romania",
    "Russia",
    "Rwanda",
    "Saint Kitts and Nevis",
    "Saint Lucia",
    "Saint Vincent and the Grenadines",
    "Samoa",
    "San Marino",
    "São Tomé and Príncipe",
    "Saudi Arabia",
    "Senegal",
    "Serbia",
    "Seychelles",
    "Sierra Leone",
    "Singapore",
    "Slovakia",
    "Slovenia",
    "Solomon Islands",
    "Somalia",
    "South Africa",
    "South Korea",
    "South Sudan",
    "Spain",
    "Sri Lanka",
    "Sudan",
    "Suriname",
    "Sweden",
    "Switzerland",
    "Syria",
    "Taiwan",
    "Tajikistan",
    "Tanzania",
    "Thailand",
    "Timor-Leste",
    "Togo",
    "Tonga",
    "Trinidad and Tobago",
    "Tunisia",
    "Türkiye",
    "Turkmenistan",
    "Tuvalu",
    "Uganda",
    "Ukraine",
    "United Arab Emirates",
    "United Kingdom",
    "United States",
    "Uruguay",
    "Uzbekistan",
    "Vanuatu",
    "Vatican City",
    "Venezuela",
    "Vietnam",
    "Yemen",
    "Zambia",
    "Zimbabwe"
]


# ============================================================
# BANKS BY COUNTRY
# ============================================================

COUNTRY_BANKS = {

    "United Kingdom": [
        "Allied Irish Bank (GB)",
        "Bank of Ireland UK",
        "Bank of Scotland",
        "Barclays Bank",
        "Birmingham Bank",
        "Card One Money",
        "Cashplus Bank",
        "Chase UK",
        "Citibank UK",
        "ClearBank",
        "C. Hoare & Co.",
        "Co-operative Bank",
        "Coutts",
        "Danske Bank",
        "First Direct",
        "Halifax",
        "Handelsbanken UK",
        "HSBC UK",
        "Investec Bank",
        "Lloyds Bank",
        "Metro Bank",
        "Monzo Bank",
        "Nationwide Building Society",
        "NatWest",
        "Revolut",
        "Royal Bank of Scotland",
        "Santander UK",
        "Skipton Building Society",
        "Starling Bank",
        "TSB Bank",
        "Ulster Bank",
        "Virgin Money",
        "Yorkshire Building Society",
        "Zopa Bank",
        "Other UK Bank or Building Society"
    ],

    "Suriname": [
        "De Surinaamsche Bank",
        "Republic Bank Suriname",
        "Hakrinbank",
        "Surinaamse Volkscredietbank",
        "Finabank",
        "Surichange Bank",
        "GODO",
        "Trustbank Amanah"
    ],

    "United States": [
        "Bank of America",
        "JPMorgan Chase",
        "Wells Fargo",
        "Citibank",
        "U.S. Bank",
        "PNC Bank",
        "Truist",
        "Capital One",
        "TD Bank",
        "Charles Schwab Bank"
    ],

    "Canada": [
        "Royal Bank of Canada",
        "Toronto-Dominion Bank",
        "Bank of Montreal",
        "Bank of Nova Scotia",
        "Canadian Imperial Bank of Commerce",
        "National Bank of Canada",
        "Desjardins"
    ],

    "Australia": [
        "Commonwealth Bank",
        "Westpac",
        "ANZ",
        "National Australia Bank",
        "Macquarie Bank",
        "Bendigo Bank",
        "Bank of Queensland"
    ],

    "New Zealand": [
        "ANZ New Zealand",
        "ASB Bank",
        "Bank of New Zealand",
        "Westpac New Zealand",
        "Kiwibank"
    ],

    "Ireland": [
        "AIB",
        "Bank of Ireland",
        "Permanent TSB",
        "Revolut Bank"
    ],

    "France": [
        "BNP Paribas",
        "Crédit Agricole",
        "Société Générale",
        "BPCE",
        "La Banque Postale",
        "Crédit Mutuel"
    ],

    "Germany": [
        "Deutsche Bank",
        "Commerzbank",
        "DZ Bank",
        "KfW",
        "ING Germany",
        "N26"
    ],

    "Spain": [
        "Banco Santander",
        "BBVA",
        "CaixaBank",
        "Banco Sabadell",
        "Unicaja Banco"
    ],

    "Italy": [
        "UniCredit",
        "Intesa Sanpaolo",
        "Banco BPM",
        "BPER Banca",
        "Monte dei Paschi di Siena"
    ],

    "Netherlands": [
        "ING Bank",
        "ABN AMRO",
        "Rabobank",
        "de Volksbank"
    ],

    "Belgium": [
        "KBC Bank",
        "BNP Paribas Fortis",
        "Belfius",
        "ING Belgium"
    ],

    "Switzerland": [
        "UBS",
        "Julius Baer",
        "Zürcher Kantonalbank",
        "Banque Cantonale Vaudoise",
        "PostFinance"
    ],

    "Austria": [
        "Erste Bank",
        "Raiffeisen Bank",
        "Bank Austria",
        "BAWAG"
    ],

    "Portugal": [
        "Caixa Geral de Depósitos",
        "Millennium BCP",
        "Novo Banco",
        "Banco Santander Totta"
    ],

    "South Africa": [
        "Standard Bank",
        "First National Bank",
        "Absa Bank",
        "Nedbank",
        "Capitec Bank"
    ],

    "Kenya": [
        "KCB Bank Kenya",
        "Equity Bank Kenya",
        "Co-operative Bank of Kenya",
        "Absa Bank Kenya",
        "NCBA Bank Kenya",
        "Standard Chartered Bank Kenya",
        "Stanbic Bank Kenya",
        "I&M Bank",
        "DTB Kenya",
        "Family Bank"
    ],

    "Nigeria": [
        "Access Bank",
        "First Bank of Nigeria",
        "Guaranty Trust Bank",
        "United Bank for Africa",
        "Zenith Bank",
        "Fidelity Bank",
        "Stanbic IBTC Bank",
        "First City Monument Bank"
    ],

    "Ghana": [
        "GCB Bank",
        "Ecobank Ghana",
        "Absa Bank Ghana",
        "Stanbic Bank Ghana",
        "Fidelity Bank Ghana",
        "United Bank for Africa Ghana"
    ],

    "Uganda": [
        "Stanbic Bank Uganda",
        "Absa Bank Uganda",
        "Centenary Bank",
        "Stanbic Bank",
        "DFCU Bank",
        "Bank of Uganda"
    ],

    "Tanzania": [
        "CRDB Bank",
        "NMB Bank",
        "NBC Tanzania",
        "Stanbic Bank Tanzania",
        "Absa Bank Tanzania",
        "Exim Bank Tanzania"
    ],

    "Rwanda": [
        "Bank of Kigali",
        "I&M Bank Rwanda",
        "Equity Bank Rwanda",
        "Absa Bank Rwanda",
        "Access Bank Rwanda"
    ],

    "India": [
        "State Bank of India",
        "HDFC Bank",
        "ICICI Bank",
        "Axis Bank",
        "Kotak Mahindra Bank",
        "Punjab National Bank",
        "Bank of Baroda"
    ],

    "China": [
        "Industrial and Commercial Bank of China",
        "China Construction Bank",
        "Agricultural Bank of China",
        "Bank of China",
        "Bank of Communications"
    ],

    "Japan": [
        "MUFG Bank",
        "SMBC",
        "Mizuho Bank",
        "Resona Bank",
        "Japan Post Bank"
    ],

    "Singapore": [
        "DBS Bank",
        "OCBC Bank",
        "United Overseas Bank"
    ],

    "Malaysia": [
        "Maybank",
        "CIMB Bank",
        "Public Bank",
        "RHB Bank",
        "Hong Leong Bank"
    ],

    "Indonesia": [
        "Bank Mandiri",
        "Bank Central Asia",
        "Bank Rakyat Indonesia",
        "Bank Negara Indonesia",
        "CIMB Niaga"
    ],

    "Philippines": [
        "BDO Unibank",
        "Bank of the Philippine Islands",
        "Metrobank",
        "Philippine National Bank",
        "Security Bank"
    ],

    "United Arab Emirates": [
        "Emirates NBD",
        "First Abu Dhabi Bank",
        "Abu Dhabi Commercial Bank",
        "Mashreq Bank",
        "Dubai Islamic Bank"
    ],

    "Saudi Arabia": [
        "Saudi National Bank",
        "Al Rajhi Bank",
        "Riyad Bank",
        "Alinma Bank",
        "Banque Saudi Fransi"
    ],

    "Qatar": [
        "Qatar National Bank",
        "Qatar Islamic Bank",
        "Commercial Bank of Qatar",
        "Doha Bank"
    ],

    "Israel": [
        "Bank Leumi",
        "Bank Hapoalim",
        "Mizrahi-Tefahot Bank",
        "Israel Discount Bank"
    ],

    "Brazil": [
        "Banco do Brasil",
        "Itaú Unibanco",
        "Bradesco",
        "Caixa Econômica Federal",
        "Santander Brasil"
    ],

    "Mexico": [
        "BBVA México",
        "Santander México",
        "Banorte",
        "HSBC México",
        "Citibanamex"
    ],

    "Argentina": [
        "Banco de la Nación Argentina",
        "Banco Galicia",
        "Banco Santander Argentina",
        "BBVA Argentina",
        "Banco Macro"
    ],

    "Colombia": [
        "Bancolombia",
        "Banco de Bogotá",
        "Davivienda",
        "BBVA Colombia",
        "Banco de Occidente"
    ],

    "Chile": [
        "Banco de Chile",
        "Banco Santander Chile",
        "Banco de Crédito e Inversiones",
        "Scotiabank Chile"
    ],

    "Peru": [
        "Banco de Crédito del Perú",
        "BBVA Perú",
        "Interbank",
        "Scotiabank Perú"
    ],

    "Norway": [
        "DNB",
        "Nordea Norway",
        "SpareBank 1",
        "Danske Bank Norway"
    ],

    "Sweden": [
        "Swedbank",
        "SEB",
        "Handelsbanken",
        "Nordea Sweden"
    ],

    "Denmark": [
        "Danske Bank",
        "Nordea Denmark",
        "Jyske Bank",
        "Sydbank"
    ],

    "Finland": [
        "Nordea Finland",
        "OP Financial Group",
        "Danske Bank Finland"
    ],

    "Poland": [
        "PKO Bank Polski",
        "Bank Pekao",
        "Santander Bank Polska",
        "mBank",
        "ING Bank Śląski"
    ],

    "Czech Republic": [
        "Česká spořitelna",
        "ČSOB",
        "Komerční banka",
        "Raiffeisenbank"
    ],

    "Romania": [
        "Banca Transilvania",
        "BCR",
        "BRD",
        "Raiffeisen Bank Romania",
        "ING Bank Romania"
    ],

    "Greece": [
        "National Bank of Greece",
        "Piraeus Bank",
        "Alpha Bank",
        "Eurobank"
    ],

    "Turkey": [
        "Ziraat Bank",
        "Garanti BBVA",
        "İş Bankası",
        "Akbank",
        "Yapı Kredi"
    ],

    "Pakistan": [
        "Habib Bank",
        "United Bank Limited",
        "MCB Bank",
        "Meezan Bank",
        "Bank Alfalah"
    ],

    "Bangladesh": [
        "Dutch-Bangla Bank",
        "BRAC Bank",
        "Eastern Bank",
        "City Bank",
        "Islami Bank Bangladesh"
    ],

    "Sri Lanka": [
        "Bank of Ceylon",
        "Commercial Bank of Ceylon",
        "Hatton National Bank",
        "Sampath Bank",
        "Nations Trust Bank"
    ],

    "Thailand": [
        "Bangkok Bank",
        "Kasikornbank",
        "Siam Commercial Bank",
        "Krung Thai Bank",
        "Bank of Ayudhya"
    ],

    "Vietnam": [
        "Vietcombank",
        "VietinBank",
        "BIDV",
        "Agribank",
        "ACB"
    ],

    "Egypt": [
        "National Bank of Egypt",
        "Banque Misr",
        "Commercial International Bank",
        "QNB Alahli",
        "AlexBank"
    ],

    "Morocco": [
        "Attijariwafa Bank",
        "Banque Populaire",
        "Bank of Africa",
        "Crédit du Maroc"
    ],

    "Mauritius": [
        "Mauritius Commercial Bank",
        "Absa Bank Mauritius",
        "AfrAsia Bank",
        "MCB"
    ],

    "Zambia": [
        "Zanaco",
        "Stanbic Bank Zambia",
        "Absa Bank Zambia",
        "First National Bank Zambia",
        "Standard Chartered Zambia"
    ],

    "Zimbabwe": [
        "CBZ Bank",
        "Stanbic Bank Zimbabwe",
        "FBC Bank",
        "Nedbank Zimbabwe",
        "First Capital Bank"
    ],

    "Botswana": [
        "First National Bank Botswana",
        "Absa Bank Botswana",
        "Stanbic Bank Botswana",
        "Bank Gaborone"
    ],

    "Namibia": [
        "First National Bank Namibia",
        "Bank Windhoek",
        "Standard Bank Namibia",
        "Nedbank Namibia"
    ]
}


# Countries without a detailed bank list get a transparent generic
# option rather than inventing a named bank.
for country in COUNTRIES:
    if country not in COUNTRY_BANKS:
        COUNTRY_BANKS[country] = [
            f"Other bank or financial institution in {country}"
        ]


# ============================================================
# CURRENCIES
# ============================================================

CURRENCIES = [
    ("GBP", "GBP — Pound Sterling"),
    ("USD", "USD — US Dollar"),
    ("EUR", "EUR — Euro"),
    ("CAD", "CAD — Canadian Dollar"),
    ("AUD", "AUD — Australian Dollar"),
    ("NZD", "NZD — New Zealand Dollar"),
    ("CHF", "CHF — Swiss Franc"),
    ("JPY", "JPY — Japanese Yen"),
    ("CNY", "CNY — Chinese Yuan"),
    ("HKD", "HKD — Hong Kong Dollar"),
    ("SGD", "SGD — Singapore Dollar"),
    ("AED", "AED — UAE Dirham"),
    ("SAR", "SAR — Saudi Riyal"),
    ("QAR", "QAR — Qatari Riyal"),
    ("ZAR", "ZAR — South African Rand"),
    ("KES", "KES — Kenyan Shilling"),
    ("NGN", "NGN — Nigerian Naira"),
    ("GHS", "GHS — Ghanaian Cedi"),
    ("UGX", "UGX — Ugandan Shilling"),
    ("TZS", "TZS — Tanzanian Shilling"),
    ("RWF", "RWF — Rwandan Franc"),
    ("INR", "INR — Indian Rupee"),
    ("PKR", "PKR — Pakistani Rupee"),
    ("BDT", "BDT — Bangladeshi Taka"),
    ("LKR", "LKR — Sri Lankan Rupee"),
    ("THB", "THB — Thai Baht"),
    ("MYR", "MYR — Malaysian Ringgit"),
    ("IDR", "IDR — Indonesian Rupiah"),
    ("PHP", "PHP — Philippine Peso"),
    ("BRL", "BRL — Brazilian Real"),
    ("MXN", "MXN — Mexican Peso"),
    ("ARS", "ARS — Argentine Peso"),
    ("CLP", "CLP — Chilean Peso"),
    ("COP", "COP — Colombian Peso"),
    ("PEN", "PEN — Peruvian Sol"),
    ("PLN", "PLN — Polish Zloty"),
    ("CZK", "CZK — Czech Koruna"),
    ("RON", "RON — Romanian Leu"),
    ("TRY", "TRY — Turkish Lira"),
    ("EGP", "EGP — Egyptian Pound"),
    ("MAD", "MAD — Moroccan Dirham"),
    ("MUR", "MUR — Mauritian Rupee"),
    ("ZMW", "ZMW — Zambian Kwacha"),
    ("ZWL", "ZWL — Zimbabwe Dollar"),
    ("SRD", "SRD — Surinamese Dollar")
]


# ============================================================
# PYTHON DATA -> JAVASCRIPT
# ============================================================

import json

countries_json = json.dumps(COUNTRIES, ensure_ascii=False)
banks_json = json.dumps(COUNTRY_BANKS, ensure_ascii=False)
currencies_json = json.dumps(CURRENCIES, ensure_ascii=False)


# ============================================================
# REPLACE NATIVE SELECTS
# ============================================================

def replace_select(html, element_id, replacement):
    pattern = re.compile(
        rf"<select\b[^>]*\bid\s*=\s*[\"']{re.escape(element_id)}[\"'][^>]*>.*?</select>",
        re.IGNORECASE | re.DOTALL
    )

    new_html, count = pattern.subn(replacement, html, count=1)

    if count == 0:
        print(f"WARNING: Could not find select #{element_id}")
    else:
        print(f"Replaced #{element_id}")

    return new_html


def get_existing_attrs(html, element_id):
    pattern = re.compile(
        rf"<select\b[^>]*\bid\s*=\s*[\"']{re.escape(element_id)}[\"'][^>]*>",
        re.IGNORECASE
    )

    match = pattern.search(html)

    if not match:
        return ""

    opening = match.group(0)

    attrs = {}

    for name, quote, value in re.findall(
        r'([A-Za-z_:][A-Za-z0-9_:\-]*)\s*=\s*(["\'])(.*?)\2',
        opening,
        re.DOTALL
    ):
        attrs[name.lower()] = value

    return attrs


def build_hidden_select(element_id, name, options, selected_value=None, required=False):
    required_attr = " required" if required else ""

    html = (
        f'<select id="{element_id}" name="{name}" '
        f'class="fairmont-native-picker"{required_attr} '
        f'aria-hidden="true" tabindex="-1">'
    )

    for value, label in options:
        selected = ""

        if selected_value and value == selected_value:
            selected = " selected"

        html += (
            f'<option value="{value}"{selected}>'
            f'{label}'
            f'</option>'
        )

    html += "</select>"

    return html


# ============================================================
# INTERNATIONAL TRANSFER HTML
# ============================================================

international_html = INTERNATIONAL_FILE.read_text(encoding="utf-8")


# Remove old picker injections from previous attempts.
old_ids = [
    "FAIRMONT_CLEAN_PICKER_STYLE",
    "FAIRMONT_CLEAN_SEARCH_PICKERS",
    "FAIRMONT_CLEAN_UK_PICKER",
    "FAIRMONT_QUICK_SEARCH_STYLE",
    "FAIRMONT_QUICK_SEARCH_SCRIPT",
    "FAIRMONT_TRANSFER_PICKER_STYLE",
    "FAIRMONT_TRANSFER_PICKER_SCRIPT"
]

for old_id in old_ids:
    international_html = re.sub(
        rf'<style[^>]*id=["\']{re.escape(old_id)}["\'][^>]*>.*?</style>',
        "",
        international_html,
        flags=re.IGNORECASE | re.DOTALL
    )

    international_html = re.sub(
        rf'<script[^>]*id=["\']{re.escape(old_id)}["\'][^>]*>.*?</script>',
        "",
        international_html,
        flags=re.IGNORECASE | re.DOTALL
    )


country_options = [("", "Select country")]
country_options += [(country, country) for country in COUNTRIES]

bank_options = [("", "Select a bank")]

currency_options = [("", "Select currency")]
currency_options += CURRENCIES


international_html = replace_select(
    international_html,
    "internationalCountry",
    build_hidden_select(
        "internationalCountry",
        "country",
        country_options,
        required=True
    )
)

international_html = replace_select(
    international_html,
    "internationalBank",
    build_hidden_select(
        "internationalBank",
        "bank_name",
        bank_options,
        required=True
    )
)

international_html = replace_select(
    international_html,
    "internationalCurrency",
    build_hidden_select(
        "internationalCurrency",
        "currency",
        currency_options,
        required=True
    )
)


# ============================================================
# SEND MONEY BANK SELECT
# ============================================================

send_html = SEND_MONEY_FILE.read_text(encoding="utf-8")

for old_id in old_ids:
    send_html = re.sub(
        rf'<style[^>]*id=["\']{re.escape(old_id)}["\'][^>]*>.*?</style>',
        "",
        send_html,
        flags=re.IGNORECASE | re.DOTALL
    )

    send_html = re.sub(
        rf'<script[^>]*id=["\']{re.escape(old_id)}["\'][^>]*>.*?</script>',
        "",
        send_html,
        flags=re.IGNORECASE | re.DOTALL
    )


# ============================================================
# JAVASCRIPT + CSS
# ============================================================

picker_code = f"""
<style id="FAIRMONT_DROPDOWN_SEARCH_PICKER_STYLE">

/* ----------------------------------------------------------
   Native select stays in the form for Flask submission.
   It is visually hidden but remains accessible to the form.
   ---------------------------------------------------------- */

.fairmont-native-picker {{
    position: absolute !important;
    width: 1px !important;
    height: 1px !important;
    padding: 0 !important;
    margin: -1px !important;
    overflow: hidden !important;
    clip: rect(0, 0, 0, 0) !important;
    white-space: nowrap !important;
    border: 0 !important;
    opacity: 0 !important;
}}


/* ----------------------------------------------------------
   Visible field
   ---------------------------------------------------------- */

.fairmont-picker {{
    position: relative;
    width: 100%;
}}

.fairmont-picker-trigger {{
    width: 100%;
    min-height: 48px;
    box-sizing: border-box;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding: 13px 15px;
    border: 1px solid rgba(255,255,255,0.14);
    border-radius: 12px;
    background: rgba(255,255,255,0.045);
    color: inherit;
    font: inherit;
    text-align: left;
    cursor: pointer;
    transition: border-color .18s ease, background .18s ease;
}}

.fairmont-picker-trigger:hover {{
    background: rgba(255,255,255,0.065);
}}

.fairmont-picker-trigger:focus {{
    outline: none;
    border-color: rgba(120,170,255,0.75);
}}

.fairmont-picker-trigger.open {{
    border-color: rgba(120,170,255,0.8);
}}

.fairmont-picker-value {{
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}}

.fairmont-picker-value.placeholder {{
    opacity: .65;
}}

.fairmont-picker-arrow {{
    flex: 0 0 auto;
    font-size: 14px;
    opacity: .7;
    transition: transform .18s ease;
}}

.fairmont-picker-trigger.open .fairmont-picker-arrow {{
    transform: rotate(180deg);
}}


/* ----------------------------------------------------------
   Dropdown popup
   ---------------------------------------------------------- */

.fairmont-picker-popup {{
    position: fixed;
    z-index: 999999;
    box-sizing: border-box;
    overflow: hidden;
    border: 1px solid rgba(255,255,255,0.14);
    border-radius: 14px;
    background: #101a2c;
    box-shadow:
        0 18px 45px rgba(0,0,0,.42),
        0 5px 18px rgba(0,0,0,.25);
    backdrop-filter: blur(18px);
}}

.fairmont-picker-search-wrap {{
    padding: 10px;
    border-bottom: 1px solid rgba(255,255,255,0.10);
    background: rgba(255,255,255,0.025);
}}

.fairmont-picker-search {{
    width: 100%;
    box-sizing: border-box;
    padding: 11px 12px;
    border: 1px solid rgba(255,255,255,0.14);
    border-radius: 10px;
    outline: none;
    background: rgba(255,255,255,0.06);
    color: #fff;
    font: inherit;
}}

.fairmont-picker-search::placeholder {{
    color: rgba(255,255,255,.55);
}}

.fairmont-picker-search:focus {{
    border-color: rgba(120,170,255,.75);
}}

.fairmont-picker-options {{
    max-height: 270px;
    overflow-y: auto;
    overscroll-behavior: contain;
}}

.fairmont-picker-option {{
    width: 100%;
    box-sizing: border-box;
    display: block;
    padding: 11px 13px;
    border: 0;
    background: transparent;
    color: #fff;
    font: inherit;
    text-align: left;
    cursor: pointer;
}}

.fairmont-picker-option:hover,
.fairmont-picker-option.active {{
    background: rgba(100,150,255,.16);
}}

.fairmont-picker-option.selected {{
    background: rgba(100,150,255,.22);
}}

.fairmont-picker-empty {{
    padding: 14px;
    color: rgba(255,255,255,.58);
    text-align: center;
    font-size: 14px;
}}

@media (max-width: 600px) {{
    .fairmont-picker-popup {{
        max-width: calc(100vw - 24px);
    }}

    .fairmont-picker-options {{
        max-height: 250px;
    }}
}}

</style>

<script id="FAIRMONT_DROPDOWN_SEARCH_PICKER_SCRIPT">
(function() {{
    "use strict";

    const COUNTRIES = {countries_json};
    const COUNTRY_BANKS = {banks_json};
    const CURRENCIES = {currencies_json};

    let activePicker = null;
    let popup = null;

    function closePicker() {{
        if (!activePicker || !popup) {{
            return;
        }}

        const trigger = activePicker.trigger;

        if (trigger) {{
            trigger.classList.remove("open");
        }}

        popup.remove();
        popup = null;
        activePicker = null;
    }}

    function positionPopup() {{
        if (!activePicker || !popup) {{
            return;
        }}

        const rect = activePicker.trigger.getBoundingClientRect();

        let width = rect.width;

        if (width < 250) {{
            width = 250;
        }}

        width = Math.min(
            width,
            window.innerWidth - 24
        );

        popup.style.width = width + "px";

        const popupHeight = Math.min(
            popup.scrollHeight,
            360
        );

        let left = rect.left;

        if (left + width > window.innerWidth - 12) {{
            left = window.innerWidth - width - 12;
        }}

        if (left < 12) {{
            left = 12;
        }}

        let top = rect.bottom + 7;

        if (top + popupHeight > window.innerHeight - 12) {{
            const above = rect.top - popupHeight - 7;

            if (above >= 12) {{
                top = above;
            }}
        }}

        popup.style.left = left + "px";
        popup.style.top = top + "px";
    }}

    function openPicker(state) {{
        if (activePicker === state) {{
            closePicker();
            return;
        }}

        closePicker();

        activePicker = state;

        state.trigger.classList.add("open");

        popup = document.createElement("div");
        popup.className = "fairmont-picker-popup";

        const searchWrap = document.createElement("div");
        searchWrap.className = "fairmont-picker-search-wrap";

        const search = document.createElement("input");
        search.type = "search";
        search.className = "fairmont-picker-search";
        search.placeholder = state.searchPlaceholder;
        search.autocomplete = "off";
        search.spellcheck = false;

        searchWrap.appendChild(search);

        const optionsBox = document.createElement("div");
        optionsBox.className = "fairmont-picker-options";

        popup.appendChild(searchWrap);
        popup.appendChild(optionsBox);

        document.body.appendChild(popup);

        function renderOptions() {{
            const query = search.value.trim().toLowerCase();

            const options = state.getOptions();

            optionsBox.innerHTML = "";

            const filtered = options.filter(function(option) {{
                return option.label.toLowerCase().includes(query);
            }});

            if (!filtered.length) {{
                const empty = document.createElement("div");
                empty.className = "fairmont-picker-empty";
                empty.textContent = "No matching options found";
                optionsBox.appendChild(empty);
                positionPopup();
                return;
            }}

            filtered.forEach(function(option) {{
                const button = document.createElement("button");

                button.type = "button";
                button.className = "fairmont-picker-option";

                if (option.value === state.select.value) {{
                    button.classList.add("selected");
                }}

                button.textContent = option.label;

                button.addEventListener("mousedown", function(event) {{
                    event.preventDefault();
                }});

                button.addEventListener("click", function(event) {{
                    event.preventDefault();
                    event.stopPropagation();

                    state.select.value = option.value;

                    state.select.dispatchEvent(
                        new Event("change", {{
                            bubbles: true
                        }})
                    );

                    state.updateLabel();

                    closePicker();

                    if (state.afterSelect) {{
                        state.afterSelect(option.value);
                    }}
                }});

                optionsBox.appendChild(button);
            }});

            positionPopup();
        }}

        search.addEventListener("input", renderOptions);

        search.addEventListener("keydown", function(event) {{
            if (event.key === "Escape") {{
                event.preventDefault();
                closePicker();
            }}
        }});

        renderOptions();

        requestAnimationFrame(function() {{
            positionPopup();
            search.focus();
        }});
    }}

    function createPicker(select, options) {{
        if (!select) {{
            return null;
        }}

        if (select.dataset.fairmontPickerReady === "1") {{
            return select._fairmontPickerState || null;
        }}

        select.dataset.fairmontPickerReady = "1";

        const wrapper = document.createElement("div");
        wrapper.className = "fairmont-picker";

        select.parentNode.insertBefore(wrapper, select);

        wrapper.appendChild(select);

        const trigger = document.createElement("button");

        trigger.type = "button";
        trigger.className = "fairmont-picker-trigger";

        const value = document.createElement("span");
        value.className = "fairmont-picker-value";

        const arrow = document.createElement("span");
        arrow.className = "fairmont-picker-arrow";
        arrow.textContent = "▾";

        trigger.appendChild(value);
        trigger.appendChild(arrow);

        wrapper.appendChild(trigger);

        const state = {{
            select: select,
            wrapper: wrapper,
            trigger: trigger,
            value: value,
            getOptions: options.getOptions,
            searchPlaceholder: options.searchPlaceholder,
            afterSelect: options.afterSelect || null,

            updateLabel: function() {{
                const selected = select.options[
                    select.selectedIndex
                ];

                if (!selected || !selected.value) {{
                    value.textContent = options.placeholder;
                    value.classList.add("placeholder");
                }} else {{
                    value.textContent = selected.textContent;
                    value.classList.remove("placeholder");
                }}
            }}
        }};

        select._fairmontPickerState = state;

        trigger.addEventListener("click", function(event) {{
            event.preventDefault();
            event.stopPropagation();
            openPicker(state);
        }});

        select.addEventListener("change", function() {{
            state.updateLabel();
        }});

        state.updateLabel();

        return state;
    }}

    function populateSelect(select, items, placeholder) {{
        if (!select) {{
            return;
        }}

        const current = select.value;

        select.innerHTML = "";

        const first = document.createElement("option");
        first.value = "";
        first.textContent = placeholder;
        select.appendChild(first);

        items.forEach(function(item) {{
            const option = document.createElement("option");

            option.value = item.value;
            option.textContent = item.label;

            select.appendChild(option);
        }});

        if (
            current &&
            items.some(function(item) {{
                return item.value === current;
            }})
        ) {{
            select.value = current;
        }} else {{
            select.value = "";
        }}

        select.dispatchEvent(
            new Event("change", {{ bubbles: true }})
        );
    }}

    function getCountryOptions() {{
        return COUNTRIES.map(function(country) {{
            return {{
                value: country,
                label: country
            }};
        }});
    }}

    function getBankOptions() {{
        const countrySelect =
            document.getElementById("internationalCountry");

        if (!countrySelect || !countrySelect.value) {{
            return [];
        }}

        const banks =
            COUNTRY_BANKS[countrySelect.value] || [];

        return banks.map(function(bank) {{
            return {{
                value: bank,
                label: bank
            }};
        }});
    }}

    function getCurrencyOptions() {{
        return CURRENCIES.map(function(item) {{
            return {{
                value: item[0],
                label: item[1]
            }};
        }});
    }}

    function initializeInternational() {{
        const country =
            document.getElementById("internationalCountry");

        const bank =
            document.getElementById("internationalBank");

        const currency =
            document.getElementById("internationalCurrency");

        if (!country) {{
            return;
        }}

        const countryPicker = createPicker(
            country,
            {{
                placeholder: "Select country",
                searchPlaceholder: "Search country...",
                getOptions: getCountryOptions
            }}
        );

        if (bank) {{
            const bankPicker = createPicker(
                bank,
                {{
                    placeholder: "Select a bank",
                    searchPlaceholder: "Search bank...",
                    getOptions: getBankOptions
                }}
            );

            country.addEventListener("change", function() {{
                populateSelect(
                    bank,
                    getBankOptions(),
                    "Select a bank"
                );

                if (bankPicker) {{
                    bankPicker.updateLabel();
                }}

                closePicker();
            }});

            populateSelect(
                bank,
                getBankOptions(),
                "Select a bank"
            );

            bankPicker.updateLabel();
        }}

        if (currency) {{
            createPicker(
                currency,
                {{
                    placeholder: "Select currency",
                    searchPlaceholder: "Search currency...",
                    getOptions: getCurrencyOptions
                }}
            );
        }}

        if (countryPicker) {{
            countryPicker.updateLabel();
        }}
    }}

    function initializeSendMoney() {{
        const bank =
            document.getElementById("bankName") ||
            document.getElementById("bank_name") ||
            document.getElementById("ukBank") ||
            document.querySelector(
                'select[name="bank_name"]'
            );

        if (!bank) {{
            return;
        }}

        const options = Array.from(
            bank.options
        ).map(function(option) {{
            return {{
                value: option.value,
                label: option.textContent
            }};
        }}).filter(function(option) {{
            return option.value !== "";
        }});

        createPicker(
            bank,
            {{
                placeholder: "Select a bank",
                searchPlaceholder: "Search bank...",
                getOptions: function() {{
                    return options;
                }}
            }}
        );
    }}

    document.addEventListener("click", function(event) {{
        if (!activePicker || !popup) {{
            return;
        }}

        if (
            popup.contains(event.target) ||
            activePicker.wrapper.contains(event.target)
        ) {{
            return;
        }}

        closePicker();
    }});

    window.addEventListener("resize", function() {{
        positionPopup();
    }});

    window.addEventListener("scroll", function() {{
        positionPopup();
    }}, true);

    document.addEventListener("keydown", function(event) {{
        if (event.key === "Escape") {{
            closePicker();
        }}
    }});

    document.addEventListener(
        "DOMContentLoaded",
        function() {{
            initializeInternational();
            initializeSendMoney();
        }}
    );

}})();
</script>
"""


# ============================================================
# APPEND NEW PICKER CODE
# ============================================================

# Remove a previous copy if it somehow remains.
international_html = re.sub(
    r'<style[^>]*id=["\']FAIRMONT_DROPDOWN_SEARCH_PICKER_STYLE["\'][^>]*>.*?</style>',
    "",
    international_html,
    flags=re.IGNORECASE | re.DOTALL
)

international_html = re.sub(
    r'<script[^>]*id=["\']FAIRMONT_DROPDOWN_SEARCH_PICKER_SCRIPT["\'][^>]*>.*?</script>',
    "",
    international_html,
    flags=re.IGNORECASE | re.DOTALL
)

send_html = re.sub(
    r'<style[^>]*id=["\']FAIRMONT_DROPDOWN_SEARCH_PICKER_STYLE["\'][^>]*>.*?</style>',
    "",
    send_html,
    flags=re.IGNORECASE | re.DOTALL
)

send_html = re.sub(
    r'<script[^>]*id=["\']FAIRMONT_DROPDOWN_SEARCH_PICKER_SCRIPT["\'][^>]*>.*?</script>',
    "",
    send_html,
    flags=re.IGNORECASE | re.DOTALL
)


international_html = international_html.rstrip() + "\n\n" + picker_code + "\n"
send_html = send_html.rstrip() + "\n\n" + picker_code + "\n"


# ============================================================
# WRITE FILES
# ============================================================

INTERNATIONAL_FILE.write_text(
    international_html,
    encoding="utf-8"
)

SEND_MONEY_FILE.write_text(
    send_html,
    encoding="utf-8"
)


print()
print("=" * 60)
print("SUCCESS: DROPDOWN SEARCH PICKER INSTALLED")
print("=" * 60)
print()
print("International Transfer:")
print("  Country  -> click -> search box + full country list")
print("  Bank     -> click -> search box + country-specific banks")
print("  Currency -> click -> search box + currency list")
print()
print("Send Money:")
print("  Bank     -> click -> search box + bank list")
print()
print("Database was NOT changed.")
print("app.py was NOT changed.")
print("Dashboard was NOT changed.")
print()
print("Backups created:")
print("  international_transfer_before_dropdown_search_fix.html")
print("  send_money_before_dropdown_search_fix.html")
print()
print("Now restart Flask and press Ctrl+F5 in your browser.")
print("=" * 60)