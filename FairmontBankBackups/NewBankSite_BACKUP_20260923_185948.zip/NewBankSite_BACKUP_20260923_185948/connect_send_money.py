from pathlib import Path

BASE_DIR = Path(r"C:\Users\DON J\Documents\NewBankSite")
DASHBOARD_FILE = BASE_DIR / "templates" / "dashboard.html"

text = DASHBOARD_FILE.read_text(encoding="utf-8")


old = '''<a
                        href="#"
                        class="service-item">

                        <span class="service-icon">
                            ↗
                        </span>

                        <span class="service-name">
                            Send<br>
                            Money
                        </span>

                    </a>'''


new = '''<a
                        href="/send-money"
                        class="service-item">

                        <span class="service-icon">
                            ↗
                        </span>

                        <span class="service-name">
                            Send<br>
                            Money
                        </span>

                    </a>'''


if old in text:

    text = text.replace(
        old,
        new,
        1
    )

    DASHBOARD_FILE.write_text(
        text,
        encoding="utf-8"
    )

    print("SUCCESS: Send Money button connected to /send-money.")

elif 'href="/send-money"' in text:

    print("Send Money button is already connected.")

else:

    print("WARNING: Send Money button was not found in the expected format.")