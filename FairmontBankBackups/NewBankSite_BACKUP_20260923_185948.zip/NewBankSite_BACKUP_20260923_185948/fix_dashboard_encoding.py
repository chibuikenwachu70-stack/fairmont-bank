from pathlib import Path

file = Path("templates/dashboard.html")

if not file.exists():
    raise SystemExit("ERROR: templates/dashboard.html was not found.")

text = file.read_text(encoding="utf-8")

# Repair text that was originally UTF-8 but became
# incorrectly decoded as Windows-1252.
try:
    repaired = text.encode("cp1252").decode("utf-8")
except UnicodeEncodeError:
    raise SystemExit(
        "ERROR: The dashboard contains characters that cannot be safely "
        "processed with this encoding repair."
    )
except UnicodeDecodeError:
    raise SystemExit(
        "ERROR: The dashboard does not appear to be consistently "
        "UTF-8/Windows-1252 corrupted. No changes were made."
    )

if repaired == text:
    print("NOTICE: No encoding corruption was detected.")
else:
    file.write_text(repaired, encoding="utf-8")
    print("SUCCESS: Dashboard character encoding repaired.")
    print()
    print("Examples that should now display correctly:")
    print("£  ↑  ≡  □  ✈  ☎  ⚡  ↔")