from pathlib import Path
import shutil
from datetime import datetime

BASE = Path(r"C:\Users\DON J\Documents\NewBankSite")
SETTINGS = BASE / "templates" / "settings.html"

# ---------------------------------------------------------
# BACKUP
# ---------------------------------------------------------

backup_dir = BASE / "login_otp_backup"
backup_dir.mkdir(exist_ok=True)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

shutil.copy2(
    SETTINGS,
    backup_dir / f"settings_before_display_fix_{timestamp}.bak"
)

# ---------------------------------------------------------
# READ FILE
# ---------------------------------------------------------

text = SETTINGS.read_text(encoding="utf-8")

# ---------------------------------------------------------
# FIND LOGIN OTP CARD
# ---------------------------------------------------------

marker = "Login OTP"

position = text.find(marker)

if position == -1:
    raise RuntimeError(
        "Login OTP text was not found in settings.html."
    )

# Find the opening <a> belonging to this card.
opening = text.rfind(
    '<a ',
    0,
    position
)

if opening == -1:
    raise RuntimeError(
        "Could not find the Login OTP card opening tag."
    )

# Find the next closing </a>.
closing = text.find(
    "</a>",
    position
)

if closing == -1:
    raise RuntimeError(
        "Could not find the Login OTP card closing tag."
    )

closing += len("</a>")

old_card = text[opening:closing]

# ---------------------------------------------------------
# REBUILD ONLY LOGIN OTP CARD
# ---------------------------------------------------------

new_card = '''<a
        href="{{ url_for('login_otp_settings') }}"
        class="settings-card"
        style="text-decoration:none; color:inherit;">

        <div class="settings-icon">
            🔐
        </div>

        <div class="settings-content">

            <p class="settings-name">
                Login OTP
            </p>

            <p class="settings-description">
                Turn login one-time password verification on or off.
            </p>

        </div>

        <div class="settings-arrow">
            ›
        </div>

    </a>'''

# ---------------------------------------------------------
# REPLACE ONLY THIS CARD
# ---------------------------------------------------------

text = (
    text[:opening]
    + new_card
    + text[closing:]
)

SETTINGS.write_text(
    text,
    encoding="utf-8"
)

print()
print("==============================================")
print("LOGIN OTP CARD DISPLAY FIXED")
print("==============================================")
print()
print("Restored:")
print("  🔐 Login OTP")
print("  Turn login one-time password verification on or off.")
print("  ›")
print()
print("The card still links to:")
print("  /settings/login-otp")
print()
print("No other Settings cards were changed.")
print()
print("Backup created:")
print(backup_dir)
print()