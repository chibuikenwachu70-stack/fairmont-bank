from pathlib import Path
import re

BASE_DIR = Path(__file__).resolve().parent
FILE = BASE_DIR / "templates" / "admin_dashboard.html"

text = FILE.read_text(encoding="utf-8")

pattern = r'(<a\s+href=")#("\s+class="action">\s*<div\s+class="action-title">\s*Account Management\s*</div>)'

match = re.search(
    pattern,
    text,
    flags=re.IGNORECASE | re.DOTALL
)

if not match:
    print("ERROR: Account Management link could not be located.")
    print("No changes were made.")
    raise SystemExit(1)

new_text = re.sub(
    pattern,
    r'\1{{ url_for("admin_accounts") }}\2',
    text,
    count=1,
    flags=re.IGNORECASE | re.DOTALL
)

FILE.write_text(new_text, encoding="utf-8")

print("Account Management link connected successfully.")