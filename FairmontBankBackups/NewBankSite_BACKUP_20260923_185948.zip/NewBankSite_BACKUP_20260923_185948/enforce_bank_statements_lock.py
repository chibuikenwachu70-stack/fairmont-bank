from pathlib import Path

path = Path("app.py")
app = path.read_text(encoding="utf-8")

old = '''@app.route("/bank-statements")
@login_required
def bank_statements():
    customer = current_user

    transactions = (
        Transaction.query
        .filter_by(customer_id=customer.id)
        .order_by(Transaction.created_at.desc())
        .all()
    )

    return render_template(
        "bank_statements.html",
        customer=customer,
        transactions=transactions,
        statement_date=datetime.now()
    )
'''

new = '''@app.route("/bank-statements")
@login_required
def bank_statements():
    customer = current_user

    if customer.bank_statements_locked:
        return render_template(
            "bank_statements_locked.html",
            customer=customer
        )

    transactions = (
        Transaction.query
        .filter_by(customer_id=customer.id)
        .order_by(Transaction.created_at.desc())
        .all()
    )

    return render_template(
        "bank_statements.html",
        customer=customer,
        transactions=transactions,
        statement_date=datetime.now()
    )
'''

if old not in app:
    print("ERROR: Existing bank_statements route was not found exactly.")
    print("No changes were made.")
    raise SystemExit(1)

app = app.replace(old, new, 1)

path.write_text(app, encoding="utf-8")

print("SUCCESS: Bank Statements lock is now enforced.")
print("Unlocked accounts will continue using the existing statement page.")
print("Locked accounts will see the locked-access page.")