from pathlib import Path
import shutil

FILE = Path("templates/live_chat.html")

text = FILE.read_text(encoding="utf-8")

if "success_message" in text and "message-success" in text:
    print("=" * 70)
    print("LIVE CHAT SUCCESS MESSAGE ALREADY EXISTS")
    print("=" * 70)
    raise SystemExit(0)

backup = Path("templates/live_chat.html.before_success_ui")
shutil.copy2(FILE, backup)

marker = '''        <form
            method="POST"
            action="{{ url_for('live_chat') }}"
            class="chat-form"
        >'''

if marker not in text:
    print("=" * 70)
    print("ERROR: Live Chat form was not found.")
    print("=" * 70)
    print()
    print("Backup created:")
    print(backup)
    raise SystemExit(1)

success_html = '''        {% if success_message %}
            <div class="message-success">
                <span class="success-icon">✓</span>
                <span>{{ success_message }}</span>
            </div>
        {% endif %}

'''

text = text.replace(marker, success_html + marker, 1)

# Add the success-message styling before the existing chat-form CSS.
css_marker = '''        .chat-form {'''

success_css = '''        .message-success {
            width: 100%;
            margin: 0 0 12px 0;
            padding: 12px 14px;
            display: flex;
            align-items: center;
            gap: 9px;
            border: 1px solid rgba(74, 180, 125, 0.28);
            border-radius: 10px;
            background: rgba(74, 180, 125, 0.08);
            color: #b9e7ce;
            font-size: 12px;
            line-height: 1.45;
        }

        .success-icon {
            width: 20px;
            height: 20px;
            flex: 0 0 20px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            background: rgba(74, 180, 125, 0.18);
            color: #8ed2aa;
            font-size: 12px;
            font-weight: 700;
        }

'''

if css_marker not in text:
    print("=" * 70)
    print("ERROR: Chat form CSS section was not found.")
    print("=" * 70)
    print()
    print("Backup created:")
    print(backup)
    raise SystemExit(1)

text = text.replace(css_marker, success_css + css_marker, 1)

FILE.write_text(text, encoding="utf-8")

print("=" * 70)
print("LIVE CHAT SUCCESS UI ADDED")
print("=" * 70)
print()
print("The customer will now see:")
print()
print("✓ Message sent successfully.")
print("  Your message has been delivered to Fairmont Bank Support.")
print()
print("Backup created:")
print(backup)