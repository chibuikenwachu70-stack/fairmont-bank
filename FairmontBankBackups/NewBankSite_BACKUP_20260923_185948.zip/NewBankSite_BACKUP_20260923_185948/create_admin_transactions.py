from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
APP_FILE = BASE_DIR / "app.py"
TEMPLATE_FILE = BASE_DIR / "templates" / "admin_transactions.html"


# ------------------------------------------------------------
# 1. Add the admin transactions route to app.py
# ------------------------------------------------------------

app_text = APP_FILE.read_text(encoding="utf-8")

if '@app.route("/admin/transactions")' in app_text:
    print("Admin transactions route already exists.")
else:
    route_code = r'''

@app.route("/admin/transactions")
def admin_transactions():
    admin_id = session.get("admin_id")

    if not admin_id:
        return redirect(url_for("admin_login"))

    admin = db.session.get(AdminUser, admin_id)

    if not admin or not admin.is_active:
        session.pop("admin_id", None)
        return redirect(url_for("admin_login"))

    search = request.args.get("search", "").strip()
    direction = request.args.get("direction", "").strip()
    status = request.args.get("status", "").strip()

    query = Transaction.query

    if search:
        search_value = f"%{search}%"

        customer_ids = [
            customer.customer_id
            for customer in Customer.query.filter(
                db.or_(
                    Customer.customer_id.ilike(search_value),
                    Customer.full_name.ilike(search_value),
                    Customer.email.ilike(search_value),
                    Customer.account_number.ilike(search_value),
                )
            ).all()
        ]

        search_conditions = [
            Transaction.transaction_reference.ilike(search_value),
            Transaction.customer_id.ilike(search_value),
            Transaction.description.ilike(search_value),
            Transaction.counterparty.ilike(search_value),
        ]

        if customer_ids:
            search_conditions.append(
                Transaction.customer_id.in_(customer_ids)
            )

        query = query.filter(db.or_(*search_conditions))

    if direction in ("Debit", "Credit"):
        query = query.filter(Transaction.direction == direction)

    if status:
        query = query.filter(Transaction.status == status)

    transactions = query.order_by(
        Transaction.id.desc()
    ).all()

    customer_map = {}

    customer_ids = {
        transaction.customer_id
        for transaction in transactions
        if transaction.customer_id
    }

    if customer_ids:
        customers = Customer.query.filter(
            Customer.customer_id.in_(customer_ids)
        ).all()

        customer_map = {
            customer.customer_id: customer
            for customer in customers
        }

    return render_template(
        "admin_transactions.html",
        admin=admin,
        transactions=transactions,
        customer_map=customer_map,
        search=search,
        direction=direction,
        status=status,
    )
'''

    marker = 'if __name__ == "__main__":'

    if marker in app_text:
        app_text = app_text.replace(
            marker,
            route_code + "\n\n" + marker,
            1
        )
    else:
        app_text = app_text.rstrip() + "\n\n" + route_code + "\n"

    APP_FILE.write_text(app_text, encoding="utf-8")

    print("Admin transactions route added successfully.")


# ------------------------------------------------------------
# 2. Create the admin transactions template
# ------------------------------------------------------------

template = r'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Transaction Management | Fairmont Bank</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background:
                radial-gradient(circle at top right, rgba(184, 149, 74, 0.08), transparent 30%),
                #07111f;
            color: #eef3f8;
        }

        .page {
            max-width: 1500px;
            margin: 0 auto;
            padding: 30px;
        }

        .topbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            margin-bottom: 28px;
        }

        .brand {
            display: flex;
            align-items: center;
        }

        .brand img {
            width: 190px;
            max-width: 100%;
            height: auto;
            display: block;
        }

        .top-actions {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .top-actions a {
            text-decoration: none;
            color: #d8b96a;
            border: 1px solid rgba(184, 149, 74, 0.35);
            padding: 10px 15px;
            border-radius: 9px;
            font-size: 13px;
            font-weight: 700;
        }

        .top-actions a:hover {
            background: rgba(184, 149, 74, 0.10);
        }

        .heading {
            margin-bottom: 22px;
        }

        .heading h1 {
            margin: 0 0 8px;
            font-size: 30px;
            letter-spacing: -0.4px;
        }

        .heading p {
            margin: 0;
            color: #91a3b7;
            font-size: 14px;
        }

        .panel {
            background: rgba(13, 28, 46, 0.88);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 16px;
            padding: 20px;
            box-shadow: 0 18px 45px rgba(0, 0, 0, 0.22);
            margin-bottom: 22px;
        }

        .filters {
            display: grid;
            grid-template-columns: minmax(220px, 1fr) 170px 170px auto;
            gap: 12px;
            align-items: end;
        }

        .field label {
            display: block;
            margin-bottom: 7px;
            color: #9fb0c3;
            font-size: 12px;
            font-weight: 700;
        }

        .field input,
        .field select {
            width: 100%;
            border: 1px solid rgba(255, 255, 255, 0.10);
            background: #091827;
            color: #eef3f8;
            border-radius: 9px;
            padding: 11px 12px;
            outline: none;
        }

        .field input:focus,
        .field select:focus {
            border-color: rgba(216, 185, 106, 0.65);
        }

        .filter-buttons {
            display: flex;
            gap: 8px;
        }

        .btn {
            border: 0;
            border-radius: 9px;
            padding: 11px 16px;
            cursor: pointer;
            font-weight: 700;
            text-decoration: none;
            font-size: 13px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .btn-primary {
            background: #b8954a;
            color: #07111f;
        }

        .btn-secondary {
            background: rgba(255, 255, 255, 0.07);
            color: #d7e0e9;
            border: 1px solid rgba(255, 255, 255, 0.09);
        }

        .summary {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
            margin-bottom: 15px;
        }

        .summary-title {
            font-size: 15px;
            font-weight: 700;
        }

        .summary-count {
            color: #9fb0c3;
            font-size: 13px;
        }

        .table-wrap {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1050px;
        }

        th {
            text-align: left;
            padding: 13px 12px;
            color: #8fa2b7;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            white-space: nowrap;
        }

        td {
            padding: 15px 12px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.055);
            font-size: 13px;
            vertical-align: middle;
        }

        tr:hover td {
            background: rgba(255, 255, 255, 0.018);
        }

        .reference {
            color: #d8b96a;
            font-weight: 700;
            white-space: nowrap;
        }

        .customer-name {
            font-weight: 700;
            margin-bottom: 3px;
        }

        .customer-id {
            color: #8295aa;
            font-size: 11px;
        }

        .amount {
            font-weight: 700;
            white-space: nowrap;
        }

        .debit {
            color: #e3a4a4;
        }

        .credit {
            color: #9ed0ae;
        }

        .badge {
            display: inline-flex;
            align-items: center;
            padding: 5px 9px;
            border-radius: 999px;
            font-size: 10px;
            font-weight: 800;
            letter-spacing: 0.3px;
            white-space: nowrap;
        }

        .badge-debit {
            color: #e3a4a4;
            background: rgba(190, 80, 80, 0.10);
            border: 1px solid rgba(190, 80, 80, 0.20);
        }

        .badge-credit {
            color: #9ed0ae;
            background: rgba(80, 170, 105, 0.10);
            border: 1px solid rgba(80, 170, 105, 0.20);
        }

        .badge-status {
            color: #d8b96a;
            background: rgba(184, 149, 74, 0.10);
            border: 1px solid rgba(184, 149, 74, 0.20);
        }

        .empty {
            text-align: center;
            padding: 55px 20px;
            color: #8ea0b4;
        }

        .empty-title {
            color: #dce5ed;
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 7px;
        }

        .footer-note {
            margin-top: 18px;
            color: #71859a;
            font-size: 11px;
        }

        @media (max-width: 900px) {
            .filters {
                grid-template-columns: 1fr;
            }

            .topbar {
                align-items: flex-start;
                flex-direction: column;
            }

            .top-actions {
                width: 100%;
            }
        }

        @media (max-width: 600px) {
            .page {
                padding: 18px;
            }

            .panel {
                padding: 14px;
            }

            .heading h1 {
                font-size: 24px;
            }
        }
    </style>
</head>

<body>

<div class="page">

    <div class="topbar">

        <div class="brand">
            <img
                src="{{ url_for('static', filename='images/fairmont-bank-logo.png') }}"
                alt="Fairmont Bank">
        </div>

        <div class="top-actions">
            <a href="{{ url_for('admin_dashboard') }}">Back to Dashboard</a>
            <a href="{{ url_for('admin_logout') }}">Sign Out</a>
        </div>

    </div>

    <div class="heading">
        <h1>Transaction Management</h1>
        <p>Review banking transaction activity across Fairmont Bank customer accounts.</p>
    </div>

    <div class="panel">

        <form method="GET" action="{{ url_for('admin_transactions') }}">

            <div class="filters">

                <div class="field">
                    <label for="search">Search Transactions</label>
                    <input
                        type="text"
                        id="search"
                        name="search"
                        value="{{ search }}"
                        placeholder="Reference, customer, ID, description or counterparty">
                </div>

                <div class="field">
                    <label for="direction">Direction</label>
                    <select id="direction" name="direction">
                        <option value="">All Transactions</option>
                        <option value="Debit" {% if direction == "Debit" %}selected{% endif %}>Debit</option>
                        <option value="Credit" {% if direction == "Credit" %}selected{% endif %}>Credit</option>
                    </select>
                </div>

                <div class="field">
                    <label for="status">Status</label>
                    <select id="status" name="status">
                        <option value="">All Statuses</option>
                        <option value="Completed" {% if status == "Completed" %}selected{% endif %}>Completed</option>
                        <option value="Pending" {% if status == "Pending" %}selected{% endif %}>Pending</option>
                        <option value="Failed" {% if status == "Failed" %}selected{% endif %}>Failed</option>
                        <option value="Cancelled" {% if status == "Cancelled" %}selected{% endif %}>Cancelled</option>
                    </select>
                </div>

                <div class="filter-buttons">
                    <button type="submit" class="btn btn-primary">Search</button>
                    <a href="{{ url_for('admin_transactions') }}" class="btn btn-secondary">Reset</a>
                </div>

            </div>

        </form>

    </div>

    <div class="panel">

        <div class="summary">
            <div class="summary-title">Transaction Activity</div>
            <div class="summary-count">
                {{ transactions|length }} transaction{% if transactions|length != 1 %}s{% endif %}
            </div>
        </div>

        <div class="table-wrap">

            {% if transactions %}

            <table>

                <thead>
                    <tr>
                        <th>Reference</th>
                        <th>Customer</th>
                        <th>Type</th>
                        <th>Direction</th>
                        <th>Amount</th>
                        <th>Balance After</th>
                        <th>Counterparty</th>
                        <th>Status</th>
                        <th>Date</th>
                    </tr>
                </thead>

                <tbody>

                    {% for transaction in transactions %}

                    {% set customer = customer_map.get(transaction.customer_id) %}

                    <tr>

                        <td>
                            <div class="reference">
                                {{ transaction.transaction_reference }}
                            </div>
                        </td>

                        <td>
                            <div class="customer-name">
                                {% if customer %}
                                    {{ customer.full_name }}
                                {% else %}
                                    Customer
                                {% endif %}
                            </div>

                            <div class="customer-id">
                                {{ transaction.customer_id }}
                            </div>
                        </td>

                        <td>
                            {{ transaction.transaction_type }}
                        </td>

                        <td>
                            {% if transaction.direction == "Debit" %}
                                <span class="badge badge-debit">DEBIT</span>
                            {% else %}
                                <span class="badge badge-credit">CREDIT</span>
                            {% endif %}
                        </td>

                        <td>
                            <span class="amount {% if transaction.direction == 'Debit' %}debit{% else %}credit{% endif %}">
                                {% if transaction.direction == "Debit" %}-{% else %}+{% endif %}
                                £{{ "%.2f"|format(transaction.amount or 0) }}
                            </span>
                        </td>

                        <td>
                            £{{ "%.2f"|format(transaction.balance_after or 0) }}
                        </td>

                        <td>
                            {{ transaction.counterparty or "—" }}
                        </td>

                        <td>
                            <span class="badge badge-status">
                                {{ transaction.status }}
                            </span>
                        </td>

                        <td>
                            {% if transaction.created_at %}
                                {{ transaction.created_at.strftime("%d %b %Y, %H:%M") }}
                            {% else %}
                                —
                            {% endif %}
                        </td>

                    </tr>

                    {% endfor %}

                </tbody>

            </table>

            {% else %}

            <div class="empty">
                <div class="empty-title">No transactions found</div>
                <div>
                    No transaction records match the current search or filters.
                </div>
            </div>

            {% endif %}

        </div>

        <div class="footer-note">
            Transaction records are displayed from the existing Fairmont Bank database.
        </div>

    </div>

</div>

</body>
</html>
'''

TEMPLATE_FILE.write_text(template, encoding="utf-8")

print("Admin transaction template created successfully.")


print()
print("=" * 70)
print("TRANSACTION MANAGEMENT SETUP COMPLETE")
print("=" * 70)
print()
print("Created:")
print("  /admin/transactions")
print("  templates/admin_transactions.html")
print()
print("Existing transaction records were NOT changed.")
print()