from pathlib import Path
import shutil
import re

BASE = Path(r"C:\Users\DON J\Documents\NewBankSite")
TEMPLATES = BASE / "templates"

FILES = [
    "account_created.html",
    "index.html",
    "open_account.html",
    "pay_bills.html",
    "login.html",
]

LOGO_REFERENCE = "fairmont-bank-logo.png"


def remove_duplicate_f_mark(text):
    """
    Remove an old standalone F brand mark when it appears
    immediately before the professional Fairmont logo.
    """

    pattern = re.compile(
        r"""
        <div\s+class=["']brand-mark["'][^>]*>
            \s*F\s*
        </div>
        \s*
        (?=<div\s+class=["']fairmont-page-brand["'])
        """,
        re.IGNORECASE | re.VERBOSE
    )

    return pattern.sub("", text)


def add_professional_page_logo_css(text):
    """
    Ensure pages using fairmont-page-brand have consistent
    professional sizing.
    """

    style_id = "fairmont-professional-page-logo"

    # Remove a previous version if this script is run again.
    text = re.sub(
        rf'<style\s+id=["\']{style_id}["\']>.*?</style>',
        "",
        text,
        flags=re.IGNORECASE | re.DOTALL
    )

    css = """
<style id="fairmont-professional-page-logo">
.fairmont-page-brand {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    margin: 0 auto 24px auto;
}

.fairmont-page-logo {
    display: block;
    width: 250px;
    max-width: 82%;
    height: auto;
    object-fit: contain;
}

@media (max-width: 600px) {
    .fairmont-page-logo {
        width: 220px;
        max-width: 84%;
    }
}
</style>
"""

    head = re.search(r"</head>", text, re.IGNORECASE)

    if head:
        text = (
            text[:head.start()]
            + css
            + "\n"
            + text[head.start():]
        )

    return text


changed = []

for filename in FILES:

    file = TEMPLATES / filename

    if not file.exists():
        print(f"SKIPPED: {filename} does not exist.")
        continue

    text = file.read_text(encoding="utf-8")
    original = text

    # Remove old duplicate F mark only when it directly precedes
    # the Fairmont page logo.
    text = remove_duplicate_f_mark(text)

    # Standardize page-logo presentation.
    if "fairmont-page-brand" in text:
        text = add_professional_page_logo_css(text)

    if text != original:

        backup = file.with_suffix(
            file.suffix + ".before_professional_branding"
        )

        shutil.copy2(file, backup)

        file.write_text(text, encoding="utf-8")

        changed.append(filename)


print()
print("=" * 70)
print("FAIRMONT BANK PROFESSIONAL BRANDING CLEANUP")
print("=" * 70)
print()

print("Logo asset:")
print(BASE / "static" / "images" / LOGO_REFERENCE)
print()

if changed:
    print("UPDATED:")
    for filename in changed:
        print(f"  - {filename}")
else:
    print("No additional branding changes were necessary.")

print()
print("The following were NOT changed:")
print("  - Database")
print("  - Customer accounts")
print("  - Transfers")
print("  - Payments")
print("  - Settings")
print("  - Dashboard functionality")
print("  - Routes")
print()

print("Professional branding cleanup complete.")
print("=" * 70)