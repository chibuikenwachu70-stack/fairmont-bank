from pathlib import Path
from datetime import datetime
import re
import html
import json

BASE = Path(__file__).resolve().parent
TEMPLATE = BASE / "templates" / "international_transfer.html"

if not TEMPLATE.exists():
    print("ERROR: Could not find:")
    print(TEMPLATE)
    raise SystemExit(1)

source = TEMPLATE.read_text(encoding="utf-8")

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = TEMPLATE.with_name(
    f"international_transfer_BEFORE_CLEAN_{timestamp}.html"
)

backup.write_text(source, encoding="utf-8")

print(f"Backup created: {backup.name}")


# ------------------------------------------------------------
# 1. Read the existing country options BEFORE removing old code
# ------------------------------------------------------------

country_match = re.search(
    r'<select\b[^>]*id=["\']internationalCountry["\'][^>]*>'
    r'(.*?)'
    r'</select>',
    source,
    re.IGNORECASE | re.DOTALL
)

if not country_match:
    print("ERROR: Existing country select was not found.")
    print("No changes were made to the template.")
    raise SystemExit(1)

country_html = country_match.group(1)

country_options = []

for match in re.finditer(
    r'<option\b([^>]*)>(.*?)</option>',
    country_html,
    re.IGNORECASE | re.DOTALL
):
    attrs = match.group(1)
    label = re.sub(r"<[^>]+>", "", match.group(2))
    label = html.unescape(label).strip()

    value_match = re.search(
        r'\bvalue=["\']([^"\']*)["\']',
        attrs,
        re.IGNORECASE
    )

    value = value_match.group(1).strip() if value_match else label

    if label and value:
        country_options.append({
            "value": value,
            "label": label
        })


# Fallback in case the old file has a damaged country select.
if len(country_options) < 50:
    countries = [
        "Afghanistan", "Albania", "Algeria", "Andorra", "Angola",
        "Antigua and Barbuda", "Argentina", "Armenia", "Australia",
        "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh",
        "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bhutan",
        "Bolivia", "Bosnia and Herzegovina", "Botswana", "Brazil",
        "Brunei", "Bulgaria", "Burkina Faso", "Burundi", "Cabo Verde",
        "Cambodia", "Cameroon", "Canada", "Central African Republic",
        "Chad", "Chile", "China", "Colombia", "Comoros", "Congo",
        "Costa Rica", "Croatia", "Cuba", "Cyprus", "Czech Republic",
        "Denmark", "Djibouti", "Dominica", "Dominican Republic",
        "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea",
        "Eritrea", "Estonia", "Eswatini", "Ethiopia", "Fiji",
        "Finland", "France", "Gabon", "Gambia", "Georgia", "Germany",
        "Ghana", "Greece", "Grenada", "Guatemala", "Guinea",
        "Guinea-Bissau", "Guyana", "Haiti", "Honduras", "Hungary",
        "Iceland", "India", "Indonesia", "Iran", "Iraq", "Ireland",
        "Israel", "Italy", "Jamaica", "Japan", "Jordan", "Kazakhstan",
        "Kenya", "Kiribati", "Kuwait", "Kyrgyzstan", "Laos", "Latvia",
        "Lebanon", "Lesotho", "Liberia", "Libya", "Liechtenstein",
        "Lithuania", "Luxembourg", "Madagascar", "Malawi", "Malaysia",
        "Maldives", "Mali", "Malta", "Marshall Islands", "Mauritania",
        "Mauritius", "Mexico", "Micronesia", "Moldova", "Monaco",
        "Mongolia", "Montenegro", "Morocco", "Mozambique", "Myanmar",
        "Namibia", "Nauru", "Nepal", "Netherlands", "New Zealand",
        "Nicaragua", "Niger", "Nigeria", "North Korea", "North Macedonia",
        "Norway", "Oman", "Pakistan", "Palau", "Palestine", "Panama",
        "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Poland",
        "Portugal", "Qatar", "Romania", "Russia", "Rwanda",
        "Saint Kitts and Nevis", "Saint Lucia",
        "Saint Vincent and the Grenadines", "Samoa", "San Marino",
        "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Serbia",
        "Seychelles", "Sierra Leone", "Singapore", "Slovakia",
        "Slovenia", "Solomon Islands", "Somalia", "South Africa",
        "South Korea", "South Sudan", "Spain", "Sri Lanka", "Sudan",
        "Suriname", "Sweden", "Switzerland", "Syria", "Taiwan",
        "Tajikistan", "Tanzania", "Thailand", "Timor-Leste", "Togo",
        "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey",
        "Turkmenistan", "Tuvalu", "Uganda", "Ukraine",
        "United Arab Emirates", "United Kingdom", "United States",
        "Uruguay", "Uzbekistan", "Vanuatu", "Vatican City",
        "Venezuela", "Vietnam", "Yemen", "Zambia", "Zimbabwe"
    ]

    country_options = [
        {"value": c, "label": c}
        for c in countries
    ]


# ------------------------------------------------------------
# 2. Extract existing bank mapping before deleting old scripts
# ------------------------------------------------------------

bank_mapping = {}

bank_match = re.search(
    r'const\s+countryBanks\s*=\s*(\{.*?\})\s*;\s*'
    r'(?:function\s+updateBanks|function\s+getBankOptions)',
    source,
    re.IGNORECASE | re.DOTALL
)

if bank_match:
    raw_mapping = bank_match.group(1)

    # Convert the known JavaScript object into JSON-compatible text.
    # The existing bank names are simple quoted strings.
    raw_mapping = re.sub(
        r"([,{]\s*)'([^']+)'\s*:",
        r'\1"\2":',
        raw_mapping
    )

    raw_mapping = re.sub(
        r"([,{]\s*)'([^']+)'(\s*[,}])",
        r'\1"\2"\3',
        raw_mapping
    )

    try:
        bank_mapping = json.loads(raw_mapping)
    except Exception:
        bank_mapping = {}


# Reliable core bank lists.
core_banks = {
    "United Kingdom": [
        "Barclays Bank",
        "HSBC UK",
        "Lloyds Bank",
        "NatWest",
        "Royal Bank of Scotland",
        "Santander UK",
        "Halifax",
        "Nationwide Building Society",
        "TSB Bank",
        "Metro Bank",
        "Monzo Bank",
        "Starling Bank",
        "Virgin Money",
        "First Direct",
        "Bank of Scotland",
        "Other UK Bank"
    ],
    "United States": [
        "JPMorgan Chase Bank",
        "Bank of America",
        "Wells Fargo Bank",
        "Citibank",
        "U.S. Bank",
        "PNC Bank",
        "Truist Bank",
        "Capital One",
        "TD Bank",
        "Charles Schwab Bank",
        "Other US Bank"
    ],
    "Canada": [
        "Royal Bank of Canada",
        "Toronto-Dominion Bank",
        "Bank of Montreal",
        "Bank of Nova Scotia",
        "Canadian Imperial Bank of Commerce",
        "National Bank of Canada",
        "Desjardins",
        "Other Canadian Bank"
    ],
    "Kenya": [
        "KCB Bank Kenya",
        "Equity Bank Kenya",
        "Co-operative Bank of Kenya",
        "Absa Bank Kenya",
        "NCBA Bank Kenya",
        "Stanbic Bank Kenya",
        "I&M Bank",
        "DTB Kenya",
        "Standard Chartered Kenya",
        "Family Bank",
        "Other Kenyan Bank"
    ],
    "Nigeria": [
        "Access Bank",
        "First Bank of Nigeria",
        "United Bank for Africa",
        "Guaranty Trust Bank",
        "Zenith Bank",
        "Fidelity Bank",
        "Ecobank Nigeria",
        "Stanbic IBTC Bank",
        "Union Bank of Nigeria",
        "Other Nigerian Bank"
    ],
    "Ghana": [
        "GCB Bank",
        "Ecobank Ghana",
        "Absa Bank Ghana",
        "Stanbic Bank Ghana",
        "Standard Chartered Ghana",
        "Fidelity Bank Ghana",
        "CalBank",
        "Republic Bank Ghana",
        "Other Ghanaian Bank"
    ],
    "South Africa": [
        "Standard Bank",
        "First National Bank",
        "Absa Bank",
        "Nedbank",
        "Capitec Bank",
        "Investec Bank",
        "African Bank",
        "Other South African Bank"
    ],
    "Suriname": [
        "De Surinaamsche Bank N.V.",
        "Republic Bank (Suriname) N.V.",
        "Hakrinbank N.V.",
        "Finabank N.V.",
        "Surinaamse Postspaarbank",
        "Stichting Surinaamse Volkscredietbank",
        "Surichange Bank N.V.",
        "Coöperatieve Spaar- en Kredietbank GODO",
        "Trustbank Amanah",
        "Southern Commercial Bank N.V.",
        "Other Surinamese Bank"
    ],
    "India": [
        "State Bank of India",
        "HDFC Bank",
        "ICICI Bank",
        "Axis Bank",
        "Kotak Mahindra Bank",
        "IndusInd Bank",
        "Punjab National Bank",
        "Bank of Baroda",
        "Canara Bank",
        "Union Bank of India",
        "Other Indian Bank"
    ],
    "Australia": [
        "Commonwealth Bank",
        "Westpac",
        "ANZ Bank",
        "National Australia Bank",
        "Macquarie Bank",
        "Bendigo Bank",
        "Bank of Queensland",
        "Other Australian Bank"
    ],
    "Germany": [
        "Deutsche Bank",
        "Commerzbank",
        "DZ Bank",
        "ING Germany",
        "N26",
        "DKB",
        "Other German Bank"
    ],
    "France": [
        "BNP Paribas",
        "Crédit Agricole",
        "Société Générale",
        "BPCE",
        "Crédit Mutuel",
        "La Banque Postale",
        "Other French Bank"
    ],
    "Netherlands": [
        "ING Bank",
        "ABN AMRO",
        "Rabobank",
        "de Volksbank",
        "Triodos Bank",
        "Other Dutch Bank"
    ],
    "Ireland": [
        "AIB",
        "Bank of Ireland",
        "Permanent TSB",
        "EBS",
        "Revolut Bank Ireland",
        "Other Irish Bank"
    ],
    "Switzerland": [
        "UBS",
        "Zürcher Kantonalbank",
        "Banque Cantonale Vaudoise",
        "Raiffeisen Switzerland",
        "PostFinance",
        "Julius Baer",
        "Other Swiss Bank"
    ],
    "UAE": [
        "Emirates NBD",
        "First Abu Dhabi Bank",
        "Abu Dhabi Commercial Bank",
        "Dubai Islamic Bank",
        "Mashreq Bank",
        "Commercial Bank of Dubai",
        "RAKBANK",
        "HSBC UAE",
        "Standard Chartered UAE",
        "Other UAE Bank"
    ],
    "United Arab Emirates": [
        "Emirates NBD",
        "First Abu Dhabi Bank",
        "Abu Dhabi Commercial Bank",
        "Dubai Islamic Bank",
        "Mashreq Bank",
        "Commercial Bank of Dubai",
        "RAKBANK",
        "HSBC UAE",
        "Standard Chartered UAE",
        "Other UAE Bank"
    ],
    "Saudi Arabia": [
        "Saudi National Bank",
        "Al Rajhi Bank",
        "Riyad Bank",
        "Alinma Bank",
        "Bank Albilad",
        "Arab National Bank",
        "Banque Saudi Fransi",
        "Other Saudi Bank"
    ],
    "Qatar": [
        "Qatar National Bank",
        "Qatar Islamic Bank",
        "Doha Bank",
        "Commercial Bank of Qatar",
        "Dukhan Bank",
        "Ahli Bank Qatar",
        "Other Qatari Bank"
    ],
    "Singapore": [
        "DBS Bank",
        "OCBC Bank",
        "United Overseas Bank",
        "Standard Chartered Singapore",
        "HSBC Singapore",
        "Citibank Singapore",
        "Maybank Singapore",
        "Other Singapore Bank"
    ],
    "Japan": [
        "MUFG Bank",
        "Sumitomo Mitsui Banking Corporation",
        "Mizuho Bank",
        "Resona Bank",
        "Japan Post Bank",
        "Other Japanese Bank"
    ],
    "China": [
        "Industrial and Commercial Bank of China",
        "China Construction Bank",
        "Agricultural Bank of China",
        "Bank of China",
        "Bank of Communications",
        "China Merchants Bank",
        "Other Chinese Bank"
    ],
    "Brazil": [
        "Banco do Brasil",
        "Itaú Unibanco",
        "Bradesco",
        "Caixa Econômica Federal",
        "Santander Brasil",
        "BTG Pactual",
        "Safra",
        "Other Brazilian Bank"
    ],
    "Mexico": [
        "BBVA México",
        "Banorte",
        "Santander México",
        "Citibanamex",
        "HSBC México",
        "Scotiabank México",
        "Banco Azteca",
        "Other Mexican Bank"
    ]
}

for country, banks in core_banks.items():
    bank_mapping[country] = banks

if not bank_mapping:
    bank_mapping = core_banks


# ------------------------------------------------------------
# 3. Remove old picker STYLE blocks
# ------------------------------------------------------------

old_style_markers = (
    "quick-search-select",
    "quick-search-input",
    "quick-search-results",
    "search-select-wrapper",
    "transfer-search-input",
    "transfer-search-results",
    "fairmont-clean",
    "fairmont-picker",
    "fairmont-real-select"
)

def remove_old_style_blocks(text):
    pattern = re.compile(
        r'<style\b[^>]*>.*?</style>',
        re.IGNORECASE | re.DOTALL
    )

    def replacement(match):
        block = match.group(0)

        if any(marker in block for marker in old_style_markers):
            return ""

        return block

    return pattern.sub(replacement, text)


source = remove_old_style_blocks(source)


# ------------------------------------------------------------
# 4. Remove old picker SCRIPT blocks
# ------------------------------------------------------------

old_script_markers = (
    "fairmont-country-bank-selector",
    "fairmont-picker",
    "fairmont-clean",
    "quick-search-select",
    "quick-search-input",
    "search-select-wrapper",
    "transfer-search-results",
    "internationalCountry",
    "internationalBank",
    "internationalCurrency",
    "countrySearchResults",
    "internationalBankSearchResults",
    "currencySearchResults"
)

def remove_old_script_blocks(text):
    pattern = re.compile(
        r'<script\b[^>]*>.*?</script>',
        re.IGNORECASE | re.DOTALL
    )

    def replacement(match):
        block = match.group(0)

        if any(marker in block for marker in old_script_markers):
            return ""

        return block

    return pattern.sub(replacement, text)


source = remove_old_script_blocks(source)


# ------------------------------------------------------------
# 5. Build ONE clean field for each selector
# ------------------------------------------------------------

country_option_html = "\n".join(
    f'        <option value="{html.escape(item["value"], quote=True)}">'
    f'{html.escape(item["label"])}'
    f'</option>'
    for item in country_options
)

country_field = f'''
            <div class="field fairmont-single-picker-field">
                <label>Destination Country</label>

                <div class="fairmont-single-picker" data-picker="country">
                    <select
                        id="internationalCountry"
                        name="country"
                        class="fairmont-picker-real-select"
                        required
                    >
                        <option value="">Select country</option>
{country_option_html}
                    </select>

                    <button
                        type="button"
                        class="fairmont-picker-trigger"
                        data-picker-trigger="country"
                        aria-haspopup="listbox"
                        aria-expanded="false"
                    >
                        <span class="fairmont-picker-label">
                            Select country
                        </span>
                        <span class="fairmont-picker-arrow">▾</span>
                    </button>
                </div>
            </div>
'''


bank_field = '''
            <div class="field fairmont-single-picker-field">
                <label>Bank Name</label>

                <div class="fairmont-single-picker" data-picker="bank">
                    <select
                        id="internationalBank"
                        name="bank_name"
                        class="fairmont-picker-real-select"
                        required
                        disabled
                    >
                        <option value="">Select a bank</option>
                    </select>

                    <button
                        type="button"
                        class="fairmont-picker-trigger"
                        data-picker-trigger="bank"
                        aria-haspopup="listbox"
                        aria-expanded="false"
                    >
                        <span class="fairmont-picker-label">
                            Select a bank
                        </span>
                        <span class="fairmont-picker-arrow">▾</span>
                    </button>
                </div>
            </div>
'''


currency_options = [
    ("GBP", "GBP — Pound Sterling"),
    ("EUR", "EUR — Euro"),
    ("USD", "USD — US Dollar"),
    ("CAD", "CAD — Canadian Dollar"),
    ("AUD", "AUD — Australian Dollar"),
    ("NZD", "NZD — New Zealand Dollar"),
    ("CHF", "CHF — Swiss Franc"),
    ("JPY", "JPY — Japanese Yen"),
    ("CNY", "CNY — Chinese Yuan"),
    ("HKD", "HKD — Hong Kong Dollar"),
    ("SGD", "SGD — Singapore Dollar"),
    ("INR", "INR — Indian Rupee"),
    ("AED", "AED — UAE Dirham"),
    ("SAR", "SAR — Saudi Riyal"),
    ("QAR", "QAR — Qatari Riyal"),
    ("ZAR", "ZAR — South African Rand"),
    ("KES", "KES — Kenyan Shilling"),
    ("NGN", "NGN — Nigerian Naira"),
    ("GHS", "GHS — Ghanaian Cedi"),
    ("TZS", "TZS — Tanzanian Shilling"),
    ("UGX", "UGX — Ugandan Shilling"),
    ("RWF", "RWF — Rwandan Franc"),
    ("BRL", "BRL — Brazilian Real"),
    ("MXN", "MXN — Mexican Peso"),
    ("ARS", "ARS — Argentine Peso"),
    ("SRD", "SRD — Surinamese Dollar"),
    ("THB", "THB — Thai Baht"),
    ("MYR", "MYR — Malaysian Ringgit"),
    ("IDR", "IDR — Indonesian Rupiah"),
    ("KRW", "KRW — South Korean Won"),
    ("TRY", "TRY — Turkish Lira"),
    ("PLN", "PLN — Polish Zloty"),
    ("SEK", "SEK — Swedish Krona"),
    ("NOK", "NOK — Norwegian Krone"),
    ("DKK", "DKK — Danish Krone"),
    ("CZK", "CZK — Czech Koruna"),
    ("HUF", "HUF — Hungarian Forint"),
    ("RON", "RON — Romanian Leu"),
    ("ILS", "ILS — Israeli New Shekel")
]

currency_option_html = "\n".join(
    f'        <option value="{code}">{html.escape(label)}</option>'
    for code, label in currency_options
)

currency_field = f'''
            <div class="field fairmont-single-picker-field">
                <label>Currency</label>

                <div class="fairmont-single-picker" data-picker="currency">
                    <select
                        id="internationalCurrency"
                        name="currency"
                        class="fairmont-picker-real-select"
                        required
                    >
                        <option value="">Select currency</option>
{currency_option_html}
                    </select>

                    <button
                        type="button"
                        class="fairmont-picker-trigger"
                        data-picker-trigger="currency"
                        aria-haspopup="listbox"
                        aria-expanded="false"
                    >
                        <span class="fairmont-picker-label">
                            Select currency
                        </span>
                        <span class="fairmont-picker-arrow">▾</span>
                    </button>
                </div>
            </div>
'''


# ------------------------------------------------------------
# 6. Replace the entire three field blocks
# ------------------------------------------------------------

def replace_field_block(text, label_text, replacement, next_label_text):
    pattern = re.compile(
        r'<div\s+class=["\']field["\'][^>]*>'
        r'\s*'
        r'<label>\s*'
        + re.escape(label_text)
        + r'.*?'
        r'(?=<div\s+class=["\']field["\'][^>]*>\s*<label>\s*'
        + re.escape(next_label_text)
        + r')',
        re.IGNORECASE | re.DOTALL
    )

    new_text, count = pattern.subn(
        replacement + "\n\n",
        text,
        count=1
    )

    return new_text, count


source, country_count = replace_field_block(
    source,
    "Destination Country",
    country_field.strip(),
    "Beneficiary Name"
)

if country_count != 1:
    print("ERROR: Could not replace Destination Country field.")
    print("No final file was written.")
    raise SystemExit(1)


source, bank_count = replace_field_block(
    source,
    "Bank Name",
    bank_field.strip(),
    "Account Number"
)

if bank_count != 1:
    print("ERROR: Could not replace Bank Name field.")
    print("No final file was written.")
    raise SystemExit(1)


source, currency_count = replace_field_block(
    source,
    "Currency",
    currency_field.strip(),
    "Amount"
)

if currency_count != 1:
    print("ERROR: Could not replace Currency field.")
    print("No final file was written.")
    raise SystemExit(1)


# ------------------------------------------------------------
# 7. Final clean picker CSS
# ------------------------------------------------------------

clean_css = r'''
<style id="fairmont-single-picker-style">
.fairmont-single-picker {
    position: relative;
    width: 100%;
}

.fairmont-picker-real-select {
    position: absolute !important;
    width: 1px !important;
    height: 1px !important;
    padding: 0 !important;
    margin: -1px !important;
    overflow: hidden !important;
    clip: rect(0, 0, 0, 0) !important;
    white-space: nowrap !important;
    border: 0 !important;
    opacity: 0 !important;
    pointer-events: none !important;
}

.fairmont-picker-trigger {
    width: 100%;
    min-height: 52px;
    box-sizing: border-box;
    border: 1px solid rgba(255,255,255,0.14);
    border-radius: 14px;
    background: rgba(255,255,255,0.055);
    color: rgba(255,255,255,0.72);
    padding: 0 46px 0 16px;
    font-size: 15px;
    text-align: left;
    cursor: pointer;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.fairmont-picker-trigger:hover {
    background: rgba(255,255,255,0.075);
}

.fairmont-picker-trigger:focus {
    outline: none;
    border-color: rgba(255,255,255,0.35);
}

.fairmont-picker-trigger.is-selected {
    color: #ffffff;
}

.fairmont-picker-label {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.fairmont-picker-arrow {
    position: absolute;
    right: 17px;
    top: 50%;
    transform: translateY(-50%);
    pointer-events: none;
}

.fairmont-single-popup {
    position: fixed;
    z-index: 2147483647;
    background: #111b30;
    border: 1px solid rgba(255,255,255,0.16);
    border-radius: 16px;
    box-shadow: 0 20px 60px rgba(0,0,0,0.55);
    overflow: hidden;
    display: none;
}

.fairmont-single-popup.is-open {
    display: block;
}

.fairmont-single-popup-search {
    width: calc(100% - 24px);
    height: 44px;
    margin: 12px;
    box-sizing: border-box;
    border: 1px solid rgba(255,255,255,0.15);
    border-radius: 11px;
    background: rgba(255,255,255,0.07);
    color: #ffffff;
    padding: 0 13px;
    outline: none;
    font-size: 15px;
}

.fairmont-single-popup-search::placeholder {
    color: rgba(255,255,255,0.45);
}

.fairmont-single-popup-list {
    max-height: 360px;
    overflow-y: auto;
    overscroll-behavior: contain;
}

.fairmont-single-popup-option {
    width: 100%;
    box-sizing: border-box;
    border: 0;
    border-top: 1px solid rgba(255,255,255,0.055);
    background: transparent;
    color: #ffffff;
    padding: 13px 16px;
    text-align: left;
    cursor: pointer;
    font-size: 14px;
}

.fairmont-single-popup-option:hover,
.fairmont-single-popup-option:focus {
    background: rgba(255,255,255,0.09);
    outline: none;
}

.fairmont-single-popup-empty {
    padding: 20px 16px;
    text-align: center;
    color: rgba(255,255,255,0.5);
    font-size: 14px;
}
</style>
'''


# ------------------------------------------------------------
# 8. Final picker JavaScript
# ------------------------------------------------------------

bank_json = json.dumps(
    bank_mapping,
    ensure_ascii=False,
    separators=(",", ":")
)

clean_js = f'''
<script id="fairmont-single-picker-script">
(function () {{
    "use strict";

    const COUNTRY_BANKS = {bank_json};

    let active = null;
    let popup = null;

    const pickerState = {{
        country: {{
            select: null,
            trigger: null,
            placeholder: "Select country",
            searchPlaceholder: "Search country..."
        }},
        bank: {{
            select: null,
            trigger: null,
            placeholder: "Select a bank",
            searchPlaceholder: "Search bank..."
        }},
        currency: {{
            select: null,
            trigger: null,
            placeholder: "Select currency",
            searchPlaceholder: "Search currency..."
        }}
    }};

    function getOptions(type) {{
        const state = pickerState[type];

        if (!state.select) {{
            return [];
        }}

        return Array.from(state.select.options)
            .filter(function (option) {{
                return option.value !== "";
            }})
            .map(function (option) {{
                return {{
                    value: option.value,
                    label: option.textContent.trim()
                }};
            }});
    }}

    function getBankOptions() {{
        const country =
            pickerState.country.select
                ? pickerState.country.select.value
                : "";

        if (!country) {{
            return [];
        }}

        const banks = COUNTRY_BANKS[country] || [];

        return banks.map(function (bank) {{
            return {{
                value: bank,
                label: bank
            }};
        }});
    }}

    function updateTrigger(type) {{
        const state = pickerState[type];

        if (!state.select || !state.trigger) {{
            return;
        }}

        const option =
            state.select.options[state.select.selectedIndex];

        const selected =
            option && option.value
                ? option.textContent.trim()
                : "";

        const label =
            state.trigger.querySelector(".fairmont-picker-label");

        if (label) {{
            label.textContent =
                selected || state.placeholder;
        }}

        state.trigger.classList.toggle(
            "is-selected",
            Boolean(selected)
        );
    }}

    function closePopup() {{
        if (popup) {{
            popup.remove();
            popup = null;
        }}

        if (active) {{
            active.state.trigger.setAttribute(
                "aria-expanded",
                "false"
            );
        }}

        active = null;
    }}

    function positionPopup() {{
        if (!popup || !active) {{
            return;
        }}

        const rect =
            active.state.trigger.getBoundingClientRect();

        const width =
            Math.min(
                430,
                Math.max(
                    260,
                    window.innerWidth - 28
                )
            );

        popup.style.width = width + "px";

        let left =
            rect.left;

        if (left + width > window.innerWidth - 14) {{
            left =
                window.innerWidth - width - 14;
        }}

        if (left < 14) {{
            left = 14;
        }}

        const popupHeight =
            Math.min(
                430,
                window.innerHeight - 28
            );

        let top =
            rect.bottom + 8;

        if (
            top + popupHeight >
            window.innerHeight - 14
        ) {{
            top =
                rect.top - popupHeight - 8;
        }}

        if (top < 14) {{
            top = 14;
        }}

        popup.style.left =
            left + "px";

        popup.style.top =
            top + "px";

        popup.style.maxHeight =
            popupHeight + "px";
    }}

    function renderOptions(type, query) {{
        if (!popup || !active) {{
            return;
        }}

        const list =
            popup.querySelector(
                ".fairmont-single-popup-list"
            );

        if (!list) {{
            return;
        }}

        let options =
            type === "bank"
                ? getBankOptions()
                : getOptions(type);

        const search =
            (query || "")
                .trim()
                .toLowerCase();

        if (search) {{
            options =
                options.filter(function (item) {{
                    return item.label
                        .toLowerCase()
                        .includes(search);
                }});
        }}

        list.innerHTML = "";

        if (!options.length) {{
            const empty =
                document.createElement("div");

            empty.className =
                "fairmont-single-popup-empty";

            empty.textContent =
                type === "bank" &&
                !pickerState.country.select.value
                    ? "Select a country first."
                    : "No matches found.";

            list.appendChild(empty);
            return;
        }}

        options.forEach(function (item) {{
            const button =
                document.createElement("button");

            button.type = "button";
            button.className =
                "fairmont-single-popup-option";
            button.textContent =
                item.label;
            button.setAttribute(
                "role",
                "option"
            );

            button.addEventListener(
                "click",
                function () {{
                    selectValue(
                        type,
                        item.value
                    );
                }}
            );

            list.appendChild(button);
        }});
    }}

    function selectValue(type, value) {{
        const state =
            pickerState[type];

        if (!state.select) {{
            return;
        }}

        state.select.value = value;

        state.select.dispatchEvent(
            new Event(
                "change",
                {{
                    bubbles: true
                }}
            )
        );

        updateTrigger(type);

        if (type === "country") {{
            const bankState =
                pickerState.bank;

            if (bankState.select) {{
                bankState.select.innerHTML =
                    '<option value="">Select a bank</option>';

                getBankOptions().forEach(
                    function (item) {{
                        const option =
                            document.createElement(
                                "option"
                            );

                        option.value =
                            item.value;

                        option.textContent =
                            item.label;

                        bankState.select.appendChild(
                            option
                        );
                    }}
                );

                bankState.select.disabled =
                    getBankOptions().length === 0;

                bankState.select.value = "";

                updateTrigger("bank");
            }}
        }}

        closePopup();
    }}

    function openPicker(type) {{
        const state =
            pickerState[type];

        if (!state.select ||
            !state.trigger) {{
            return;
        }}

        if (active && active.type === type) {{
            closePopup();
            return;
        }}

        closePopup();

        popup =
            document.createElement("div");

        popup.className =
            "fairmont-single-popup";

        popup.setAttribute(
            "role",
            "listbox"
        );

        const search =
            document.createElement("input");

        search.type = "search";
        search.className =
            "fairmont-single-popup-search";

        search.placeholder =
            state.searchPlaceholder;

        search.autocomplete =
            "off";

        search.spellcheck =
            false;

        const list =
            document.createElement("div");

        list.className =
            "fairmont-single-popup-list";

        popup.appendChild(search);
        popup.appendChild(list);

        document.body.appendChild(popup);

        active = {{
            type: type,
            state: state
        }};

        state.trigger.setAttribute(
            "aria-expanded",
            "true"
        );

        popup.classList.add("is-open");

        renderOptions(type, "");

        positionPopup();

        requestAnimationFrame(
            function () {{
                search.focus();
            }}
        );

        search.addEventListener(
            "input",
            function () {{
                renderOptions(
                    type,
                    search.value
                );
            }}
        );
    }}

    function initialize() {{
        pickerState.country.select =
            document.getElementById(
                "internationalCountry"
            );

        pickerState.country.trigger =
            document.querySelector(
                '[data-picker-trigger="country"]'
            );

        pickerState.bank.select =
            document.getElementById(
                "internationalBank"
            );

        pickerState.bank.trigger =
            document.querySelector(
                '[data-picker-trigger="bank"]'
            );

        pickerState.currency.select =
            document.getElementById(
                "internationalCurrency"
            );

        pickerState.currency.trigger =
            document.querySelector(
                '[data-picker-trigger="currency"]'
            );

        Object.keys(pickerState).forEach(
            function (type) {{
                const state =
                    pickerState[type];

                if (!state.select ||
                    !state.trigger) {{
                    return;
                }}

                state.trigger.addEventListener(
                    "click",
                    function () {{
                        openPicker(type);
                    }}
                );

                updateTrigger(type);
            }}
        );

        if (pickerState.bank.select) {{
            pickerState.bank.select.disabled =
                true;
        }}

        if (pickerState.country.select) {{
            pickerState.country.select.addEventListener(
                "change",
                function () {{
                    const bank =
                        pickerState.bank.select;

                    if (!bank) {{
                        return;
                    }}

                    bank.innerHTML =
                        '<option value="">Select a bank</option>';

                    getBankOptions().forEach(
                        function (item) {{
                            const option =
                                document.createElement(
                                    "option"
                                );

                            option.value =
                                item.value;

                            option.textContent =
                                item.label;

                            bank.appendChild(option);
                        }}
                    );

                    bank.disabled =
                        getBankOptions().length === 0;

                    bank.value = "";

                    updateTrigger("bank");
                }}
            );
        }}

        document.addEventListener(
            "click",
            function (event) {{
                if (!active || !popup) {{
                    return;
                }}

                if (
                    popup.contains(event.target) ||
                    active.state.trigger.contains(
                        event.target
                    )
                ) {{
                    return;
                }}

                closePopup();
            }}
        );

        document.addEventListener(
            "keydown",
            function (event) {{
                if (event.key === "Escape") {{
                    closePopup();
                }}
            }}
        );

        window.addEventListener(
            "resize",
            positionPopup
        );

        window.addEventListener(
            "scroll",
            positionPopup,
            true
        );
    }}

    if (
        document.readyState ===
        "loading"
    ) {{
        document.addEventListener(
            "DOMContentLoaded",
            initialize
        );
    }} else {{
        initialize();
    }}
}})();
</script>
'''


# ------------------------------------------------------------
# 9. Insert ONLY our new CSS and JS
# ------------------------------------------------------------

if 'id="fairmont-single-picker-style"' in source:
    print("ERROR: New picker CSS marker already exists unexpectedly.")
    raise SystemExit(1)

if 'id="fairmont-single-picker-script"' in source:
    print("ERROR: New picker JS marker already exists unexpectedly.")
    raise SystemExit(1)

source = source.replace(
    "</head>",
    clean_css + "\n</head>",
    1
)

source = source.replace(
    "</body>",
    clean_js + "\n</body>",
    1
)


# ------------------------------------------------------------
# 10. Safety checks BEFORE writing
# ------------------------------------------------------------

checks = {
    'country select': len(re.findall(
        r'<select\b[^>]*name=["\']country["\']',
        source,
        re.IGNORECASE
    )),
    'bank select': len(re.findall(
        r'<select\b[^>]*name=["\']bank_name["\']',
        source,
        re.IGNORECASE
    )),
    'currency select': len(re.findall(
        r'<select\b[^>]*name=["\']currency["\']',
        source,
        re.IGNORECASE
    )),
    'country trigger': len(re.findall(
        r'data-picker-trigger=["\']country["\']',
        source,
        re.IGNORECASE
    )),
    'bank trigger': len(re.findall(
        r'data-picker-trigger=["\']bank["\']',
        source,
        re.IGNORECASE
    )),
    'currency trigger': len(re.findall(
        r'data-picker-trigger=["\']currency["\']',
        source,
        re.IGNORECASE
    )),
    'new picker script': source.count(
        'id="fairmont-single-picker-script"'
    ),
    'new picker style': source.count(
        'id="fairmont-single-picker-style"'
    )
}

print()
print("FINAL STRUCTURE CHECK")
print("----------------------")

for name, count in checks.items():
    print(f"{name}: {count}")

expected = {
    'country select': 1,
    'bank select': 1,
    'currency select': 1,
    'country trigger': 1,
    'bank trigger': 1,
    'currency trigger': 1,
    'new picker script': 1,
    'new picker style': 1
}

for name, expected_count in expected.items():
    if checks[name] != expected_count:
        print()
        print(
            f"ERROR: {name} should be "
            f"{expected_count}, but is {checks[name]}."
        )
        print("NO FINAL FILE WAS WRITTEN.")
        raise SystemExit(1)


# These old visible picker elements must be gone.
old_visible_markers = [
    "class=\"quick-search-select\"",
    "class=\"search-select-wrapper\"",
    "class=\"quick-search-input\"",
    "class=\"transfer-search-input\"",
    "class=\"quick-search-results\"",
    "class=\"fairmont-clean-trigger\"",
    "class=\"fairmont-picker-trigger\""
]

# fairmont-picker-trigger is our NEW trigger, so exclude it.
for marker in old_visible_markers:
    if marker == 'class="fairmont-picker-trigger"':
        continue

    if marker in source:
        print()
        print(
            "ERROR: Old picker marker still exists:",
            marker
        )
        print("NO FINAL FILE WAS WRITTEN.")
        raise SystemExit(1)


# ------------------------------------------------------------
# 11. Write only after ALL checks pass
# ------------------------------------------------------------

TEMPLATE.write_text(source, encoding="utf-8")

print()
print("==============================================")
print("SUCCESS: International transfer pickers fixed")
print("==============================================")
print()
print("Exactly one visible picker trigger exists for:")
print("  - Destination Country")
print("  - Bank Name")
print("  - Currency")
print()
print("Search appears only inside the opened dropdown.")
print("Bank choices depend on the selected country.")
print("Suriname is included.")
print()
print("Database was NOT changed.")
print("app.py was NOT changed.")
print("Dashboard was NOT changed.")
print()
print(f"Backup: {backup.name}")