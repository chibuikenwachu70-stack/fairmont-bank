from pathlib import Path

APP_FILE = Path(__file__).resolve().parent / "app.py"

if not APP_FILE.exists():
    print("ERROR: app.py was not found.")
    raise SystemExit(1)

text = APP_FILE.read_text(encoding="utf-8")

if '@app.route("/admin/customer/<int:customer_id>/edit"' in text:
    print("Edit customer route already exists.")
    raise SystemExit(0)

marker = '@app.route("/admin/transactions")'

position = text.find(marker)

if position == -1:
    print("ERROR: Could not find the admin transactions route.")
    print("No changes were made.")
    raise SystemExit(1)

route = r'''
# ============================================================
# ADMIN — EDIT CUSTOMER DETAILS
# ============================================================

@app.route(
    "/admin/customer/<int:customer_id>/edit",
    methods=["GET", "POST"]
)
def admin_edit_customer(customer_id):

    admin_id = session.get("admin_id")

    if not admin_id:
        return redirect(url_for("admin_login"))

    admin = db.session.get(AdminUser, admin_id)

    if admin is None or not admin.is_active:
        session.pop("admin_id", None)
        session.pop("admin_username", None)
        return redirect(url_for("admin_login"))

    customer = db.session.get(Customer, customer_id)

    if customer is None:
        return redirect(url_for("admin_customers"))

    if request.method == "POST":

        full_name = request.form.get(
            "full_name",
            ""
        ).strip()

        email = request.form.get(
            "email",
            ""
        ).strip()

        phone = request.form.get(
            "phone",
            ""
        ).strip()

        country = request.form.get(
            "country",
            ""
        ).strip()

        account_type = request.form.get(
            "account_type",
            ""
        ).strip().lower()

        account_status = request.form.get(
            "account_status",
            ""
        ).strip()

        if not full_name:
            flash(
                "Customer full name is required.",
                "error"
            )

            return render_template(
                "admin_edit_customer.html",
                admin=admin,
                customer=customer
            )

        if not email:
            flash(
                "Customer email address is required.",
                "error"
            )

            return render_template(
                "admin_edit_customer.html",
                admin=admin,
                customer=customer
            )

        if not phone:
            flash(
                "Customer phone number is required.",
                "error"
            )

            return render_template(
                "admin_edit_customer.html",
                admin=admin,
                customer=customer
            )

        if not country:
            flash(
                "Customer country is required.",
                "error"
            )

            return render_template(
                "admin_edit_customer.html",
                admin=admin,
                customer=customer
            )

        if account_type not in {
            "savings",
            "current"
        }:
            flash(
                "Please select a valid account type.",
                "error"
            )

            return render_template(
                "admin_edit_customer.html",
                admin=admin,
                customer=customer
            )

        if not account_status:
            flash(
                "Please select an account status.",
                "error"
            )

            return render_template(
                "admin_edit_customer.html",
                admin=admin,
                customer=customer
            )

        existing_email = Customer.query.filter(
            Customer.email == email,
            Customer.id != customer.id
        ).first()

        if existing_email:
            flash(
                "Another customer is already using that email address.",
                "error"
            )

            return render_template(
                "admin_edit_customer.html",
                admin=admin,
                customer=customer
            )

        existing_phone = Customer.query.filter(
            Customer.phone == phone,
            Customer.id != customer.id
        ).first()

        if existing_phone:
            flash(
                "Another customer is already using that phone number.",
                "error"
            )

            return render_template(
                "admin_edit_customer.html",
                admin=admin,
                customer=customer
            )

        customer.full_name = full_name
        customer.email = email
        customer.phone = phone
        customer.country = country
        customer.account_type = account_type
        customer.account_status = account_status

        db.session.commit()

        flash(
            "Customer details updated successfully.",
            "success"
        )

        return redirect(
            url_for(
                "admin_customer_profile",
                customer_id=customer.id
            )
        )

    return render_template(
        "admin_edit_customer.html",
        admin=admin,
        customer=customer
    )


'''

text = (
    text[:position]
    + route
    + text[position:]
)

APP_FILE.write_text(
    text,
    encoding="utf-8"
)

print()
print("=" * 70)
print("ADMIN EDIT CUSTOMER ROUTE ADDED")
print("=" * 70)
print()
print("Route:")
print("/admin/customer/<customer_id>/edit")
print()
print("Editable:")
print("  - Full name")
print("  - Email")
print("  - Phone")
print("  - Country")
print("  - Account type")
print("  - Account status")
print()
print("Protected:")
print("  - Customer ID")
print("  - Account number")
print("  - Account balance")
print("  - Transaction history")
print()