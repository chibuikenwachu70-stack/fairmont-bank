from pathlib import Path

DASHBOARD_FILE = Path("templates/dashboard.html")

if not DASHBOARD_FILE.exists():
    raise SystemExit("ERROR: templates/dashboard.html was not found.")

html = DASHBOARD_FILE.read_text(encoding="utf-8")


# =========================================================
# 1. ADD UNREAD NOTIFICATION COUNT TO DASHBOARD
# =========================================================

if "notification_unread_count" not in html:

    html = html.replace(
        '<header class="dashboard-header">',
        '''<header class="dashboard-header">

                <a
                    href="/notifications"
                    class="dashboard-notification-button"
                    aria-label="Notifications">

                    <span class="dashboard-notification-icon">
                        ♢
                    </span>

                    {% if notification_unread_count > 0 %}

                        <span class="dashboard-notification-badge">
                            {{ notification_unread_count }}
                        </span>

                    {% endif %}

                </a>''',
        1
    )

    print("SUCCESS: Notification button added to dashboard header.")

else:
    print("INFO: Notification button already exists.")


# =========================================================
# 2. ADD SCOPED NOTIFICATION STYLING
# =========================================================

if ".dashboard-notification-button" not in html:

    style_block = '''
<style>

    .dashboard-notification-button {
        position: relative;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 42px;
        height: 42px;
        border-radius: 12px;
        text-decoration: none;
        background: rgba(255,255,255,0.06);
        border: 1px solid rgba(255,255,255,0.10);
        margin-right: 8px;
    }

    .dashboard-notification-icon {
        font-size: 20px;
        line-height: 1;
    }

    .dashboard-notification-badge {
        position: absolute;
        top: -5px;
        right: -5px;
        min-width: 18px;
        height: 18px;
        padding: 0 5px;
        border-radius: 999px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 10px;
        font-weight: 700;
        background: #ffffff;
        color: #111827;
        border: 2px solid rgba(15,23,42,0.9);
    }

</style>
'''

    html = html.replace(
        "</head>",
        style_block + "\n</head>",
        1
    )

    print("SUCCESS: Notification button styling added.")


# =========================================================
# 3. WRITE DASHBOARD
# =========================================================

DASHBOARD_FILE.write_text(
    html,
    encoding="utf-8"
)

print()
print("Dashboard notification integration complete.")
print("Existing dashboard sections were not redesigned.")