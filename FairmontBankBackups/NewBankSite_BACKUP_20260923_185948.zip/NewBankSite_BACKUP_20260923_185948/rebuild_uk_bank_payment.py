from pathlib import Path
from datetime import datetime
import shutil
import re

BASE = Path(".")
APP = BASE / "app.py"
TEMPLATES = BASE / "templates"

print()
print("=" * 60)
print("REBUILD UK BANK PAYMENT")
print("=" * 60)
print()

if not APP.exists():
    print("ERROR: app.py was not found.")
    raise SystemExit(1)

if not TEMPLATES.exists():
    print("ERROR: templates folder was not found.")
    raise SystemExit(1)

# ---------------------------------------------------------
# BACKUP APP
# ---------------------------------------------------------

stamp = datetime.now().strftime("%Y%m%d_%H%M%S")

app_backup = APP.with_name(
    "app_BEFORE_UK_PAYMENT_REBUILD_" + stamp + ".py"
)

shutil.copy2(APP, app_backup)

print("App backup created:")
print(" ", app_backup.name)

# ---------------------------------------------------------
# CREATE UK BANK PAYMENT TEMPLATE
# ---------------------------------------------------------

template_path = TEMPLATES / "send_money.html"

if template_path.exists():
    template_backup = TEMPLATES / (
        "send_money_BEFORE_UK_PAYMENT_REBUILD_"
        + stamp
        + ".html"
    )

    shutil.copy2(template_path, template_backup)

    print("Existing template backup created:")
    print(" ", template_backup.name)

# ---------------------------------------------------------
# TEMPLATE
# ---------------------------------------------------------

template = r'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>UK Bank Payment</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            font-family: Arial, Helvetica, sans-serif;
            background:
                radial-gradient(circle at top left, rgba(36, 91, 150, 0.28), transparent 38%),
                linear-gradient(145deg, #07111f, #0b1d31 55%, #06101c);
            color: #ffffff;
        }

        .page {
            width: 100%;
            max-width: 620px;
            margin: 0 auto;
            padding: 18px 16px 50px;
        }

        .topbar {
            display: flex;
            align-items: center;
            gap: 14px;
            margin-bottom: 22px;
        }

        .back {
            width: 42px;
            height: 42px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            color: #ffffff;
            background: rgba(255,255,255,0.08);
            border: 1px solid rgba(255,255,255,0.10);
            font-size: 23px;
        }

        .top-title {
            font-size: 21px;
            font-weight: 700;
        }

        .subtitle {
            color: rgba(255,255,255,0.58);
            font-size: 13px;
            margin-top: 3px;
        }

        .balance-card {
            padding: 18px;
            border-radius: 20px;
            background: rgba(255,255,255,0.065);
            border: 1px solid rgba(255,255,255,0.10);
            margin-bottom: 20px;
        }

        .balance-label {
            font-size: 12px;
            color: rgba(255,255,255,0.55);
            text-transform: uppercase;
            letter-spacing: 0.08em;
        }

        .balance {
            margin-top: 7px;
            font-size: 28px;
            font-weight: 700;
        }

        .account-number {
            margin-top: 7px;
            font-size: 13px;
            color: rgba(255,255,255,0.60);
        }

        .card {
            padding: 20px;
            border-radius: 22px;
            background: rgba(255,255,255,0.055);
            border: 1px solid rgba(255,255,255,0.10);
            box-shadow: 0 18px 45px rgba(0,0,0,0.18);
        }

        .section-title {
            font-size: 18px;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .section-description {
            color: rgba(255,255,255,0.55);
            font-size: 13px;
            line-height: 1.5;
            margin-bottom: 22px;
        }

        .field {
            margin-bottom: 18px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-size: 13px;
            color: rgba(255,255,255,0.78);
        }

        input,
        select {
            width: 100%;
            height: 50px;
            border: 1px solid rgba(255,255,255,0.12);
            border-radius: 14px;
            outline: none;
            background: rgba(255,255,255,0.065);
            color: #ffffff;
            padding: 0 14px;
            font-size: 14px;
        }

        input::placeholder {
            color: rgba(255,255,255,0.38);
        }

        select {
            appearance: none;
            cursor: pointer;
        }

        select option {
            background: #ffffff;
            color: #111111;
        }

        /* ------------------------------------------------
           CUSTOM BANK PICKER
        ------------------------------------------------ */

        .bank-picker {
            position: relative;
        }

        .bank-trigger {
            width: 100%;
            min-height: 50px;
            padding: 0 15px;
            border-radius: 14px;
            border: 1px solid rgba(255,255,255,0.12);
            background: rgba(255,255,255,0.065);
            color: #ffffff;
            display: flex;
            align-items: center;
            justify-content: space-between;
            text-align: left;
            cursor: pointer;
            font-size: 14px;
        }

        .bank-trigger:hover {
            background: rgba(255,255,255,0.09);
        }

        .bank-trigger-arrow {
            font-size: 16px;
            opacity: 0.65;
        }

        .bank-popup {
            display: none;
            position: fixed;
            z-index: 99999;
            background: #102235;
            border: 1px solid rgba(255,255,255,0.14);
            border-radius: 16px;
            box-shadow: 0 25px 70px rgba(0,0,0,0.45);
            overflow: hidden;
        }

        .bank-popup.open {
            display: block;
        }

        .bank-search-area {
            padding: 12px;
            border-bottom: 1px solid rgba(255,255,255,0.09);
            background: #102235;
        }

        .bank-search {
            width: 100%;
            height: 44px;
            border-radius: 11px;
            border: 1px solid rgba(255,255,255,0.13);
            background: rgba(255,255,255,0.07);
            color: #ffffff;
            padding: 0 13px;
            outline: none;
            font-size: 14px;
        }

        .bank-search::placeholder {
            color: rgba(255,255,255,0.48);
        }

        .bank-options {
            max-height: 330px;
            overflow-y: auto;
            padding: 7px;
        }

        .bank-option {
            width: 100%;
            border: 0;
            background: transparent;
            color: #ffffff;
            text-align: left;
            padding: 12px 13px;
            border-radius: 10px;
            cursor: pointer;
            font-size: 14px;
        }

        .bank-option:hover {
            background: rgba(255,255,255,0.09);
        }

        .bank-empty {
            padding: 18px 13px;
            color: rgba(255,255,255,0.50);
            font-size: 13px;
        }

        .submit-button {
            width: 100%;
            height: 53px;
            margin-top: 5px;
            border: 0;
            border-radius: 15px;
            background: #ffffff;
            color: #081522;
            font-size: 15px;
            font-weight: 700;
            cursor: pointer;
        }

        .submit-button:hover {
            opacity: 0.92;
        }

        .security-note {
            margin-top: 18px;
            text-align: center;
            color: rgba(255,255,255,0.43);
            font-size: 11px;
            line-height: 1.5;
        }

        @media (max-width: 480px) {
            .page {
                padding: 14px 12px 40px;
            }

            .card {
                padding: 17px;
            }
        }
    </style>
</head>

<body>

<div class="page">

    <div class="topbar">
        <a class="back" href="{{ url_for('dashboard') }}">‹</a>

        <div>
            <div class="top-title">UK Bank Payment</div>
            <div class="subtitle">Send money to a UK bank account</div>
        </div>
    </div>

    <div class="balance-card">
        <div class="balance-label">Available Balance</div>

        <div class="balance">
            £{{ "{:,.2f}".format(customer.account_balance or 0) }}
        </div>

        <div class="account-number">
            Account Number {{ customer.account_number }}
        </div>
    </div>

    <div class="card">

        <div class="section-title">Bank Payment</div>

        <div class="section-description">
            Enter the recipient's UK bank details and payment amount.
        </div>

        <form method="POST" action="{{ url_for('send_money') }}" id="ukPaymentForm">

            <input type="hidden" name="transfer_type" value="uk">

            <div class="field">
                <label for="recipient_name">Recipient Name</label>

                <input
                    type="text"
                    id="recipient_name"
                    name="recipient_name"
                    placeholder="Enter recipient name"
                    required
                >
            </div>

            <div class="field">

                <label>Bank</label>

                <div class="bank-picker">

                    <button
                        type="button"
                        class="bank-trigger"
                        id="bankTrigger"
                        aria-expanded="false"
                    >
                        <span id="bankTriggerText">Select a bank</span>
                        <span class="bank-trigger-arrow">▾</span>
                    </button>

                    <select
                        id="bankSelect"
                        name="bank_name"
                        hidden
                        required
                    >
                        <option value="">Select a bank</option>

                        {% for bank in banks %}
                            <option value="{{ bank.name }}">
                                {{ bank.name }}
                            </option>
                        {% endfor %}
                    </select>

                </div>

            </div>

            <div class="field">
                <label for="account_number">Account Number</label>

                <input
                    type="text"
                    id="account_number"
                    name="account_number"
                    inputmode="numeric"
                    maxlength="8"
                    placeholder="8-digit account number"
                    required
                >
            </div>

            <div class="field">
                <label for="sort_code">Sort Code</label>

                <input
                    type="text"
                    id="sort_code"
                    name="sort_code"
                    inputmode="numeric"
                    maxlength="6"
                    placeholder="6-digit sort code"
                    required
                >
            </div>

            <div class="field">
                <label for="amount">Amount</label>

                <input
                    type="number"
                    id="amount"
                    name="amount"
                    min="0.01"
                    step="0.01"
                    placeholder="0.00"
                    required
                >
            </div>

            <div class="field">
                <label for="reference">Payment Reference</label>

                <input
                    type="text"
                    id="reference"
                    name="reference"
                    maxlength="100"
                    placeholder="Optional payment reference"
                >
            </div>

            <button type="submit" class="submit-button">
                Review Payment
            </button>

        </form>

    </div>

    <div class="security-note">
        Please check the recipient details carefully before submitting a payment.
    </div>

</div>

<div class="bank-popup" id="bankPopup">

    <div class="bank-search-area">

        <input
            type="text"
            class="bank-search"
            id="bankSearch"
            placeholder="Search bank"
            autocomplete="off"
        >

    </div>

    <div class="bank-options" id="bankOptions"></div>

</div>

<script>
(function () {

    const trigger = document.getElementById("bankTrigger");
    const triggerText = document.getElementById("bankTriggerText");
    const select = document.getElementById("bankSelect");

    const popup = document.getElementById("bankPopup");
    const search = document.getElementById("bankSearch");
    const optionsBox = document.getElementById("bankOptions");

    if (!trigger || !select || !popup || !search || !optionsBox) {
        return;
    }

    const options = Array.from(select.options).map(function (option) {
        return {
            value: option.value,
            text: option.textContent.trim()
        };
    });

    function renderOptions(searchTerm) {

        optionsBox.innerHTML = "";

        const term = (searchTerm || "").trim().toLowerCase();

        const matches = options.filter(function (option) {

            if (option.value === "") {
                return false;
            }

            return (
                term === "" ||
                option.text.toLowerCase().includes(term)
            );
        });

        if (matches.length === 0) {

            const empty = document.createElement("div");

            empty.className = "bank-empty";
            empty.textContent = "No banks found.";

            optionsBox.appendChild(empty);

            return;
        }

        matches.forEach(function (option) {

            const button = document.createElement("button");

            button.type = "button";
            button.className = "bank-option";
            button.textContent = option.text;

            button.addEventListener("click", function () {

                select.value = option.value;
                triggerText.textContent = option.text;

                closePopup();
            });

            optionsBox.appendChild(button);
        });
    }

    function positionPopup() {

        const rect = trigger.getBoundingClientRect();

        popup.style.width = rect.width + "px";
        popup.style.left = rect.left + "px";

        const popupHeight = Math.min(400, window.innerHeight - 30);

        let top = rect.bottom + 7;

        if (top + popupHeight > window.innerHeight) {
            top = Math.max(10, rect.top - popupHeight - 7);
        }

        popup.style.top = top + "px";
    }

    function openPopup() {

        renderOptions("");

        positionPopup();

        popup.classList.add("open");

        trigger.setAttribute("aria-expanded", "true");

        search.value = "";

        setTimeout(function () {
            search.focus();
        }, 30);
    }

    function closePopup() {

        popup.classList.remove("open");

        trigger.setAttribute("aria-expanded", "false");
    }

    trigger.addEventListener("click", function (event) {

        event.stopPropagation();

        if (popup.classList.contains("open")) {
            closePopup();
        } else {
            openPopup();
        }

    });

    search.addEventListener("input", function () {
        renderOptions(search.value);
    });

    popup.addEventListener("click", function (event) {
        event.stopPropagation();
    });

    document.addEventListener("click", function () {
        closePopup();
    });

    window.addEventListener("resize", function () {

        if (popup.classList.contains("open")) {
            positionPopup();
        }

    });

    window.addEventListener("scroll", function () {

        if (popup.classList.contains("open")) {
            positionPopup();
        }

    }, true);

    document.addEventListener("keydown", function (event) {

        if (event.key === "Escape") {
            closePopup();
        }

    });

})();
</script>

</body>
</html>
'''

template_path.write_text(template, encoding="utf-8")

print()
print("New send_money.html created.")

# ---------------------------------------------------------
# NEW ROUTE
# ---------------------------------------------------------

route = r'''
@app.route("/send-money", methods=["GET", "POST"])
def send_money():
    if "customer_id" not in session:
        return redirect(url_for("login"))

    customer = Customer.query.filter_by(
        customer_id=session["customer_id"]
    ).first()

    if not customer:
        session.clear()
        return redirect(url_for("login"))

    banks = Bank.query.filter_by(
        country="UK",
        active=True
    ).order_by(Bank.name.asc()).all()

    if request.method == "GET":
        return render_template(
            "send_money.html",
            customer=customer,
            banks=banks
        )

    recipient_name = request.form.get(
        "recipient_name",
        ""
    ).strip()

    bank_name = request.form.get(
        "bank_name",
        ""
    ).strip()

    account_number = request.form.get(
        "account_number",
        ""
    ).strip()

    sort_code = request.form.get(
        "sort_code",
        ""
    ).strip()

    reference = request.form.get(
        "reference",
        ""
    ).strip()

    amount_text = request.form.get(
        "amount",
        ""
    ).strip()

    if not recipient_name:
        flash("Please enter the recipient name.", "error")
        return redirect(url_for("send_money"))

    if not bank_name:
        flash("Please select a bank.", "error")
        return redirect(url_for("send_money"))

    if not re.fullmatch(r"\d{8}", account_number):
        flash("Account number must contain exactly 8 digits.", "error")
        return redirect(url_for("send_money"))

    if not re.fullmatch(r"\d{6}", sort_code):
        flash("Sort code must contain exactly 6 digits.", "error")
        return redirect(url_for("send_money"))

    try:
        amount = float(amount_text)
    except (TypeError, ValueError):
        flash("Please enter a valid amount.", "error")
        return redirect(url_for("send_money"))

    if amount <= 0:
        flash("Payment amount must be greater than zero.", "error")
        return redirect(url_for("send_money"))

    if amount > float(customer.account_balance or 0):
        flash("Insufficient available balance.", "error")
        return redirect(url_for("send_money"))

    bank = Bank.query.filter_by(
        name=bank_name,
        country="UK",
        active=True
    ).first()

    if not bank:
        flash("The selected UK bank is not available.", "error")
        return redirect(url_for("send_money"))

    # -----------------------------------------------------
    # FAIRMOINT INTERNAL ACCOUNT MATCH
    # -----------------------------------------------------

    recipient_customer = Customer.query.filter_by(
        account_number=account_number
    ).first()

    if recipient_customer and recipient_customer.customer_id == customer.customer_id:
        flash(
            "You cannot send a payment to your own account.",
            "error"
        )
        return redirect(url_for("send_money"))

    # -----------------------------------------------------
    # INTERNAL FAIRMONT TRANSFER
    # -----------------------------------------------------

    if recipient_customer:

        if str(recipient_customer.account_status).lower() != "active":
            flash(
                "The recipient account is not active.",
                "error"
            )
            return redirect(url_for("send_money"))

        customer.account_balance = (
            float(customer.account_balance or 0)
            - amount
        )

        recipient_customer.account_balance = (
            float(recipient_customer.account_balance or 0)
            + amount
        )

        reference_value = (
            reference
            if reference
            else "Bank payment"
        )

        sender_transaction = Transaction(
            transaction_reference=generate_transaction_reference(),
            customer_id=customer.customer_id,
            transaction_type="Bank Transfer",
            direction="Debit",
            amount=amount,
            balance_after=float(customer.account_balance),
            description=reference_value,
            counterparty=recipient_customer.full_name,
            status="Completed"
        )

        recipient_transaction = Transaction(
            transaction_reference=generate_transaction_reference(),
            customer_id=recipient_customer.customer_id,
            transaction_type="Bank Transfer",
            direction="Credit",
            amount=amount,
            balance_after=float(recipient_customer.account_balance),
            description=reference_value,
            counterparty=customer.full_name,
            status="Completed"
        )

        db.session.add(sender_transaction)
        db.session.add(recipient_transaction)

        db.session.commit()

        return render_template(
            "transfer_confirmation.html",
            customer=customer,
            amount=amount,
            recipient_name=recipient_customer.full_name,
            bank_name=bank_name,
            account_number=account_number,
            sort_code=sort_code,
            reference=reference,
            status="Completed"
        )

    # -----------------------------------------------------
    # EXTERNAL UK BANK PAYMENT
    # -----------------------------------------------------

    transfer_reference = generate_transaction_reference()

    external_transfer = ExternalTransfer(
        transaction_reference=transfer_reference,
        customer_id=customer.customer_id,
        transfer_type="UK Bank Payment",
        bank_name=bank_name,
        recipient_name=recipient_name,
        account_number=account_number,
        sort_code=sort_code,
        country="United Kingdom",
        currency="GBP",
        amount=amount,
        fee=0.0,
        reference=reference,
        status="Pending"
    )

    db.session.add(external_transfer)
    db.session.commit()

    return render_template(
        "transfer_confirmation.html",
        customer=customer,
        amount=amount,
        recipient_name=recipient_name,
        bank_name=bank_name,
        account_number=account_number,
        sort_code=sort_code,
        reference=reference,
        status="Pending"
    )

'''

# ---------------------------------------------------------
# REMOVE POSSIBLE DUPLICATE SEND-MONEY ROUTE
# ---------------------------------------------------------

send_route_pattern = re.compile(
    r"""
    ^@app\.route\(
        \s*['"]/send-money['"]
        [^)]*
    \)
    \s*
    .*?
    (?=
        ^@app\.route\(
        |
        ^if __name__\s*==\s*['"]__main__['"]
    )
    """,
    re.IGNORECASE | re.MULTILINE | re.DOTALL | re.VERBOSE
)

app_text = APP.read_text(encoding="utf-8")

app_text = send_route_pattern.sub("", app_text)

# ---------------------------------------------------------
# INSERT ROUTE BEFORE MAIN
# ---------------------------------------------------------

main_marker = re.search(
    r'^if __name__\s*==\s*[\'"]__main__[\'"]\s*:',
    app_text,
    re.MULTILINE
)

if not main_marker:
    print()
    print("ERROR: Could not find Flask main block.")
    print("The template was created, but app.py was NOT changed.")
    raise SystemExit(1)

insert_position = main_marker.start()

app_text = (
    app_text[:insert_position]
    + route
    + "\n"
    + app_text[insert_position:]
)

# ---------------------------------------------------------
# WRITE APP
# ---------------------------------------------------------

APP.write_text(app_text, encoding="utf-8")

print("New /send-money route created.")

# ---------------------------------------------------------
# VALIDATION
# ---------------------------------------------------------

final_app = APP.read_text(encoding="utf-8")

route_count = len(
    re.findall(
        r'@app\.route\(\s*[\'"]/send-money[\'"]',
        final_app,
        re.IGNORECASE
    )
)

template_exists = template_path.exists()

print()
print("=" * 60)
print("FINAL VALIDATION")
print("=" * 60)
print()
print("send_money route count:", route_count)
print("send_money.html exists:", template_exists)

if route_count != 1:
    print()
    print("ERROR: Expected exactly one /send-money route.")
    raise SystemExit(1)

if not template_exists:
    print()
    print("ERROR: send_money.html was not created.")
    raise SystemExit(1)

print()
print("=" * 60)
print("SUCCESS")
print("=" * 60)
print()
print("UK Bank Payment has been rebuilt.")
print()
print("The bank selector contains:")
print("  - One visible Bank field")
print("  - Search inside the opened dropdown")
print("  - UK bank list")
print("  - No duplicate picker")
print()
print("Backup:")
print(" ", app_backup.name)