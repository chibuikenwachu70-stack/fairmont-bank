from pathlib import Path

APP_FILE = Path(__file__).resolve().parent / "app.py"

if not APP_FILE.exists():
    print("ERROR: app.py was not found.")
    raise SystemExit(1)

text = APP_FILE.read_text(encoding="utf-8")

route_start = text.find(
    '@app.route("/admin/incoming-payment", methods=["GET", "POST"])'
)

if route_start == -1:
    print("ERROR: Incoming payment route was not found.")
    raise SystemExit(1)

# The next route starts with this decorator.
next_route = text.find(
    '@app.route("/admin/create-customer"',
    route_start + 1
)

if next_route == -1:
    print("ERROR: The next admin route was not found.")
    print("No changes were made.")
    raise SystemExit(1)

route = text[route_start:next_route]

# ------------------------------------------------------------
# Replace the existing balance calculation.
# ------------------------------------------------------------

old_balance = '''        current_balance = float(
            receiver.account_balance or 0
        )

        new_balance = current_balance + amount
'''

new_balance = '''        previous_balance = float(
            receiver.account_balance or 0
        )

        new_balance = previous_balance + amount

        posted_at = datetime.now().strftime(
            "%d %B %Y, %H:%M:%S"
        )
'''

if "previous_balance = float(" not in route:

    if old_balance not in route:
        print("ERROR: The expected balance calculation was not found.")
        print("No changes were made.")
        raise SystemExit(1)

    route = route.replace(
        old_balance,
        new_balance,
        1
    )

# ------------------------------------------------------------
# Add the receipt values to render_template().
# ------------------------------------------------------------

old_receipt = '''            transaction_reference=transaction_reference,
            new_balance=new_balance
'''

new_receipt = '''            transaction_reference=transaction_reference,
            previous_balance=previous_balance,
            new_balance=new_balance,
            posted_at=posted_at
'''

if "previous_balance=previous_balance" not in route:

    if old_receipt not in route:
        print("ERROR: The receipt render section was not found.")
        print("No changes were made.")
        raise SystemExit(1)

    route = route.replace(
        old_receipt,
        new_receipt,
        1
    )

# ------------------------------------------------------------
# Write only the incoming-payment route back.
# ------------------------------------------------------------

text = (
    text[:route_start]
    + route
    + text[next_route:]
)

APP_FILE.write_text(
    text,
    encoding="utf-8"
)

print()
print("=" * 70)
print("INCOMING PAYMENT RECEIPT ROUTE UPDATED SUCCESSFULLY")
print("=" * 70)
print()
print("Receipt now receives:")
print("  Previous balance")
print("  New balance")
print("  Posting date and time")
print()
print("Existing payment logic was preserved.")
print("No customer records were deleted or recreated.")
print()