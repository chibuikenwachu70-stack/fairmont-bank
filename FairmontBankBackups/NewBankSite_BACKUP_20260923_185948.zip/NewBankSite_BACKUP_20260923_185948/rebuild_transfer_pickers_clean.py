from pathlib import Path
from datetime import datetime
import re
import html
import shutil
import sys


BASE_DIR = Path(r"C:\Users\DON J\Documents\NewBankSite")
TEMPLATE = BASE_DIR / "templates" / "international_transfer.html"


# ============================================================
# COUNTRY DATA
# ============================================================

COUNTRIES = [
    "Afghanistan", "Albania", "Algeria", "Andorra", "Angola",
    "Antigua and Barbuda", "Argentina", "Armenia", "Australia",
    "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh",
    "Barbados", "Belarus", "Belgium", "Belize", "Benin",
    "Bhutan", "Bolivia", "Bosnia and Herzegovina", "Botswana",
    "Brazil", "Brunei", "Bulgaria", "Burkina Faso", "Burundi",
    "Cambodia", "Cameroon", "Canada", "Cape Verde",
    "Central African Republic", "Chad", "Chile", "China",
    "Colombia", "Comoros", "Congo", "Costa Rica", "Croatia",
    "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti",
    "Dominica", "Dominican Republic", "Ecuador", "Egypt",
    "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia",
    "Eswatini", "Ethiopia", "Fiji", "Finland", "France",
    "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Greece",
    "Grenada", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana",
    "Haiti", "Honduras", "Hungary", "Iceland", "India",
    "Indonesia", "Iran", "Iraq", "Ireland", "Israel", "Italy",
    "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya",
    "Kiribati", "Kuwait", "Kyrgyzstan", "Laos", "Latvia",
    "Lebanon", "Lesotho", "Liberia", "Libya", "Liechtenstein",
    "Lithuania", "Luxembourg", "Madagascar", "Malawi", "Malaysia",
    "Maldives", "Mali", "Malta", "Marshall Islands", "Mauritania",
    "Mauritius", "Mexico", "Micronesia", "Moldova", "Monaco",
    "Mongolia", "Montenegro", "Morocco", "Mozambique", "Myanmar",
    "Namibia", "Nauru", "Nepal", "Netherlands", "New Zealand",
    "Nicaragua", "Niger", "Nigeria", "North Korea", "North Macedonia",
    "Norway", "Oman", "Pakistan", "Palau", "Palestine", "Panama",
    "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Poland",
    "Portugal", "Qatar", "Romania", "Russia", "Rwanda",
    "Saint Kitts and Nevis", "Saint Lucia",
    "Saint Vincent and the Grenadines", "Samoa", "San Marino",
    "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Serbia",
    "Seychelles", "Sierra Leone", "Singapore", "Slovakia",
    "Slovenia", "Solomon Islands", "Somalia", "South Africa",
    "South Korea", "South Sudan", "Spain", "Sri Lanka", "Sudan",
    "Suriname", "Sweden", "Switzerland", "Syria", "Taiwan",
    "Tajikistan", "Tanzania", "Thailand", "Timor-Leste", "Togo",
    "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey",
    "Turkmenistan", "Tuvalu", "Uganda", "Ukraine",
    "United Arab Emirates", "United Kingdom", "United States",
    "Uruguay", "Uzbekistan", "Vanuatu", "Vatican City",
    "Venezuela", "Vietnam", "Yemen", "Zambia", "Zimbabwe"
]


# ============================================================
# BANK DATA
# ============================================================

BANKS = {
    "United Kingdom": [
        "Allied Irish Bank (GB)",
        "Bank of Ireland UK",
        "Bank of Scotland",
        "Barclays Bank",
        "Birmingham Bank",
        "Card One Money",
        "Cashplus Bank",
        "Chase UK",
        "Citibank UK",
        "ClearBank",
        "C. Hoare & Co.",
        "Co-operative Bank",
        "Coutts",
        "Danske Bank",
        "First Direct",
        "Halifax",
        "Handelsbanken UK",
        "HSBC UK",
        "Investec Bank",
        "Lloyds Bank",
        "Metro Bank",
        "Monzo Bank",
        "Nationwide Building Society",
        "NatWest",
        "Revolut",
        "Royal Bank of Scotland",
        "Santander UK",
        "Skipton Building Society",
        "Starling Bank",
        "TSB Bank",
        "Ulster Bank",
        "Virgin Money",
        "Yorkshire Building Society",
        "Zopa Bank",
        "Other UK Bank or Building Society"
    ],

    "Suriname": [
        "De Surinaamsche Bank (DSB)",
        "Republic Bank Suriname",
        "Hakrinbank",
        "Surinaamse Volkscredietbank",
        "Finabank",
        "Surichange Bank",
        "GODO Coöperatieve Spaar- en Kredietbank",
        "Trustbank Amanah",
        "Postspaarbank"
    ],

    "United States": [
        "Bank of America",
        "JPMorgan Chase Bank",
        "Wells Fargo Bank",
        "Citibank",
        "U.S. Bank",
        "PNC Bank",
        "Truist Bank",
        "Capital One",
        "TD Bank",
        "Goldman Sachs Bank",
        "Other US Bank"
    ],

    "Canada": [
        "Royal Bank of Canada",
        "Toronto-Dominion Bank",
        "Bank of Montreal",
        "Canadian Imperial Bank of Commerce",
        "Bank of Nova Scotia",
        "National Bank of Canada",
        "Desjardins",
        "Other Canadian Bank"
    ],

    "Kenya": [
        "KCB Bank Kenya",
        "Equity Bank Kenya",
        "Co-operative Bank of Kenya",
        "Absa Bank Kenya",
        "NCBA Bank Kenya",
        "Stanbic Bank Kenya",
        "Standard Chartered Bank Kenya",
        "I&M Bank Kenya",
        "DTB Kenya",
        "Family Bank",
        "Other Kenyan Bank"
    ],

    "Nigeria": [
        "Access Bank",
        "Guaranty Trust Bank",
        "Zenith Bank",
        "First Bank of Nigeria",
        "United Bank for Africa",
        "Fidelity Bank",
        "Union Bank of Nigeria",
        "Sterling Bank",
        "Stanbic IBTC Bank",
        "Wema Bank",
        "Other Nigerian Bank"
    ],

    "Ghana": [
        "GCB Bank",
        "Ecobank Ghana",
        "Absa Bank Ghana",
        "Standard Chartered Bank Ghana",
        "Stanbic Bank Ghana",
        "Fidelity Bank Ghana",
        "CalBank",
        "United Bank for Africa Ghana",
        "Other Ghanaian Bank"
    ],

    "South Africa": [
        "Standard Bank",
        "First National Bank",
        "Absa Bank South Africa",
        "Nedbank",
        "Capitec Bank",
        "Investec Bank South Africa",
        "African Bank",
        "Discovery Bank",
        "Other South African Bank"
    ],

    "India": [
        "State Bank of India",
        "HDFC Bank",
        "ICICI Bank",
        "Axis Bank",
        "Kotak Mahindra Bank",
        "Punjab National Bank",
        "Bank of Baroda",
        "Canara Bank",
        "Union Bank of India",
        "IndusInd Bank",
        "Other Indian Bank"
    ],

    "Australia": [
        "Commonwealth Bank",
        "Westpac",
        "ANZ",
        "National Australia Bank",
        "Macquarie Bank",
        "Bendigo Bank",
        "ING Australia",
        "Other Australian Bank"
    ],

    "Germany": [
        "Deutsche Bank",
        "Commerzbank",
        "DZ Bank",
        "KfW",
        "ING Germany",
        "N26",
        "Other German Bank"
    ],

    "France": [
        "BNP Paribas",
        "Crédit Agricole",
        "Société Générale",
        "BPCE",
        "La Banque Postale",
        "Crédit Mutuel",
        "Other French Bank"
    ],

    "Netherlands": [
        "ING Bank",
        "ABN AMRO",
        "Rabobank",
        "de Volksbank",
        "Other Dutch Bank"
    ],

    "Ireland": [
        "AIB",
        "Bank of Ireland",
        "Permanent TSB",
        "Revolut Ireland",
        "Other Irish Bank"
    ],

    "Switzerland": [
        "UBS",
        "Credit Suisse",
        "Julius Baer",
        "Zürcher Kantonalbank",
        "Other Swiss Bank"
    ],

    "United Arab Emirates": [
        "Emirates NBD",
        "First Abu Dhabi Bank",
        "Abu Dhabi Commercial Bank",
        "Mashreq",
        "Dubai Islamic Bank",
        "Emirates Islamic",
        "Other UAE Bank"
    ],

    "Saudi Arabia": [
        "Saudi National Bank",
        "Al Rajhi Bank",
        "Riyad Bank",
        "Saudi Awwal Bank",
        "Banque Saudi Fransi",
        "Arab National Bank",
        "Bank Albilad",
        "Other Saudi Bank"
    ],

    "Qatar": [
        "Qatar National Bank",
        "Qatar Islamic Bank",
        "Commercial Bank Qatar",
        "Doha Bank",
        "Masraf Al Rayan",
        "Other Qatari Bank"
    ],

    "Singapore": [
        "DBS Bank",
        "OCBC Bank",
        "United Overseas Bank",
        "Standard Chartered Singapore",
        "Citibank Singapore",
        "Other Singapore Bank"
    ],

    "Japan": [
        "MUFG Bank",
        "Sumitomo Mitsui Banking Corporation",
        "Mizuho Bank",
        "Resona Bank",
        "Japan Post Bank",
        "Other Japanese Bank"
    ],

    "China": [
        "Industrial and Commercial Bank of China",
        "China Construction Bank",
        "Bank of China",
        "Agricultural Bank of China",
        "Bank of Communications",
        "China Merchants Bank",
        "Other Chinese Bank"
    ],

    "Brazil": [
        "Banco do Brasil",
        "Itaú Unibanco",
        "Bradesco",
        "Caixa Econômica Federal",
        "Santander Brasil",
        "BTG Pactual",
        "Other Brazilian Bank"
    ],

    "Mexico": [
        "BBVA México",
        "Citibanamex",
        "Santander México",
        "Banorte",
        "HSBC México",
        "Scotiabank México",
        "Other Mexican Bank"
    ]
}


# ============================================================
# CURRENCY DATA
# ============================================================

CURRENCIES = [
    ("GBP", "British Pound Sterling"),
    ("EUR", "Euro"),
    ("USD", "United States Dollar"),
    ("CAD", "Canadian Dollar"),
    ("AUD", "Australian Dollar"),
    ("NZD", "New Zealand Dollar"),
    ("CHF", "Swiss Franc"),
    ("JPY", "Japanese Yen"),
    ("CNY", "Chinese Yuan"),
    ("SGD", "Singapore Dollar"),
    ("INR", "Indian Rupee"),
    ("AED", "UAE Dirham"),
    ("SAR", "Saudi Riyal"),
    ("QAR", "Qatari Riyal"),
    ("ZAR", "South African Rand"),
    ("KES", "Kenyan Shilling"),
    ("NGN", "Nigerian Naira"),
    ("GHS", "Ghanaian Cedi"),
    ("TZS", "Tanzanian Shilling"),
    ("UGX", "Ugandan Shilling"),
    ("BRL", "Brazilian Real"),
    ("MXN", "Mexican Peso"),
    ("SRD", "Surinamese Dollar"),
    ("THB", "Thai Baht"),
    ("MYR", "Malaysian Ringgit"),
    ("IDR", "Indonesian Rupiah"),
    ("KRW", "South Korean Won"),
    ("TRY", "Turkish Lira"),
    ("PLN", "Polish Zloty"),
    ("SEK", "Swedish Krona"),
    ("NOK", "Norwegian Krone"),
    ("DKK", "Danish Krone"),
    ("CZK", "Czech Koruna"),
    ("HUF", "Hungarian Forint"),
    ("RON", "Romanian Leu"),
    ("ILS", "Israeli New Shekel")
]


# ============================================================
# HELPERS
# ============================================================

def esc(value):
    return html.escape(str(value), quote=True)


def js_json(value):
    import json
    return json.dumps(value, ensure_ascii=False)


def find_select(text, select_id):
    pattern = re.compile(
        r'<select\b[^>]*\bid=["\']'
        + re.escape(select_id)
        + r'["\'][^>]*>.*?</select>',
        re.IGNORECASE | re.DOTALL
    )

    match = pattern.search(text)

    if not match:
        return None

    return match


def find_enclosing_field(text, select_match):
    """
    Finds the .field div containing the real select.
    Uses balanced div scanning rather than assuming a particular
    HTML layout.
    """

    select_start = select_match.start()

    div_pattern = re.compile(r'<div\b[^>]*>', re.IGNORECASE)

    candidates = []

    for match in div_pattern.finditer(text, 0, select_start):
        opening = match.group(0)

        if "field" in opening.lower():
            candidates.append(match)

    if not candidates:
        return None

    for opening_match in reversed(candidates):

        start = opening_match.start()
        depth = 0
        pos = opening_match.start()

        token_pattern = re.compile(
            r'<div\b[^>]*>|</div\s*>',
            re.IGNORECASE
        )

        for token in token_pattern.finditer(text, start):

            token_text = token.group(0).lower()

            if token_text.startswith("<div"):
                depth += 1

            else:
                depth -= 1

                if depth == 0:
                    end = token.end()

                    if start <= select_start < end:
                        return start, end

                    break

    return None


def build_country_select():
    options = [
        '<option value="">Select country</option>'
    ]

    for country in COUNTRIES:
        options.append(
            '<option value="{0}">{0}</option>'.format(esc(country))
        )

    return """<select
        id="internationalCountry"
        name="country"
        class="fairmont-clean-real-select"
        required
    >
        {options}
    </select>""".format(
        options="\n        ".join(options)
    )


def build_bank_select():
    return """<select
        id="internationalBank"
        name="bank_name"
        class="fairmont-clean-real-select"
        required
    >
        <option value="">Select a bank</option>
    </select>"""


def build_currency_select():
    options = [
        '<option value="">Select currency</option>'
    ]

    for code, name in CURRENCIES:
        options.append(
            '<option value="{0}">{0} — {1}</option>'.format(
                esc(code),
                esc(name)
            )
        )

    return """<select
        id="internationalCurrency"
        name="currency"
        class="fairmont-clean-real-select"
        required
    >
        {options}
    </select>""".format(
        options="\n        ".join(options)
    )


def trigger(kind, placeholder):
    return """
<button
    type="button"
    class="fairmont-clean-trigger"
    data-clean-picker="{kind}"
    aria-expanded="false"
>
    <span class="fairmont-clean-value">{placeholder}</span>
    <span class="fairmont-clean-arrow">▾</span>
</button>
""".format(
        kind=esc(kind),
        placeholder=esc(placeholder)
    )


def replace_field(text, select_id, field_html):
    select_match = find_select(text, select_id)

    if not select_match:
        raise RuntimeError(
            "Could not find real select: {}".format(select_id)
        )

    field = find_enclosing_field(text, select_match)

    if not field:
        raise RuntimeError(
            "Could not find enclosing field for: {}".format(select_id)
        )

    start, end = field

    return text[:start] + field_html + text[end:]


# ============================================================
# BUILD CLEAN FIELD HTML
# ============================================================

country_field = """
<div class="field fairmont-clean-field">

    <label>Destination Country</label>

    {select}

    {trigger}

</div>
""".format(
    select=build_country_select(),
    trigger=trigger("country", "Select country")
)


bank_field = """
<div class="field fairmont-clean-field">

    <label>Bank Name</label>

    {select}

    {trigger}

</div>
""".format(
    select=build_bank_select(),
    trigger=trigger("bank", "Select a bank")
)


currency_field = """
<div class="field fairmont-clean-field">

    <label>Currency</label>

    {select}

    {trigger}

</div>
""".format(
    select=build_currency_select(),
    trigger=trigger("currency", "Select currency")
)


# ============================================================
# CLEAN OLD PICKER CODE
# ============================================================

def remove_tag_blocks(text, tag, markers):
    pattern = re.compile(
        r"<" + tag + r"\b[^>]*>.*?</" + tag + r">",
        re.IGNORECASE | re.DOTALL
    )

    removed = 0

    def replacement(match):
        nonlocal removed

        block = match.group(0).lower()

        if any(marker.lower() in block for marker in markers):
            removed += 1
            return ""

        return match.group(0)

    text = pattern.sub(replacement, text)

    return text, removed


OLD_MARKERS = [
    "fairmont-picker",
    "fairmont-final",
    "fairmont-clean-picker",
    "quick-search-select",
    "search-select-wrapper",
    "countrysearchresults",
    "internationalbanksearch",
    "internationalbanksearchresults",
    "currencysearch",
    "currencysearchresults",
    "fairmont-country-bank-selector"
]


# ============================================================
# NEW CSS
# ============================================================

CLEAN_CSS = r"""
<style id="fairmont-clean-picker-css">

.fairmont-clean-field {
    position: relative;
}

.fairmont-clean-real-select {
    position: absolute !important;
    left: -10000px !important;
    top: auto !important;
    width: 1px !important;
    height: 1px !important;
    opacity: 0 !important;
    pointer-events: none !important;
}

.fairmont-clean-trigger {
    width: 100%;
    min-height: 52px;
    border: 1px solid rgba(255,255,255,0.14);
    border-radius: 14px;
    background: rgba(255,255,255,0.055);
    color: inherit;
    padding: 0 15px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    cursor: pointer;
    text-align: left;
    font: inherit;
}

.fairmont-clean-trigger:hover {
    background: rgba(255,255,255,0.08);
}

.fairmont-clean-value {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.fairmont-clean-arrow {
    flex: 0 0 auto;
    font-size: 15px;
}

.fairmont-clean-popup {
    position: fixed;
    z-index: 999999;
    width: min(420px, calc(100vw - 28px));
    max-height: min(430px, calc(100vh - 40px));
    overflow: hidden;
    border-radius: 16px;
    border: 1px solid rgba(255,255,255,0.16);
    background: #101b2d;
    box-shadow: 0 22px 60px rgba(0,0,0,0.45);
}

.fairmont-clean-search-wrap {
    padding: 12px;
    border-bottom: 1px solid rgba(255,255,255,0.10);
    background: #101b2d;
}

.fairmont-clean-search {
    width: 100%;
    box-sizing: border-box;
    border: 1px solid rgba(255,255,255,0.15);
    border-radius: 11px;
    background: rgba(255,255,255,0.07);
    color: inherit;
    padding: 11px 13px;
    outline: none;
    font: inherit;
}

.fairmont-clean-options {
    max-height: 340px;
    overflow-y: auto;
    padding: 7px;
}

.fairmont-clean-option {
    width: 100%;
    border: 0;
    border-radius: 10px;
    background: transparent;
    color: inherit;
    padding: 11px 12px;
    text-align: left;
    cursor: pointer;
    font: inherit;
}

.fairmont-clean-option:hover,
.fairmont-clean-option:focus {
    background: rgba(255,255,255,0.09);
    outline: none;
}

.fairmont-clean-empty {
    padding: 18px 12px;
    opacity: 0.65;
    text-align: center;
}

</style>
"""


# ============================================================
# NEW JAVASCRIPT
# ============================================================

BANK_DATA_JSON = js_json(BANKS)
COUNTRY_DATA_JSON = js_json(COUNTRIES)

CLEAN_JS = r"""
<script id="fairmont-clean-picker-js">
(function () {

    "use strict";

    const countryBanks = __BANK_DATA__;
    const countries = __COUNTRY_DATA__;

    const countrySelect = document.getElementById("internationalCountry");
    const bankSelect = document.getElementById("internationalBank");
    const currencySelect = document.getElementById("internationalCurrency");

    if (!countrySelect || !bankSelect || !currencySelect) {
        console.error("Fairmont picker: required selects were not found.");
        return;
    }

    let activePopup = null;
    let activeType = null;
    let activeTrigger = null;

    function getSelect(type) {
        if (type === "country") return countrySelect;
        if (type === "bank") return bankSelect;
        if (type === "currency") return currencySelect;
        return null;
    }

    function getItems(type) {

        if (type === "country") {
            return countries.map(function (country) {
                return {
                    value: country,
                    label: country
                };
            });
        }

        if (type === "bank") {

            const selectedCountry = countrySelect.value;

            const banks = countryBanks[selectedCountry] || [
                "Other bank in " + selectedCountry
            ];

            return banks.map(function (bank) {
                return {
                    value: bank,
                    label: bank
                };
            });
        }

        if (type === "currency") {

            const items = [];

            for (let i = 0; i < currencySelect.options.length; i++) {

                const option = currencySelect.options[i];

                if (!option.value) {
                    continue;
                }

                items.push({
                    value: option.value,
                    label: option.textContent
                });
            }

            return items;
        }

        return [];
    }

    function updateBankOptions() {

        const selectedCountry = countrySelect.value;

        bankSelect.innerHTML =
            '<option value="">Select a bank</option>';

        if (!selectedCountry) {
            updateTrigger("bank", "Select a bank");
            return;
        }

        const banks = countryBanks[selectedCountry] || [
            "Other bank in " + selectedCountry
        ];

        banks.forEach(function (bank) {

            const option = document.createElement("option");

            option.value = bank;
            option.textContent = bank;

            bankSelect.appendChild(option);
        });

        updateTrigger("bank", "Select a bank");
    }

    function updateTrigger(type, text) {

        const trigger =
            document.querySelector(
                '[data-clean-picker="' + type + '"]'
            );

        if (!trigger) return;

        const value =
            trigger.querySelector(".fairmont-clean-value");

        if (value) {
            value.textContent = text;
        }
    }

    function closePopup() {

        if (activePopup) {
            activePopup.remove();
        }

        activePopup = null;

        if (activeTrigger) {
            activeTrigger.setAttribute(
                "aria-expanded",
                "false"
            );
        }

        activeTrigger = null;
        activeType = null;
    }

    function positionPopup(trigger, popup) {

        const rect = trigger.getBoundingClientRect();

        popup.style.visibility = "hidden";
        popup.style.left = "0px";
        popup.style.top = "0px";

        document.body.appendChild(popup);

        const popupRect = popup.getBoundingClientRect();

        let left = rect.left;

        let top = rect.bottom + 7;

        if (
            left + popupRect.width >
            window.innerWidth - 12
        ) {
            left =
                window.innerWidth -
                popupRect.width -
                12;
        }

        if (left < 12) {
            left = 12;
        }

        if (
            top + popupRect.height >
            window.innerHeight - 12
        ) {
            const above =
                rect.top -
                popupRect.height -
                7;

            if (above >= 12) {
                top = above;
            } else {
                top =
                    Math.max(
                        12,
                        window.innerHeight -
                        popupRect.height -
                        12
                    );
            }
        }

        popup.style.left = left + "px";
        popup.style.top = top + "px";
        popup.style.visibility = "visible";
    }

    function renderOptions(type, optionsContainer, query) {

        optionsContainer.innerHTML = "";

        const normalized =
            (query || "").trim().toLowerCase();

        const items =
            getItems(type).filter(function (item) {

                if (!normalized) {
                    return true;
                }

                return item.label
                    .toLowerCase()
                    .includes(normalized);
            });

        if (!items.length) {

            const empty =
                document.createElement("div");

            empty.className =
                "fairmont-clean-empty";

            empty.textContent =
                "No matching options";

            optionsContainer.appendChild(empty);

            return;
        }

        items.forEach(function (item) {

            const button =
                document.createElement("button");

            button.type = "button";

            button.className =
                "fairmont-clean-option";

            button.textContent =
                item.label;

            button.addEventListener(
                "click",
                function () {

                    const select =
                        getSelect(type);

                    if (!select) return;

                    let option =
                        Array.from(
                            select.options
                        ).find(
                            function (existing) {
                                return (
                                    existing.value ===
                                    item.value
                                );
                            }
                        );

                    if (!option) {

                        option =
                            document.createElement(
                                "option"
                            );

                        option.value =
                            item.value;

                        option.textContent =
                            item.label;

                        select.appendChild(option);
                    }

                    select.value =
                        item.value;

                    select.dispatchEvent(
                        new Event(
                            "change",
                            {
                                bubbles: true
                            }
                        )
                    );

                    updateTrigger(
                        type,
                        item.label
                    );

                    closePopup();
                }
            );

            optionsContainer.appendChild(
                button
            );
        });
    }

    function openPopup(type, trigger) {

        if (
            activePopup &&
            activeType === type
        ) {
            closePopup();
            return;
        }

        closePopup();

        activeType = type;
        activeTrigger = trigger;

        trigger.setAttribute(
            "aria-expanded",
            "true"
        );

        const popup =
            document.createElement("div");

        popup.className =
            "fairmont-clean-popup";

        const searchWrap =
            document.createElement("div");

        searchWrap.className =
            "fairmont-clean-search-wrap";

        const search =
            document.createElement("input");

        search.type = "search";

        search.className =
            "fairmont-clean-search";

        search.placeholder =
            type === "country"
                ? "Search country..."
                : type === "bank"
                    ? "Search bank..."
                    : "Search currency...";

        search.autocomplete = "off";

        const options =
            document.createElement("div");

        options.className =
            "fairmont-clean-options";

        searchWrap.appendChild(search);

        popup.appendChild(searchWrap);
        popup.appendChild(options);

        activePopup = popup;

        positionPopup(
            trigger,
            popup
        );

        renderOptions(
            type,
            options,
            ""
        );

        search.addEventListener(
            "input",
            function () {
                renderOptions(
                    type,
                    options,
                    search.value
                );
            }
        );

        search.addEventListener(
            "keydown",
            function (event) {

                if (event.key === "Escape") {
                    closePopup();
                }
            }
        );

        setTimeout(
            function () {
                search.focus();
            },
            0
        );
    }

    document
        .querySelectorAll(
            ".fairmont-clean-trigger"
        )
        .forEach(
            function (trigger) {

                trigger.addEventListener(
                    "click",
                    function (event) {

                        event.preventDefault();

                        const type =
                            trigger.getAttribute(
                                "data-clean-picker"
                            );

                        openPopup(
                            type,
                            trigger
                        );
                    }
                );
            }
        );

    countrySelect.addEventListener(
        "change",
        function () {

            updateBankOptions();

            updateTrigger(
                "country",
                countrySelect.value ||
                "Select country"
            );

            updateTrigger(
                "bank",
                "Select a bank"
            );
        }
    );

    bankSelect.addEventListener(
        "change",
        function () {

            updateTrigger(
                "bank",
                bankSelect.value ||
                "Select a bank"
            );
        }
    );

    currencySelect.addEventListener(
        "change",
        function () {

            const selected =
                currencySelect.options[
                    currencySelect.selectedIndex
                ];

            updateTrigger(
                "currency",
                selected && selected.value
                    ? selected.textContent
                    : "Select currency"
            );
        }
    );

    document.addEventListener(
        "click",
        function (event) {

            if (!activePopup) {
                return;
            }

            if (
                activePopup.contains(
                    event.target
                )
            ) {
                return;
            }

            if (
                activeTrigger &&
                activeTrigger.contains(
                    event.target
                )
            ) {
                return;
            }

            closePopup();
        }
    );

    document.addEventListener(
        "keydown",
        function (event) {

            if (event.key === "Escape") {
                closePopup();
            }
        }
    );

    window.addEventListener(
        "resize",
        function () {

            if (
                activePopup &&
                activeTrigger
            ) {
                positionPopup(
                    activeTrigger,
                    activePopup
                );
            }
        }
    );

    window.addEventListener(
        "scroll",
        function () {

            if (
                activePopup &&
                activeTrigger
            ) {
                positionPopup(
                    activeTrigger,
                    activePopup
                );
            }
        },
        true
    );

    updateBankOptions();

})();
</script>
"""

CLEAN_JS = CLEAN_JS.replace(
    "__BANK_DATA__",
    BANK_DATA_JSON
)

CLEAN_JS = CLEAN_JS.replace(
    "__COUNTRY_DATA__",
    COUNTRY_DATA_JSON
)


# ============================================================
# MAIN
# ============================================================

def main():

    print()
    print("==============================================")
    print("FAIRMONT INTERNATIONAL TRANSFER CLEAN REBUILD")
    print("==============================================")
    print()

    if not TEMPLATE.exists():
        print("ERROR: Template was not found:")
        print(TEMPLATE)
        sys.exit(1)

    original = TEMPLATE.read_text(
        encoding="utf-8"
    )

    print(
        "Original template size: {:,} characters".format(
            len(original)
        )
    )

    # --------------------------------------------------------
    # VERIFY REAL SELECTS BEFORE TOUCHING ANYTHING
    # --------------------------------------------------------

    required_selects = [
        "internationalCountry",
        "internationalBank",
        "internationalCurrency"
    ]

    matches = {}

    for select_id in required_selects:

        found = find_select(
            original,
            select_id
        )

        if not found:
            print(
                "ERROR: Could not find select: {}".format(
                    select_id
                )
            )
            print()
            print("NO FILE WAS CHANGED.")
            sys.exit(1)

        matches[select_id] = found

        print(
            "{}: FOUND".format(select_id)
        )

    print()

    # --------------------------------------------------------
    # BACKUP
    # --------------------------------------------------------

    timestamp = datetime.now().strftime(
        "%Y%m%d_%H%M%S"
    )

    backup = TEMPLATE.with_name(
        "international_transfer_BEFORE_CLEAN_REBUILD_{}.html".format(
            timestamp
        )
    )

    shutil.copy2(
        TEMPLATE,
        backup
    )

    print("Backup created:")
    print(backup.name)
    print()

    # --------------------------------------------------------
    # REMOVE OLD PICKER STYLE/SCRIPT BLOCKS
    # --------------------------------------------------------

    text = original

    text, removed_styles = remove_tag_blocks(
        text,
        "style",
        OLD_MARKERS
    )

    text, removed_scripts = remove_tag_blocks(
        text,
        "script",
        OLD_MARKERS
    )

    print(
        "Old picker style blocks removed: {}".format(
            removed_styles
        )
    )

    print(
        "Old picker script blocks removed: {}".format(
            removed_scripts
        )
    )

    print()

    # --------------------------------------------------------
    # RELOCATE SELECT MATCHES AFTER CLEANUP
    # --------------------------------------------------------

    # Replace fields one at a time, locating each select again
    # from the current text.

    try:

        text = replace_field(
            text,
            "internationalCountry",
            country_field
        )

        text = replace_field(
            text,
            "internationalBank",
            bank_field
        )

        text = replace_field(
            text,
            "internationalCurrency",
            currency_field
        )

    except Exception as exc:

        print(
            "ERROR while replacing fields:"
        )

        print(str(exc))
        print()
        print("NO FILE WAS CHANGED.")
        print(
            "Your backup is available at:"
        )
        print(backup.name)

        sys.exit(1)

    # --------------------------------------------------------
    # REMOVE ANY REMAINING OLD TRIGGER MARKUP
    # OUTSIDE THE THREE REAL FIELDS
    # --------------------------------------------------------

    old_trigger_patterns = [

        r'<button\b[^>]*class=["\'][^"\']*fairmont-final-trigger[^"\']*["\'][^>]*>.*?</button>',

        r'<button\b[^>]*class=["\'][^"\']*fairmont-picker-trigger[^"\']*["\'][^>]*>.*?</button>',

        r'<button\b[^>]*class=["\'][^"\']*fairmont-clean-trigger[^"\']*["\'][^>]*>.*?</button>',
    ]

    # We intentionally do NOT globally remove fairmont-clean-trigger
    # because the three new triggers must remain.
    # Therefore only the first two old trigger patterns are removed.

    for pattern in old_trigger_patterns[:2]:

        text = re.sub(
            pattern,
            "",
            text,
            flags=re.IGNORECASE | re.DOTALL
        )

    # --------------------------------------------------------
    # INSERT NEW CSS
    # --------------------------------------------------------

    if 'id="fairmont-clean-picker-css"' in text:

        text = re.sub(
            r'<style\b[^>]*id=["\']fairmont-clean-picker-css["\'][^>]*>.*?</style>',
            "",
            text,
            flags=re.IGNORECASE | re.DOTALL
        )

    if "</head>" in text.lower():

        head_match = re.search(
            r"</head>",
            text,
            re.IGNORECASE
        )

        insert_at = head_match.start()

        text = (
            text[:insert_at]
            + CLEAN_CSS
            + "\n"
            + text[insert_at:]
        )

    else:

        print(
            "ERROR: </head> was not found."
        )

        print()
        print("NO FILE WAS CHANGED.")
        sys.exit(1)

    # --------------------------------------------------------
    # INSERT NEW JAVASCRIPT
    # --------------------------------------------------------

    if 'id="fairmont-clean-picker-js"' in text:

        text = re.sub(
            r'<script\b[^>]*id=["\']fairmont-clean-picker-js["\'][^>]*>.*?</script>',
            "",
            text,
            flags=re.IGNORECASE | re.DOTALL
        )

    body_match = re.search(
        r"</body>",
        text,
        re.IGNORECASE
    )

    if not body_match:

        print(
            "ERROR: </body> was not found."
        )

        print()
        print("NO FILE WAS CHANGED.")
        sys.exit(1)

    insert_at = body_match.start()

    text = (
        text[:insert_at]
        + CLEAN_JS
        + "\n"
        + text[insert_at:]
    )

    # ========================================================
    # FINAL VALIDATION
    # ========================================================

    print("FINAL VALIDATION")
    print("================")

    validation_ok = True

    for select_id in required_selects:

        count = len(
            re.findall(
                r'<select\b[^>]*\bid=["\']'
                + re.escape(select_id)
                + r'["\']',
                text,
                flags=re.IGNORECASE
            )
        )

        print(
            "{}: {}".format(
                select_id,
                count
            )
        )

        if count != 1:
            validation_ok = False

    trigger_count = len(
        re.findall(
            r'class=["\'][^"\']*fairmont-clean-trigger',
            text,
            flags=re.IGNORECASE
        )
    )

    print(
        "clean triggers: {}".format(
            trigger_count
        )
    )

    if trigger_count != 3:
        validation_ok = False

    css_count = text.count(
        'id="fairmont-clean-picker-css"'
    )

    js_count = text.count(
        'id="fairmont-clean-picker-js"'
    )

    print(
        "clean CSS: {}".format(
            css_count
        )
    )

    print(
        "clean JS: {}".format(
            js_count
        )
    )

    # Old trigger classes must be completely gone.
    old_final_count = len(
        re.findall(
            r'fairmont-final-trigger',
            text,
            flags=re.IGNORECASE
        )
    )

    old_picker_count = len(
        re.findall(
            r'fairmont-picker-trigger',
            text,
            flags=re.IGNORECASE
        )
    )

    print(
        "old fairmont-final triggers: {}".format(
            old_final_count
        )
    )

    print(
        "old fairmont-picker triggers: {}".format(
            old_picker_count
        )
    )

    if old_final_count != 0:
        validation_ok = False

    if old_picker_count != 0:
        validation_ok = False

    if css_count != 1:
        validation_ok = False

    if js_count != 1:
        validation_ok = False

    print()

    if not validation_ok:

        print(
            "VALIDATION FAILED."
        )

        print(
            "NO FILE WAS CHANGED."
        )

        print(
            "Backup remains available:"
        )

        print(backup.name)

        sys.exit(1)

    # --------------------------------------------------------
    # WRITE ONLY AFTER SUCCESSFUL VALIDATION
    # --------------------------------------------------------

    TEMPLATE.write_text(
        text,
        encoding="utf-8"
    )

    print(
        "SUCCESS: International transfer pickers rebuilt."
    )

    print()
    print("The page now has:")
    print("  1. Country field")
    print("  1. Bank field")
    print("  1. Currency field")
    print()
    print("Search appears only after opening a field.")
    print("Bank choices change when the country changes.")
    print("No duplicate old picker buttons remain.")
    print()
    print("Backup:")
    print(backup.name)
    print()


if __name__ == "__main__":
    main()