from pathlib import Path
import re
import shutil
from datetime import datetime

BASE = Path(r"C:\Users\DON J\Documents\NewBankSite")
SETTINGS = BASE / "templates" / "settings.html"

# ---------------------------------------------------------
# BACKUP
# ---------------------------------------------------------

backup_dir = BASE / "login_otp_backup"
backup_dir.mkdir(exist_ok=True)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

shutil.copy2(
    SETTINGS,
    backup_dir / f"settings_before_card_fix_{timestamp}.bak"
)

# ---------------------------------------------------------
# READ SETTINGS PAGE
# ---------------------------------------------------------

text = SETTINGS.read_text(encoding="utf-8")

# Already fixed?
if "url_for('login_otp_settings')" in text:
    print()
    print("Login OTP card is already linked.")
    print()
    raise SystemExit(0)

# ---------------------------------------------------------
# FIND THE LOGIN OTP CARD
# ---------------------------------------------------------

position = text.find("Login OTP")

if position == -1:
    raise RuntimeError(
        "Could not find 'Login OTP' inside templates/settings.html."
    )

# Find the nearest opening settings-card before Login OTP.
opening = text.rfind(
    '<div class="settings-card"',
    0,
    position
)

if opening == -1:
    raise RuntimeError(
        "Could not find the opening Login OTP settings card."
    )

# Find the closing div after Login OTP.
closing = text.find("</div>", position)

if closing == -1:
    raise RuntimeError(
        "Could not find the closing Login OTP settings card."
    )

closing += len("</div>")

card = text[opening:closing]

# ---------------------------------------------------------
# CONVERT CARD TO LINK
# ---------------------------------------------------------

if "<div" not in card:
    raise RuntimeError(
        "The detected Login OTP card does not have the expected structure."
    )

card = card.replace(
    '<div class="settings-card"',
    '<a href="{{ url_for(\'login_otp_settings\') }}" '
    'class="settings-card" '
    'style="text-decoration:none; color:inherit;"',
    1
)

# Change only the outer closing tag.
card = card.rsplit(
    "</div>",
    1
)[0] + "</a>"

# ---------------------------------------------------------
# WRITE CHANGE
# ---------------------------------------------------------

text = (
    text[:opening]
    + card
    + text[closing:]
)

SETTINGS.write_text(
    text,
    encoding="utf-8"
)

print()
print("==============================================")
print("LOGIN OTP CARD FIXED")
print("==============================================")
print()
print("The Login OTP card now opens:")
print("  /settings/login-otp")
print()
print("No other Settings cards were changed.")
print("No dashboard design was changed.")
print()
print("Backup:")
print(backup_dir)
print()