from pathlib import Path
import shutil
import re

BASE_DIR = Path(__file__).resolve().parent
APP_FILE = BASE_DIR / "app.py"

if not APP_FILE.exists():
    print("ERROR: app.py was not found.")
    raise SystemExit(1)

text = APP_FILE.read_text(encoding="utf-8")

if "def live_chat():" in text:
    print("Live Chat route already exists.")
    raise SystemExit(0)

backup_file = BASE_DIR / "app.py.before_live_chat_route"
shutil.copy2(APP_FILE, backup_file)

route_block = r'''

# ============================================================
# FAIRmont BANK LIVE CHAT
# Customer Support Chat
# ============================================================

@app.route("/live-chat", methods=["GET", "POST"])
@login_required
def live_chat():

    # Find the customer's existing conversation.
    conversation = (
        LiveChatConversation.query
        .filter_by(customer_id=current_user.id)
        .order_by(LiveChatConversation.updated_at.desc())
        .first()
    )

    # Create the first conversation when the customer opens Live Chat.
    if conversation is None:
        conversation = LiveChatConversation(
            customer_id=current_user.id,
            status="Open",
            subject="Bank Support"
        )

        db.session.add(conversation)
        db.session.commit()

    if request.method == "POST":

        message_text = request.form.get("message", "").strip()

        if not message_text:
            return redirect(url_for("live_chat"))

        if len(message_text) > 2000:
            message_text = message_text[:2000]

        message = LiveChatMessage(
            conversation_id=conversation.id,
            sender_type="customer",
            sender_id=current_user.id,
            message=message_text,
            is_read=False
        )

        conversation.status = "Open"
        conversation.updated_at = datetime.utcnow()

        db.session.add(message)
        db.session.commit()

        return redirect(url_for("live_chat"))

    messages = (
        LiveChatMessage.query
        .filter_by(conversation_id=conversation.id)
        .order_by(LiveChatMessage.created_at.asc())
        .all()
    )

    # Mark bank/support replies as read once the customer opens the chat.
    unread_support_messages = (
        LiveChatMessage.query
        .filter_by(
            conversation_id=conversation.id,
            sender_type="support",
            is_read=False
        )
        .all()
    )

    for support_message in unread_support_messages:
        support_message.is_read = True

    if unread_support_messages:
        db.session.commit()

    return render_template(
        "live_chat.html",
        conversation=conversation,
        messages=messages
    )

'''

# Insert the route before the application's final app.run block.
run_pattern = re.compile(
    r'\nif\s+__name__\s*==\s*[\'"]__main__[\'"]\s*:\s*\n',
    re.MULTILINE
)

match = run_pattern.search(text)

if not match:
    print("ERROR: Could not find the final app.run block.")
    print("No changes were made.")
    raise SystemExit(1)

new_text = text[:match.start()] + route_block + text[match.start():]

APP_FILE.write_text(new_text, encoding="utf-8")

print("=" * 70)
print("LIVE CHAT CUSTOMER ROUTE ADDED")
print("=" * 70)
print()
print("Route:")
print("  /live-chat")
print()
print("Methods:")
print("  GET  - Open chat")
print("  POST - Send customer message")
print()
print("Existing banking routes were not intentionally changed.")
print()
print("Backup created:")
print(backup_file)
print("=" * 70)