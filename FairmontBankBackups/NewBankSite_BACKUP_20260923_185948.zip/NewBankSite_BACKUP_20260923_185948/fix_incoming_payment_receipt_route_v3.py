from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
APP_FILE = BASE_DIR / "app.py"

if not APP_FILE.exists():
    print("ERROR: app.py was not found.")
    raise SystemExit(1)

text = APP_FILE.read_text(encoding="utf-8")

route_start = text.find(
    '@app.route("/admin/incoming-payment", methods=["GET", "POST"])'
)

if route_start == -1:
    print("ERROR: Incoming payment route was not found.")
    raise SystemExit(1)

route_end = text.find(
    '\n\n\n  # ============================================================',
    route_start
)

if route_end == -1:
    print("ERROR: Could not determine the end of the incoming payment route.")
    raise SystemExit(1)

route = text[route_start:route_end]

# ------------------------------------------------------------
# Add previous balance and posting time.
# ------------------------------------------------------------

old_balance = '''        current_balance = float(
            receiver.account_balance or 0
        )

        new_balance = current_balance + amount
'''

new_balance = '''        previous_balance = float(
            receiver.account_balance or 0
        )

        new_balance = previous_balance + amount

        posted_at = datetime.now().strftime(
            "%d %B %Y, %H:%M:%S"
        )
'''

if "previous_balance = float(" not in route:

    if old_balance not in route:
        print("ERROR: Expected balance calculation was not found.")
        print("No changes were made.")
        raise SystemExit(1)

    route = route.replace(
        old_balance,
        new_balance,
        1
    )

# ------------------------------------------------------------
# Make sure the receipt receives the new values.
# ------------------------------------------------------------

old_render = '''            payment_reference=payment_reference,
            description=description,
            transaction_reference=transaction_reference,
            new_balance=new_balance
'''

new_render = '''            payment_reference=payment_reference,
            description=description,
            transaction_reference=transaction_reference,
            previous_balance=previous_balance,
            new_balance=new_balance,
            posted_at=posted_at
'''

if old_render not in route:
    print("ERROR: Expected receipt render block was not found.")
    print("No changes were made.")
    raise SystemExit(1)

route = route.replace(
    old_render,
    new_render,
    1
)

# ------------------------------------------------------------
# Write the corrected route back into app.py.
# ------------------------------------------------------------

text = (
    text[:route_start]
    + route
    + text[route_end:]
)

APP_FILE.write_text(
    text,
    encoding="utf-8"
)

print()
print("=" * 70)
print("INCOMING PAYMENT RECEIPT ROUTE UPDATED")
print("=" * 70)
print()
print("Added to the receipt:")
print("  - Previous balance")
print("  - New balance")
print("  - Posting date and time")
print()
print("Existing payment posting logic was preserved.")
print("No customer records were deleted or recreated.")
print()