from app import app, db, Bank

with app.app_context():

    bank = Bank.query.filter_by(name="Fairmont Bank").first()

    if not bank:
        raise SystemExit("ERROR: Fairmont Bank was not found.")

    print(f"Before: name={bank.name!r}, country={bank.country!r}, active={bank.active!r}")

    bank.country = "United Kingdom"
    bank.active = True

    db.session.commit()

    print(f"After:  name={bank.name!r}, country={bank.country!r}, active={bank.active!r}")
    print("SUCCESS: Fairmont Bank is now registered under United Kingdom.")