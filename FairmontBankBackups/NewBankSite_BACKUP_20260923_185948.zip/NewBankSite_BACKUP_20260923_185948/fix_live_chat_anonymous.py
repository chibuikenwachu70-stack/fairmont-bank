from pathlib import Path
import shutil

FILE = Path("app.py")

text = FILE.read_text(encoding="utf-8")

start = text.find('@app.route("/live-chat"')

if start == -1:
    print("ERROR: /live-chat route was not found.")
    raise SystemExit(1)

end = text.find("\n@app.route(", start + 1)

if end == -1:
    end = len(text)

old_route = text[start:end]

backup = Path("app.py.before_live_chat_anonymous_fix")
shutil.copy2(FILE, backup)

new_route = r'''@app.route("/live-chat", methods=["GET", "POST"])
def live_chat():
    """
    Fairmont Bank customer Live Chat.

    Logged-in customers use their existing bank customer conversation.
    Visitors who are not logged in can still open the Live Chat page
    without accessing current_user.id.
    """

    # ---------------------------------------------------------
    # LOGGED-IN CUSTOMER CHAT
    # ---------------------------------------------------------
    if current_user.is_authenticated:

        conversation = (
            LiveChatConversation.query
            .filter_by(
                customer_id=current_user.id,
                status="Open"
            )
            .order_by(LiveChatConversation.created_at.desc())
            .first()
        )

        if conversation is None:
            conversation = LiveChatConversation(
                customer_id=current_user.id,
                status="Open",
                subject="Bank Support"
            )
            db.session.add(conversation)
            db.session.commit()

        if request.method == "POST":
            message_text = request.form.get("message", "").strip()

            if message_text:
                if len(message_text) > 2000:
                    message_text = message_text[:2000]

                customer_message = LiveChatMessage(
                    conversation_id=conversation.id,
                    sender_type="customer",
                    sender_id=current_user.id,
                    message=message_text,
                    is_read=False,
                    created_at=datetime.utcnow()
                )

                conversation.updated_at = datetime.utcnow()

                db.session.add(customer_message)
                db.session.commit()

                return redirect(url_for("live_chat"))

        chat_messages = (
            LiveChatMessage.query
            .filter_by(conversation_id=conversation.id)
            .order_by(LiveChatMessage.created_at.asc())
            .all()
        )

        # Mark support messages as read when the customer opens the chat.
        unread_support = (
            LiveChatMessage.query
            .filter_by(
                conversation_id=conversation.id,
                sender_type="support",
                is_read=False
            )
            .all()
        )

        for message in unread_support:
            message.is_read = True

        if unread_support:
            db.session.commit()

        return render_template(
            "live_chat.html",
            conversation=conversation,
            chat_messages=chat_messages,
            is_authenticated=True
        )

    # ---------------------------------------------------------
    # NOT LOGGED IN
    # ---------------------------------------------------------
    # The page can open from the login screen, but we do not
    # attach an anonymous visitor to a customer account.
    return render_template(
        "live_chat.html",
        conversation=None,
        chat_messages=[],
        is_authenticated=False
    )
'''

text = text[:start] + new_route + text[end:]

FILE.write_text(text, encoding="utf-8")

print("=" * 70)
print("LIVE CHAT ANONYMOUS ACCESS FIXED")
print("=" * 70)
print()
print("Logged-in customers:")
print("  Existing customer conversation is used.")
print()
print("Visitors:")
print("  Live Chat page can now open without a customer login.")
print()
print("Existing conversations and database records were not deleted.")
print()
print("Backup created:")
print(backup)