from pathlib import Path
import shutil

FILE = Path("app.py")

text = FILE.read_text(encoding="utf-8")

backup = Path("app.py.before_live_chat_subject")
shutil.copy2(FILE, backup)

# ---------------------------------------------------------
# 1. Replace conversation creation
# ---------------------------------------------------------

old_conversation = '''        if conversation is None:
            conversation = LiveChatConversation(
                customer_id=current_user.id,
                status="Open",
                subject="Bank Support"
            )
            db.session.add(conversation)
            db.session.commit()
'''

new_conversation = '''        if conversation is None:
            conversation_subject = request.form.get(
                "subject",
                ""
            ).strip()

            if request.method == "POST" and not conversation_subject:
                return render_template(
                    "live_chat.html",
                    conversation=None,
                    chat_messages=[],
                    is_authenticated=True,
                    subject_error="Please enter a subject or reason for contacting Fairmont Bank Support."
                )

            if len(conversation_subject) > 200:
                conversation_subject = conversation_subject[:200]

            conversation = LiveChatConversation(
                customer_id=current_user.id,
                status="Open",
                subject=conversation_subject or "Bank Support"
            )

            db.session.add(conversation)
            db.session.commit()
'''

if old_conversation not in text:
    print("=" * 70)
    print("ERROR: Existing Live Chat conversation creation block was not found.")
    print("=" * 70)
    print()
    print("Backup created:")
    print(backup)
    raise SystemExit(1)

text = text.replace(old_conversation, new_conversation, 1)


# ---------------------------------------------------------
# 2. Add subject_error to normal authenticated render
# ---------------------------------------------------------

old_render = '''        return render_template(
            "live_chat.html",
            conversation=conversation,
            chat_messages=chat_messages,
            is_authenticated=True,
            success_message=success_message
        )'''

new_render = '''        return render_template(
            "live_chat.html",
            conversation=conversation,
            chat_messages=chat_messages,
            is_authenticated=True,
            success_message=success_message,
            subject_error=None
        )'''

if old_render not in text:
    print("=" * 70)
    print("ERROR: Authenticated Live Chat render block was not found.")
    print("=" * 70)
    print()
    print("Backup created:")
    print(backup)
    raise SystemExit(1)

text = text.replace(old_render, new_render, 1)


FILE.write_text(text, encoding="utf-8")

print("=" * 70)
print("LIVE CHAT SUBJECT SUPPORT ADDED")
print("=" * 70)
print()
print("Customers can now provide a subject when starting")
print("a new Live Chat conversation.")
print()
print("The existing database is preserved.")
print()
print("Backup created:")
print(backup)