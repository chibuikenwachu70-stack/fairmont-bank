from pathlib import Path

BASE_DIR = Path(r"C:\Users\DON J\Documents\NewBankSite")
APP_FILE = BASE_DIR / "app.py"


text = APP_FILE.read_text(encoding="utf-8")


# =========================================================
# ADD IMPORTS
# =========================================================

old_import = "from flask import Flask, render_template, request, session, redirect"

new_import = "from flask import Flask, render_template, request, session, redirect, url_for"

if old_import in text and "url_for" not in old_import:
    text = text.replace(
        old_import,
        new_import,
        1
    )


# =========================================================
# ADD DATETIME IMPORT
# =========================================================

if "from datetime import datetime" not in text:

    marker = "import os"

    if marker in text:

        text = text.replace(
            marker,
            marker + "\nfrom datetime import datetime",
            1
        )


# =========================================================
# ADD TRANSACTION MODEL
# =========================================================

transaction_model = '''

# =========================================================
# TRANSACTION MODEL
# =========================================================

class Transaction(db.Model):

    id = db.Column(
        db.Integer,
        primary_key=True
    )

    transaction_reference = db.Column(
        db.String(40),
        unique=True,
        nullable=False
    )

    customer_id = db.Column(
        db.String(20),
        nullable=False,
        index=True
    )

    transaction_type = db.Column(
        db.String(40),
        nullable=False
    )

    direction = db.Column(
        db.String(20),
        nullable=False
    )

    amount = db.Column(
        db.Float,
        nullable=False
    )

    balance_after = db.Column(
        db.Float,
        nullable=False
    )

    description = db.Column(
        db.String(255),
        nullable=False
    )

    counterparty = db.Column(
        db.String(150),
        nullable=True
    )

    status = db.Column(
        db.String(30),
        nullable=False,
        default="Completed"
    )

    created_at = db.Column(
        db.DateTime,
        nullable=False,
        default=datetime.utcnow
    )

'''


if "class Transaction(db.Model):" not in text:

    customer_model_marker = "# =========================================================\n# CUSTOMER ID GENERATOR"

    if customer_model_marker not in text:

        print("ERROR: Could not find Customer ID Generator section.")

        raise SystemExit(1)

    text = text.replace(
        customer_model_marker,
        transaction_model + "\n" + customer_model_marker,
        1
    )

    print("SUCCESS: Transaction model added.")

else:

    print("Transaction model already exists.")


# =========================================================
# ADD TRANSACTION REFERENCE GENERATOR
# =========================================================

reference_function = '''

# =========================================================
# TRANSACTION REFERENCE GENERATOR
# =========================================================

def generate_transaction_reference():

    while True:

        reference = (
            "FT"
            + datetime.utcnow().strftime("%Y%m%d%H%M%S")
            + secrets.token_hex(3).upper()
        )

        existing = Transaction.query.filter_by(
            transaction_reference=reference
        ).first()

        if existing is None:

            return reference

'''


if "def generate_transaction_reference():" not in text:

    marker = "# =========================================================\n# HOME"

    if marker not in text:

        print("ERROR: Could not find HOME section.")

        raise SystemExit(1)

    text = text.replace(
        marker,
        reference_function + "\n" + marker,
        1
    )

    print("SUCCESS: Transaction reference generator added.")

else:

    print("Transaction reference generator already exists.")


# =========================================================
# ADD TRANSACTION HISTORY ROUTE
# =========================================================

history_route = '''

# =========================================================
# TRANSACTION HISTORY
# =========================================================

@app.route("/transactions")
def transactions():

    customer_id = session.get("customer_id")

    if not customer_id:

        return render_template(
            "login.html",
            error="Please sign in to view your transactions."
        )

    customer = Customer.query.filter_by(
        customer_id=customer_id
    ).first()

    if customer is None:

        session.clear()

        return render_template(
            "login.html",
            error="Your session could not be verified. Please sign in again."
        )

    transaction_list = (
        Transaction.query
        .filter_by(customer_id=customer.customer_id)
        .order_by(Transaction.created_at.desc())
        .all()
    )

    return render_template(
        "transactions.html",
        customer=customer,
        transactions=transaction_list
    )


'''


if '@app.route("/transactions")' not in text:

    marker = "# =========================================================\n# MY PROFILE"

    if marker not in text:

        print("ERROR: Could not find MY PROFILE section.")

        raise SystemExit(1)

    text = text.replace(
        marker,
        history_route + marker,
        1
    )

    print("SUCCESS: Transaction History route added.")

else:

    print("Transaction History route already exists.")


# =========================================================
# ADD TRANSACTION DETAILS ROUTE
# =========================================================

details_route = '''

# =========================================================
# TRANSACTION DETAILS
# =========================================================

@app.route("/transaction/<transaction_reference>")
def transaction_details(transaction_reference):

    customer_id = session.get("customer_id")

    if not customer_id:

        return render_template(
            "login.html",
            error="Please sign in to view this transaction."
        )

    transaction = Transaction.query.filter_by(
        transaction_reference=transaction_reference,
        customer_id=customer_id
    ).first()

    if transaction is None:

        return (
            "Transaction not found.",
            404
        )

    customer = Customer.query.filter_by(
        customer_id=customer_id
    ).first()

    return render_template(
        "transaction_details.html",
        customer=customer,
        transaction=transaction
    )


'''


if '@app.route("/transaction/<transaction_reference>")' not in text:

    marker = "# =========================================================\n# MY PROFILE"

    text = text.replace(
        marker,
        details_route + marker,
        1
    )

    print("SUCCESS: Transaction Details route added.")

else:

    print("Transaction Details route already exists.")


# =========================================================
# MAKE DATABASE CREATE ALL
# =========================================================

if "db.create_all()" not in text:

    print("WARNING: db.create_all() was not found.")
    print("The existing application should already create tables on startup.")


# =========================================================
# SAVE
# =========================================================

APP_FILE.write_text(
    text,
    encoding="utf-8"
)


print()
print("==============================================")
print("TRANSACTION SYSTEM FOUNDATION ADDED")
print("==============================================")
print()
print("Added:")
print(" - Transaction database model")
print(" - Transaction reference generator")
print(" - Transaction History route")
print(" - Transaction Details route")
print()
print("Existing customer data was not changed.")
print("Existing dashboard design was not changed.")
print()