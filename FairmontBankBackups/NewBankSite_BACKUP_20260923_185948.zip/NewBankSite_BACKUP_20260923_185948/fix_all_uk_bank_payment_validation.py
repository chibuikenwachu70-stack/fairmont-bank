from pathlib import Path

APP = Path("app.py")

text = APP.read_text(encoding="utf-8-sig")

old = '''    bank = Bank.query.filter(
        Bank.name == bank_name,
        Bank.country.in_(["UK", "United Kingdom"]),
        Bank.active.is_(True)
    ).first()

    if not bank:
        flash("The selected UK bank is not available.", "error")
        return redirect(url_for("send_money"))
'''

new = '''    # UK bank names come from the Fairmont UK bank selector.
    # Do not require every selector option to exist in the
    # optional Bank database table.
    #
    # The important validation here is that the customer actually
    # selected a bank. The selected bank name is then stored with
    # the payment request.

    if not bank_name:
        flash("Please select a UK bank.", "error")
        return redirect(url_for("send_money"))
'''

if old not in text:
    raise RuntimeError(
        "ERROR: The current UK bank validation block was not found. "
        "No changes were made."
    )

text = text.replace(old, new, 1)

APP.write_text(text, encoding="utf-8")

print("SUCCESS: UK bank payment validation fixed for all selector banks.")