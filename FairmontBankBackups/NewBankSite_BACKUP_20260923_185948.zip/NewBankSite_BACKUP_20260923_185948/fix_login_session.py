from pathlib import Path

path = Path("app.py")
text = path.read_text(encoding="utf-8")

old = '''        session.clear()

        login_user(customer)

        session["customer_id"] = customer.customer_id
'''

new = '''        login_user(customer)

        session["customer_id"] = customer.customer_id
'''

if old not in text:
    print("ERROR: Expected login session block was not found.")
    raise SystemExit(1)

text = text.replace(old, new, 1)

path.write_text(text, encoding="utf-8")

print("SUCCESS: Login session handling updated.")