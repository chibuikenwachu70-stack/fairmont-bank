from pathlib import Path
import re
import shutil

BASE = Path(r"C:\Users\DON J\Documents\NewBankSite")
TEMPLATES = BASE / "templates"
LOGO = "images/fairmont-bank-logo.png"

# Files that are old backups or temporary copies must never be modified.
EXCLUDED_WORDS = (
    "backup",
    "before",
    "BEFORE",
    "removed",
    "old",
)

def is_active_template(path):
    name = path.name.lower()

    if not name.endswith(".html"):
        return False

    for word in EXCLUDED_WORDS:
        if word.lower() in name:
            return False

    return True


logo_block = """<div class="fairmont-page-brand">
    <img
        src="{{ url_for('static', filename='images/fairmont-bank-logo.png') }}"
        alt="Fairmont Bank"
        class="fairmont-page-logo">
</div>"""


css_block = """
<style id="fairmont-universal-logo">
.fairmont-page-brand {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    margin: 0 auto 20px auto;
}

.fairmont-page-logo {
    display: block;
    width: 190px;
    max-width: 75%;
    height: auto;
    object-fit: contain;
}
</style>
"""


changed_files = []
skipped_files = []

for file in sorted(TEMPLATES.glob("*.html")):

    if not is_active_template(file):
        continue

    try:
        text = file.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        skipped_files.append((file.name, "encoding"))
        continue

    original = text

    # Match simple actual brand-name blocks only.
    pattern = re.compile(
        r'<div\s+class=["\']brand-name["\'][^>]*>'
        r'.*?'
        r'</div>',
        re.IGNORECASE | re.DOTALL
    )

    if not pattern.search(text):
        continue

    # Never touch a page that already contains the exact image logo
    # inside the same branding area.
    text = pattern.sub(logo_block, text)

    # Add universal logo styling once.
    if text != original and "fairmont-universal-logo" not in text:
        head_match = re.search(r"</head>", text, re.IGNORECASE)

        if head_match:
            text = (
                text[:head_match.start()]
                + css_block
                + "\n"
                + text[head_match.start():]
            )

    if text != original:
        backup = file.with_suffix(file.suffix + ".before_universal_logo")
        shutil.copy2(file, backup)

        file.write_text(text, encoding="utf-8")

        changed_files.append(file.name)


print()
print("=" * 70)
print("FAIRMONT BANK LOGO STANDARDIZATION")
print("=" * 70)
print()

print(f"Logo source:")
print(BASE / "static" / LOGO)
print()

if changed_files:
    print("UPDATED ACTIVE TEMPLATES:")
    for name in changed_files:
        print(f"  - {name}")
else:
    print("No additional simple brand-name blocks required replacement.")

print()

if skipped_files:
    print("SKIPPED:")
    for name, reason in skipped_files:
        print(f"  - {name} ({reason})")

print()
print("IMPORTANT:")
print("The dashboard and login logo structures were not redesigned.")
print("Old backup templates were not modified.")
print("Forms, routes, database logic and transaction functionality were not modified.")
print()
print("Logo standardization complete.")
print("=" * 70)