from pathlib import Path

path = Path("templates/admin_dashboard.html")
text = path.read_text(encoding="utf-8")

if "url_for('admin_payment_approvals')" in text or 'url_for("admin_payment_approvals")' in text:
    print("Payment Approvals link already exists.")
    raise SystemExit(0)

# Add a Payment Approvals sidebar link immediately after Transaction Management.
sidebar_marker = 'href="{{ url_for("admin_transactions") }}"'

if sidebar_marker in text:
    replacement = sidebar_marker + '''
                        <a href="{{ url_for("admin_payment_approvals") }}" class="admin-sidebar-link">
                            <span class="admin-sidebar-icon">✓</span>
                            <span>
                                <strong>Payment Approvals</strong>
                                <small>Review pending payments</small>
                            </span>
                        </a>'''
    text = text.replace(sidebar_marker, replacement, 1)
else:
    print("WARNING: Sidebar Transaction Management link was not found.")

# Add a main dashboard action immediately after Transaction Management.
main_marker = 'href="{{ url_for("admin_transactions") }}"'

# Find the second occurrence if there is one.
first_position = text.find(main_marker)
second_position = text.find(main_marker, first_position + len(main_marker)) if first_position >= 0 else -1

if second_position >= 0:
    insertion = '''
                    <a href="{{ url_for("admin_payment_approvals") }}" class="admin-action-card">
                        <div class="admin-action-icon">✓</div>
                        <div>
                            <h3>Payment Approvals</h3>
                            <p>Review and approve pending customer payments.</p>
                        </div>
                    </a>
'''
    text = text[:second_position + len(main_marker)] + insertion + text[second_position + len(main_marker):]
elif "Payment Approvals" not in text:
    print("WARNING: Main Transaction Management action could not be located.")

path.write_text(text, encoding="utf-8")

print("SUCCESS: Payment Approvals added to the admin dashboard.")