from pathlib import Path
import shutil

BASE = Path(r"C:\Users\DON J\Documents\NewBankSite")
FILE = BASE / "templates" / "login.html"

backup = FILE.with_suffix(".html.logo_backup")
shutil.copy2(FILE, backup)

text = FILE.read_text(encoding="utf-8")

# Remove the old text-only Fairmont Bank branding if present.
old_patterns = [
    '<div class="login-brand">FAIRMONT BANK</div>',
    '<div class="login-brand">Fairmont Bank</div>',
    '<div class="login-brand">FAIRMONT BANK</div>',
]

for old in old_patterns:
    text = text.replace(old, '')

# If the existing login-brand element is still present,
# replace its contents with the same logo used by the dashboard.
marker = '<div class="login-brand">'

start = text.find(marker)

if start != -1:
    end = text.find("</div>", start)

    if end == -1:
        print("ERROR: Could not find the end of the login-brand element.")
        raise SystemExit(1)

    end += len("</div>")

    new_brand = """<div class="login-brand">
    <img
        src="{{ url_for('static', filename='images/fairmont-bank-logo.png') }}"
        alt="Fairmont Bank"
        class="login-fairmont-logo">
</div>"""

    text = text[:start] + new_brand + text[end:]

else:
    # Add the logo immediately before CUSTOMER BANKING.
    customer_marker = "CUSTOMER BANKING"

    pos = text.find(customer_marker)

    if pos == -1:
        print("ERROR: CUSTOMER BANKING section was not found.")
        raise SystemExit(1)

    new_brand = """<div class="login-brand">
    <img
        src="{{ url_for('static', filename='images/fairmont-bank-logo.png') }}"
        alt="Fairmont Bank"
        class="login-fairmont-logo">
</div>

"""

    text = text[:pos] + new_brand + text[pos:]

# Add styling without changing the rest of the login page.
style = """
<style id="fairmont-login-logo-fix">
.login-brand {
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    width: 100% !important;
    margin: 0 auto 18px auto !important;
    background: transparent !important;
    padding: 0 !important;
    border: 0 !important;
}

.login-fairmont-logo {
    display: block !important;
    width: auto !important;
    max-width: 260px !important;
    height: auto !important;
    max-height: 90px !important;
    object-fit: contain !important;
}
</style>
"""

if "fairmont-login-logo-fix" not in text:
    head_end = text.find("</head>")

    if head_end == -1:
        print("ERROR: </head> was not found.")
        raise SystemExit(1)

    text = text[:head_end] + style + "\n" + text[head_end:]

FILE.write_text(text, encoding="utf-8")

print("SUCCESS: Login page now uses the same Fairmont Bank logo as the dashboard.")
print(f"Backup created: {backup.name}")