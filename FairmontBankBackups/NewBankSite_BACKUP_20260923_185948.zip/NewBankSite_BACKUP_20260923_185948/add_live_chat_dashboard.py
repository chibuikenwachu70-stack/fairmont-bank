from pathlib import Path
import shutil
import re

BASE_DIR = Path(__file__).resolve().parent
DASHBOARD_FILE = BASE_DIR / "templates" / "dashboard.html"

if not DASHBOARD_FILE.exists():
    print("ERROR: templates\\dashboard.html was not found.")
    raise SystemExit(1)

text = DASHBOARD_FILE.read_text(encoding="utf-8")

if 'href="/live-chat"' in text:
    print("Live Chat dashboard service is already present.")
    raise SystemExit(0)

backup_file = BASE_DIR / "templates" / "dashboard.html.before_live_chat"
shutil.copy2(DASHBOARD_FILE, backup_file)

live_chat_card = r'''
                    <!-- Live Chat -->
                    <a
                        href="/live-chat"
                        class="service-item">

                        <span class="service-icon">
                            ?
                        </span>

                        <span class="service-name">
                            Live<br>
                            Chat
                        </span>

                    </a>


'''

# Put Live Chat immediately after Send Money.
pattern = re.compile(
    r'(\s*<!-- Send Money -->.*?</a>\s*)',
    re.IGNORECASE | re.DOTALL
)

match = pattern.search(text)

if not match:
    print("ERROR: Could not find the Send Money service card.")
    print("No changes were made.")
    raise SystemExit(1)

new_text = (
    text[:match.end()]
    + live_chat_card
    + text[match.end():]
)

DASHBOARD_FILE.write_text(new_text, encoding="utf-8")

print("=" * 70)
print("LIVE CHAT ADDED TO FAIRmont BANK DASHBOARD")
print("=" * 70)
print()
print("Added service:")
print("  Live Chat")
print()
print("Link:")
print("  /live-chat")
print()
print("Position:")
print("  Immediately after Send Money")
print()
print("Dashboard design and existing service cards were preserved.")
print()
print("Backup created:")
print(backup_file)
print("=" * 70)