from pathlib import Path

path = Path("templates/dashboard.html")
text = path.read_text(encoding="utf-8")

start_marker = "<!-- Bank Statement -->"
end_marker = "<!-- Flights and Travels -->"

start = text.find(start_marker)
end = text.find(end_marker, start)

if start == -1:
    print("ERROR: Bank Statement marker not found.")
    raise SystemExit(1)

if end == -1:
    print("ERROR: Flights and Travels marker not found.")
    raise SystemExit(1)

new_block = """                    <!-- Bank Statement -->

                    <a
                        href="/bank-statements"
                        class="service-item">

                        <span class="service-icon">
                            â–¡
                        </span>

                        <span class="service-name">
                            Bank<br>
                            Statement
                        </span>

                    </a>


"""

text = text[:start] + new_block + text[end:]

path.write_text(text, encoding="utf-8")

print("SUCCESS: Bank Statement card rebuilt correctly.")