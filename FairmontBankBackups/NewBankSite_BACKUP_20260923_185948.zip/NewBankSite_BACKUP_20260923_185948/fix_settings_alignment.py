from pathlib import Path
import re

path = Path("templates/settings.html")

html = path.read_text(encoding="utf-8")

start_marker = "    <!-- LOGIN OTP -->"
end_marker = "    <!-- BANK STATEMENTS -->"

start = html.find(start_marker)
end = html.find(end_marker)

if start == -1:
    print("ERROR: LOGIN OTP section was not found.")
    raise SystemExit(1)

if end == -1:
    print("ERROR: BANK STATEMENTS section was not found.")
    raise SystemExit(1)

section = html[start:end]

# Find the Login OTP closing </a>
login_close = section.find("</a>")

if login_close == -1:
    print("ERROR: Login OTP closing </a> was not found.")
    raise SystemExit(1)

login_close += len("</a>")

# Keep everything through the </a>, then remove any
# accidental extra HTML that appeared after it.
clean_section = section[:login_close] + "\n\n"

html = html[:start] + clean_section + html[end:]

path.write_text(html, encoding="utf-8")

print("SUCCESS: Settings alignment fixed.")
print("Removed the extra broken HTML after Login OTP.")
print("The seven Settings cards now have the same structure.")