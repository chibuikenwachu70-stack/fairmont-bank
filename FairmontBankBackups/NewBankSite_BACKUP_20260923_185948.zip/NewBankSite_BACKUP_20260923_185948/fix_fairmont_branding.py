from pathlib import Path

file = Path("templates/dashboard.html")

if not file.exists():
    raise SystemExit("ERROR: templates/dashboard.html was not found.")

text = file.read_text(encoding="utf-8")

old_notification = """<span class="dashboard-notification-icon">
                        ♢
                    </span>"""

new_notification = """<span class="dashboard-notification-icon" aria-hidden="true">
                        <svg
                            viewBox="0 0 24 24"
                            width="24"
                            height="24"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="1.8"
                            stroke-linecap="round"
                            stroke-linejoin="round">
                            <path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"></path>
                            <path d="M10 21h4"></path>
                        </svg>
                    </span>"""

if old_notification not in text:
    raise SystemExit(
        "ERROR: The existing notification diamond was not found. "
        "No changes were made."
    )

text = text.replace(old_notification, new_notification, 1)

old_brand = """<p class="dashboard-eyebrow">
                    FAIRMONT BANK
                </p>"""

new_brand = """<div class="fairmont-dashboard-brand">
                    <img
                        src="{{ url_for('static', filename='images/fairmont-bank-logo.png') }}"
                        alt="Fairmont Bank"
                        class="fairmont-dashboard-logo">
                </div>"""

if old_brand not in text:
    raise SystemExit(
        "ERROR: The existing FAIRMONT BANK branding was not found. "
        "No changes were made."
    )

text = text.replace(old_brand, new_brand, 1)

css_marker = "</style>"

css = """
<style id="fairmont-branding-notification-fix">

.dashboard-notification-button {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
}

.dashboard-notification-icon {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 100%;
}

.dashboard-notification-icon svg {
    width: 24px;
    height: 24px;
    display: block;
}

.fairmont-dashboard-brand {
    display: flex;
    align-items: center;
    margin-top: 4px;
    margin-bottom: 10px;
}

.fairmont-dashboard-logo {
    display: block;
    width: 175px;
    height: auto;
    max-width: 100%;
    object-fit: contain;
}

@media (max-width: 600px) {
    .fairmont-dashboard-logo {
        width: 155px;
    }
}

</style>
"""

if 'id="fairmont-branding-notification-fix"' not in text:
    if css_marker not in text:
        raise SystemExit(
            "ERROR: Could not find a safe location for the branding CSS."
        )

    text = text.replace(
        css_marker,
        css + "\n" + css_marker,
        1
    )

file.write_text(text, encoding="utf-8")

print("SUCCESS: Notification diamond replaced with a bell icon.")
print("SUCCESS: Fairmont Bank branding replaced with the supplied logo.")
print("SUCCESS: Existing dashboard layout and services were left unchanged.")