from pathlib import Path

APP = Path("app.py")

text = APP.read_text(encoding="utf-8-sig")

# Make sure the function exists.
if "def admin_incoming_payment():" not in text:
    raise RuntimeError(
        "ERROR: admin_incoming_payment() was not found in app.py."
    )

# Remove an old copy of this repair if it was previously added.
marker = "# FAIRMont_ADMIN_INCOMING_ENDPOINT_FIX"

if marker in text:
    text = text.split(marker)[0].rstrip() + "\n"

repair = r'''

# FAIRMont_ADMIN_INCOMING_ENDPOINT_FIX
#
# Explicitly register the existing admin incoming-payment function
# under the endpoint name used by admin_dashboard.html.
#
# This repairs the endpoint without changing the existing payment
# processing logic.

if "admin_incoming_payment" not in app.view_functions:

    app.add_url_rule(
        "/admin/incoming-payment",
        endpoint="admin_incoming_payment",
        view_func=admin_incoming_payment,
        methods=["GET", "POST"]
    )

'''

# Insert before the application startup block.
startup_marker = '\nif __name__ == "__main__":'

if startup_marker not in text:
    raise RuntimeError(
        "ERROR: Could not find the app startup section."
    )

text = text.replace(
    startup_marker,
    repair + startup_marker,
    1
)

APP.write_text(
    text,
    encoding="utf-8"
)

print("SUCCESS: admin_incoming_payment endpoint registration repaired.")