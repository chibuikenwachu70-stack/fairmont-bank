from pathlib import Path
import shutil

FILE = Path("app.py")

text = FILE.read_text(encoding="utf-8")

if "sender_type" in text and "class BankMessage" in text:
    print("=" * 70)
    print("BANK MESSAGE SENDER FIELD ALREADY EXISTS IN app.py")
    print("=" * 70)
else:
    backup = Path("app.py.before_bank_message_sender")
    shutil.copy2(FILE, backup)

    marker = '''    subject = db.Column(
        db.String(200),
        nullable=False
    )
'''

    replacement = '''    subject = db.Column(
        db.String(200),
        nullable=False
    )

    sender_type = db.Column(
        db.String(20),
        nullable=False,
        default="customer"
    )
'''

    if marker not in text:
        print("ERROR: BankMessage subject field was not found.")
        print("Backup created:", backup)
        raise SystemExit(1)

    text = text.replace(marker, replacement, 1)

    FILE.write_text(text, encoding="utf-8")

    print("=" * 70)
    print("BANK MESSAGE SENDER FIELD ADDED TO MODEL")
    print("=" * 70)
    print()
    print("Backup created:")
    print(backup)

print()
print("Now creating the database column...")