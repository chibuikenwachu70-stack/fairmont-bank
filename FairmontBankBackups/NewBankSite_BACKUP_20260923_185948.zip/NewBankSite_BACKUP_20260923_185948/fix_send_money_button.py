from pathlib import Path

BASE_DIR = Path(r"C:\Users\DON J\Documents\NewBankSite")
FILE = BASE_DIR / "templates" / "dashboard.html"

text = FILE.read_text(encoding="utf-8")

start = text.find("<!-- Send Money -->")

if start == -1:
    raise SystemExit("ERROR: Send Money section was not found.")

# Find the next service-item closing anchor after the Send Money comment.
end = text.find("</a>", start)

if end == -1:
    raise SystemExit("ERROR: Send Money link closing tag was not found.")

end += len("</a>")

section = text[start:end]

print("Current Send Money section:")
print("--------------------------------")
print(section)
print("--------------------------------")

# Replace only the href inside this specific section.
if 'href="/send-money"' in section:
    print("Send Money button is already connected to /send-money.")

elif 'href="#"' in section:

    section = section.replace(
        'href="#"',
        'href="/send-money"',
        1
    )

    text = text[:start] + section + text[end:]

    FILE.write_text(
        text,
        encoding="utf-8"
    )

    print("SUCCESS: Send Money button connected to /send-money.")

else:
    raise SystemExit(
        "ERROR: The Send Money section does not contain the expected href."
    )