from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DASHBOARD = BASE_DIR / "templates" / "admin_dashboard.html"

if not DASHBOARD.exists():
    print("ERROR: admin_dashboard.html was not found.")
    raise SystemExit(1)

html = DASHBOARD.read_text(encoding="utf-8")

new_action = '''<a href="{{ url_for("admin_create_customer") }}" class="action">
    <div class="action-title">
        Create Customer Account
    </div>
    <div class="action-text">
        Create a new Fairmont customer account with optional initial funding.
    </div>
</a>
'''

# Do not add it twice.
if 'url_for("admin_create_customer")' in html:
    print()
    print("=" * 70)
    print("CREATE CUSTOMER ACCOUNT ACTION ALREADY EXISTS")
    print("=" * 70)
    raise SystemExit(0)

# Prefer inserting immediately after Post Incoming Payment.
post_payment_marker = '''</a>'''

post_payment_position = html.find(
    'url_for("admin_incoming_payment")'
)

if post_payment_position != -1:
    closing_tag = html.find("</a>", post_payment_position)

    if closing_tag != -1:
        insert_position = closing_tag + len("</a>")
        html = (
            html[:insert_position]
            + "\n\n"
            + new_action
            + html[insert_position:]
        )
    else:
        print("ERROR: Could not locate the end of Post Incoming Payment.")
        raise SystemExit(1)

else:
    # Fallback: insert after Account Management.
    account_position = html.find(
        'url_for("admin_accounts")'
    )

    if account_position == -1:
        print(
            "ERROR: Could not find Account Management or "
            "Post Incoming Payment."
        )
        raise SystemExit(1)

    closing_tag = html.find("</a>", account_position)

    if closing_tag == -1:
        print("ERROR: Could not locate the Account Management closing tag.")
        raise SystemExit(1)

    insert_position = closing_tag + len("</a>")

    html = (
        html[:insert_position]
        + "\n\n"
        + new_action
        + html[insert_position:]
    )

DASHBOARD.write_text(html, encoding="utf-8")

print()
print("=" * 70)
print("CREATE CUSTOMER ACCOUNT ACTION ADDED")
print("=" * 70)
print()
print("Administration Portal now includes:")
print("  - Customer Management")
print("  - Transaction Management")
print("  - Account Management")
print("  - Post Incoming Payment")
print("  - Create Customer Account")
print()
print("Existing dashboard actions were preserved.")
print()