from pathlib import Path
import re

BASE = Path(__file__).resolve().parent
APP = BASE / "app.py"
TEMPLATES = BASE / "templates"

app_text = APP.read_text(encoding="utf-8")

# ---------------------------------------------------------
# Add Data Bundles route
# ---------------------------------------------------------

if '@app.route("/data-bundles"' in app_text:
    print("Data Bundles route already exists.")
else:
    marker = '\nif __name__ == "__main__":'

    route = r'''

@app.route("/data-bundles", methods=["GET", "POST"])
@login_required
def data_bundles():
    customer = current_user

    networks = [
        "EE",
        "O2",
        "Vodafone",
        "Three UK",
        "Tesco Mobile",
        "giffgaff",
        "Lebara",
        "Lycamobile",
        "Other Mobile Network"
    ]

    bundles = [
        {"name": "500 MB", "amount": 2.00},
        {"name": "1 GB", "amount": 5.00},
        {"name": "2 GB", "amount": 8.00},
        {"name": "5 GB", "amount": 12.00},
        {"name": "10 GB", "amount": 18.00},
        {"name": "20 GB", "amount": 25.00},
        {"name": "30 GB", "amount": 30.00},
        {"name": "50 GB", "amount": 40.00},
    ]

    if request.method == "GET":
        return render_template(
            "data_bundles.html",
            customer=customer,
            networks=networks,
            bundles=bundles
        )

    provider = request.form.get("provider", "").strip()
    phone_number = request.form.get("phone_number", "").strip()
    bundle_name = request.form.get("bundle_name", "").strip()
    payment_reference = request.form.get("payment_reference", "").strip()

    errors = []

    if provider not in networks:
        errors.append("Please select a mobile network.")

    if not phone_number:
        errors.append("Please enter the mobile phone number.")

    selected_bundle = None

    for bundle in bundles:
        if bundle["name"] == bundle_name:
            selected_bundle = bundle
            break

    if selected_bundle is None:
        errors.append("Please select a valid data bundle.")

    amount = selected_bundle["amount"] if selected_bundle else 0.0

    if amount > float(customer.account_balance):
        errors.append("Insufficient balance for this data bundle purchase.")

    if errors:
        return render_template(
            "data_bundles.html",
            customer=customer,
            networks=networks,
            bundles=bundles,
            errors=errors,
            provider=provider,
            phone_number=phone_number,
            bundle_name=bundle_name,
            payment_reference=payment_reference
        )

    new_balance = float(customer.account_balance) - amount

    transaction_reference = generate_transaction_reference()

    customer.account_balance = new_balance

    transaction = Transaction(
        transaction_reference=transaction_reference,
        customer_id=customer.id,
        transaction_type="Data Bundle Purchase",
        direction="Debit",
        amount=amount,
        balance_after=new_balance,
        description=f"{bundle_name} mobile data bundle",
        counterparty=provider,
        status="Completed"
    )

    db.session.add(transaction)
    db.session.commit()

    return render_template(
        "data_bundle_confirmation.html",
        customer=customer,
        provider=provider,
        phone_number=phone_number,
        bundle_name=bundle_name,
        amount=amount,
        payment_reference=payment_reference,
        transaction_reference=transaction_reference,
        new_balance=new_balance
    )
'''

    if marker not in app_text:
        raise SystemExit(
            "ERROR: Could not find the app.py ending marker. Nothing was changed."
        )

    app_text = app_text.replace(marker, route + marker, 1)
    APP.write_text(app_text, encoding="utf-8")
    print("SUCCESS: Data Bundles route added.")


# ---------------------------------------------------------
# Data Bundles page
# ---------------------------------------------------------

data_bundles_html = r'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Bundles | Fairmont Bank</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            font-family: Arial, Helvetica, sans-serif;
            background:
                radial-gradient(circle at top left, rgba(30, 82, 150, .35), transparent 35%),
                linear-gradient(145deg, #06152c, #0a2345 55%, #06152c);
            color: #ffffff;
        }

        .page {
            width: 100%;
            max-width: 760px;
            margin: 0 auto;
            padding: 24px 18px 50px;
        }

        .back {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: #d8e8ff;
            text-decoration: none;
            font-size: 14px;
            margin-bottom: 22px;
        }

        .card {
            background: rgba(10, 31, 61, .78);
            border: 1px solid rgba(255,255,255,.10);
            border-radius: 22px;
            padding: 24px;
            box-shadow: 0 18px 50px rgba(0,0,0,.28);
            backdrop-filter: blur(14px);
        }

        .brand {
            font-size: 13px;
            letter-spacing: 2px;
            color: #9fc7ff;
            margin-bottom: 8px;
            font-weight: 700;
        }

        h1 {
            margin: 0 0 8px;
            font-size: 28px;
        }

        .intro {
            margin: 0 0 22px;
            color: #aebfd7;
            line-height: 1.55;
        }

        .balance {
            padding: 15px 16px;
            border-radius: 15px;
            background: rgba(255,255,255,.055);
            border: 1px solid rgba(255,255,255,.08);
            margin-bottom: 22px;
        }

        .balance-label {
            color: #aebfd7;
            font-size: 13px;
            margin-bottom: 5px;
        }

        .balance-value {
            font-size: 22px;
            font-weight: 700;
        }

        .error {
            background: rgba(180, 35, 55, .18);
            border: 1px solid rgba(255, 90, 110, .30);
            color: #ffd7dc;
            border-radius: 13px;
            padding: 13px 15px;
            margin-bottom: 18px;
        }

        label {
            display: block;
            font-size: 13px;
            color: #c9d9ee;
            margin: 17px 0 8px;
        }

        select,
        input {
            width: 100%;
            padding: 14px 15px;
            border-radius: 13px;
            border: 1px solid rgba(255,255,255,.11);
            background: #0a1d39;
            color: #ffffff;
            outline: none;
            font-size: 15px;
        }

        select:focus,
        input:focus {
            border-color: #5598ed;
        }

        option {
            background: #0a1d39;
            color: #ffffff;
        }

        .button {
            width: 100%;
            margin-top: 24px;
            padding: 15px;
            border: 0;
            border-radius: 14px;
            background: #2e78d1;
            color: white;
            font-size: 15px;
            font-weight: 700;
            cursor: pointer;
        }

        .button:hover {
            background: #3d88e3;
        }

        .note {
            margin-top: 15px;
            color: #899db9;
            font-size: 12px;
            line-height: 1.5;
        }

        @media (max-width: 520px) {
            .page {
                padding: 18px 13px 40px;
            }

            .card {
                padding: 20px 16px;
                border-radius: 19px;
            }

            h1 {
                font-size: 24px;
            }
        }
    </style>
</head>

<body>

<div class="page">

    <a class="back" href="/dashboard">← Back to Dashboard</a>

    <div class="card">

        <div class="brand">FAIRMONT BANK</div>

        <h1>Data Bundles</h1>

        <p class="intro">
            Purchase a mobile data bundle for your phone or another mobile number.
        </p>

        <div class="balance">
            <div class="balance-label">Available Balance</div>
            <div class="balance-value">
                £{{ "{:,.2f}".format(customer.account_balance|float) }}
            </div>
        </div>

        {% if errors %}
            <div class="error">
                {% for error in errors %}
                    <div>{{ error }}</div>
                {% endfor %}
            </div>
        {% endif %}

        <form method="POST">

            <label for="provider">Mobile Network</label>
            <select name="provider" id="provider" required>
                <option value="">Select mobile network</option>

                {% for network in networks %}
                    <option value="{{ network }}"
                        {% if provider == network %}selected{% endif %}>
                        {{ network }}
                    </option>
                {% endfor %}
            </select>

            <label for="phone_number">Mobile Phone Number</label>
            <input
                type="tel"
                id="phone_number"
                name="phone_number"
                value="{{ phone_number or '' }}"
                placeholder="Enter mobile number"
                autocomplete="tel"
                required
            >

            <label for="bundle_name">Data Bundle</label>
            <select name="bundle_name" id="bundle_name" required>
                <option value="">Select data bundle</option>

                {% for bundle in bundles %}
                    <option value="{{ bundle.name }}"
                        {% if bundle_name == bundle.name %}selected{% endif %}>
                        {{ bundle.name }} — £{{ "{:,.2f}".format(bundle.amount) }}
                    </option>
                {% endfor %}
            </select>

            <label for="payment_reference">
                Payment Reference <span style="color:#8295af;">(Optional)</span>
            </label>

            <input
                type="text"
                id="payment_reference"
                name="payment_reference"
                value="{{ payment_reference or '' }}"
                placeholder="Optional reference"
                maxlength="100"
            >

            <button class="button" type="submit">
                Purchase Data Bundle
            </button>

        </form>

        <div class="note">
            The selected bundle amount will be deducted from the available account
            balance and recorded in your transaction history.
        </div>

    </div>

</div>

</body>
</html>
'''

(TEMPLATES / "data_bundles.html").write_text(
    data_bundles_html,
    encoding="utf-8"
)

print("SUCCESS: templates/data_bundles.html created.")


# ---------------------------------------------------------
# Confirmation page
# ---------------------------------------------------------

confirmation_html = r'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Bundle Confirmation | Fairmont Bank</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            font-family: Arial, Helvetica, sans-serif;
            background:
                radial-gradient(circle at top left, rgba(30, 82, 150, .35), transparent 35%),
                linear-gradient(145deg, #06152c, #0a2345 55%, #06152c);
            color: #ffffff;
        }

        .page {
            width: 100%;
            max-width: 650px;
            margin: 0 auto;
            padding: 35px 18px 50px;
        }

        .card {
            background: rgba(10, 31, 61, .80);
            border: 1px solid rgba(255,255,255,.10);
            border-radius: 22px;
            padding: 27px;
            box-shadow: 0 18px 50px rgba(0,0,0,.28);
        }

        .success {
            width: 56px;
            height: 56px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(53, 180, 116, .18);
            border: 1px solid rgba(80, 220, 145, .30);
            color: #73e3a6;
            font-size: 27px;
            margin-bottom: 18px;
        }

        .brand {
            font-size: 13px;
            letter-spacing: 2px;
            color: #9fc7ff;
            font-weight: 700;
            margin-bottom: 8px;
        }

        h1 {
            margin: 0 0 8px;
            font-size: 27px;
        }

        .intro {
            color: #aebfd7;
            margin-bottom: 24px;
        }

        .details {
            border-top: 1px solid rgba(255,255,255,.08);
        }

        .row {
            display: flex;
            justify-content: space-between;
            gap: 20px;
            padding: 14px 0;
            border-bottom: 1px solid rgba(255,255,255,.07);
        }

        .label {
            color: #91a6c2;
            font-size: 13px;
        }

        .value {
            text-align: right;
            font-size: 14px;
            font-weight: 600;
        }

        .status {
            color: #72e0a4;
        }

        .balance {
            margin-top: 20px;
            padding: 16px;
            border-radius: 15px;
            background: rgba(255,255,255,.055);
        }

        .balance-label {
            color: #9eb2cd;
            font-size: 13px;
        }

        .balance-value {
            margin-top: 5px;
            font-size: 23px;
            font-weight: 700;
        }

        .actions {
            display: flex;
            gap: 10px;
            margin-top: 22px;
        }

        .button {
            flex: 1;
            display: block;
            text-align: center;
            padding: 14px;
            border-radius: 13px;
            text-decoration: none;
            background: #2e78d1;
            color: white;
            font-weight: 700;
            font-size: 14px;
        }

        .button.secondary {
            background: rgba(255,255,255,.07);
            border: 1px solid rgba(255,255,255,.09);
        }

        @media (max-width: 520px) {
            .page {
                padding: 20px 13px 40px;
            }

            .card {
                padding: 21px 16px;
            }

            .row {
                align-items: flex-start;
            }

            .actions {
                flex-direction: column;
            }
        }
    </style>
</head>

<body>

<div class="page">

    <div class="card">

        <div class="success">✓</div>

        <div class="brand">FAIRMONT BANK</div>

        <h1>Data Bundle Purchased</h1>

        <div class="intro">
            Your data bundle purchase has been successfully completed.
        </div>

        <div class="details">

            <div class="row">
                <span class="label">Mobile Network</span>
                <span class="value">{{ provider }}</span>
            </div>

            <div class="row">
                <span class="label">Mobile Number</span>
                <span class="value">{{ phone_number }}</span>
            </div>

            <div class="row">
                <span class="label">Data Bundle</span>
                <span class="value">{{ bundle_name }}</span>
            </div>

            <div class="row">
                <span class="label">Amount</span>
                <span class="value">
                    £{{ "{:,.2f}".format(amount|float) }}
                </span>
            </div>

            {% if payment_reference %}
            <div class="row">
                <span class="label">Payment Reference</span>
                <span class="value">{{ payment_reference }}</span>
            </div>
            {% endif %}

            <div class="row">
                <span class="label">Transaction Reference</span>
                <span class="value">{{ transaction_reference }}</span>
            </div>

            <div class="row">
                <span class="label">Status</span>
                <span class="value status">Completed</span>
            </div>

        </div>

        <div class="balance">
            <div class="balance-label">New Available Balance</div>
            <div class="balance-value">
                £{{ "{:,.2f}".format(new_balance|float) }}
            </div>
        </div>

        <div class="actions">
            <a class="button" href="/transactions">
                View Transactions
            </a>

            <a class="button secondary" href="/dashboard">
                Dashboard
            </a>
        </div>

    </div>

</div>

</body>
</html>
'''

(TEMPLATES / "data_bundle_confirmation.html").write_text(
    confirmation_html,
    encoding="utf-8"
)

print("SUCCESS: templates/data_bundle_confirmation.html created.")


# ---------------------------------------------------------
# Update dashboard Data Bundles card
# ---------------------------------------------------------

dashboard = TEMPLATES / "dashboard.html"

if dashboard.exists():
    dashboard_text = dashboard.read_text(encoding="utf-8")

    marker = "<!-- Data Bundles -->"
    start = dashboard_text.find(marker)

    if start != -1:
        end = dashboard_text.find("</a>", start)

        if end != -1:
            section = dashboard_text[start:end]

            if 'href="/data-bundles"' not in section:
                section = section.replace(
                    'href="#"',
                    'href="/data-bundles"',
                    1
                )

                dashboard_text = (
                    dashboard_text[:start]
                    + section
                    + dashboard_text[end:]
                )

                dashboard.write_text(
                    dashboard_text,
                    encoding="utf-8"
                )

                print("SUCCESS: Dashboard Data Bundles card linked to /data-bundles.")
            else:
                print("Dashboard Data Bundles card already links to /data-bundles.")
        else:
            print("WARNING: Data Bundles card closing tag was not found.")
    else:
        print("WARNING: Data Bundles dashboard card was not found.")
else:
    print("WARNING: templates/dashboard.html was not found.")


print()
print("DATA BUNDLES INSTALLATION COMPLETE.")
print("Next: run: python -m py_compile app.py")