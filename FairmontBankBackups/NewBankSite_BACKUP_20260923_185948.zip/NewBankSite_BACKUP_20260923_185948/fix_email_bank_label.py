from pathlib import Path

file = Path("templates/dashboard.html")

if not file.exists():
    raise SystemExit("ERROR: templates/dashboard.html was not found.")

text = file.read_text(encoding="utf-8")

old = """<!-- Email the Bank -->

                    <a
                        href="/email-bank"
                        class="service-item">

                        <span class="service-icon">
                            ✉
                        </span>

                        <span class="service-name">
                            Email the<br>
                            Bank
                        </span>

                    </a>"""

new = """<!-- Contact Bank -->

                    <a
                        href="/email-bank"
                        class="service-item">

                        <span class="service-icon">
                            ✉
                        </span>

                        <span class="service-name">
                            Contact<br>
                            Bank
                        </span>

                    </a>"""

if old not in text:
    raise SystemExit(
        "ERROR: The exact Email the Bank card was not found. "
        "No changes were made."
    )

text = text.replace(old, new, 1)

file.write_text(text, encoding="utf-8")

print("SUCCESS: Email the Bank has been renamed to Contact Bank.")
print("The /email-bank link and envelope icon were preserved.")
print("No other dashboard service was changed.")