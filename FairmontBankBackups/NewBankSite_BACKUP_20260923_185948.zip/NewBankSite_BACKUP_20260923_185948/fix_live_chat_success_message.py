from pathlib import Path
import shutil

FILE = Path("app.py")

text = FILE.read_text(encoding="utf-8")

backup = Path("app.py.before_live_chat_success_message")
shutil.copy2(FILE, backup)

old = '''                db.session.add(customer_message)
                db.session.commit()

                return redirect(url_for("live_chat"))'''

new = '''                db.session.add(customer_message)
                db.session.commit()

                session["live_chat_success"] = (
                    "Message sent successfully. "
                    "Your message has been delivered to Fairmont Bank Support."
                )

                return redirect(url_for("live_chat"))'''

if old not in text:
    print("=" * 70)
    print("ERROR: Live Chat send block was not found.")
    print("=" * 70)
    print()
    print("Backup created:")
    print(backup)
    raise SystemExit(1)

text = text.replace(old, new, 1)

old_render = '''        return render_template(
            "live_chat.html",
            conversation=conversation,
            chat_messages=chat_messages,
            is_authenticated=True
        )'''

new_render = '''        success_message = session.pop("live_chat_success", None)

        return render_template(
            "live_chat.html",
            conversation=conversation,
            chat_messages=chat_messages,
            is_authenticated=True,
            success_message=success_message
        )'''

if old_render not in text:
    print("=" * 70)
    print("ERROR: Live Chat render block was not found.")
    print("=" * 70)
    print()
    print("Backup created:")
    print(backup)
    raise SystemExit(1)

text = text.replace(old_render, new_render, 1)

FILE.write_text(text, encoding="utf-8")

print("=" * 70)
print("LIVE CHAT SUCCESS MESSAGE ADDED")
print("=" * 70)
print()
print("Backup created:")
print(backup)