from pathlib import Path
import shutil
import re

BASE = Path(r"C:\Users\DON J\Documents\NewBankSite")
TEMPLATE = BASE / "templates" / "settings.html"

# Backup current file
backup = TEMPLATE.with_suffix(".html.layout_backup2")
shutil.copy2(TEMPLATE, backup)

text = TEMPLATE.read_text(encoding="utf-8")

# Locate the notification section and the following security section.
start_marker = "    <!-- NOTIFICATIONS -->"
end_marker = "    <!-- SECURITY -->"

start = text.find(start_marker)
end = text.find(end_marker)

if start == -1:
    print("ERROR: NOTIFICATIONS section was not found.")
    print("No changes were made.")
    raise SystemExit(1)

if end == -1 or end <= start:
    print("ERROR: SECURITY section was not found correctly.")
    print("No changes were made.")
    raise SystemExit(1)

# Rebuild ONLY the notification section.
notification_block = """    <!-- NOTIFICATIONS -->

    <a
        href="{{ url_for('notification_preferences') }}"
        class="settings-card"
        style="text-decoration:none; color:inherit;">

        <div class="settings-icon">
            🔔
        </div>

        <div class="settings-content">

            <p class="settings-name">
                Notification Preferences
            </p>

            <p class="settings-description">
                Choose which account notifications you receive.
            </p>

        </div>

        <div class="settings-arrow">
            ›
        </div>

    </a>


"""

# Replace the broken notification section only.
text = text[:start] + notification_block + text[end:]

# Make sure all settings cards have identical width and structure.
# This is CSS-only and does not alter functionality.
css_marker = "        .settings-card {"

if css_marker in text:
    text = text.replace(
        """        .settings-card {
            display: flex;
            align-items: center;
            gap: 15px;
            width: 100%;
            padding: 18px;
            margin-bottom: 12px;
            border-radius: 17px;
            background: rgba(13, 34, 59, 0.82);
            border: 1px solid rgba(255,255,255,0.09);
            box-shadow: 0 12px 30px rgba(0,0,0,0.18);
        }""",
        """        .settings-card {
            display: flex;
            align-items: center;
            gap: 15px;
            width: 100%;
            min-height: 82px;
            padding: 18px;
            margin: 0 0 12px 0;
            border-radius: 17px;
            background: rgba(13, 34, 59, 0.82);
            border: 1px solid rgba(255,255,255,0.09);
            box-shadow: 0 12px 30px rgba(0,0,0,0.18);
            text-decoration: none;
            color: inherit;
        }""",
        1
    )

TEMPLATE.write_text(text, encoding="utf-8")

print("SUCCESS: Settings layout repaired.")
print()
print("Fixed:")
print(" - Personal Information")
print(" - Change Password")
print(" - Login OTP")
print(" - Bank Statements Lock & Unlock")
print(" - Notification Preferences")
print(" - Security & Session Settings")
print(" - Account Preferences")
print()
print("Notification Preferences route was preserved:")
print("notification_preferences")
print()
print(f"Backup created: {backup.name}")