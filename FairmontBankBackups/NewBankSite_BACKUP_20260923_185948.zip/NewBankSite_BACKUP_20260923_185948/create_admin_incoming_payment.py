from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
TEMPLATES = BASE_DIR / "templates"

TEMPLATES.mkdir(exist_ok=True)

template = r'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Post Incoming Payment | Fairmont Bank</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            font-family: Arial, Helvetica, sans-serif;
            background:
                radial-gradient(circle at top left, rgba(184,149,74,.10), transparent 32%),
                #071525;
            color: #edf3fb;
        }

        .page {
            width: 100%;
            max-width: 1050px;
            margin: 0 auto;
            padding: 30px 20px 60px;
        }

        .topbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            margin-bottom: 25px;
        }

        .brand {
            color: #ffffff;
            font-size: 20px;
            font-weight: 800;
            letter-spacing: 1.5px;
        }

        .brand span {
            color: #d5b467;
        }

        .back {
            color: #aebfd2;
            text-decoration: none;
            font-size: 14px;
            font-weight: 600;
        }

        .back:hover {
            color: #d5b467;
        }

        .hero {
            margin-bottom: 25px;
        }

        .hero h1 {
            margin: 0 0 8px;
            font-size: 30px;
            letter-spacing: -.5px;
        }

        .hero p {
            margin: 0;
            color: #8fa5bd;
            line-height: 1.6;
        }

        .card {
            background: rgba(12, 31, 51, .90);
            border: 1px solid rgba(184,149,74,.20);
            border-radius: 20px;
            padding: 28px;
            box-shadow: 0 25px 70px rgba(0,0,0,.28);
        }

        .section-title {
            margin: 0 0 18px;
            color: #ffffff;
            font-size: 17px;
        }

        .section-title span {
            color: #d5b467;
        }

        .section {
            padding-bottom: 26px;
            margin-bottom: 26px;
            border-bottom: 1px solid rgba(255,255,255,.08);
        }

        .section:last-of-type {
            border-bottom: 0;
            margin-bottom: 0;
            padding-bottom: 0;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 17px;
        }

        .field {
            display: flex;
            flex-direction: column;
            gap: 7px;
        }

        .field.full {
            grid-column: 1 / -1;
        }

        label {
            color: #a9bbcf;
            font-size: 13px;
            font-weight: 700;
        }

        input,
        select,
        textarea {
            width: 100%;
            border: 1px solid rgba(255,255,255,.10);
            border-radius: 11px;
            background: #091b2d;
            color: #ffffff;
            padding: 13px 14px;
            outline: none;
            font-size: 14px;
        }

        input:focus,
        select:focus,
        textarea:focus {
            border-color: rgba(213,180,103,.65);
            box-shadow: 0 0 0 3px rgba(213,180,103,.08);
        }

        select {
            cursor: pointer;
        }

        textarea {
            min-height: 100px;
            resize: vertical;
        }

        .hint {
            color: #7188a1;
            font-size: 12px;
            line-height: 1.45;
        }

        .receiver-preview {
            margin-top: 16px;
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 12px;
        }

        .preview-box {
            padding: 14px;
            border-radius: 12px;
            background: rgba(255,255,255,.035);
            border: 1px solid rgba(255,255,255,.07);
        }

        .preview-label {
            color: #7389a2;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: .7px;
            margin-bottom: 5px;
        }

        .preview-value {
            color: #f3f7fb;
            font-size: 14px;
            font-weight: 700;
            word-break: break-word;
        }

        .notice {
            padding: 14px 16px;
            border-radius: 12px;
            background: rgba(184,149,74,.07);
            border: 1px solid rgba(184,149,74,.18);
            color: #b9c8d8;
            font-size: 13px;
            line-height: 1.55;
            margin-bottom: 22px;
        }

        .flash {
            padding: 13px 15px;
            border-radius: 11px;
            margin-bottom: 18px;
            font-size: 13px;
            line-height: 1.5;
        }

        .flash.error {
            background: rgba(190, 65, 65, .12);
            border: 1px solid rgba(220, 90, 90, .25);
            color: #ffb5b5;
        }

        .flash.success {
            background: rgba(60, 170, 110, .12);
            border: 1px solid rgba(90, 200, 140, .25);
            color: #a9efc7;
        }

        .actions {
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            margin-top: 25px;
        }

        .button {
            border: 0;
            border-radius: 11px;
            padding: 14px 21px;
            background: #b8954a;
            color: #081625;
            font-size: 14px;
            font-weight: 800;
            cursor: pointer;
        }

        .button:hover {
            background: #d5b467;
        }

        .button.secondary {
            background: rgba(255,255,255,.06);
            border: 1px solid rgba(255,255,255,.10);
            color: #c8d5e3;
            text-decoration: none;
        }

        .button.secondary:hover {
            background: rgba(255,255,255,.10);
        }

        @media (max-width: 700px) {
            .grid,
            .receiver-preview {
                grid-template-columns: 1fr;
            }

            .field.full {
                grid-column: auto;
            }

            .topbar {
                align-items: flex-start;
                flex-direction: column;
            }

            .card {
                padding: 20px;
            }

            .actions {
                flex-direction: column;
            }

            .button {
                width: 100%;
                text-align: center;
            }
        }
    </style>
</head>

<body>

<div class="page">

    <div class="topbar">
        <div class="brand">
            FAIRMONT <span>BANK</span>
        </div>

        <a class="back" href="{{ url_for('admin_dashboard') }}">
            Back to Administration
        </a>
    </div>

    <div class="hero">
        <h1>Post Incoming Payment</h1>
        <p>
            Record an incoming payment received by an existing Fairmont Bank customer.
        </p>
    </div>

    <div class="card">

        {% with messages = get_flashed_messages(with_categories=true) %}
            {% if messages %}
                {% for category, message in messages %}
                    <div class="flash {{ category }}">
                        {{ message }}
                    </div>
                {% endfor %}
            {% endif %}
        {% endwith %}

        <div class="notice">
            The payment will be credited directly to the selected customer's
            account and recorded as a completed credit transaction. The external
            sender does not need to be a Fairmont Bank customer.
        </div>

        <form method="POST">

            <div class="section">

                <h2 class="section-title">
                    <span>01</span> Receiver
                </h2>

                <div class="grid">

                    <div class="field full">
                        <label for="receiver_customer_id">
                            Fairmont Customer
                        </label>

                        <select
                            id="receiver_customer_id"
                            name="receiver_customer_id"
                            required
                        >
                            <option value="">
                                Select the receiving customer
                            </option>

                            {% for customer in customers %}
                                <option
                                    value="{{ customer.id }}"
                                    {% if form_data.get('receiver_customer_id') == customer.id|string %}selected{% endif %}
                                >
                                    {{ customer.full_name }}
                                    — {{ customer.customer_id }}
                                    {% if customer.account_number %}
                                        — {{ customer.account_number }}
                                    {% endif %}
                                </option>
                            {% endfor %}
                        </select>

                        <div class="hint">
                            Only existing Fairmont customer accounts are available.
                        </div>
                    </div>

                </div>

                <div class="receiver-preview">

                    <div class="preview-box">
                        <div class="preview-label">Customer ID</div>
                        <div class="preview-value" id="previewCustomerId">
                            Select customer
                        </div>
                    </div>

                    <div class="preview-box">
                        <div class="preview-label">Account Number</div>
                        <div class="preview-value" id="previewAccountNumber">
                            Select customer
                        </div>
                    </div>

                    <div class="preview-box">
                        <div class="preview-label">Current Balance</div>
                        <div class="preview-value" id="previewBalance">
                            Select customer
                        </div>
                    </div>

                </div>

            </div>

            <div class="section">

                <h2 class="section-title">
                    <span>02</span> Sender
                </h2>

                <div class="grid">

                    <div class="field">
                        <label for="sender_name">Sender Name</label>
                        <input
                            type="text"
                            id="sender_name"
                            name="sender_name"
                            maxlength="150"
                            value="{{ form_data.get('sender_name', '') }}"
                            required
                        >
                    </div>

                    <div class="field">
                        <label for="sender_account_number">
                            Sender Account Number
                        </label>
                        <input
                            type="text"
                            id="sender_account_number"
                            name="sender_account_number"
                            maxlength="50"
                            value="{{ form_data.get('sender_account_number', '') }}"
                            required
                        >
                    </div>

                    <div class="field">
                        <label for="sender_bank">Sender Bank</label>
                        <input
                            type="text"
                            id="sender_bank"
                            name="sender_bank"
                            maxlength="150"
                            value="{{ form_data.get('sender_bank', '') }}"
                            required
                        >
                    </div>

                    <div class="field">
                        <label for="sender_country">Sender Country</label>
                        <input
                            type="text"
                            id="sender_country"
                            name="sender_country"
                            maxlength="100"
                            value="{{ form_data.get('sender_country', '') }}"
                            required
                        >
                    </div>

                </div>

            </div>

            <div class="section">

                <h2 class="section-title">
                    <span>03</span> Payment Details
                </h2>

                <div class="grid">

                    <div class="field">
                        <label for="amount">Amount</label>
                        <input
                            type="number"
                            id="amount"
                            name="amount"
                            min="0.01"
                            step="0.01"
                            value="{{ form_data.get('amount', '') }}"
                            required
                        >
                    </div>

                    <div class="field">
                        <label for="payment_reference">
                            Payment Reference
                        </label>
                        <input
                            type="text"
                            id="payment_reference"
                            name="payment_reference"
                            maxlength="255"
                            value="{{ form_data.get('payment_reference', '') }}"
                            required
                        >
                    </div>

                    <div class="field full">
                        <label for="description">
                            Payment Description
                        </label>

                        <textarea
                            id="description"
                            name="description"
                            maxlength="255"
                            required
                        >{{ form_data.get('description', '') }}</textarea>
                    </div>

                </div>

            </div>

            <div class="actions">

                <a
                    href="{{ url_for('admin_dashboard') }}"
                    class="button secondary"
                >
                    Cancel
                </a>

                <button type="submit" class="button">
                    Post Incoming Payment
                </button>

            </div>

        </form>

    </div>

</div>

<script>
    const customers = {{ customer_data|tojson }};

    const customerSelect =
        document.getElementById("receiver_customer_id");

    const customerId =
        document.getElementById("previewCustomerId");

    const accountNumber =
        document.getElementById("previewAccountNumber");

    const balance =
        document.getElementById("previewBalance");

    function updateReceiverPreview() {

        const selectedId = customerSelect.value;

        const customer = customers.find(
            item => String(item.id) === String(selectedId)
        );

        if (!customer) {
            customerId.textContent = "Select customer";
            accountNumber.textContent = "Select customer";
            balance.textContent = "Select customer";
            return;
        }

        customerId.textContent =
            customer.customer_id || "Not assigned";

        accountNumber.textContent =
            customer.account_number || "Not assigned";

        balance.textContent =
            "£" + Number(customer.balance || 0).toLocaleString(
                "en-GB",
                {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                }
            );
    }

    customerSelect.addEventListener(
        "change",
        updateReceiverPreview
    );

    updateReceiverPreview();
</script>

</body>
</html>
'''

output = TEMPLATES / "admin_incoming_payment.html"
output.write_text(template, encoding="utf-8")

print()
print("=" * 70)
print("INCOMING PAYMENT TEMPLATE CREATED")
print("=" * 70)
print()
print(output)
print()
print("The existing database and customer records were not changed.")
print()