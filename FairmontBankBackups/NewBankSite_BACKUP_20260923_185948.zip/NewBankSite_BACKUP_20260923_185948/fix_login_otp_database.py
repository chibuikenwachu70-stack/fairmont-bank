import sqlite3
from pathlib import Path

DB = Path(
    r"C:\Users\DON J\Documents\NewBankSite\instance\fairmont.db"
)

print()
print("Checking database:")
print(DB)
print()

if not DB.exists():
    raise RuntimeError(
        f"Database was not found:\n{DB}"
    )

connection = sqlite3.connect(DB)

try:

    cursor = connection.cursor()

    cursor.execute(
        "PRAGMA table_info(customer)"
    )

    columns = [
        row[1]
        for row in cursor.fetchall()
    ]

    print("Existing Customer columns:")
    for column in columns:
        print(" -", column)

    print()

    if "login_otp_enabled" in columns:

        print(
            "login_otp_enabled already exists."
        )

    else:

        print(
            "Adding login_otp_enabled..."
        )

        cursor.execute(
            """
            ALTER TABLE customer
            ADD COLUMN login_otp_enabled
            BOOLEAN NOT NULL DEFAULT 0
            """
        )

        connection.commit()

        print(
            "login_otp_enabled added successfully."
        )

    print()

    cursor.execute(
        "PRAGMA table_info(customer)"
    )

    updated_columns = [
        row[1]
        for row in cursor.fetchall()
    ]

    if "login_otp_enabled" not in updated_columns:
        raise RuntimeError(
            "The column could not be verified."
        )

    # Verify the existing customer records were preserved.
    cursor.execute(
        """
        SELECT
            customer_id,
            full_name,
            account_number,
            login_otp_enabled
        FROM customer
        """
    )

    customers = cursor.fetchall()

    print("Customer records:")
    print()

    for customer in customers:
        print(
            f"Customer ID: {customer[0]} | "
            f"Name: {customer[1]} | "
            f"Account: {customer[2]} | "
            f"OTP: {customer[3]}"
        )

    print()
    print("========================================")
    print("DATABASE MIGRATION SUCCESSFUL")
    print("========================================")
    print()
    print("Existing customer records were preserved.")
    print("Login OTP defaults to OFF.")
    print()

finally:

    connection.close()