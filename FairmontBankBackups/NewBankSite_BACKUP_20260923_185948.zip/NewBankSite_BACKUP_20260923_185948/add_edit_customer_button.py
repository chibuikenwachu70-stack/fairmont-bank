from pathlib import Path

path = Path("templates/admin_customer_profile.html")

text = path.read_text(encoding="utf-8")

if "admin_edit_customer" in text:
    print("Edit Customer Details button already exists.")
    raise SystemExit(0)

target = """<div class="header-title">
                <h1>Customer Profile</h1>
                <p>Customer administration</p>
            </div>"""

replacement = """<div class="header-title">
                <h1>Customer Profile</h1>
                <p>Customer administration</p>
            </div>

            <a
                href="{{ url_for('admin_edit_customer', customer_id=customer.id) }}"
                class="edit-customer-button">
                Edit Customer Details
            </a>"""

if target not in text:
    print("ERROR: Could not find the Customer Profile header.")
    print("No changes were made.")
    raise SystemExit(1)

text = text.replace(target, replacement, 1)

style_marker = """        .back-link {
"""

button_css = """        .edit-customer-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 11px 16px;
            border-radius: 10px;
            background: linear-gradient(
                135deg,
                #b8954a,
                #d8b96a
            );
            color: #071426;
            text-decoration: none;
            font-size: 13px;
            font-weight: 700;
            border: 1px solid rgba(216, 185, 106, 0.55);
            white-space: nowrap;
            transition: 0.2s ease;
        }

        .edit-customer-button:hover {
            transform: translateY(-1px);
            filter: brightness(1.05);
        }

"""

if style_marker not in text:
    print("ERROR: Could not find the existing back-link CSS section.")
    print("No changes were made.")
    raise SystemExit(1)

text = text.replace(style_marker, button_css + style_marker, 1)

path.write_text(text, encoding="utf-8")

print("SUCCESS: Edit Customer Details button added.")