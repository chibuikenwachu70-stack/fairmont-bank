from pathlib import Path
import shutil

FILE = Path("app.py")

text = FILE.read_text(encoding="utf-8")

old = '''@app.route("/live-chat", methods=["GET", "POST"])
@login_required
def live_chat():'''

new = '''@app.route("/live-chat", methods=["GET", "POST"])
def live_chat():'''

if old not in text:
    print("=" * 70)
    print("LIVE CHAT ROUTE PATTERN NOT FOUND")
    print("=" * 70)
    print()
    print("The route may already have been changed.")
    raise SystemExit(1)

backup = Path("app.py.before_live_chat_access_fix")
shutil.copy2(FILE, backup)

text = text.replace(old, new, 1)

FILE.write_text(text, encoding="utf-8")

print("=" * 70)
print("LIVE CHAT ACCESS FIXED")
print("=" * 70)
print()
print("The login-page Live Chat link can now open /live-chat.")
print()
print("Backup created:")
print(backup)