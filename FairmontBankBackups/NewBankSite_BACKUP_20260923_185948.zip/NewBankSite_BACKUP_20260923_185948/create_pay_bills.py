from pathlib import Path
import re

BASE = Path(__file__).resolve().parent
APP_FILE = BASE / "app.py"
TEMPLATE_DIR = BASE / "templates"

print("=" * 60)
print("FAIRMONT BANK - PAY BILLS")
print("=" * 60)

# ------------------------------------------------------------
# BACKUP
# ------------------------------------------------------------

backup_file = BASE / "app_BEFORE_PAY_BILLS.py"

if not backup_file.exists():
    backup_file.write_text(
        APP_FILE.read_text(encoding="utf-8"),
        encoding="utf-8"
    )
    print("App backup created:")
    print(f"  {backup_file.name}")
else:
    print("Existing Pay Bills backup preserved:")
    print(f"  {backup_file.name}")


# ------------------------------------------------------------
# ADD PAY BILLS ROUTE
# ------------------------------------------------------------

app_text = APP_FILE.read_text(
    encoding="utf-8"
)

if '@app.route("/pay-bills"' in app_text:

    print("Pay Bills route already exists.")

else:

    route_code = '''

# ============================================================
# PAY BILLS
# ============================================================

@app.route("/pay-bills", methods=["GET", "POST"])
@login_required
def pay_bills():

    customer = current_user

    if request.method == "GET":

        return render_template(
            "pay_bills.html",
            customer=customer
        )

    bill_category = request.form.get(
        "bill_category",
        ""
    ).strip()

    provider = request.form.get(
        "provider",
        ""
    ).strip()

    account_reference = request.form.get(
        "account_reference",
        ""
    ).strip()

    amount_text = request.form.get(
        "amount",
        ""
    ).strip()

    payment_reference = request.form.get(
        "payment_reference",
        ""
    ).strip()

    errors = []

    allowed_categories = {
        "Electricity",
        "Gas",
        "Water",
        "Council Tax",
        "Broadband",
        "Mobile Phone",
        "Landline",
        "TV & Entertainment",
        "Other Bills"
    }

    if bill_category not in allowed_categories:

        errors.append(
            "Please select a valid bill category."
        )

    if not provider:

        errors.append(
            "Please enter or select the bill provider."
        )

    if not account_reference:

        errors.append(
            "Please enter your customer or account reference."
        )

    try:

        amount = float(amount_text)

    except (TypeError, ValueError):

        amount = 0

        errors.append(
            "Please enter a valid payment amount."
        )

    if amount <= 0:

        if "Please enter a valid payment amount." not in errors:

            errors.append(
                "Payment amount must be greater than £0.00."
            )

    if amount > float(customer.account_balance or 0):

        errors.append(
            "Insufficient available balance."
        )

    if errors:

        return render_template(
            "pay_bills.html",
            customer=customer,
            errors=errors,
            form=request.form
        )

    transaction_reference = generate_transaction_reference()

    customer.account_balance = (
        float(customer.account_balance or 0)
        - amount
    )

    description = (
        f"{bill_category} payment"
    )

    counterparty = provider

    transaction = Transaction(

        transaction_reference=transaction_reference,

        customer_id=customer.customer_id,

        transaction_type="Bill Payment",

        direction="Debit",

        amount=amount,

        balance_after=float(
            customer.account_balance
        ),

        description=description,

        counterparty=counterparty,

        status="Completed"
    )

    db.session.add(transaction)

    try:

        db.session.commit()

    except Exception:

        db.session.rollback()

        return render_template(
            "pay_bills.html",
            customer=customer,
            errors=[
                "The payment could not be completed. Please try again."
            ],
            form=request.form
        )

    return render_template(
        "bill_payment_confirmation.html",
        customer=customer,
        transaction=transaction,
        bill_category=bill_category,
        provider=provider,
        account_reference=account_reference,
        payment_reference=payment_reference
    )

'''

    app_text = app_text.rstrip() + "\n" + route_code

    APP_FILE.write_text(
        app_text,
        encoding="utf-8"
    )

    print("Pay Bills route added:")
    print("  /pay-bills")


# ------------------------------------------------------------
# PAY BILLS PAGE
# ------------------------------------------------------------

pay_bills_html = r'''<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Pay Bills | Fairmont Bank</title>

    <link
        rel="stylesheet"
        href="{{ url_for('static', filename='css/style.css') }}"
    >

    <style>

        * {
            box-sizing: border-box;
        }

        body {

            margin: 0;

            min-height: 100vh;

            font-family:
                Inter,
                -apple-system,
                BlinkMacSystemFont,
                "Segoe UI",
                sans-serif;

            background:
                radial-gradient(
                    circle at top right,
                    rgba(61, 91, 145, 0.22),
                    transparent 38%
                ),
                #07111f;

            color: #ffffff;
        }


        .bills-page {

            min-height: 100vh;

            padding:
                22px 18px 40px;
        }


        .bills-container {

            width:
                min(720px, 100%);

            margin:
                0 auto;
        }


        .bills-topbar {

            display: flex;

            align-items: center;

            justify-content:
                space-between;

            gap: 16px;

            margin-bottom:
                30px;
        }


        .back-link {

            color:
                rgba(255,255,255,0.72);

            text-decoration:
                none;

            font-size:
                14px;

            font-weight:
                600;
        }


        .back-link:hover {

            color:
                #ffffff;
        }


        .brand-small {

            display:
                flex;

            align-items:
                center;

            gap:
                9px;
        }


        .brand-mark {

            width:
                34px;

            height:
                34px;

            border-radius:
                10px;

            display:
                flex;

            align-items:
                center;

            justify-content:
                center;

            background:
                rgba(255,255,255,0.08);

            border:
                1px solid
                rgba(255,255,255,0.10);

            font-weight:
                700;
        }


        .brand-name {

            display:
                flex;

            flex-direction:
                column;

            line-height:
                1;
        }


        .brand-name strong {

            font-size:
                12px;

            letter-spacing:
                2px;
        }


        .brand-name span {

            margin-top:
                3px;

            font-size:
                8px;

            letter-spacing:
                3px;

            opacity:
                0.58;
        }


        .bills-heading {

            margin-bottom:
                24px;
        }


        .eyebrow {

            margin:
                0 0 9px;

            font-size:
                10px;

            font-weight:
                700;

            letter-spacing:
                2px;

            text-transform:
                uppercase;

            color:
                rgba(255,255,255,0.46);
        }


        h1 {

            margin:
                0;

            font-size:
                clamp(30px, 7vw, 42px);

            line-height:
                1.08;

            letter-spacing:
                -1px;
        }


        .intro {

            margin:
                12px 0 0;

            color:
                rgba(255,255,255,0.60);

            font-size:
                14px;

            line-height:
                1.6;
        }


        .balance-card {

            margin-bottom:
                16px;

            padding:
                17px 18px;

            border-radius:
                17px;

            background:
                rgba(255,255,255,0.055);

            border:
                1px solid
                rgba(255,255,255,0.08);
        }


        .balance-label {

            display:
                block;

            margin-bottom:
                5px;

            color:
                rgba(255,255,255,0.43);

            font-size:
                11px;

            text-transform:
                uppercase;

            letter-spacing:
                1.4px;
        }


        .balance-value {

            font-size:
                24px;

            font-weight:
                700;
        }


        .bill-form {

            padding:
                20px;

            border-radius:
                22px;

            background:
                linear-gradient(
                    145deg,
                    rgba(255,255,255,0.095),
                    rgba(255,255,255,0.045)
                );

            border:
                1px solid
                rgba(255,255,255,0.09);

            box-shadow:
                0 18px 45px
                rgba(0,0,0,0.20);
        }


        .field {

            margin-bottom:
                17px;
        }


        label {

            display:
                block;

            margin-bottom:
                8px;

            color:
                rgba(255,255,255,0.75);

            font-size:
                12px;

            font-weight:
                600;
        }


        select,
        input {

            width:
                100%;

            height:
                50px;

            padding:
                0 14px;

            border-radius:
                13px;

            border:
                1px solid
                rgba(255,255,255,0.10);

            outline:
                none;

            background:
                rgba(0,0,0,0.20);

            color:
                #ffffff;

            font-size:
                14px;
        }


        select:focus,
        input:focus {

            border-color:
                rgba(255,255,255,0.27);
        }


        select option {

            background:
                #101d2e;

            color:
                #ffffff;
        }


        .field-help {

            margin:
                7px 0 0;

            color:
                rgba(255,255,255,0.38);

            font-size:
                11px;
        }


        .errors {

            margin-bottom:
                18px;

            padding:
                14px 15px;

            border-radius:
                13px;

            background:
                rgba(180,50,50,0.14);

            border:
                1px solid
                rgba(220,90,90,0.22);

            color:
                rgba(255,220,220,0.88);

            font-size:
                13px;

            line-height:
                1.6;
        }


        .errors div + div {

            margin-top:
                4px;
        }


        .submit-button {

            width:
                100%;

            min-height:
                52px;

            border:
                0;

            border-radius:
                14px;

            cursor:
                pointer;

            background:
                #ffffff;

            color:
                #07111f;

            font-size:
                14px;

            font-weight:
                700;
        }


        .submit-button:hover {

            opacity:
                0.92;
        }


        .security-note {

            margin-top:
                16px;

            text-align:
                center;

            color:
                rgba(255,255,255,0.35);

            font-size:
                11px;

            line-height:
                1.5;
        }


        @media (max-width: 500px) {

            .bills-page {

                padding:
                    18px 14px 32px;
            }

            .bill-form {

                padding:
                    17px;
            }

        }

    </style>

</head>


<body>

<main class="bills-page">

    <div class="bills-container">


        <div class="bills-topbar">

            <a
                href="{{ url_for('services') }}"
                class="back-link"
            >
                ← Services
            </a>


            <div class="brand-small">

                <div class="brand-mark">
                    F
                </div>

                <div class="brand-name">

                    <strong>
                        FAIRMONT
                    </strong>

                    <span>
                        BANK
                    </span>

                </div>

            </div>

        </div>


        <section class="bills-heading">

            <p class="eyebrow">
                Everyday Banking
            </p>

            <h1>
                Pay Bills
            </h1>

            <p class="intro">
                Make a bill payment from your Fairmont Bank account
                using the secure payment form below.
            </p>

        </section>


        <div class="balance-card">

            <span class="balance-label">
                Available balance
            </span>

            <div class="balance-value">
                £{{ "{:,.2f}".format(customer.account_balance or 0) }}
            </div>

        </div>


        {% if errors %}

        <div class="errors">

            {% for error in errors %}

                <div>
                    {{ error }}
                </div>

            {% endfor %}

        </div>

        {% endif %}


        <form
            method="POST"
            action="{{ url_for('pay_bills') }}"
            class="bill-form"
        >


            <div class="field">

                <label for="bill_category">
                    Bill category
                </label>

                <select
                    id="bill_category"
                    name="bill_category"
                    required
                >

                    <option value="">
                        Select bill category
                    </option>

                    {% for category in [
                        "Electricity",
                        "Gas",
                        "Water",
                        "Council Tax",
                        "Broadband",
                        "Mobile Phone",
                        "Landline",
                        "TV & Entertainment",
                        "Other Bills"
                    ] %}

                    <option
                        value="{{ category }}"
                        {% if form is defined and form.get('bill_category') == category %}
                            selected
                        {% endif %}
                    >
                        {{ category }}
                    </option>

                    {% endfor %}

                </select>

            </div>


            <div class="field">

                <label for="provider">
                    Bill provider
                </label>

                <input
                    type="text"
                    id="provider"
                    name="provider"
                    value="{{ form.get('provider', '') if form is defined else '' }}"
                    placeholder="Enter provider or biller"
                    autocomplete="organization"
                    required
                >

                <p class="field-help">
                    Enter the company or organisation receiving the payment.
                </p>

            </div>


            <div class="field">

                <label for="account_reference">
                    Customer / account reference
                </label>

                <input
                    type="text"
                    id="account_reference"
                    name="account_reference"
                    value="{{ form.get('account_reference', '') if form is defined else '' }}"
                    placeholder="Enter your bill account reference"
                    required
                >

            </div>


            <div class="field">

                <label for="amount">
                    Payment amount
                </label>

                <input
                    type="number"
                    id="amount"
                    name="amount"
                    value="{{ form.get('amount', '') if form is defined else '' }}"
                    placeholder="0.00"
                    min="0.01"
                    step="0.01"
                    inputmode="decimal"
                    required
                >

            </div>


            <div class="field">

                <label for="payment_reference">
                    Payment reference
                    <span style="opacity:0.45;">
                        (optional)
                    </span>
                </label>

                <input
                    type="text"
                    id="payment_reference"
                    name="payment_reference"
                    value="{{ form.get('payment_reference', '') if form is defined else '' }}"
                    placeholder="Optional payment reference"
                    maxlength="255"
                >

            </div>


            <button
                type="submit"
                class="submit-button"
            >
                Continue Payment
            </button>


        </form>


        <div class="security-note">
            Your payment is recorded securely in your Fairmont
            transaction history after successful processing.
        </div>


    </div>

</main>

</body>

</html>
'''

TEMPLATE_DIR.mkdir(
    parents=True,
    exist_ok=True
)

(TEMPLATE_DIR / "pay_bills.html").write_text(
    pay_bills_html,
    encoding="utf-8"
)

print("Pay Bills page created:")
print("  templates\\pay_bills.html")


# ------------------------------------------------------------
# CONFIRMATION PAGE
# ------------------------------------------------------------

confirmation_html = r'''<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Payment Complete | Fairmont Bank</title>

    <link
        rel="stylesheet"
        href="{{ url_for('static', filename='css/style.css') }}"
    >

    <style>

        * {
            box-sizing: border-box;
        }

        body {

            margin: 0;

            min-height: 100vh;

            font-family:
                Inter,
                -apple-system,
                BlinkMacSystemFont,
                "Segoe UI",
                sans-serif;

            background:
                radial-gradient(
                    circle at top right,
                    rgba(61, 91, 145, 0.22),
                    transparent 38%
                ),
                #07111f;

            color: #ffffff;
        }


        .confirmation-page {

            min-height: 100vh;

            padding:
                24px 18px 40px;

            display:
                flex;

            align-items:
                center;

            justify-content:
                center;
        }


        .confirmation-card {

            width:
                min(540px, 100%);

            padding:
                30px 24px;

            border-radius:
                24px;

            background:
                linear-gradient(
                    145deg,
                    rgba(255,255,255,0.10),
                    rgba(255,255,255,0.045)
                );

            border:
                1px solid
                rgba(255,255,255,0.10);

            box-shadow:
                0 24px 55px
                rgba(0,0,0,0.25);
        }


        .success-mark {

            width:
                56px;

            height:
                56px;

            margin-bottom:
                20px;

            border-radius:
                50%;

            display:
                flex;

            align-items:
                center;

            justify-content:
                center;

            background:
                rgba(255,255,255,0.10);

            border:
                1px solid
                rgba(255,255,255,0.15);

            font-size:
                24px;
        }


        .eyebrow {

            margin:
                0 0 8px;

            font-size:
                10px;

            letter-spacing:
                2px;

            text-transform:
                uppercase;

            color:
                rgba(255,255,255,0.45);
        }


        h1 {

            margin:
                0;

            font-size:
                30px;
        }


        .message {

            margin:
                11px 0 24px;

            color:
                rgba(255,255,255,0.62);

            font-size:
                14px;

            line-height:
                1.6;
        }


        .details {

            border-top:
                1px solid
                rgba(255,255,255,0.08);

            border-bottom:
                1px solid
                rgba(255,255,255,0.08);
        }


        .detail {

            display:
                flex;

            justify-content:
                space-between;

            gap:
                20px;

            padding:
                13px 0;

            border-bottom:
                1px solid
                rgba(255,255,255,0.055);

            font-size:
                13px;
        }


        .detail:last-child {

            border-bottom:
                0;
        }


        .detail-label {

            color:
                rgba(255,255,255,0.42);
        }


        .detail-value {

            text-align:
                right;

            font-weight:
                600;

            word-break:
                break-word;
        }


        .new-balance {

            margin-top:
                20px;

            padding:
                15px;

            border-radius:
                14px;

            background:
                rgba(255,255,255,0.055);
        }


        .new-balance-label {

            display:
                block;

            margin-bottom:
                5px;

            color:
                rgba(255,255,255,0.42);

            font-size:
                10px;

            text-transform:
                uppercase;

            letter-spacing:
                1.3px;
        }


        .new-balance-value {

            font-size:
                22px;

            font-weight:
                700;
        }


        .actions {

            display:
                grid;

            grid-template-columns:
                1fr 1fr;

            gap:
                10px;

            margin-top:
                20px;
        }


        .action {

            min-height:
                48px;

            display:
                flex;

            align-items:
                center;

            justify-content:
                center;

            border-radius:
                13px;

            text-decoration:
                none;

            font-size:
                13px;

            font-weight:
                700;
        }


        .primary {

            background:
                #ffffff;

            color:
                #07111f;
        }


        .secondary {

            background:
                rgba(255,255,255,0.06);

            color:
                #ffffff;

            border:
                1px solid
                rgba(255,255,255,0.10);
        }


        @media (max-width: 450px) {

            .confirmation-card {

                padding:
                    25px 18px;
            }

            .actions {

                grid-template-columns:
                    1fr;
            }

        }

    </style>

</head>


<body>

<main class="confirmation-page">

    <section class="confirmation-card">


        <div class="success-mark">
            ✓
        </div>


        <p class="eyebrow">
            Fairmont Bank
        </p>


        <h1>
            Payment complete
        </h1>


        <p class="message">
            Your {{ bill_category }} payment has been
            successfully recorded in your Fairmont account.
        </p>


        <div class="details">


            <div class="detail">

                <span class="detail-label">
                    Provider
                </span>

                <span class="detail-value">
                    {{ provider }}
                </span>

            </div>


            <div class="detail">

                <span class="detail-label">
                    Account reference
                </span>

                <span class="detail-value">
                    {{ account_reference }}
                </span>

            </div>


            <div class="detail">

                <span class="detail-label">
                    Amount
                </span>

                <span class="detail-value">
                    £{{ "{:,.2f}".format(transaction.amount) }}
                </span>

            </div>


            <div class="detail">

                <span class="detail-label">
                    Transaction reference
                </span>

                <span class="detail-value">
                    {{ transaction.transaction_reference }}
                </span>

            </div>


            {% if payment_reference %}

            <div class="detail">

                <span class="detail-label">
                    Payment reference
                </span>

                <span class="detail-value">
                    {{ payment_reference }}
                </span>

            </div>

            {% endif %}


            <div class="detail">

                <span class="detail-label">
                    Status
                </span>

                <span class="detail-value">
                    {{ transaction.status }}
                </span>

            </div>


        </div>


        <div class="new-balance">

            <span class="new-balance-label">
                Available balance
            </span>

            <div class="new-balance-value">
                £{{ "{:,.2f}".format(customer.account_balance or 0) }}
            </div>

        </div>


        <div class="actions">

            <a
                href="{{ url_for('transactions') }}"
                class="action primary"
            >
                View Transactions
            </a>


            <a
                href="{{ url_for('services') }}"
                class="action secondary"
            >
                Back to Services
            </a>

        </div>


    </section>

</main>

</body>

</html>
'''

(TEMPLATE_DIR / "bill_payment_confirmation.html").write_text(
    confirmation_html,
    encoding="utf-8"
)

print("Confirmation page created:")
print("  templates\\bill_payment_confirmation.html")


# ------------------------------------------------------------
# UPDATE SERVICES HUB LINK
# ------------------------------------------------------------

services_file = TEMPLATE_DIR / "services.html"

if services_file.exists():

    services_text = services_file.read_text(
        encoding="utf-8"
    )

    services_text = services_text.replace(
        'href="#"\n                class="service-card"\n                data-service="pay-bills"',
        'href="/pay-bills"\n                class="service-card"'
    )

    services_file.write_text(
        services_text,
        encoding="utf-8"
    )

    print("Services Hub Pay Bills link updated.")


# ------------------------------------------------------------
# UPDATE DASHBOARD PAY BILLS LINK
# ------------------------------------------------------------

dashboard_file = TEMPLATE_DIR / "dashboard.html"

if dashboard_file.exists():

    dashboard_text = dashboard_file.read_text(
        encoding="utf-8",
        errors="replace"
    )

    dashboard_text = dashboard_text.replace(
        'href="/services#pay-bills"',
        'href="/pay-bills"'
    )

    dashboard_file.write_text(
        dashboard_text,
        encoding="utf-8"
    )

    print("Dashboard Pay Bills link updated.")


# ------------------------------------------------------------
# VALIDATION
# ------------------------------------------------------------

print()
print("=" * 60)
print("VALIDATION")
print("=" * 60)

import sys

if str(BASE) not in sys.path:
    sys.path.insert(0, str(BASE))

try:

    from app import app

    with app.app_context():

        app.jinja_env.get_template(
            "pay_bills.html"
        )

        app.jinja_env.get_template(
            "bill_payment_confirmation.html"
        )

        routes = [
            str(rule)
            for rule in app.url_map.iter_rules()
            if rule.rule == "/pay-bills"
        ]

        if routes:
            print("/pay-bills route: OK")
        else:
            print("/pay-bills route: MISSING")

        print("pay_bills.html: OK")
        print("bill_payment_confirmation.html: OK")

except Exception as exc:

    print()
    print("VALIDATION ERROR:")
    print(type(exc).__name__ + ":", exc)
    raise


print()
print("=" * 60)
print("PAY BILLS CREATED SUCCESSFULLY")
print("=" * 60)
print()
print("Open after starting Flask:")
print("  http://127.0.0.1:5000/pay-bills")
print()