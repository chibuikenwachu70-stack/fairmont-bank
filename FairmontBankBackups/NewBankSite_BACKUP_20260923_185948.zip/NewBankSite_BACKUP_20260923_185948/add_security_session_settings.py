from pathlib import Path
import shutil
import re

BASE = Path(r"C:\Users\DON J\Documents\NewBankSite")
APP = BASE / "app.py"
TEMPLATE = BASE / "templates" / "settings.html"
SECURITY_TEMPLATE = BASE / "templates" / "security_session_settings.html"

# ---------------------------------------------------------
# BACKUPS
# ---------------------------------------------------------

app_backup = APP.with_suffix(".py.security_session_backup")
template_backup = TEMPLATE.with_suffix(".html.security_session_backup")

shutil.copy2(APP, app_backup)
shutil.copy2(TEMPLATE, template_backup)

# ---------------------------------------------------------
# 1. ADD SECURITY & SESSION ROUTE
# ---------------------------------------------------------

app_text = APP.read_text(encoding="utf-8")

route_block = r'''

# =========================================================
# SECURITY & SESSION SETTINGS
# =========================================================

@app.route("/settings/security-session")
@login_required
def security_session_settings():
    customer = current_user

    return render_template(
        "security_session_settings.html",
        customer=customer
    )

'''

if 'def security_session_settings():' not in app_text:

    marker = '\n@app.route("/personal-information")'

    if marker not in app_text:
        print("ERROR: Could not find the Personal Information route.")
        print("No app.py changes were made.")
        raise SystemExit(1)

    app_text = app_text.replace(
        marker,
        route_block + marker,
        1
    )

    APP.write_text(app_text, encoding="utf-8")

    print("SUCCESS: Security & Session route added.")

else:
    print("Security & Session route already exists. No duplicate route added.")


# ---------------------------------------------------------
# 2. MAKE THE SETTINGS CARD CLICKABLE
# ---------------------------------------------------------

settings_text = TEMPLATE.read_text(encoding="utf-8")

pattern = re.compile(
    r'    <!-- SECURITY -->.*?'
    r'    <!-- ACCOUNT PREFERENCES -->',
    re.DOTALL
)

replacement = '''    <!-- SECURITY -->

    <a
        href="{{ url_for('security_session_settings') }}"
        class="settings-card"
        style="text-decoration:none; color:inherit;">

        <div class="settings-icon">
            🛡
        </div>

        <div class="settings-content">

            <p class="settings-name">
                Security &amp; Session Settings
            </p>

            <p class="settings-description">
                Review your current login session and manage session access.
            </p>

        </div>

        <div class="settings-arrow">
            ›
        </div>

    </a>


    <!-- ACCOUNT PREFERENCES -->
'''

new_settings_text, count = pattern.subn(
    replacement,
    settings_text,
    count=1
)

if count != 1:
    print("ERROR: Security & Session Settings card could not be located.")
    print("The app.py route was added, but settings.html was not changed.")
    raise SystemExit(1)

TEMPLATE.write_text(new_settings_text, encoding="utf-8")

print("SUCCESS: Security & Session Settings card connected.")


# ---------------------------------------------------------
# 3. CREATE THE SECURITY & SESSION PAGE
# ---------------------------------------------------------

security_page = r'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Security &amp; Session Settings - Fairmont Bank</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            background:
                radial-gradient(
                    circle at top left,
                    rgba(35, 76, 125, 0.28),
                    transparent 38%
                ),
                linear-gradient(
                    180deg,
                    #07182d 0%,
                    #061426 100%
                );
            color: #ffffff;
            font-family: Arial, Helvetica, sans-serif;
        }

        .security-page {
            width: 100%;
            max-width: 760px;
            margin: 0 auto;
            padding: 22px 18px 45px;
        }

        .security-header {
            display: flex;
            align-items: center;
            gap: 14px;
            margin-bottom: 24px;
        }

        .back-button {
            width: 42px;
            height: 42px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            color: #ffffff;
            background: rgba(255,255,255,0.07);
            border: 1px solid rgba(255,255,255,0.10);
            font-size: 22px;
            flex: 0 0 42px;
        }

        .security-title {
            margin: 0;
            font-size: 24px;
            font-weight: 700;
        }

        .security-subtitle {
            margin: 4px 0 0;
            color: rgba(255,255,255,0.60);
            font-size: 13px;
        }

        .security-card {
            width: 100%;
            margin-bottom: 14px;
            padding: 18px;
            border-radius: 17px;
            background: rgba(13, 34, 59, 0.82);
            border: 1px solid rgba(255,255,255,0.09);
            box-shadow: 0 12px 30px rgba(0,0,0,0.18);
        }

        .security-card-title {
            margin: 0 0 6px;
            font-size: 16px;
            font-weight: 600;
        }

        .security-card-description {
            margin: 0;
            color: rgba(255,255,255,0.58);
            font-size: 12px;
            line-height: 1.5;
        }

        .session-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
            margin-top: 16px;
            padding-top: 15px;
            border-top: 1px solid rgba(255,255,255,0.08);
        }

        .session-label {
            color: rgba(255,255,255,0.55);
            font-size: 12px;
            margin-bottom: 4px;
        }

        .session-value {
            font-size: 14px;
            font-weight: 600;
        }

        .status-active {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            color: #ffffff;
        }

        .status-dot {
            width: 9px;
            height: 9px;
            border-radius: 50%;
            background: #4fd18b;
            display: inline-block;
        }

        .sign-out-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 44px;
            padding: 0 18px;
            border-radius: 12px;
            background: rgba(190, 64, 64, 0.18);
            border: 1px solid rgba(230, 100, 100, 0.30);
            color: #ffffff;
            text-decoration: none;
            font-size: 13px;
            font-weight: 600;
        }

        .sign-out-button:hover {
            background: rgba(190, 64, 64, 0.28);
        }

        .security-note {
            margin-top: 18px;
            padding: 15px 16px;
            border-radius: 14px;
            background: rgba(255,255,255,0.045);
            border: 1px solid rgba(255,255,255,0.07);
            color: rgba(255,255,255,0.52);
            font-size: 12px;
            line-height: 1.5;
        }

        @media (max-width: 600px) {

            .security-page {
                padding: 18px 14px 35px;
            }

            .security-title {
                font-size: 22px;
            }

            .session-row {
                align-items: flex-start;
                flex-direction: column;
            }

            .sign-out-button {
                width: 100%;
            }
        }
    </style>
</head>

<body>

<div class="security-page">

    <div class="security-header">

        <a
            href="{{ url_for('settings') }}"
            class="back-button"
            aria-label="Back to Settings">
            ‹
        </a>

        <div>
            <h1 class="security-title">
                Security &amp; Session Settings
            </h1>

            <p class="security-subtitle">
                Review your account security and current login session
            </p>
        </div>

    </div>


    <!-- CURRENT SESSION -->

    <div class="security-card">

        <p class="security-card-title">
            Current Session
        </p>

        <p class="security-card-description">
            This is the Fairmont Bank session currently signed in on this device.
        </p>

        <div class="session-row">

            <div>
                <div class="session-label">
                    Session status
                </div>

                <div class="session-value status-active">
                    <span class="status-dot"></span>
                    Active
                </div>
            </div>

            <div>
                <div class="session-label">
                    Customer ID
                </div>

                <div class="session-value">
                    {{ customer.customer_id }}
                </div>
            </div>

        </div>

    </div>


    <!-- ACCOUNT SECURITY -->

    <div class="security-card">

        <p class="security-card-title">
            Account Security
        </p>

        <p class="security-card-description">
            Your account requires a valid Fairmont Bank customer login before
            protected account information can be accessed.
        </p>

        <div class="session-row">

            <div>
                <div class="session-label">
                    Account status
                </div>

                <div class="session-value">
                    {{ customer.account_status }}
                </div>
            </div>

        </div>

    </div>


    <!-- SIGN OUT -->

    <div class="security-card">

        <p class="security-card-title">
            Sign Out
        </p>

        <p class="security-card-description">
            Sign out of the current Fairmont Bank session on this device.
        </p>

        <div class="session-row">

            <div>
                <div class="session-label">
                    Current session
                </div>

                <div class="session-value">
                    {{ customer.customer_id }}
                </div>
            </div>

            <a
                href="{{ url_for('logout') }}"
                class="sign-out-button">
                Sign Out
            </a>

        </div>

    </div>


    <div class="security-note">
        For stronger account protection, keep your password private and sign
        out when using a shared or public computer.
    </div>

</div>

</body>
</html>
'''

SECURITY_TEMPLATE.write_text(
    security_page,
    encoding="utf-8"
)

print("SUCCESS: Security & Session Settings page created.")
print()
print("Backups created:")
print(f" - {app_backup.name}")
print(f" - {template_backup.name}")