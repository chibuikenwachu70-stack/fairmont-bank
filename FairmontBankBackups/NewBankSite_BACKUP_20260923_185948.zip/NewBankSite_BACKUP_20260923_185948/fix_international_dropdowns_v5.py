from pathlib import Path
from datetime import datetime
import re

FILE = Path("templates") / "international_transfer.html"

if not FILE.exists():
    print("ERROR: international_transfer.html was not found.")
    raise SystemExit(1)

html = FILE.read_text(encoding="utf-8")

# ============================================================
# BACKUP
# ============================================================

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = FILE.with_name(
    f"international_transfer_BEFORE_V5_{timestamp}.html"
)

backup.write_text(html, encoding="utf-8")

print(f"Backup created: {backup.name}")
print()

# ============================================================
# SAFETY CHECKS
# ============================================================

required_ids = [
    "internationalCountry",
    "internationalBank",
    "internationalCurrency",
]

for element_id in required_ids:
    count = len(
        re.findall(
            rf'id=["\']{re.escape(element_id)}["\']',
            html,
            re.IGNORECASE
        )
    )

    print(f"{element_id}: {count}")

    if count != 1:
        print()
        print(
            f"ERROR: Expected exactly one element with id "
            f"'{element_id}', found {count}."
        )
        print("NO FILE WAS CHANGED.")
        raise SystemExit(1)

print()

# ============================================================
# REMOVE OLD FAIRmont PICKER CSS BLOCKS
# ============================================================

style_pattern = re.compile(
    r"<style\b[^>]*>.*?</style>",
    re.IGNORECASE | re.DOTALL
)

styles = list(style_pattern.finditer(html))

removed_styles = 0

for match in reversed(styles):
    block = match.group(0)

    old_markers = [
        "fairmont-picker",
        "fairmont-final",
        "quick-search-select",
        "search-select-wrapper",
        "search-select-dropdown",
        "countrySearchResults",
        "internationalBankSearchResults",
        "currencySearchResults",
    ]

    if any(marker in block for marker in old_markers):
        html = html[:match.start()] + html[match.end():]
        removed_styles += 1

print(f"Old picker style blocks removed: {removed_styles}")

# ============================================================
# REMOVE OLD PICKER JAVASCRIPT BLOCKS
# ============================================================

script_pattern = re.compile(
    r"<script\b[^>]*>.*?</script>",
    re.IGNORECASE | re.DOTALL
)

scripts = list(script_pattern.finditer(html))

removed_scripts = 0

for match in reversed(scripts):
    block = match.group(0)

    old_markers = [
        "fairmont-picker",
        "fairmont-final",
        "quick-search-select",
        "search-select-wrapper",
        "countrySearchResults",
        "internationalBankSearchResults",
        "currencySearchResults",
        "internationalCountry",
        "internationalBank",
        "internationalCurrency",
        "countryBanks",
    ]

    # Only remove scripts that are clearly picker-related.
    # Do not remove unrelated form/application scripts.
    picker_markers = [
        "fairmont-picker",
        "fairmont-final",
        "quick-search-select",
        "search-select-wrapper",
        "countrySearchResults",
        "internationalBankSearchResults",
        "currencySearchResults",
        "countryBanks",
    ]

    if any(marker in block for marker in picker_markers):
        html = html[:match.start()] + html[match.end():]
        removed_scripts += 1

print(f"Old picker script blocks removed: {removed_scripts}")

# ============================================================
# COUNTRY DATA
# ============================================================

countries = [
    "Afghanistan",
    "Albania",
    "Algeria",
    "Andorra",
    "Angola",
    "Antigua and Barbuda",
    "Argentina",
    "Armenia",
    "Australia",
    "Austria",
    "Azerbaijan",
    "Bahamas",
    "Bahrain",
    "Bangladesh",
    "Barbados",
    "Belarus",
    "Belgium",
    "Belize",
    "Benin",
    "Bhutan",
    "Bolivia",
    "Bosnia and Herzegovina",
    "Botswana",
    "Brazil",
    "Brunei",
    "Bulgaria",
    "Burkina Faso",
    "Burundi",
    "Cambodia",
    "Cameroon",
    "Canada",
    "Cape Verde",
    "Central African Republic",
    "Chad",
    "Chile",
    "China",
    "Colombia",
    "Comoros",
    "Costa Rica",
    "Croatia",
    "Cuba",
    "Cyprus",
    "Czech Republic",
    "Democratic Republic of the Congo",
    "Denmark",
    "Djibouti",
    "Dominica",
    "Dominican Republic",
    "Ecuador",
    "Egypt",
    "El Salvador",
    "Equatorial Guinea",
    "Eritrea",
    "Estonia",
    "Eswatini",
    "Ethiopia",
    "Fiji",
    "Finland",
    "France",
    "Gabon",
    "Gambia",
    "Georgia",
    "Germany",
    "Ghana",
    "Greece",
    "Grenada",
    "Guatemala",
    "Guinea",
    "Guyana",
    "Haiti",
    "Honduras",
    "Hungary",
    "Iceland",
    "India",
    "Indonesia",
    "Iraq",
    "Ireland",
    "Israel",
    "Italy",
    "Jamaica",
    "Japan",
    "Jordan",
    "Kazakhstan",
    "Kenya",
    "Kuwait",
    "Kyrgyzstan",
    "Laos",
    "Latvia",
    "Lebanon",
    "Lesotho",
    "Liberia",
    "Libya",
    "Liechtenstein",
    "Lithuania",
    "Luxembourg",
    "Madagascar",
    "Malawi",
    "Malaysia",
    "Maldives",
    "Mali",
    "Malta",
    "Mauritania",
    "Mauritius",
    "Mexico",
    "Moldova",
    "Monaco",
    "Mongolia",
    "Montenegro",
    "Morocco",
    "Mozambique",
    "Myanmar",
    "Namibia",
    "Nepal",
    "Netherlands",
    "New Zealand",
    "Nicaragua",
    "Niger",
    "Nigeria",
    "North Korea",
    "North Macedonia",
    "Norway",
    "Oman",
    "Pakistan",
    "Panama",
    "Papua New Guinea",
    "Paraguay",
    "Peru",
    "Philippines",
    "Poland",
    "Portugal",
    "Qatar",
    "Republic of the Congo",
    "Romania",
    "Russia",
    "Rwanda",
    "Saint Kitts and Nevis",
    "Saint Lucia",
    "Saint Vincent and the Grenadines",
    "Samoa",
    "San Marino",
    "Saudi Arabia",
    "Senegal",
    "Serbia",
    "Seychelles",
    "Sierra Leone",
    "Singapore",
    "Slovakia",
    "Slovenia",
    "Solomon Islands",
    "Somalia",
    "South Africa",
    "South Korea",
    "South Sudan",
    "Spain",
    "Sri Lanka",
    "Sudan",
    "Suriname",
    "Sweden",
    "Switzerland",
    "Syria",
    "Taiwan",
    "Tajikistan",
    "Tanzania",
    "Thailand",
    "Timor-Leste",
    "Togo",
    "Tonga",
    "Trinidad and Tobago",
    "Tunisia",
    "Turkey",
    "Turkmenistan",
    "Uganda",
    "Ukraine",
    "United Arab Emirates",
    "United Kingdom",
    "United States",
    "Uruguay",
    "Uzbekistan",
    "Vanuatu",
    "Vatican City",
    "Venezuela",
    "Vietnam",
    "Yemen",
    "Zambia",
    "Zimbabwe",
]

# ============================================================
# BANK DATA
# ============================================================

banks = {
    "United Kingdom": [
        "Allied Irish Bank (GB)",
        "Bank of Ireland UK",
        "Bank of Scotland",
        "Barclays Bank",
        "Birmingham Bank",
        "Card One Money",
        "Cashplus Bank",
        "Chase UK",
        "Citibank UK",
        "ClearBank",
        "C. Hoare & Co.",
        "Co-operative Bank",
        "Coutts",
        "Danske Bank",
        "First Direct",
        "Halifax",
        "Handelsbanken UK",
        "HSBC UK",
        "Investec Bank",
        "Lloyds Bank",
        "Metro Bank",
        "Monzo Bank",
        "Nationwide Building Society",
        "NatWest",
        "Revolut",
        "Royal Bank of Scotland",
        "Santander UK",
        "Skipton Building Society",
        "Starling Bank",
        "TSB Bank",
        "Ulster Bank",
        "Virgin Money",
        "Yorkshire Building Society",
        "Zopa Bank",
        "Other UK Bank or Building Society",
    ],

    "Suriname": [
        "De Surinaamsche Bank",
        "Republic Bank Suriname",
        "Hakrinbank",
        "Surinaamse Volkscredietbank",
        "Finabank",
        "Surichange Bank",
        "GODO",
        "Trustbank Amanah",
        "Postspaarbank",
        "Other Surinamese Bank",
    ],

    "United States": [
        "Bank of America",
        "JPMorgan Chase Bank",
        "Wells Fargo Bank",
        "Citibank",
        "U.S. Bank",
        "PNC Bank",
        "Truist Bank",
        "Capital One",
        "Goldman Sachs Bank USA",
        "Other US Bank",
    ],

    "Canada": [
        "Royal Bank of Canada",
        "Toronto-Dominion Bank",
        "Bank of Montreal",
        "Canadian Imperial Bank of Commerce",
        "Bank of Nova Scotia",
        "National Bank of Canada",
        "Desjardins",
        "Other Canadian Bank",
    ],

    "Australia": [
        "Commonwealth Bank",
        "Westpac",
        "Australia and New Zealand Banking Group",
        "National Australia Bank",
        "Macquarie Bank",
        "Other Australian Bank",
    ],

    "Germany": [
        "Deutsche Bank",
        "Commerzbank",
        "DZ Bank",
        "KfW",
        "ING Germany",
        "Other German Bank",
    ],

    "France": [
        "BNP Paribas",
        "Crédit Agricole",
        "Société Générale",
        "BPCE",
        "Crédit Mutuel",
        "Other French Bank",
    ],

    "Ireland": [
        "AIB",
        "Bank of Ireland",
        "Permanent TSB",
        "Revolut Bank",
        "Other Irish Bank",
    ],

    "Netherlands": [
        "ING Bank",
        "ABN AMRO",
        "Rabobank",
        "de Volksbank",
        "Other Dutch Bank",
    ],

    "Switzerland": [
        "UBS",
        "Julius Baer",
        "Zürcher Kantonalbank",
        "Banque Cantonale Vaudoise",
        "Other Swiss Bank",
    ],

    "India": [
        "State Bank of India",
        "HDFC Bank",
        "ICICI Bank",
        "Axis Bank",
        "Kotak Mahindra Bank",
        "IndusInd Bank",
        "Other Indian Bank",
    ],

    "China": [
        "Bank of China",
        "Industrial and Commercial Bank of China",
        "China Construction Bank",
        "Agricultural Bank of China",
        "Bank of Communications",
        "Other Chinese Bank",
    ],

    "Japan": [
        "MUFG Bank",
        "Sumitomo Mitsui Banking Corporation",
        "Mizuho Bank",
        "Resona Bank",
        "Other Japanese Bank",
    ],

    "Singapore": [
        "DBS Bank",
        "OCBC Bank",
        "United Overseas Bank",
        "Standard Chartered Singapore",
        "Other Singaporean Bank",
    ],

    "South Africa": [
        "Standard Bank",
        "First National Bank",
        "Absa Bank",
        "Nedbank",
        "Capitec Bank",
        "Investec Bank",
        "Other South African Bank",
    ],

    "Kenya": [
        "KCB Bank Kenya",
        "Equity Bank Kenya",
        "Co-operative Bank of Kenya",
        "Absa Bank Kenya",
        "NCBA Bank Kenya",
        "Stanbic Bank Kenya",
        "I&M Bank",
        "DTB Bank Kenya",
        "Family Bank",
        "Other Kenyan Bank",
    ],

    "Nigeria": [
        "Access Bank",
        "First Bank of Nigeria",
        "Guaranty Trust Bank",
        "Zenith Bank",
        "United Bank for Africa",
        "Fidelity Bank",
        "Other Nigerian Bank",
    ],

    "Ghana": [
        "GCB Bank",
        "Ecobank Ghana",
        "Absa Bank Ghana",
        "Stanbic Bank Ghana",
        "Fidelity Bank Ghana",
        "Republic Bank Ghana",
        "Other Ghanaian Bank",
    ],

    "United Arab Emirates": [
        "Emirates NBD",
        "First Abu Dhabi Bank",
        "Abu Dhabi Commercial Bank",
        "Mashreq Bank",
        "Dubai Islamic Bank",
        "RAKBANK",
        "Other UAE Bank",
    ],

    "Saudi Arabia": [
        "Saudi National Bank",
        "Al Rajhi Bank",
        "Riyad Bank",
        "Alinma Bank",
        "Banque Saudi Fransi",
        "Arab National Bank",
        "Other Saudi Bank",
    ],

    "Qatar": [
        "Qatar National Bank",
        "Qatar Islamic Bank",
        "Commercial Bank Qatar",
        "Doha Bank",
        "Masraf Al Rayan",
        "Other Qatari Bank",
    ],

    "Brazil": [
        "Banco do Brasil",
        "Itaú Unibanco",
        "Bradesco",
        "Caixa Econômica Federal",
        "Santander Brasil",
        "Other Brazilian Bank",
    ],

    "Mexico": [
        "BBVA México",
        "Banorte",
        "Santander México",
        "HSBC México",
        "Citibanamex",
        "Other Mexican Bank",
    ],
}

# ============================================================
# CURRENCY DATA
# ============================================================

currencies = [
    ("GBP", "Pound Sterling"),
    ("EUR", "Euro"),
    ("USD", "US Dollar"),
    ("CAD", "Canadian Dollar"),
    ("AUD", "Australian Dollar"),
    ("NZD", "New Zealand Dollar"),
    ("CHF", "Swiss Franc"),
    ("JPY", "Japanese Yen"),
    ("CNY", "Chinese Yuan"),
    ("SGD", "Singapore Dollar"),
    ("INR", "Indian Rupee"),
    ("AED", "UAE Dirham"),
    ("SAR", "Saudi Riyal"),
    ("QAR", "Qatari Riyal"),
    ("ZAR", "South African Rand"),
    ("KES", "Kenyan Shilling"),
    ("NGN", "Nigerian Naira"),
    ("GHS", "Ghanaian Cedi"),
    ("TZS", "Tanzanian Shilling"),
    ("UGX", "Ugandan Shilling"),
    ("BRL", "Brazilian Real"),
    ("MXN", "Mexican Peso"),
    ("SRD", "Surinamese Dollar"),
    ("THB", "Thai Baht"),
    ("MYR", "Malaysian Ringgit"),
    ("IDR", "Indonesian Rupiah"),
    ("KRW", "South Korean Won"),
    ("TRY", "Turkish Lira"),
    ("PLN", "Polish Zloty"),
    ("SEK", "Swedish Krona"),
    ("NOK", "Norwegian Krone"),
    ("DKK", "Danish Krone"),
    ("CZK", "Czech Koruna"),
    ("HUF", "Hungarian Forint"),
    ("RON", "Romanian Leu"),
    ("ILS", "Israeli New Shekel"),
]

# ============================================================
# BUILD JAVASCRIPT DATA
# ============================================================

import json

country_json = json.dumps(countries, ensure_ascii=False)
banks_json = json.dumps(banks, ensure_ascii=False)
currency_json = json.dumps(
    [
        {"code": code, "name": name}
        for code, name in currencies
    ],
    ensure_ascii=False
)

# ============================================================
# NEW CSS
# ============================================================

new_css = r"""
<style id="fairmont-clean-picker-css">

/* ==========================================================
   FAIRMONT CLEAN SEARCH DROPDOWNS
   ========================================================== */

.fairmont-clean-picker-select {
    position: relative;
}

.fairmont-clean-real-select {
    position: absolute !important;
    width: 1px !important;
    height: 1px !important;
    min-width: 1px !important;
    min-height: 1px !important;
    opacity: 0 !important;
    pointer-events: none !important;
    overflow: hidden !important;
    clip: rect(0 0 0 0) !important;
}

.fairmont-clean-trigger {
    width: 100%;
    min-height: 50px;
    box-sizing: border-box;
    border: 1px solid rgba(255,255,255,.12);
    border-radius: 12px;
    background: rgba(255,255,255,.055);
    color: #ffffff;
    padding: 0 14px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    cursor: pointer;
    font: inherit;
    text-align: left;
}

.fairmont-clean-trigger:hover {
    border-color: rgba(255,255,255,.25);
}

.fairmont-clean-trigger:focus {
    outline: none;
    border-color: rgba(255,255,255,.38);
}

.fairmont-clean-trigger-value {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.fairmont-clean-trigger-arrow {
    flex: 0 0 auto;
    opacity: .7;
    font-size: 13px;
}

.fairmont-clean-popup {
    position: fixed;
    z-index: 999999;
    width: min(420px, calc(100vw - 28px));
    background: #111b30;
    border: 1px solid rgba(255,255,255,.16);
    border-radius: 16px;
    box-shadow: 0 22px 70px rgba(0,0,0,.60);
    overflow: hidden;
}

.fairmont-clean-search {
    display: block;
    width: calc(100% - 24px);
    height: 44px;
    margin: 12px;
    padding: 0 13px;
    box-sizing: border-box;
    border: 1px solid rgba(255,255,255,.16);
    border-radius: 11px;
    background: rgba(255,255,255,.07);
    color: #ffffff;
    outline: none;
    font-size: 14px;
}

.fairmont-clean-search::placeholder {
    color: rgba(255,255,255,.50);
}

.fairmont-clean-options {
    max-height: min(360px, 48vh);
    overflow-y: auto;
    padding: 6px;
}

.fairmont-clean-option {
    display: block;
    width: 100%;
    border: 0;
    background: transparent;
    color: #ffffff;
    padding: 12px 13px;
    border-radius: 10px;
    text-align: left;
    cursor: pointer;
    font-size: 14px;
}

.fairmont-clean-option:hover {
    background: rgba(255,255,255,.09);
}

.fairmont-clean-option.selected {
    background: rgba(255,255,255,.13);
}

.fairmont-clean-empty {
    padding: 20px;
    color: rgba(255,255,255,.50);
    text-align: center;
    font-size: 14px;
}

</style>
"""

# ============================================================
# NEW JAVASCRIPT
# ============================================================

new_js = f"""
<script id="fairmont-clean-picker-js">
(function () {{
    "use strict";

    const COUNTRIES = {country_json};

    const BANKS = {banks_json};

    const CURRENCIES = {currency_json};

    const countrySelect = document.getElementById("internationalCountry");
    const bankSelect = document.getElementById("internationalBank");
    const currencySelect = document.getElementById("internationalCurrency");

    if (!countrySelect || !bankSelect || !currencySelect) {{
        console.error("Fairmont clean picker: required select elements were not found.");
        return;
    }}

    /*
     * ----------------------------------------------------------
     * Populate real hidden selects
     * ----------------------------------------------------------
     */

    function clearSelect(select) {{
        while (select.options.length > 0) {{
            select.remove(0);
        }}
    }}

    function addOption(select, value, text) {{
        const option = document.createElement("option");
        option.value = value;
        option.textContent = text;
        select.appendChild(option);
    }}

    clearSelect(countrySelect);
    addOption(countrySelect, "", "Select country");

    COUNTRIES.forEach(function (country) {{
        addOption(countrySelect, country, country);
    }});

    clearSelect(bankSelect);
    addOption(bankSelect, "", "Select a bank");

    clearSelect(currencySelect);
    addOption(currencySelect, "", "Select currency");

    CURRENCIES.forEach(function (currency) {{
        addOption(
            currencySelect,
            currency.code,
            currency.code + " — " + currency.name
        );
    }});

    /*
     * ----------------------------------------------------------
     * Bank list depends on selected country
     * ----------------------------------------------------------
     */

    function populateBanks(country) {{
        clearSelect(bankSelect);

        addOption(bankSelect, "", "Select a bank");

        let list = BANKS[country];

        if (!Array.isArray(list) || list.length === 0) {{
            if (country) {{
                list = ["Other bank in " + country];
            }} else {{
                list = [];
            }}
        }}

        list.forEach(function (bank) {{
            addOption(bankSelect, bank, bank);
        }});

        bankSelect.value = "";
    }}

    countrySelect.addEventListener("change", function () {{
        populateBanks(countrySelect.value);
    }});

    /*
     * ----------------------------------------------------------
     * Create one clean visible trigger for each select
     * ----------------------------------------------------------
     */

    function createPicker(select, type, placeholder) {{
        const field = select.closest(".field");

        if (!field) {{
            console.error(
                "Fairmont clean picker: field wrapper not found for",
                select.id
            );
            return;
        }}

        field.classList.add("fairmont-clean-picker-select");

        /*
         * Remove only triggers generated by this clean picker.
         * This prevents duplicates if the script is accidentally
         * initialized twice.
         */
        field.querySelectorAll(
            '[data-fairmont-clean-trigger="' + type + '"]'
        ).forEach(function (node) {{
            node.remove();
        }});

        select.classList.add("fairmont-clean-real-select");

        const trigger = document.createElement("button");

        trigger.type = "button";
        trigger.className = "fairmont-clean-trigger";
        trigger.setAttribute(
            "data-fairmont-clean-trigger",
            type
        );
        trigger.setAttribute("aria-expanded", "false");

        const value = document.createElement("span");
        value.className = "fairmont-clean-trigger-value";
        value.textContent = placeholder;

        const arrow = document.createElement("span");
        arrow.className = "fairmont-clean-trigger-arrow";
        arrow.textContent = "▾";

        trigger.appendChild(value);
        trigger.appendChild(arrow);

        select.insertAdjacentElement("afterend", trigger);

        select.addEventListener("change", function () {{
            const selected =
                select.options[select.selectedIndex];

            value.textContent =
                selected && selected.value
                    ? selected.textContent
                    : placeholder;
        }});

        return {{
            field: field,
            select: select,
            trigger: trigger,
            value: value,
            type: type,
            placeholder: placeholder
        }};
    }}

    const countryPicker = createPicker(
        countrySelect,
        "country",
        "Select country"
    );

    const bankPicker = createPicker(
        bankSelect,
        "bank",
        "Select a bank"
    );

    const currencyPicker = createPicker(
        currencySelect,
        "currency",
        "Select currency"
    );

    /*
     * ----------------------------------------------------------
     * Popup
     * ----------------------------------------------------------
     */

    let activePicker = null;
    let popup = null;

    function closePopup() {{
        if (popup) {{
            popup.remove();
            popup = null;
        }}

        if (activePicker) {{
            activePicker.trigger.setAttribute(
                "aria-expanded",
                "false"
            );
        }}

        activePicker = null;
    }}

    function positionPopup() {{
        if (!popup || !activePicker) {{
            return;
        }}

        const rect =
            activePicker.trigger.getBoundingClientRect();

        const popupWidth =
            Math.min(420, window.innerWidth - 28);

        let left =
            rect.left + (rect.width / 2) - (popupWidth / 2);

        left = Math.max(
            14,
            Math.min(
                left,
                window.innerWidth - popupWidth - 14
            )
        );

        const popupHeight =
            Math.min(
                460,
                window.innerHeight - 28
            );

        let top = rect.bottom + 8;

        if (
            top + popupHeight >
            window.innerHeight - 14
        ) {{
            top = rect.top - popupHeight - 8;
        }}

        if (top < 14) {{
            top = 14;
        }}

        popup.style.width = popupWidth + "px";
        popup.style.left = left + "px";
        popup.style.top = top + "px";
    }}

    function getOptions(picker) {{
        const select = picker.select;

        return Array.from(select.options)
            .filter(function (option) {{
                return option.value !== "";
            }})
            .map(function (option) {{
                return {{
                    value: option.value,
                    text: option.textContent
                }};
            }});
    }}

    function openPopup(picker) {{
        closePopup();

        activePicker = picker;

        picker.trigger.setAttribute(
            "aria-expanded",
            "true"
        );

        popup = document.createElement("div");
        popup.className = "fairmont-clean-popup";

        const search = document.createElement("input");

        search.type = "search";
        search.className = "fairmont-clean-search";
        search.placeholder =
            picker.type === "country"
                ? "Search country..."
                : picker.type === "bank"
                    ? "Search bank..."
                    : "Search currency...";

        search.autocomplete = "off";
        search.spellcheck = false;

        const optionsBox = document.createElement("div");

        optionsBox.className =
            "fairmont-clean-options";

        popup.appendChild(search);
        popup.appendChild(optionsBox);

        document.body.appendChild(popup);

        function renderOptions(filterText) {{
            const query =
                String(filterText || "")
                    .trim()
                    .toLowerCase();

            optionsBox.innerHTML = "";

            const options = getOptions(picker)
                .filter(function (option) {{
                    return !query ||
                        option.text
                            .toLowerCase()
                            .includes(query);
                }});

            if (options.length === 0) {{
                const empty =
                    document.createElement("div");

                empty.className =
                    "fairmont-clean-empty";

                empty.textContent =
                    "No matching results";

                optionsBox.appendChild(empty);

                return;
            }}

            options.forEach(function (option) {{
                const button =
                    document.createElement("button");

                button.type = "button";
                button.className =
                    "fairmont-clean-option";

                if (
                    picker.select.value ===
                    option.value
                ) {{
                    button.classList.add("selected");
                }}

                button.textContent = option.text;

                button.addEventListener(
                    "click",
                    function (event) {{
                        event.stopPropagation();

                        picker.select.value =
                            option.value;

                        picker.select.dispatchEvent(
                            new Event("change", {{
                                bubbles: true
                            }})
                        );

                        closePopup();
                    }}
                );

                optionsBox.appendChild(button);
            }});
        }}

        renderOptions("");

        search.addEventListener(
            "input",
            function () {{
                renderOptions(search.value);
            }}
        );

        popup.addEventListener(
            "click",
            function (event) {{
                event.stopPropagation();
            }}
        );

        positionPopup();

        setTimeout(function () {{
            search.focus();
        }}, 0);
    }}

    [countryPicker, bankPicker, currencyPicker]
        .filter(Boolean)
        .forEach(function (picker) {{
            picker.trigger.addEventListener(
                "click",
                function (event) {{
                    event.preventDefault();
                    event.stopPropagation();

                    if (
                        activePicker === picker &&
                        popup
                    ) {{
                        closePopup();
                    }} else {{
                        openPopup(picker);
                    }}
                }}
            );
        }});

    /*
     * Close when clicking outside.
     */

    document.addEventListener(
        "click",
        function () {{
            closePopup();
        }}
    );

    /*
     * Close with Escape.
     */

    document.addEventListener(
        "keydown",
        function (event) {{
            if (event.key === "Escape") {{
                closePopup();
            }}
        }}
    );

    /*
     * Reposition on scroll/resize.
     */

    window.addEventListener(
        "resize",
        positionPopup
    );

    window.addEventListener(
        "scroll",
        positionPopup,
        true
    );

    /*
     * Initial bank state.
     */

    populateBanks(countrySelect.value);

    /*
     * Make absolutely sure the three original native selects
     * cannot visually appear as duplicate controls.
     */

    [countrySelect, bankSelect, currencySelect]
        .forEach(function (select) {{
            select.classList.add(
                "fairmont-clean-real-select"
            );
        }});

    console.log(
        "Fairmont clean transfer pickers initialized successfully."
    );
}})();
</script>
"""

# ============================================================
# INSERT CSS BEFORE </head>
# ============================================================

if "</head>" not in html.lower():
    print()
    print("ERROR: </head> was not found.")
    print("NO FILE WAS CHANGED.")
    raise SystemExit(1)

html = re.sub(
    r"</head>",
    new_css + "\n</head>",
    html,
    count=1,
    flags=re.IGNORECASE
)

# ============================================================
# INSERT JAVASCRIPT BEFORE </body>
# ============================================================

if "</body>" not in html.lower():
    print()
    print("ERROR: </body> was not found.")
    print("NO FILE WAS CHANGED.")
    raise SystemExit(1)

html = re.sub(
    r"</body>",
    new_js + "\n</body>",
    html,
    count=1,
    flags=re.IGNORECASE
)

# ============================================================
# FINAL SAFETY VALIDATION
# ============================================================

checks = {
    "country select": len(
        re.findall(
            r'id=["\']internationalCountry["\']',
            html,
            re.IGNORECASE
        )
    ),
    "bank select": len(
        re.findall(
            r'id=["\']internationalBank["\']',
            html,
            re.IGNORECASE
        )
    ),
    "currency select": len(
        re.findall(
            r'id=["\']internationalCurrency["\']',
            html,
            re.IGNORECASE
        )
    ),
    "clean CSS": html.count(
        'id="fairmont-clean-picker-css"'
    ),
    "clean JS": html.count(
        'id="fairmont-clean-picker-js"'
    ),
}

print()
print("=" * 70)
print("FINAL VALIDATION")
print("=" * 70)

for name, count in checks.items():
    print(f"{name}: {count}")

if checks["country select"] != 1:
    print("ERROR: Country select validation failed.")
    print("NO FILE WAS CHANGED.")
    raise SystemExit(1)

if checks["bank select"] != 1:
    print("ERROR: Bank select validation failed.")
    print("NO FILE WAS CHANGED.")
    raise SystemExit(1)

if checks["currency select"] != 1:
    print("ERROR: Currency select validation failed.")
    print("NO FILE WAS CHANGED.")
    raise SystemExit(1)

if checks["clean CSS"] != 1:
    print("ERROR: Clean CSS validation failed.")
    print("NO FILE WAS CHANGED.")
    raise SystemExit(1)

if checks["clean JS"] != 1:
    print("ERROR: Clean JavaScript validation failed.")
    print("NO FILE WAS CHANGED.")
    raise SystemExit(1)

# ============================================================
# WRITE ONLY AFTER ALL VALIDATIONS PASS
# ============================================================

FILE.write_text(html, encoding="utf-8")

print()
print("=" * 70)
print("SUCCESS")
print("=" * 70)
print()
print("international_transfer.html was updated.")
print()
print("The page now has:")
print("  1. One Country field")
print("  2. One Bank field")
print("  3. One Currency field")
print()
print("Each field:")
print("  - opens when clicked")
print("  - contains its own search box")
print("  - shows the matching options underneath")
print("  - closes after selection")
print()
print("Bank options change according to the selected country.")
print()
print("No backend files were changed.")
print("No database files were changed.")
print("No dashboard files were changed.")
print()
print(f"Backup: {backup.name}")