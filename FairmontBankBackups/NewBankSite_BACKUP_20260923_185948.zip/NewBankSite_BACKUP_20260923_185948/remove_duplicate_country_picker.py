from pathlib import Path
import re
import shutil

BASE_DIR = Path(__file__).resolve().parent
TEMPLATE = BASE_DIR / "templates" / "international_transfer.html"

if not TEMPLATE.exists():
    print("ERROR: international_transfer.html was not found.")
    raise SystemExit(1)

# ------------------------------------------------------------
# BACKUP
# ------------------------------------------------------------

backup = TEMPLATE.with_name(
    "international_transfer_before_duplicate_country_fix.html"
)

if not backup.exists():
    shutil.copy2(TEMPLATE, backup)
    print("Backup created:")
    print(backup)

html = TEMPLATE.read_text(encoding="utf-8")


# ------------------------------------------------------------
# MAKE SURE THE NATIVE SELECTS ARE COMPLETELY HIDDEN
# ------------------------------------------------------------

extra_css = r"""
<style id="fairmont-remove-native-selects">
/* Hide the original native selects completely.
   The custom searchable buttons are used instead. */

select.fairmont-hidden-select,
#internationalCountry.fairmont-hidden-select,
#internationalBank.fairmont-hidden-select,
#internationalCurrency.fairmont-hidden-select {
    position: absolute !important;
    width: 1px !important;
    height: 1px !important;
    min-width: 1px !important;
    min-height: 1px !important;
    max-width: 1px !important;
    max-height: 1px !important;
    opacity: 0 !important;
    visibility: hidden !important;
    pointer-events: none !important;
    border: 0 !important;
    padding: 0 !important;
    margin: 0 !important;
    overflow: hidden !important;
    clip: rect(0 0 0 0) !important;
    clip-path: inset(50%) !important;
    white-space: nowrap !important;
}
</style>
"""

# Remove an older copy if this script has been run before.
html = re.sub(
    r'<style[^>]*id=["\']fairmont-remove-native-selects["\'][^>]*>.*?</style>',
    '',
    html,
    flags=re.IGNORECASE | re.DOTALL
)

html = html.replace("</head>", extra_css + "\n</head>", 1)


# ------------------------------------------------------------
# REMOVE DUPLICATE CUSTOM BUTTONS
# ------------------------------------------------------------

# The new picker should have exactly ONE visible button per field.
# Remove previously generated buttons that are immediately associated
# with the three selects.

html = re.sub(
    r'<button[^>]*class=["\'][^"\']*fairmont-picker-trigger[^"\']*["\'][^>]*>.*?</button>',
    '',
    html,
    flags=re.IGNORECASE | re.DOTALL
)


# ------------------------------------------------------------
# ADD A CLEAN INITIALIZATION SCRIPT
# ------------------------------------------------------------

script = r"""
<script id="fairmont-clean-picker-init">
(function () {
    "use strict";

    function initializeFairmontPickers() {

        var country = document.getElementById("internationalCountry");
        var bank = document.getElementById("internationalBank");
        var currency = document.getElementById("internationalCurrency");

        if (!country || !bank || !currency) {
            console.error(
                "Fairmont picker: required fields were not found."
            );
            return;
        }

        /*
         * Remove any duplicate visible controls created by previous
         * versions of the picker.
         */
        document.querySelectorAll(
            ".fairmont-picker-trigger"
        ).forEach(function (button) {
            button.remove();
        });

        /*
         * Make absolutely sure the native selects remain hidden.
         */
        country.classList.add("fairmont-hidden-select");
        bank.classList.add("fairmont-hidden-select");
        currency.classList.add("fairmont-hidden-select");

        country.style.display = "none";
        bank.style.display = "none";
        currency.style.display = "none";

        /*
         * Prevent this cleanup from being mistaken for a visible
         * native select.
         */
        country.setAttribute("aria-hidden", "true");
        bank.setAttribute("aria-hidden", "true");
        currency.setAttribute("aria-hidden", "true");

        console.log(
            "Fairmont: duplicate native country selector removed."
        );
    }

    if (document.readyState === "loading") {
        document.addEventListener(
            "DOMContentLoaded",
            initializeFairmontPickers
        );
    } else {
        initializeFairmontPickers();
    }

})();
</script>
"""

# Remove an older copy.
html = re.sub(
    r'<script[^>]*id=["\']fairmont-clean-picker-init["\'][^>]*>.*?</script>',
    '',
    html,
    flags=re.IGNORECASE | re.DOTALL
)

html = html.replace("</body>", script + "\n</body>", 1)


# ------------------------------------------------------------
# SAVE
# ------------------------------------------------------------

TEMPLATE.write_text(html, encoding="utf-8")

print()
print("==============================================")
print("DUPLICATE COUNTRY SELECTOR FIXED")
print("==============================================")
print()
print("The original native Country selector is now")
print("completely hidden.")
print()
print("The same cleanup was applied to:")
print("  - Country")
print("  - Bank")
print("  - Currency")
print()
print("Backup:")
print(backup)
print()
print("Restart Flask and press Ctrl + F5.")
print()