from pathlib import Path

file = Path("templates/dashboard.html")

if not file.exists():
    raise SystemExit("ERROR: templates/dashboard.html was not found.")

text = file.read_text(encoding="utf-8")

old_css = """<style id="email-bank-visible-label-css">

.dashboard-email-button {
    gap: 8px;
    white-space: nowrap;
}

.dashboard-email-label {
    font-size: 14px;
    font-weight: 600;
    line-height: 1;
    color: inherit;
}

</style>"""

new_css = """<style id="email-bank-visible-label-css">

.dashboard-email-button {
    width: auto !important;
    min-width: 0;
    height: 42px;
    padding: 0 12px;
    gap: 8px;
    white-space: nowrap;
    flex-shrink: 0;
    box-sizing: border-box;
}

.dashboard-email-icon {
    flex-shrink: 0;
}

.dashboard-email-label {
    display: inline-block;
    font-size: 14px;
    font-weight: 600;
    line-height: 1;
    white-space: nowrap;
}

</style>"""

if old_css in text:
    text = text.replace(old_css, new_css, 1)
    print("SUCCESS: Email Bank button width has been corrected.")
else:
    # If the exact previous block differs, replace the existing
    # visible-label style block safely.
    start = text.find('<style id="email-bank-visible-label-css">')

    if start == -1:
        raise SystemExit(
            "ERROR: The Email Bank label CSS block was not found."
        )

    end = text.find("</style>", start)

    if end == -1:
        raise SystemExit(
            "ERROR: The Email Bank label CSS block is incomplete."
        )

    end += len("</style>")

    text = text[:start] + new_css + text[end:]

    print("SUCCESS: Email Bank label CSS was corrected.")

file.write_text(text, encoding="utf-8")

print()
print("Email Bank now has its own properly sized button.")
print("The notification bell will no longer be covered.")
print("No other dashboard elements were changed.")