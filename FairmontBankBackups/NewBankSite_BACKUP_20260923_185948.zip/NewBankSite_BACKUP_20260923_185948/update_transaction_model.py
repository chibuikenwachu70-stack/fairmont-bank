from pathlib import Path
import re

BASE_DIR = Path(__file__).resolve().parent
FILE = BASE_DIR / "app.py"

text = FILE.read_text(encoding="utf-8")

fields = """    sender_name = db.Column(
        db.String(150),
        nullable=True
    )

    sender_account_number = db.Column(
        db.String(50),
        nullable=True
    )

    sender_bank = db.Column(
        db.String(150),
        nullable=True
    )

    sender_country = db.Column(
        db.String(100),
        nullable=True
    )
"""

# Locate the Transaction model
model_match = re.search(
    r'class Transaction\(db\.Model\):.*?(?=\nclass |\n@app\.route|\nif __name__)',
    text,
    flags=re.DOTALL
)

if not model_match:
    print("ERROR: Transaction model was not found.")
    raise SystemExit(1)

model_block = model_match.group(0)

if "sender_name = db.Column" in model_block:
    print("Sender fields are already present in the Transaction model.")
else:
    marker = """    status = db.Column(
        db.String(30),
        nullable=False,
        default="Completed"
    )"""

    if marker not in model_block:
        print("ERROR: Transaction status field could not be located.")
        print("No changes were made.")
        raise SystemExit(1)

    updated_model = model_block.replace(
        marker,
        marker + "\n\n" + fields,
        1
    )

    text = text[:model_match.start()] + updated_model + text[model_match.end():]

    FILE.write_text(text, encoding="utf-8")

    print("Transaction sender fields added to the model successfully.")

print()
print("=" * 70)
print("TRANSACTION MODEL UPDATE COMPLETE")
print("=" * 70)