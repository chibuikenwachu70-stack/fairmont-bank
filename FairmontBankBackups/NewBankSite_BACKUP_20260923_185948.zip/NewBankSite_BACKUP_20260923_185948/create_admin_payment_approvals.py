from pathlib import Path

path = Path("app.py")
text = path.read_text(encoding="utf-8")

if 'def admin_payment_approvals():' in text:
    print("Admin Payment Approvals route already exists.")
    raise SystemExit(0)

marker = '\n\n@app.route("/admin/incoming-payment"'

if marker not in text:
    print("ERROR: Could not find the admin incoming payment route.")
    print("No changes were made.")
    raise SystemExit(1)

route = r'''

@app.route("/admin/payment-approvals")
def admin_payment_approvals():
    admin_id = session.get("admin_id")

    if not admin_id:
        return redirect(url_for("admin_login"))

    admin = db.session.get(AdminUser, admin_id)

    if admin is None or not admin.is_active:
        session.pop("admin_id", None)
        session.pop("admin_username", None)
        return redirect(url_for("admin_login"))

    status_filter = request.args.get("status", "Pending Approval").strip()

    allowed_statuses = {
        "Pending Approval",
        "Approved",
        "Rejected",
        "All"
    }

    if status_filter not in allowed_statuses:
        status_filter = "Pending Approval"

    query = PaymentApproval.query

    if status_filter != "All":
        query = query.filter_by(status=status_filter)

    approvals = query.order_by(
        PaymentApproval.created_at.desc()
    ).all()

    customer_map = {}

    customer_ids = {
        approval.customer_id
        for approval in approvals
        if approval.customer_id
    }

    if customer_ids:
        customers = Customer.query.filter(
            Customer.customer_id.in_(customer_ids)
        ).all()

        customer_map = {
            customer.customer_id: customer
            for customer in customers
        }

    pending_count = PaymentApproval.query.filter_by(
        status="Pending Approval"
    ).count()

    approved_count = PaymentApproval.query.filter_by(
        status="Approved"
    ).count()

    rejected_count = PaymentApproval.query.filter_by(
        status="Rejected"
    ).count()

    return render_template(
        "admin_payment_approvals.html",
        admin=admin,
        approvals=approvals,
        customer_map=customer_map,
        status_filter=status_filter,
        pending_count=pending_count,
        approved_count=approved_count,
        rejected_count=rejected_count
    )
'''

text = text.replace(marker, route + marker, 1)

path.write_text(text, encoding="utf-8")

print("SUCCESS: Admin Payment Approvals route added.")