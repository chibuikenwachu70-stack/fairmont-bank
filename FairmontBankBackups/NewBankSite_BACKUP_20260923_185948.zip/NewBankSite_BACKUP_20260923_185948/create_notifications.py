from pathlib import Path

APP_FILE = Path("app.py")
DASHBOARD_FILE = Path("templates/dashboard.html")
NOTIFICATIONS_FILE = Path("templates/notifications.html")

if not APP_FILE.exists():
    raise SystemExit("ERROR: app.py was not found.")

if not DASHBOARD_FILE.exists():
    raise SystemExit("ERROR: templates/dashboard.html was not found.")


# =========================================================
# 1. ADD NOTIFICATION MODEL
# =========================================================

app_text = APP_FILE.read_text(encoding="utf-8")

if "class Notification(" not in app_text:

    model_marker = "class Transaction("

    if model_marker not in app_text:
        raise SystemExit(
            "ERROR: Transaction model could not be located."
        )

    notification_model = '''class Notification(db.Model):

    id = db.Column(db.Integer, primary_key=True)

    customer_id = db.Column(
        db.String(50),
        nullable=False,
        index=True
    )

    title = db.Column(
        db.String(150),
        nullable=False
    )

    message = db.Column(
        db.Text,
        nullable=False
    )

    notification_type = db.Column(
        db.String(50),
        default="General",
        nullable=False
    )

    is_read = db.Column(
        db.Boolean,
        default=False,
        nullable=False
    )

    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow,
        nullable=False
    )


'''

    app_text = app_text.replace(
        model_marker,
        notification_model + model_marker,
        1
    )

    print("SUCCESS: Notification model added.")

else:
    print("INFO: Notification model already exists.")


# =========================================================
# 2. ADD NOTIFICATION ROUTES
# =========================================================

if '@app.route("/notifications")' not in app_text:

    route_marker = '@app.route("/transactions")'

    if route_marker not in app_text:
        raise SystemExit(
            "ERROR: Transaction route could not be located."
        )

    notification_routes = '''@app.route("/notifications")
def notifications():

    customer_id = session.get("customer_id")

    if not customer_id:
        return redirect(url_for("login"))

    customer = Customer.query.filter_by(
        customer_id=customer_id
    ).first()

    if customer is None:
        session.clear()
        return redirect(url_for("login"))

    notification_list = (
        Notification.query
        .filter_by(customer_id=customer.customer_id)
        .order_by(Notification.created_at.desc())
        .all()
    )

    unread_count = (
        Notification.query
        .filter_by(
            customer_id=customer.customer_id,
            is_read=False
        )
        .count()
    )

    return render_template(
        "notifications.html",
        customer=customer,
        notifications=notification_list,
        unread_count=unread_count
    )


@app.route("/notifications/<int:notification_id>/read", methods=["POST"])
def mark_notification_read(notification_id):

    customer_id = session.get("customer_id")

    if not customer_id:
        return redirect(url_for("login"))

    notification = Notification.query.filter_by(
        id=notification_id,
        customer_id=customer_id
    ).first()

    if notification is None:
        return ("Notification not found.", 404)

    notification.is_read = True

    db.session.commit()

    return redirect(url_for("notifications"))


@app.route("/notifications/mark-all-read", methods=["POST"])
def mark_all_notifications_read():

    customer_id = session.get("customer_id")

    if not customer_id:
        return redirect(url_for("login"))

    Notification.query.filter_by(
        customer_id=customer_id,
        is_read=False
    ).update(
        {
            "is_read": True
        },
        synchronize_session=False
    )

    db.session.commit()

    return redirect(url_for("notifications"))


'''

    app_text = app_text.replace(
        route_marker,
        notification_routes + route_marker,
        1
    )

    print("SUCCESS: Notification routes added.")

else:
    print("INFO: Notification routes already exist.")


# =========================================================
# 3. CREATE NOTIFICATIONS PAGE
# =========================================================

if not NOTIFICATIONS_FILE.exists():

    notifications_html = '''<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0">

    <title>Notifications | Fairmont Bank</title>

    <link
        rel="stylesheet"
        href="{{ url_for('static', filename='css/style.css') }}">

    <style>

        .notification-page {
            min-height: 100vh;
            padding: 24px 16px;
        }

        .notification-shell {
            width: min(760px, 100%);
            margin: 0 auto;
        }

        .notification-header {
            display: flex;
            align-items: center;
            gap: 14px;
            margin-bottom: 22px;
        }

        .notification-back {
            text-decoration: none;
            font-size: 24px;
        }

        .notification-header h1 {
            margin: 0;
        }

        .notification-header p {
            margin: 3px 0 0;
            opacity: .7;
            font-size: 13px;
        }

        .notification-toolbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            margin-bottom: 18px;
        }

        .notification-count {
            font-size: 14px;
            opacity: .75;
        }

        .notification-toolbar form {
            margin: 0;
        }

        .notification-toolbar button {
            border: 0;
            border-radius: 10px;
            padding: 10px 14px;
            cursor: pointer;
            font-weight: 600;
        }

        .notification-list {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .notification-item {
            position: relative;
            padding: 17px;
            border-radius: 16px;
            background: rgba(255,255,255,.06);
            border: 1px solid rgba(255,255,255,.09);
        }

        .notification-item.unread {
            border-color: rgba(255,255,255,.22);
            background: rgba(255,255,255,.09);
        }

        .notification-title-row {
            display: flex;
            justify-content: space-between;
            gap: 12px;
        }

        .notification-title {
            font-weight: 700;
        }

        .notification-date {
            font-size: 12px;
            opacity: .55;
            white-space: nowrap;
        }

        .notification-message {
            margin: 8px 0 12px;
            line-height: 1.5;
            opacity: .85;
        }

        .notification-type {
            display: inline-block;
            font-size: 11px;
            opacity: .65;
            margin-bottom: 10px;
        }

        .notification-read-form button {
            border: 0;
            background: transparent;
            padding: 0;
            cursor: pointer;
            font-size: 12px;
            opacity: .7;
        }

        .notification-empty {
            text-align: center;
            padding: 50px 20px;
            border-radius: 16px;
            background: rgba(255,255,255,.05);
            border: 1px solid rgba(255,255,255,.08);
        }

        .notification-empty h2 {
            margin-bottom: 8px;
        }

        .notification-empty p {
            opacity: .65;
            margin: 0;
        }

        @media (max-width: 600px) {

            .notification-toolbar {
                align-items: flex-start;
                flex-direction: column;
            }

            .notification-title-row {
                flex-direction: column;
                gap: 5px;
            }

        }

    </style>

</head>

<body>

    <main class="notification-page">

        <div class="notification-shell">

            <header class="notification-header">

                <a
                    href="/dashboard"
                    class="notification-back">
                    ←
                </a>

                <div>

                    <p>
                        FAIRMONT BANK
                    </p>

                    <h1>
                        Notifications
                    </h1>

                </div>

            </header>


            <div class="notification-toolbar">

                <div class="notification-count">

                    {% if unread_count %}

                        {{ unread_count }}
                        unread notification{% if unread_count != 1 %}s{% endif %}

                    {% else %}

                        All notifications are read.

                    {% endif %}

                </div>


                {% if unread_count %}

                    <form
                        method="POST"
                        action="{{ url_for('mark_all_notifications_read') }}">

                        <button type="submit">
                            Mark all as read
                        </button>

                    </form>

                {% endif %}

            </div>


            {% if notifications %}

                <div class="notification-list">

                    {% for notification in notifications %}

                        <article
                            class="notification-item
                            {% if not notification.is_read %}unread{% endif %}">

                            <div class="notification-title-row">

                                <div class="notification-title">
                                    {{ notification.title }}
                                </div>

                                <div class="notification-date">

                                    {{ notification.created_at.strftime("%d %b %Y, %H:%M") }}

                                </div>

                            </div>


                            <div class="notification-type">
                                {{ notification.notification_type }}
                            </div>


                            <div class="notification-message">

                                {{ notification.message }}

                            </div>


                            {% if not notification.is_read %}

                                <form
                                    method="POST"
                                    action="{{ url_for('mark_notification_read', notification_id=notification.id) }}"
                                    class="notification-read-form">

                                    <button type="submit">
                                        Mark as read
                                    </button>

                                </form>

                            {% endif %}

                        </article>

                    {% endfor %}

                </div>

            {% else %}

                <div class="notification-empty">

                    <h2>
                        No notifications
                    </h2>

                    <p>
                        Important account activity and bank messages will appear here.
                    </p>

                </div>

            {% endif %}

        </div>

    </main>

</body>

</html>
'''

    NOTIFICATIONS_FILE.write_text(
        notifications_html,
        encoding="utf-8"
    )

    print("SUCCESS: notifications.html created.")

else:
    print("INFO: notifications.html already exists.")


# =========================================================
# 4. ADD DATABASE CREATION SAFETY
# =========================================================

APP_FILE.write_text(app_text, encoding="utf-8")

print()
print("Notification system installation complete.")
print()
print("Added:")
print("  - Notification database model")
print("  - Notifications page")
print("  - Mark as read")
print("  - Mark all as read")
print("  - Persistent customer notifications")
print()
print("The existing dashboard was NOT redesigned.")