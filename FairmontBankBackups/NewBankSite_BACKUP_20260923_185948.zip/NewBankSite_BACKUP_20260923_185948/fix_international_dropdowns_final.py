from pathlib import Path
import re
from datetime import datetime

BASE = Path(__file__).resolve().parent
TEMPLATE = BASE / "templates" / "international_transfer.html"

if not TEMPLATE.exists():
    print("ERROR: templates\\international_transfer.html was not found.")
    raise SystemExit(1)

# ------------------------------------------------------------
# BACKUP
# ------------------------------------------------------------

stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = TEMPLATE.with_name(
    f"international_transfer_before_dropdown_final_{stamp}.html"
)

original = TEMPLATE.read_text(encoding="utf-8")
backup.write_text(original, encoding="utf-8")

print(f"Backup created: {backup.name}")

html = original

# ------------------------------------------------------------
# 1. REMOVE PREVIOUS PICKER CODE
# ------------------------------------------------------------

# Remove our previous injected blocks if they exist.
marker_patterns = [
    r"<!--\s*FAIRMONT_TRANSFER_PICKERS_START\s*-->.*?<!--\s*FAIRMONT_TRANSFER_PICKERS_END\s*-->",
    r"<!--\s*FAIRMONT_DROPDOWN_FIX_START\s*-->.*?<!--\s*FAIRMONT_DROPDOWN_FIX_END\s*-->",
    r"<!--\s*TRANSFER_DROPDOWN_START\s*-->.*?<!--\s*TRANSFER_DROPDOWN_END\s*-->",
]

for pattern in marker_patterns:
    html = re.sub(
        pattern,
        "",
        html,
        flags=re.IGNORECASE | re.DOTALL
    )

# ------------------------------------------------------------
# 2. REMOVE OLD CUSTOM PICKER WRAPPERS
# ------------------------------------------------------------

old_class_patterns = [
    r'<div[^>]*class=["\'][^"\']*(?:fairmont|quick-search|country-picker|bank-picker|currency-picker|dropdown-picker)[^"\']*["\'][^>]*>.*?</div>',
    r'<div[^>]*id=["\'][^"\']*(?:fairmont|quick-search|country-picker|bank-picker|currency-picker|dropdown-picker)[^"\']*["\'][^>]*>.*?</div>',
]

for pattern in old_class_patterns:
    # Repeat because wrappers may be nested.
    for _ in range(4):
        html = re.sub(
            pattern,
            "",
            html,
            flags=re.IGNORECASE | re.DOTALL
        )

# ------------------------------------------------------------
# 3. REMOVE OLD STANDALONE SEARCH INPUTS
# ------------------------------------------------------------

html = re.sub(
    r'<input[^>]*(?:placeholder=["\']Search\s+(?:country|bank|currency)[^"\']*["\'])[^>]*>',
    "",
    html,
    flags=re.IGNORECASE
)

html = re.sub(
    r'<input[^>]*(?:id|class)=["\'][^"\']*(?:country-search|bank-search|currency-search|quick-search|dropdown-search)[^"\']*["\'][^>]*>',
    "",
    html,
    flags=re.IGNORECASE
)

# ------------------------------------------------------------
# 4. REMOVE OLD CUSTOM BUTTONS
# ------------------------------------------------------------

# These are old generated buttons such as:
# Select country ▾
# Select a bank ▾
# Select currency ▾

html = re.sub(
    r'<button[^>]*>(?:\s*)Select\s+country(?:\s*)[▾▼⌄]?(?:\s*)</button>',
    "",
    html,
    flags=re.IGNORECASE
)

html = re.sub(
    r'<button[^>]*>(?:\s*)Select\s+a\s+bank(?:\s*)[▾▼⌄]?(?:\s*)</button>',
    "",
    html,
    flags=re.IGNORECASE
)

html = re.sub(
    r'<button[^>]*>(?:\s*)Select\s+currency(?:\s*)[▾▼⌄]?(?:\s*)</button>',
    "",
    html,
    flags=re.IGNORECASE
)

# ------------------------------------------------------------
# 5. REMOVE OLD GENERATED SELECT WRAPPERS
# ------------------------------------------------------------

wrapper_ids = [
    "country-picker",
    "bank-picker",
    "currency-picker",
    "fairmont-country-picker",
    "fairmont-bank-picker",
    "fairmont-currency-picker",
    "quick-country-picker",
    "quick-bank-picker",
    "quick-currency-picker",
]

for wid in wrapper_ids:
    pattern = (
        rf'<(?:div|section|span)[^>]*id=["\']{re.escape(wid)}["\'][^>]*>'
        r'.*?</(?:div|section|span)>'
    )
    html = re.sub(
        pattern,
        "",
        html,
        flags=re.IGNORECASE | re.DOTALL
    )

# ------------------------------------------------------------
# 6. FIND THE REAL SELECTS
# ------------------------------------------------------------

def find_select(name):
    pattern = (
        rf'<select\b'
        rf'(?=[^>]*\bname=["\']{re.escape(name)}["\'])'
        rf'[^>]*>.*?</select>'
    )

    match = re.search(
        pattern,
        html,
        flags=re.IGNORECASE | re.DOTALL
    )

    if match:
        return match.group(0)

    return None


country_select = find_select("country")
bank_select = find_select("bank_name")
currency_select = find_select("currency")

if not country_select:
    print("ERROR: Could not find the real country select.")
    print('Expected: <select name="country">')
    raise SystemExit(1)

if not bank_select:
    print("ERROR: Could not find the real bank select.")
    print('Expected: <select name="bank_name">')
    raise SystemExit(1)

if not currency_select:
    print("ERROR: Could not find the real currency select.")
    raise SystemExit(1)

# ------------------------------------------------------------
# 7. BUILD CLEAN REAL SELECTS
# ------------------------------------------------------------

country_select_clean = """
<select
    name="country"
    id="fairmont-real-country"
    class="fairmont-real-select"
>
    <option value="">Select country</option>
</select>
"""

bank_select_clean = """
<select
    name="bank_name"
    id="fairmont-real-bank"
    class="fairmont-real-select"
>
    <option value="">Select a bank</option>
</select>
"""

currency_select_clean = """
<select
    name="currency"
    id="fairmont-real-currency"
    class="fairmont-real-select"
>
    <option value="">Select currency</option>
</select>
"""

html = html.replace(country_select, country_select_clean, 1)
html = html.replace(bank_select, bank_select_clean, 1)
html = html.replace(currency_select, currency_select_clean, 1)

# ------------------------------------------------------------
# 8. CREATE ONE CLEAN PICKER FOR EACH FIELD
# ------------------------------------------------------------

country_picker = """
<div class="fairmont-picker" data-picker="country">
    <button
        type="button"
        class="fairmont-picker-button"
        id="fairmont-country-button"
        aria-expanded="false"
    >
        <span id="fairmont-country-label">Select country</span>
        <span class="fairmont-picker-arrow">▾</span>
    </button>
</div>
"""

bank_picker = """
<div class="fairmont-picker" data-picker="bank">
    <button
        type="button"
        class="fairmont-picker-button"
        id="fairmont-bank-button"
        aria-expanded="false"
    >
        <span id="fairmont-bank-label">Select a bank</span>
        <span class="fairmont-picker-arrow">▾</span>
    </button>
</div>
"""

currency_picker = """
<div class="fairmont-picker" data-picker="currency">
    <button
        type="button"
        class="fairmont-picker-button"
        id="fairmont-currency-button"
        aria-expanded="false"
    >
        <span id="fairmont-currency-label">Select currency</span>
        <span class="fairmont-picker-arrow">▾</span>
    </button>
</div>
"""

# Put the custom button immediately after each real select.
html = html.replace(
    country_select_clean,
    country_select_clean + country_picker,
    1
)

html = html.replace(
    bank_select_clean,
    bank_select_clean + bank_picker,
    1
)

html = html.replace(
    currency_select_clean,
    currency_select_clean + currency_picker,
    1
)

# ------------------------------------------------------------
# 9. CLEAN CSS + JAVASCRIPT
# ------------------------------------------------------------

css = r"""
<!-- FAIRMONT_TRANSFER_PICKERS_START -->
<style>
.fairmont-real-select {
    display: none !important;
}

.fairmont-picker {
    width: 100%;
    position: relative;
    margin: 0;
}

.fairmont-picker-button {
    width: 100%;
    min-height: 52px;
    padding: 0 16px;
    border: 1px solid rgba(255,255,255,.14);
    border-radius: 14px;
    background: rgba(255,255,255,.055);
    color: #ffffff;
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 15px;
    font-weight: 500;
    cursor: pointer;
    text-align: left;
    box-sizing: border-box;
}

.fairmont-picker-button:hover {
    border-color: rgba(255,255,255,.28);
}

.fairmont-picker-arrow {
    font-size: 16px;
    opacity: .75;
    margin-left: 10px;
}

.fairmont-transfer-popup {
    position: fixed;
    z-index: 999999;
    width: min(420px, calc(100vw - 30px));
    max-height: min(520px, calc(100vh - 30px));
    background: #101827;
    border: 1px solid rgba(255,255,255,.16);
    border-radius: 16px;
    box-shadow: 0 24px 70px rgba(0,0,0,.55);
    overflow: hidden;
    display: flex;
    flex-direction: column;
}

.fairmont-transfer-search-wrap {
    padding: 12px;
    border-bottom: 1px solid rgba(255,255,255,.10);
    background: #101827;
    flex: 0 0 auto;
}

.fairmont-transfer-search {
    width: 100%;
    height: 44px;
    box-sizing: border-box;
    border: 1px solid rgba(255,255,255,.15);
    border-radius: 11px;
    background: rgba(255,255,255,.07);
    color: #ffffff;
    outline: none;
    padding: 0 13px;
    font-size: 14px;
}

.fairmont-transfer-search::placeholder {
    color: rgba(255,255,255,.55);
}

.fairmont-transfer-search:focus {
    border-color: rgba(255,255,255,.35);
}

.fairmont-transfer-options {
    overflow-y: auto;
    padding: 7px;
    flex: 1 1 auto;
}

.fairmont-transfer-option {
    width: 100%;
    border: 0;
    background: transparent;
    color: #ffffff;
    padding: 12px 13px;
    border-radius: 10px;
    text-align: left;
    font-size: 14px;
    cursor: pointer;
    display: block;
}

.fairmont-transfer-option:hover,
.fairmont-transfer-option:focus {
    background: rgba(255,255,255,.09);
    outline: none;
}

.fairmont-transfer-empty {
    padding: 20px 13px;
    color: rgba(255,255,255,.55);
    font-size: 14px;
    text-align: center;
}

.fairmont-transfer-backdrop {
    position: fixed;
    inset: 0;
    z-index: 999998;
    background: transparent;
}

body.fairmont-picker-open {
    overflow: hidden;
}
</style>
<!-- FAIRMONT_TRANSFER_PICKERS_END -->
"""

javascript = r"""
<script>
/* FAIRMONT_TRANSFER_PICKERS_START */

(function () {
    "use strict";

    const countrySelect = document.getElementById("fairmont-real-country");
    const bankSelect = document.getElementById("fairmont-real-bank");
    const currencySelect = document.getElementById("fairmont-real-currency");

    const countryButton = document.getElementById("fairmont-country-button");
    const bankButton = document.getElementById("fairmont-bank-button");
    const currencyButton = document.getElementById("fairmont-currency-button");

    const countryLabel = document.getElementById("fairmont-country-label");
    const bankLabel = document.getElementById("fairmont-bank-label");
    const currencyLabel = document.getElementById("fairmont-currency-label");

    if (!countrySelect || !bankSelect || !currencySelect ||
        !countryButton || !bankButton || !currencyButton) {
        console.error("Fairmont transfer picker initialization failed.");
        return;
    }

    const countries = [
        "Afghanistan","Albania","Algeria","Andorra","Angola",
        "Antigua and Barbuda","Argentina","Armenia","Australia",
        "Austria","Azerbaijan","Bahamas","Bahrain","Bangladesh",
        "Barbados","Belarus","Belgium","Belize","Benin","Bhutan",
        "Bolivia","Bosnia and Herzegovina","Botswana","Brazil",
        "Brunei","Bulgaria","Burkina Faso","Burundi","Cambodia",
        "Cameroon","Canada","Cape Verde","Central African Republic",
        "Chad","Chile","China","Colombia","Comoros","Costa Rica",
        "Croatia","Cuba","Cyprus","Czech Republic","Denmark",
        "Djibouti","Dominica","Dominican Republic","Ecuador","Egypt",
        "El Salvador","Equatorial Guinea","Eritrea","Estonia",
        "Eswatini","Ethiopia","Fiji","Finland","France","Gabon",
        "Gambia","Georgia","Germany","Ghana","Greece","Grenada",
        "Guatemala","Guinea","Guinea-Bissau","Guyana","Haiti",
        "Honduras","Hungary","Iceland","India","Indonesia","Iran",
        "Iraq","Ireland","Israel","Italy","Jamaica","Japan",
        "Jordan","Kazakhstan","Kenya","Kiribati","Kuwait",
        "Kyrgyzstan","Laos","Latvia","Lebanon","Lesotho","Liberia",
        "Libya","Liechtenstein","Lithuania","Luxembourg",
        "Madagascar","Malawi","Malaysia","Maldives","Mali","Malta",
        "Marshall Islands","Mauritania","Mauritius","Mexico",
        "Micronesia","Moldova","Monaco","Mongolia","Montenegro",
        "Morocco","Mozambique","Myanmar","Namibia","Nauru","Nepal",
        "Netherlands","New Zealand","Nicaragua","Niger","Nigeria",
        "North Korea","North Macedonia","Norway","Oman","Pakistan",
        "Palau","Panama","Papua New Guinea","Paraguay","Peru",
        "Philippines","Poland","Portugal","Qatar","Republic of the Congo",
        "Romania","Russia","Rwanda","Saint Kitts and Nevis",
        "Saint Lucia","Saint Vincent and the Grenadines","Samoa",
        "San Marino","Sao Tome and Principe","Saudi Arabia","Senegal",
        "Serbia","Seychelles","Sierra Leone","Singapore","Slovakia",
        "Slovenia","Solomon Islands","Somalia","South Africa",
        "South Korea","South Sudan","Spain","Sri Lanka","Sudan",
        "Suriname","Sweden","Switzerland","Syria","Taiwan","Tajikistan",
        "Tanzania","Thailand","Timor-Leste","Togo","Tonga",
        "Trinidad and Tobago","Tunisia","Turkey","Turkmenistan",
        "Tuvalu","Uganda","Ukraine","United Arab Emirates",
        "United Kingdom","United States","Uruguay","Uzbekistan",
        "Vanuatu","Vatican City","Venezuela","Vietnam","Yemen",
        "Zambia","Zimbabwe"
    ];

    const banks = {
        "United Kingdom": [
            "Allied Irish Bank (GB)",
            "Bank of Ireland UK",
            "Bank of Scotland",
            "Barclays Bank",
            "Birmingham Bank",
            "Card One Money",
            "Cashplus Bank",
            "Chase UK",
            "Citibank UK",
            "ClearBank",
            "C. Hoare & Co.",
            "Co-operative Bank",
            "Coutts",
            "Danske Bank",
            "First Direct",
            "Halifax",
            "Handelsbanken UK",
            "HSBC UK",
            "Investec Bank",
            "Lloyds Bank",
            "Metro Bank",
            "Monzo Bank",
            "Nationwide Building Society",
            "NatWest",
            "Revolut",
            "Royal Bank of Scotland",
            "Santander UK",
            "Skipton Building Society",
            "Starling Bank",
            "TSB Bank",
            "Ulster Bank",
            "Virgin Money",
            "Yorkshire Building Society",
            "Zopa Bank",
            "Other UK Bank or Building Society"
        ],

        "Suriname": [
            "De Surinaamsche Bank",
            "Republic Bank Suriname",
            "Hakrinbank",
            "Surinaamse Volkscredietbank",
            "Finabank",
            "Surichange Bank",
            "GODO",
            "Trustbank Amanah",
            "Postspaarbank"
        ],

        "United States": [
            "Bank of America",
            "JPMorgan Chase",
            "Wells Fargo",
            "Citibank",
            "U.S. Bank",
            "PNC Bank",
            "Capital One",
            "Truist Bank",
            "TD Bank",
            "Goldman Sachs Bank USA"
        ],

        "Canada": [
            "Royal Bank of Canada",
            "Toronto-Dominion Bank",
            "Bank of Montreal",
            "Canadian Imperial Bank of Commerce",
            "Scotiabank",
            "National Bank of Canada",
            "Desjardins"
        ],

        "Australia": [
            "Commonwealth Bank",
            "Westpac",
            "ANZ",
            "National Australia Bank",
            "Macquarie Bank"
        ],

        "Germany": [
            "Deutsche Bank",
            "Commerzbank",
            "DZ Bank",
            "KfW",
            "ING Germany"
        ],

        "France": [
            "BNP Paribas",
            "Crédit Agricole",
            "Société Générale",
            "BPCE",
            "La Banque Postale"
        ],

        "Ireland": [
            "AIB",
            "Bank of Ireland",
            "Permanent TSB",
            "Ulster Bank",
            "EBS",
            "Avant Money"
        ],

        "Netherlands": [
            "ING Bank",
            "ABN AMRO",
            "Rabobank",
            "de Volksbank"
        ],

        "Switzerland": [
            "UBS",
            "Julius Baer",
            "Zürcher Kantonalbank",
            "Banque Cantonale Vaudoise"
        ],

        "India": [
            "State Bank of India",
            "HDFC Bank",
            "ICICI Bank",
            "Axis Bank",
            "Kotak Mahindra Bank",
            "IndusInd Bank"
        ],

        "China": [
            "Industrial and Commercial Bank of China",
            "China Construction Bank",
            "Bank of China",
            "Agricultural Bank of China",
            "Bank of Communications"
        ],

        "Japan": [
            "MUFG Bank",
            "Sumitomo Mitsui Banking Corporation",
            "Mizuho Bank",
            "Resona Bank",
            "SBI Shinsei Bank"
        ],

        "Singapore": [
            "DBS Bank",
            "OCBC Bank",
            "United Overseas Bank"
        ],

        "South Africa": [
            "Standard Bank",
            "First National Bank",
            "Absa Bank",
            "Nedbank",
            "Capitec Bank"
        ],

        "Kenya": [
            "KCB Bank Kenya",
            "Equity Bank Kenya",
            "Co-operative Bank of Kenya",
            "Absa Bank Kenya",
            "NCBA Bank Kenya",
            "Standard Chartered Bank Kenya",
            "Stanbic Bank Kenya",
            "I&M Bank",
            "DTB Kenya"
        ],

        "Nigeria": [
            "Access Bank",
            "Guaranty Trust Bank",
            "Zenith Bank",
            "First Bank of Nigeria",
            "United Bank for Africa",
            "Fidelity Bank",
            "Stanbic IBTC Bank"
        ],

        "Ghana": [
            "GCB Bank",
            "Ecobank Ghana",
            "Absa Bank Ghana",
            "Standard Chartered Bank Ghana",
            "Stanbic Bank Ghana",
            "Fidelity Bank Ghana"
        ],

        "United Arab Emirates": [
            "Emirates NBD",
            "First Abu Dhabi Bank",
            "Abu Dhabi Commercial Bank",
            "Mashreq Bank",
            "Dubai Islamic Bank"
        ],

        "Saudi Arabia": [
            "Saudi National Bank",
            "Al Rajhi Bank",
            "Riyad Bank",
            "Alinma Bank",
            "Bank Albilad"
        ],

        "Qatar": [
            "Qatar National Bank",
            "Qatar Islamic Bank",
            "Doha Bank",
            "Commercial Bank"
        ],

        "Brazil": [
            "Banco do Brasil",
            "Itaú Unibanco",
            "Bradesco",
            "Caixa Econômica Federal",
            "Santander Brasil"
        ],

        "Mexico": [
            "BBVA México",
            "Banorte",
            "Santander México",
            "Citibanamex",
            "HSBC México",
            "Scotiabank México"
        ]
    };

    const currencies = [
        ["GBP", "Pound Sterling"],
        ["USD", "US Dollar"],
        ["EUR", "Euro"],
        ["CAD", "Canadian Dollar"],
        ["AUD", "Australian Dollar"],
        ["NZD", "New Zealand Dollar"],
        ["CHF", "Swiss Franc"],
        ["JPY", "Japanese Yen"],
        ["CNY", "Chinese Yuan"],
        ["INR", "Indian Rupee"],
        ["SGD", "Singapore Dollar"],
        ["HKD", "Hong Kong Dollar"],
        ["ZAR", "South African Rand"],
        ["KES", "Kenyan Shilling"],
        ["NGN", "Nigerian Naira"],
        ["GHS", "Ghanaian Cedi"],
        ["AED", "UAE Dirham"],
        ["SAR", "Saudi Riyal"],
        ["QAR", "Qatari Riyal"],
        ["SRD", "Surinamese Dollar"],
        ["BRL", "Brazilian Real"],
        ["MXN", "Mexican Peso"]
    ];

    function clearSelect(select) {
        while (select.options.length > 0) {
            select.remove(0);
        }
    }

    function addOption(select, value, text) {
        const option = document.createElement("option");
        option.value = value;
        option.textContent = text;
        select.appendChild(option);
    }

    function loadCountries() {
        clearSelect(countrySelect);
        addOption(countrySelect, "", "Select country");

        countries.forEach(function (country) {
            addOption(countrySelect, country, country);
        });
    }

    function loadBanks(country) {
        clearSelect(bankSelect);
        addOption(bankSelect, "", "Select a bank");

        const list = banks[country] || [];

        list.forEach(function (bank) {
            addOption(bankSelect, bank, bank);
        });

        bankLabel.textContent = "Select a bank";
    }

    function loadCurrencies() {
        clearSelect(currencySelect);
        addOption(currencySelect, "", "Select currency");

        currencies.forEach(function (item) {
            addOption(
                currencySelect,
                item[0],
                item[0] + " — " + item[1]
            );
        });
    }

    loadCountries();
    loadBanks("");
    loadCurrencies();

    let popup = null;
    let backdrop = null;

    function closePicker() {
        if (popup) {
            popup.remove();
            popup = null;
        }

        if (backdrop) {
            backdrop.remove();
            backdrop = null;
        }

        document.body.classList.remove("fairmont-picker-open");

        [countryButton, bankButton, currencyButton].forEach(function (button) {
            button.setAttribute("aria-expanded", "false");
        });
    }

    function getItems(type) {
        if (type === "country") {
            return countries.map(function (item) {
                return {
                    value: item,
                    label: item
                };
            });
        }

        if (type === "bank") {
            const selectedCountry = countrySelect.value;
            const list = banks[selectedCountry] || [];

            return list.map(function (item) {
                return {
                    value: item,
                    label: item
                };
            });
        }

        return currencies.map(function (item) {
            return {
                value: item[0],
                label: item[0] + " — " + item[1]
            };
        });
    }

    function getButton(type) {
        if (type === "country") return countryButton;
        if (type === "bank") return bankButton;
        return currencyButton;
    }

    function getSelect(type) {
        if (type === "country") return countrySelect;
        if (type === "bank") return bankSelect;
        return currencySelect;
    }

    function renderOptions(type, query) {
        if (!popup) return;

        const optionsBox =
            popup.querySelector(".fairmont-transfer-options");

        const normalized = (query || "").trim().toLowerCase();

        const items = getItems(type).filter(function (item) {
            return item.label.toLowerCase().includes(normalized);
        });

        optionsBox.innerHTML = "";

        if (!items.length) {
            const empty = document.createElement("div");
            empty.className = "fairmont-transfer-empty";
            empty.textContent = "No matches found";
            optionsBox.appendChild(empty);
            return;
        }

        items.forEach(function (item) {
            const option = document.createElement("button");

            option.type = "button";
            option.className = "fairmont-transfer-option";
            option.textContent = item.label;

            option.addEventListener("click", function () {
                const select = getSelect(type);
                const button = getButton(type);

                select.value = item.value;

                if (type === "country") {
                    countryLabel.textContent = item.label;

                    loadBanks(item.value);

                    bankSelect.value = "";
                    bankLabel.textContent = "Select a bank";
                }

                if (type === "bank") {
                    bankLabel.textContent = item.label;
                }

                if (type === "currency") {
                    currencyLabel.textContent = item.label;
                }

                select.dispatchEvent(
                    new Event("change", { bubbles: true })
                );

                button.setAttribute("aria-expanded", "false");

                closePicker();
            });

            optionsBox.appendChild(option);
        });
    }

    function openPicker(type) {
        closePicker();

        const button = getButton(type);

        button.setAttribute("aria-expanded", "true");

        backdrop = document.createElement("div");
        backdrop.className = "fairmont-transfer-backdrop";

        backdrop.addEventListener("click", function () {
            closePicker();
        });

        document.body.appendChild(backdrop);

        popup = document.createElement("div");
        popup.className = "fairmont-transfer-popup";

        const searchWrap = document.createElement("div");
        searchWrap.className = "fairmont-transfer-search-wrap";

        const search = document.createElement("input");
        search.type = "search";
        search.className = "fairmont-transfer-search";

        if (type === "country") {
            search.placeholder = "Search country...";
        } else if (type === "bank") {
            search.placeholder = "Search bank...";
        } else {
            search.placeholder = "Search currency...";
        }

        search.autocomplete = "off";

        searchWrap.appendChild(search);

        const options = document.createElement("div");
        options.className = "fairmont-transfer-options";

        popup.appendChild(searchWrap);
        popup.appendChild(options);

        document.body.appendChild(popup);

        const rect = button.getBoundingClientRect();

        const popupWidth = Math.min(
            420,
            window.innerWidth - 30
        );

        let left = rect.left;

        if (left + popupWidth > window.innerWidth - 15) {
            left = window.innerWidth - popupWidth - 15;
        }

        if (left < 15) {
            left = 15;
        }

        let top = rect.bottom + 8;

        const estimatedHeight = Math.min(
            520,
            window.innerHeight - 30
        );

        if (top + estimatedHeight > window.innerHeight - 15) {
            top = rect.top - estimatedHeight - 8;
        }

        if (top < 15) {
            top = 15;
        }

        popup.style.left = left + "px";
        popup.style.top = top + "px";
        popup.style.width = popupWidth + "px";

        renderOptions(type, "");

        search.addEventListener("input", function () {
            renderOptions(type, search.value);
        });

        search.addEventListener("keydown", function (event) {
            if (event.key === "Escape") {
                closePicker();
            }
        });

        setTimeout(function () {
            search.focus();
        }, 20);

        document.body.classList.add("fairmont-picker-open");
    }

    countryButton.addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();
        openPicker("country");
    });

    bankButton.addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();

        if (!countrySelect.value) {
            openPicker("bank");
            return;
        }

        openPicker("bank");
    });

    currencyButton.addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();
        openPicker("currency");
    });

    countrySelect.addEventListener("change", function () {
        if (countrySelect.value) {
            countryLabel.textContent = countrySelect.value;
        } else {
            countryLabel.textContent = "Select country";
        }

        loadBanks(countrySelect.value);
    });

    bankSelect.addEventListener("change", function () {
        if (bankSelect.value) {
            bankLabel.textContent = bankSelect.value;
        } else {
            bankLabel.textContent = "Select a bank";
        }
    });

    currencySelect.addEventListener("change", function () {
        const selected = currencySelect.options[
            currencySelect.selectedIndex
        ];

        if (selected && selected.value) {
            currencyLabel.textContent = selected.textContent;
        } else {
            currencyLabel.textContent = "Select currency";
        }
    });

    window.addEventListener("resize", function () {
        closePicker();
    });

    window.addEventListener("scroll", function () {
        if (popup) {
            closePicker();
        }
    }, true);

    // Restore existing values if Flask repopulates the form.
    if (countrySelect.value) {
        countryLabel.textContent = countrySelect.value;
        loadBanks(countrySelect.value);
    }

    if (bankSelect.value) {
        bankLabel.textContent = bankSelect.value;
    }

    if (currencySelect.value) {
        const selectedCurrency =
            currencySelect.options[currencySelect.selectedIndex];

        if (selectedCurrency) {
            currencyLabel.textContent =
                selectedCurrency.textContent;
        }
    }

})();

/* FAIRMONT_TRANSFER_PICKERS_END */
</script>
"""

# ------------------------------------------------------------
# 10. INSERT CLEAN CSS BEFORE </head>
# ------------------------------------------------------------

if "</head>" in html.lower():
    position = html.lower().rfind("</head>")
    html = html[:position] + css + "\n" + html[position:]
else:
    html = css + "\n" + html

# ------------------------------------------------------------
# 11. INSERT CLEAN JS BEFORE </body>
# ------------------------------------------------------------

if "</body>" in html.lower():
    position = html.lower().rfind("</body>")
    html = html[:position] + javascript + "\n" + html[position:]
else:
    html += "\n" + javascript

# ------------------------------------------------------------
# 12. FINAL SAFETY CLEANUP
# ------------------------------------------------------------

# Remove accidental duplicate copies of our markers.
# Keep only the last CSS block and last JS block.

def keep_last_block(text, start_marker, end_marker):
    pattern = (
        re.escape(start_marker)
        + r".*?"
        + re.escape(end_marker)
    )

    matches = list(
        re.finditer(
            pattern,
            text,
            flags=re.IGNORECASE | re.DOTALL
        )
    )

    if len(matches) <= 1:
        return text

    # Remove all except the final occurrence.
    for match in reversed(matches[:-1]):
        text = text[:match.start()] + text[match.end():]

    return text


html = keep_last_block(
    html,
    "<!-- FAIRMONT_TRANSFER_PICKERS_START -->",
    "<!-- FAIRMONT_TRANSFER_PICKERS_END -->"
)

html = keep_last_block(
    html,
    "/* FAIRMONT_TRANSFER_PICKERS_START */",
    "/* FAIRMONT_TRANSFER_PICKERS_END */"
)

# ------------------------------------------------------------
# 13. WRITE FILE
# ------------------------------------------------------------

TEMPLATE.write_text(html, encoding="utf-8")

print()
print("==============================================")
print("INTERNATIONAL TRANSFER DROPDOWNS FIXED")
print("==============================================")
print()
print("Country:")
print("  One Select country bar")
print("  Search appears INSIDE opened dropdown")
print()
print("Bank:")
print("  One Select a bank bar")
print("  Search appears INSIDE opened dropdown")
print("  Banks depend on selected country")
print()
print("Currency:")
print("  One Select currency bar")
print("  Search appears INSIDE opened dropdown")
print()
print("No permanent duplicate search bars.")
print("No duplicate select bars.")
print()
print(f"Backup: {backup.name}")
print()
print("IMPORTANT:")
print("Restart Flask if necessary, then refresh the page.")
print("Use Ctrl + F5 in the browser to force a fresh page.")
print()