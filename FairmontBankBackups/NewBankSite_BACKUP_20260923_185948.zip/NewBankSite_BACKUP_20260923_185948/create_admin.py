from pathlib import Path
import getpass

from app import app, db, AdminUser
from werkzeug.security import generate_password_hash


print("=" * 70)
print("FAIRMONT BANK ADMIN ACCOUNT SETUP")
print("=" * 70)
print()

username = input("Enter admin username: ").strip()

if not username:
    print("ERROR: Username cannot be empty.")
    raise SystemExit(1)

password = getpass.getpass("Enter admin password: ")

if not password:
    print("ERROR: Password cannot be empty.")
    raise SystemExit(1)

confirm_password = getpass.getpass("Confirm admin password: ")

if password != confirm_password:
    print("ERROR: Passwords do not match.")
    raise SystemExit(1)

if len(password) < 8:
    print("ERROR: Admin password must contain at least 8 characters.")
    raise SystemExit(1)

with app.app_context():

    existing = AdminUser.query.filter_by(
        username=username
    ).first()

    if existing:
        print()
        print("ERROR: An administrator with that username already exists.")
        raise SystemExit(1)

    admin = AdminUser(
        username=username,
        password_hash=generate_password_hash(password),
        is_active=True
    )

    db.session.add(admin)
    db.session.commit()

    print()
    print("=" * 70)
    print("ADMIN ACCOUNT CREATED SUCCESSFULLY")
    print("=" * 70)
    print()
    print("Username:", username)
    print("Password: stored securely as a password hash")
    print("Status: Active")
    print()
    print("The password was not written into app.py.")
    print("=" * 70)