from pathlib import Path
import re

file = Path("templates/dashboard.html")

if not file.exists():
    raise SystemExit("ERROR: templates/dashboard.html was not found.")

text = file.read_text(encoding="utf-8")

# Find the existing Email Bank button.
pattern = (
    r'(<a\s+href="/email-bank"'
    r'[^>]*class="dashboard-email-button"'
    r'[^>]*>.*?'
    r'</span>)'
    r'(\s*</a>)'
)

match = re.search(pattern, text, flags=re.IGNORECASE | re.DOTALL)

if not match:
    raise SystemExit(
        "ERROR: The existing Email Bank button could not be found."
    )

# Prevent duplicate text if the script is run again.
button = match.group(0)

if "dashboard-email-label" in button:
    print("INFO: 'Email the Bank' text is already present.")
else:
    label = """
                        <span class="dashboard-email-label">
                            Email the Bank
                        </span>
"""

    # Insert the visible text immediately after the envelope icon.
    replacement = match.group(1) + label + match.group(2)

    text = (
        text[:match.start()]
        + replacement
        + text[match.end():]
    )

    file.write_text(text, encoding="utf-8")

    print("SUCCESS: Added visible 'Email the Bank' text.")

print()
print("The envelope remains beside the notification bell.")
print("The text is part of the same clickable /email-bank button.")
print("No image or photo was created.")
print()