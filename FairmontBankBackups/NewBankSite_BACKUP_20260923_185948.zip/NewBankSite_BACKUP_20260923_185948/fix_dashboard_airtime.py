from pathlib import Path

file = Path("templates/dashboard.html")

if not file.exists():
    raise SystemExit("ERROR: templates/dashboard.html was not found.")

text = file.read_text(encoding="utf-8")

old = '''                      <!-- Airtime -->

                      <a
                          href="#"
                          class="service-item">'''

new = '''                      <!-- Airtime -->

                      <a
                          href="{{ url_for('airtime') }}"
                          class="service-item">'''

if old not in text:
    raise SystemExit(
        "ERROR: The exact Airtime card was not found. "
        "No changes were made."
    )

text = text.replace(old, new, 1)

file.write_text(text, encoding="utf-8")

print("SUCCESS: Dashboard Airtime card now opens /airtime.")