from pathlib import Path
import re

BASE = Path(".")
APP = BASE / "app.py"
TEMPLATES = BASE / "templates"

if not APP.exists():
    raise SystemExit("ERROR: app.py was not found.")

TEMPLATES.mkdir(exist_ok=True)

app_text = APP.read_text(encoding="utf-8")

# ---------------------------------------------------------
# 1. Add Flights & Travel route
# ---------------------------------------------------------

if '@app.route("/flights-travel"' not in app_text:

    route_code = r'''

@app.route("/flights-travel", methods=["GET", "POST"])
@login_required
def flights_travel():
    customer = current_user

    travel_categories = [
        "Flight Booking",
        "Hotel Booking",
        "Airport Transfer",
        "Travel Insurance",
        "Train & Rail",
        "Bus & Coach",
        "Car Rental",
        "Other Travel"
    ]

    if request.method == "GET":
        return render_template(
            "flights_travel.html",
            customer=customer,
            categories=travel_categories
        )

    category = request.form.get("category", "").strip()
    provider = request.form.get("provider", "").strip()
    traveler_name = request.form.get("traveler_name", "").strip()
    booking_reference = request.form.get("booking_reference", "").strip()
    amount_text = request.form.get("amount", "").strip()
    payment_reference = request.form.get("payment_reference", "").strip()

    errors = []

    if category not in travel_categories:
        errors.append("Please select a travel service.")

    if not provider:
        errors.append("Please enter the airline, hotel, or travel provider.")

    if not traveler_name:
        errors.append("Please enter the traveler name.")

    if not booking_reference:
        errors.append("Please enter the booking or travel reference.")

    try:
        amount = float(amount_text)
    except (TypeError, ValueError):
        amount = 0

    if amount <= 0:
        errors.append("Please enter a valid payment amount.")

    if amount > float(customer.account_balance):
        errors.append("Insufficient balance for this travel payment.")

    if errors:
        return render_template(
            "flights_travel.html",
            customer=customer,
            categories=travel_categories,
            errors=errors,
            category=category,
            provider=provider,
            traveler_name=traveler_name,
            booking_reference=booking_reference,
            amount=amount_text,
            payment_reference=payment_reference
        )

    new_balance = float(customer.account_balance) - amount
    transaction_reference = generate_transaction_reference()

    customer.account_balance = new_balance

    transaction = Transaction(
        transaction_reference=transaction_reference,
        customer_id=customer.id,
        transaction_type="Travel Payment",
        direction="Debit",
        amount=amount,
        balance_after=new_balance,
        description=f"{category} payment",
        counterparty=provider,
        status="Completed"
    )

    db.session.add(transaction)
    db.session.commit()

    return render_template(
        "flights_travel_confirmation.html",
        customer=customer,
        category=category,
        provider=provider,
        traveler_name=traveler_name,
        booking_reference=booking_reference,
        amount=amount,
        payment_reference=payment_reference,
        transaction_reference=transaction_reference,
        new_balance=new_balance
    )
'''

    # Insert before the final app.run block.
    pattern = r'\nif __name__\s*==\s*[\'"]__main__[\'"]\s*:'
    match = re.search(pattern, app_text)

    if not match:
        raise SystemExit(
            "ERROR: Final app.run block could not be located. "
            "No changes were made to app.py."
        )

    app_text = (
        app_text[:match.start()]
        + route_code
        + app_text[match.start():]
    )

    APP.write_text(app_text, encoding="utf-8")

    print("SUCCESS: /flights-travel route added.")

else:
    print("NOTICE: /flights-travel route already exists.")

# ---------------------------------------------------------
# 2. Flights & Travel page
# ---------------------------------------------------------

flights_html = r'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Flights & Travel | Fairmont Bank</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background:
                radial-gradient(circle at top left, rgba(40, 83, 145, 0.28), transparent 35%),
                linear-gradient(145deg, #061426, #0a1d34 55%, #07111f);
            color: #ffffff;
            min-height: 100vh;
        }

        .page {
            width: 100%;
            max-width: 760px;
            margin: 0 auto;
            padding: 22px 16px 40px;
        }

        .back {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: #dceaff;
            text-decoration: none;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .back:hover {
            color: #ffffff;
        }

        .header {
            margin-bottom: 20px;
        }

        .eyebrow {
            color: #8fb7ed;
            font-size: 12px;
            font-weight: 700;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            margin-bottom: 8px;
        }

        h1 {
            margin: 0;
            font-size: 30px;
            letter-spacing: -0.5px;
        }

        .subtitle {
            margin-top: 8px;
            color: #aebed2;
            line-height: 1.5;
            font-size: 14px;
        }

        .balance {
            background: rgba(255, 255, 255, 0.07);
            border: 1px solid rgba(255, 255, 255, 0.10);
            border-radius: 18px;
            padding: 18px;
            margin-bottom: 16px;
            backdrop-filter: blur(14px);
        }

        .balance-label {
            color: #9db0c8;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .balance-value {
            margin-top: 7px;
            font-size: 25px;
            font-weight: 700;
        }

        .card {
            background: rgba(11, 31, 55, 0.82);
            border: 1px solid rgba(255, 255, 255, 0.10);
            border-radius: 22px;
            padding: 20px;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.22);
            backdrop-filter: blur(16px);
        }

        .error {
            background: rgba(180, 45, 55, 0.18);
            border: 1px solid rgba(255, 100, 110, 0.35);
            color: #ffd5d8;
            border-radius: 13px;
            padding: 12px 14px;
            margin-bottom: 14px;
            font-size: 13px;
        }

        .field {
            margin-bottom: 16px;
        }

        label {
            display: block;
            color: #dce8f6;
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 8px;
        }

        input,
        select {
            width: 100%;
            border: 1px solid rgba(255, 255, 255, 0.13);
            background: rgba(255, 255, 255, 0.06);
            color: #ffffff;
            border-radius: 13px;
            padding: 13px 14px;
            font-size: 14px;
            outline: none;
        }

        input:focus,
        select:focus {
            border-color: rgba(123, 177, 244, 0.75);
        }

        select option {
            background: #0b2038;
            color: #ffffff;
        }

        .button {
            width: 100%;
            border: 0;
            border-radius: 14px;
            padding: 14px;
            background: #2f70c9;
            color: #ffffff;
            font-size: 15px;
            font-weight: 700;
            cursor: pointer;
            margin-top: 4px;
        }

        .button:hover {
            background: #3b80df;
        }

        .secure {
            text-align: center;
            color: #71869f;
            font-size: 11px;
            margin-top: 15px;
        }

        @media (max-width: 520px) {
            .page {
                padding: 18px 13px 30px;
            }

            h1 {
                font-size: 26px;
            }

            .card {
                padding: 17px;
            }
        }
    </style>
</head>

<body>

<div class="page">

    <a href="{{ url_for('dashboard') }}" class="back">
        ← Back to Dashboard
    </a>

    <div class="header">

        <div class="eyebrow">Fairmont Bank</div>

        <h1>Flights & Travel</h1>

        <div class="subtitle">
            Pay for travel services and bookings directly from your Fairmont Bank account.
        </div>

    </div>

    <div class="balance">

        <div class="balance-label">
            Available Balance
        </div>

        <div class="balance-value">
            £{{ "{:,.2f}".format(customer.account_balance or 0) }}
        </div>

    </div>

    <div class="card">

        {% if errors %}

            <div class="error">

                {% for error in errors %}
                    <div>{{ error }}</div>
                {% endfor %}

            </div>

        {% endif %}

        <form method="POST">

            <div class="field">

                <label for="category">
                    Travel Service
                </label>

                <select name="category" id="category" required>

                    <option value="">
                        Select a travel service
                    </option>

                    {% for item in categories %}

                        <option value="{{ item }}"
                            {% if category == item %}selected{% endif %}>
                            {{ item }}
                        </option>

                    {% endfor %}

                </select>

            </div>

            <div class="field">

                <label for="provider">
                    Airline / Hotel / Travel Provider
                </label>

                <input
                    type="text"
                    id="provider"
                    name="provider"
                    value="{{ provider or '' }}"
                    placeholder="Enter provider name"
                    required>

            </div>

            <div class="field">

                <label for="traveler_name">
                    Traveler Name
                </label>

                <input
                    type="text"
                    id="traveler_name"
                    name="traveler_name"
                    value="{{ traveler_name or '' }}"
                    placeholder="Enter traveler name"
                    required>

            </div>

            <div class="field">

                <label for="booking_reference">
                    Booking / Travel Reference
                </label>

                <input
                    type="text"
                    id="booking_reference"
                    name="booking_reference"
                    value="{{ booking_reference or '' }}"
                    placeholder="Enter booking or travel reference"
                    required>

            </div>

            <div class="field">

                <label for="amount">
                    Payment Amount (£)
                </label>

                <input
                    type="number"
                    id="amount"
                    name="amount"
                    value="{{ amount or '' }}"
                    min="0.01"
                    step="0.01"
                    placeholder="0.00"
                    required>

            </div>

            <div class="field">

                <label for="payment_reference">
                    Payment Reference (Optional)
                </label>

                <input
                    type="text"
                    id="payment_reference"
                    name="payment_reference"
                    value="{{ payment_reference or '' }}"
                    placeholder="Optional payment reference">

            </div>

            <button type="submit" class="button">
                Make Travel Payment
            </button>

        </form>

        <div class="secure">
            Travel payments are recorded securely in your Fairmont Bank transaction history.
        </div>

    </div>

</div>

</body>
</html>
'''

(TEMPLATES / "flights_travel.html").write_text(
    flights_html,
    encoding="utf-8"
)

print("SUCCESS: flights_travel.html created.")

# ---------------------------------------------------------
# 3. Confirmation page
# ---------------------------------------------------------

confirmation_html = r'''<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Travel Payment Confirmed | Fairmont Bank</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background:
                radial-gradient(circle at top, rgba(40, 83, 145, 0.28), transparent 40%),
                linear-gradient(145deg, #061426, #0a1d34 55%, #07111f);
            color: #ffffff;
            min-height: 100vh;
        }

        .page {
            width: 100%;
            max-width: 650px;
            margin: 0 auto;
            padding: 28px 16px 40px;
        }

        .card {
            background: rgba(11, 31, 55, 0.86);
            border: 1px solid rgba(255, 255, 255, 0.10);
            border-radius: 24px;
            padding: 25px;
            backdrop-filter: blur(16px);
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.25);
        }

        .success {
            width: 58px;
            height: 58px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 17px;
            background: rgba(48, 175, 112, 0.18);
            border: 1px solid rgba(91, 221, 153, 0.35);
            color: #75e0a8;
            font-size: 28px;
        }

        .eyebrow {
            color: #8fb7ed;
            font-size: 12px;
            font-weight: 700;
            letter-spacing: 1.5px;
            text-transform: uppercase;
        }

        h1 {
            margin: 7px 0;
            font-size: 27px;
        }

        .intro {
            color: #aebed2;
            font-size: 14px;
            line-height: 1.5;
            margin-bottom: 22px;
        }

        .details {
            border-top: 1px solid rgba(255,255,255,0.09);
        }

        .row {
            display: flex;
            justify-content: space-between;
            gap: 15px;
            padding: 13px 0;
            border-bottom: 1px solid rgba(255,255,255,0.07);
            font-size: 13px;
        }

        .label {
            color: #91a5bc;
        }

        .value {
            text-align: right;
            color: #f3f7fc;
            font-weight: 600;
            word-break: break-word;
        }

        .status {
            color: #75e0a8;
        }

        .amount {
            font-size: 19px;
        }

        .actions {
            display: grid;
            gap: 10px;
            margin-top: 22px;
        }

        .button {
            display: block;
            text-align: center;
            text-decoration: none;
            padding: 13px;
            border-radius: 13px;
            font-size: 14px;
            font-weight: 700;
            background: #2f70c9;
            color: #ffffff;
        }

        .secondary {
            background: rgba(255,255,255,0.07);
            border: 1px solid rgba(255,255,255,0.10);
        }

    </style>

</head>

<body>

<div class="page">

    <div class="card">

        <div class="success">
            ✓
        </div>

        <div class="eyebrow">
            Fairmont Bank
        </div>

        <h1>
            Travel Payment Completed
        </h1>

        <div class="intro">
            Your travel payment has been successfully processed and recorded in your transaction history.
        </div>

        <div class="details">

            <div class="row">
                <div class="label">Travel Service</div>
                <div class="value">{{ category }}</div>
            </div>

            <div class="row">
                <div class="label">Provider</div>
                <div class="value">{{ provider }}</div>
            </div>

            <div class="row">
                <div class="label">Traveler</div>
                <div class="value">{{ traveler_name }}</div>
            </div>

            <div class="row">
                <div class="label">Booking Reference</div>
                <div class="value">{{ booking_reference }}</div>
            </div>

            <div class="row">
                <div class="label">Amount</div>
                <div class="value amount">
                    £{{ "{:,.2f}".format(amount) }}
                </div>
            </div>

            {% if payment_reference %}

            <div class="row">
                <div class="label">Payment Reference</div>
                <div class="value">{{ payment_reference }}</div>
            </div>

            {% endif %}

            <div class="row">
                <div class="label">Transaction Reference</div>
                <div class="value">{{ transaction_reference }}</div>
            </div>

            <div class="row">
                <div class="label">Status</div>
                <div class="value status">
                    Completed
                </div>
            </div>

            <div class="row">
                <div class="label">New Balance</div>
                <div class="value">
                    £{{ "{:,.2f}".format(new_balance) }}
                </div>
            </div>

        </div>

        <div class="actions">

            <a href="{{ url_for('transactions') }}" class="button">
                View Transactions
            </a>

            <a href="{{ url_for('dashboard') }}" class="button secondary">
                Back to Dashboard
            </a>

        </div>

    </div>

</div>

</body>
</html>
'''

(TEMPLATES / "flights_travel_confirmation.html").write_text(
    confirmation_html,
    encoding="utf-8"
)

print("SUCCESS: flights_travel_confirmation.html created.")

print()
print("=" * 65)
print("FLIGHTS & TRAVEL FEATURE INSTALLATION COMPLETE")
print("=" * 65)
print()
print("Route: /flights-travel")
print("Page: templates/flights_travel.html")
print("Confirmation: templates/flights_travel_confirmation.html")
print()
print("Next step:")
print("Run: python -m py_compile app.py")