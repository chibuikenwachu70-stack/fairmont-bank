from pathlib import Path

APP_FILE = Path("app.py")

text = APP_FILE.read_text(encoding="utf-8")

marker = '\nif __name__ == "__main__":'

if marker not in text:
    raise SystemExit(
        'ERROR: The if __name__ == "__main__": block was not found. '
        'No changes were made.'
    )

if '@app.route("/admin/create-customer"' in text:
    raise SystemExit(
        "ERROR: The admin create-customer route already exists. "
        "No changes were made."
    )

route = r'''

# ============================================================
# ADMIN — CREATE CUSTOMER ACCOUNT
# ============================================================

@app.route("/admin/create-customer", methods=["GET", "POST"])
def admin_create_customer():

    admin_id = session.get("admin_id")

    if not admin_id:
        return redirect(url_for("admin_login"))

    admin = db.session.get(AdminUser, admin_id)

    if admin is None or not admin.is_active:
        session.pop("admin_id", None)
        return redirect(url_for("admin_login"))

    form_data = (
        request.form.to_dict()
        if request.method == "POST"
        else {}
    )

    if request.method == "POST":

        full_name = (
            request.form.get("full_name", "").strip()
        )

        email = (
            request.form.get("email", "").strip().lower()
        )

        phone = (
            request.form.get("phone", "").strip()
        )

        account_type = (
            request.form.get("account_type", "").strip().lower()
        )

        country = (
            request.form.get("country", "").strip()
        )

        password = request.form.get("password", "")

        confirm_password = request.form.get(
            "confirm_password",
            ""
        )

        initial_funding_text = (
            request.form.get(
                "initial_funding",
                "0"
            ).strip()
        )

        funding_reference = (
            request.form.get(
                "funding_reference",
                ""
            ).strip()
        )

        funding_description = (
            request.form.get(
                "funding_description",
                ""
            ).strip()
        )

        if not full_name:
            flash(
                "Please enter the customer's full name.",
                "error"
            )

            return render_template(
                "admin_create_customer.html",
                admin=admin,
                form_data=form_data
            )

        if not email:
            flash(
                "Please enter the customer's email address.",
                "error"
            )

            return render_template(
                "admin_create_customer.html",
                admin=admin,
                form_data=form_data
            )

        if not phone:
            flash(
                "Please enter the customer's phone number.",
                "error"
            )

            return render_template(
                "admin_create_customer.html",
                admin=admin,
                form_data=form_data
            )

        if account_type not in {"savings", "current"}:
            flash(
                "Please select a valid account type.",
                "error"
            )

            return render_template(
                "admin_create_customer.html",
                admin=admin,
                form_data=form_data
            )

        if not country:
            flash(
                "Please enter the customer's country.",
                "error"
            )

            return render_template(
                "admin_create_customer.html",
                admin=admin,
                form_data=form_data
            )

        if len(password) < 6:
            flash(
                "The initial password must contain at least 6 characters.",
                "error"
            )

            return render_template(
                "admin_create_customer.html",
                admin=admin,
                form_data=form_data
            )

        if password != confirm_password:
            flash(
                "The password confirmation does not match.",
                "error"
            )

            return render_template(
                "admin_create_customer.html",
                admin=admin,
                form_data=form_data
            )

        existing_email = Customer.query.filter_by(
            email=email
        ).first()

        if existing_email:
            flash(
                "A customer with that email address already exists.",
                "error"
            )

            return render_template(
                "admin_create_customer.html",
                admin=admin,
                form_data=form_data
            )

        existing_phone = Customer.query.filter_by(
            phone=phone
        ).first()

        if existing_phone:
            flash(
                "A customer with that phone number already exists.",
                "error"
            )

            return render_template(
                "admin_create_customer.html",
                admin=admin,
                form_data=form_data
            )

        try:
            initial_funding = float(
                initial_funding_text or "0"
            )
        except (TypeError, ValueError):

            flash(
                "Initial funding amount is not valid.",
                "error"
            )

            return render_template(
                "admin_create_customer.html",
                admin=admin,
                form_data=form_data
            )

        if initial_funding < 0:

            flash(
                "Initial funding cannot be negative.",
                "error"
            )

            return render_template(
                "admin_create_customer.html",
                admin=admin,
                form_data=form_data
            )

        if initial_funding > 0 and not funding_description:
            funding_description = "Initial account funding"

        # Generate a unique Fairmont Customer ID.
        customer_id = generate_customer_id()

        # Generate a unique 10-digit account number.
        account_number = generate_account_number()

        customer = Customer(
            customer_id=customer_id,
            account_number=account_number,
            full_name=full_name,
            email=email,
            phone=phone,
            account_type=account_type,
            country=country,
            password_hash=generate_password_hash(password),
            account_status="Active",
            account_balance=initial_funding
        )

        db.session.add(customer)

        db.session.flush()

        # Create the initial funding transaction only when
        # an amount greater than zero was provided.
        if initial_funding > 0:

            transaction_reference = (
                generate_transaction_reference()
            )

            transaction = Transaction(
                transaction_reference=transaction_reference,
                customer_id=customer.customer_id,
                transaction_type="Account Funding",
                direction="Credit",
                amount=initial_funding,
                balance_after=initial_funding,
                description=(
                    funding_description
                    or "Initial account funding"
                ),
                counterparty="Fairmont Bank",
                status="Completed",
                sender_name="Fairmont Bank",
                sender_account_number="",
                sender_bank="Fairmont Bank",
                sender_country="United Kingdom"
            )

            db.session.add(transaction)

        db.session.commit()

        return render_template(
            "admin_create_customer_success.html",
            admin=admin,
            customer=customer,
            initial_funding=initial_funding,
            funding_reference=funding_reference,
            funding_description=funding_description,
            transaction_reference=(
                transaction_reference
                if initial_funding > 0
                else None
            )
        )

    return render_template(
        "admin_create_customer.html",
        admin=admin,
        form_data=form_data
    )

'''

text = text.replace(
    marker,
    route + marker,
    1
)

APP_FILE.write_text(
    text,
    encoding="utf-8"
)

print()
print("=" * 70)
print("ADMIN CREATE CUSTOMER ROUTE ADDED")
print("=" * 70)
print()
print("Route:")
print("  /admin/create-customer")
print()
print("Features:")
print("  - Admin authentication")
print("  - Unique Fairmont Customer ID")
print("  - Unique 10-digit account number")
print("  - Duplicate email protection")
print("  - Duplicate phone protection")
print("  - Password hashing")
print("  - Active account creation")
print("  - Optional initial funding")
print("  - Account Funding credit transaction")
print()
print("Existing customer records were not deleted or recreated.")
print()