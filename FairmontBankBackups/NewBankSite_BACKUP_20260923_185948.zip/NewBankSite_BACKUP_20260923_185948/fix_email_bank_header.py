from pathlib import Path
import re

file = Path("templates/dashboard.html")

if not file.exists():
    raise SystemExit("ERROR: templates/dashboard.html was not found.")

text = file.read_text(encoding="utf-8")

# ---------------------------------------------------------
# 1. Remove the Email Bank / Contact Bank service card
# ---------------------------------------------------------

patterns = [
    r'\s*<!--\s*Email the Bank\s*-->.*?</a>',
    r'\s*<!--\s*Email Bank\s*-->.*?</a>',
    r'\s*<!--\s*Contact Bank\s*-->.*?</a>',
    r'\s*<a\s+href=["\']/email-bank["\'].*?</a>',
]

removed = False

for pattern in patterns:
    new_text, count = re.subn(
        pattern,
        "",
        text,
        count=1,
        flags=re.IGNORECASE | re.DOTALL
    )

    if count > 0:
        text = new_text
        removed = True
        print("SUCCESS: Removed the Email/Contact Bank service card.")
        break

if not removed:
    print("INFO: No Email/Contact Bank service card was found.")


# ---------------------------------------------------------
# 2. Add Email Bank beside the existing notification button
# ---------------------------------------------------------

if 'class="dashboard-email-button"' not in text:

    email_button = """
                    <a
                        href="/email-bank"
                        class="dashboard-email-button"
                        aria-label="Email the Bank"
                        title="Email the Bank">

                        <span class="dashboard-email-icon" aria-hidden="true">
                            <svg
                                viewBox="0 0 24 24"
                                width="23"
                                height="23"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="1.8"
                                stroke-linecap="round"
                                stroke-linejoin="round">
                                <rect
                                    x="3"
                                    y="5"
                                    width="18"
                                    height="14"
                                    rx="2">
                                </rect>
                                <path d="m3 7 9 6 9-6"></path>
                            </svg>
                        </span>

                    </a>
"""

    notification_pattern = (
        r'(<a\s+href=["\']/notifications["\']'
        r'[^>]*class=["\'][^"\']*dashboard-notification-button[^"\']*["\']'
        r'[^>]*>.*?</a>)'
    )

    match = re.search(
        notification_pattern,
        text,
        flags=re.IGNORECASE | re.DOTALL
    )

    if not match:
        raise SystemExit(
            "ERROR: Existing notification button was not found. "
            "No dashboard changes were saved."
        )

    notification_button = match.group(1)

    replacement = (
        '<div class="dashboard-header-actions">\n'
        + email_button
        + '\n'
        + notification_button
        + '\n'
        + '                    </div>'
    )

    text = (
        text[:match.start()]
        + replacement
        + text[match.end():]
    )

    print("SUCCESS: Added Email Bank beside the notification button.")

else:
    print("INFO: Email Bank header button already exists.")


# ---------------------------------------------------------
# 3. Add styling only for the new header envelope
# ---------------------------------------------------------

if "fairmont-email-header-css" not in text:

    css = """
<style id="fairmont-email-header-css">

.dashboard-header-actions {
    display: flex;
    align-items: center;
    gap: 10px;
}

.dashboard-email-button {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 44px;
    height: 44px;
    border-radius: 14px;
    text-decoration: none;
    color: inherit;
}

.dashboard-email-icon {
    display: flex;
    align-items: center;
    justify-content: center;
}

.dashboard-email-icon svg {
    display: block;
}

</style>
"""

    head_match = re.search(
        r"</head>",
        text,
        flags=re.IGNORECASE
    )

    if not head_match:
        raise SystemExit(
            "ERROR: </head> was not found. "
            "No dashboard changes were saved."
        )

    text = (
        text[:head_match.start()]
        + css
        + "\n"
        + text[head_match.start():]
    )

    print("SUCCESS: Added Email Bank header styling.")


# ---------------------------------------------------------
# 4. Save
# ---------------------------------------------------------

file.write_text(text, encoding="utf-8")

print()
print("==============================================")
print("EMAIL BANK HEADER FIX COMPLETE")
print("==============================================")
print("Services card removed.")
print("Envelope placed beside Notifications.")
print("Envelope links to /email-bank.")
print("Existing notification button preserved.")
print("No images or photos were generated.")
print()