from pathlib import Path

BASE = Path(r"C:\Users\DON J\Documents\NewBankSite")

TEMPLATES = BASE / "templates"
STATIC_JS = BASE / "static" / "js"
STATIC_CSS = BASE / "static" / "css"

TEMPLATES.mkdir(parents=True, exist_ok=True)
STATIC_JS.mkdir(parents=True, exist_ok=True)
STATIC_CSS.mkdir(parents=True, exist_ok=True)


# =========================================================
# SEND MONEY PAGE
# =========================================================

send_money = r'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send Money | Fairmont Bank</title>
    <link rel="stylesheet" href="{{ url_for('static', filename='css/transfer.css') }}">
</head>

<body>

<div class="transfer-page">

    <header class="transfer-header">
        <a href="{{ url_for('dashboard') }}" class="back-button">‹</a>

        <div>
            <div class="eyebrow">PAYMENTS</div>
            <h1>Send Money</h1>
        </div>
    </header>


    <section class="balance-card">
        <span>AVAILABLE BALANCE</span>
        <strong>£{{ "{:,.2f}".format(customer.account_balance or 0) }}</strong>

        <div class="account-reference">
            <div>
                <small>Account Number</small>
                <b>{{ customer.account_number or "Not assigned" }}</b>
            </div>

            <div>
                <small>Customer ID</small>
                <b>{{ customer.customer_id }}</b>
            </div>
        </div>
    </section>


    {% if error %}
    <div class="alert error">
        {{ error }}
    </div>
    {% endif %}


    <section class="panel">

        <div class="section-heading">
            <span class="section-icon">£</span>
            <div>
                <h2>Choose transfer type</h2>
                <p>Select where you want the money to go.</p>
            </div>
        </div>


        <div class="transfer-types">

            <button
                type="button"
                class="transfer-type active"
                data-type="uk"
                onclick="selectTransferType('uk')">

                <span class="type-icon">UK</span>

                <span>
                    <strong>UK Bank Account</strong>
                    <small>Send GBP to a UK bank account</small>
                </span>

            </button>


            <button
                type="button"
                class="transfer-type"
                data-type="fairmont"
                onclick="selectTransferType('fairmont')">

                <span class="type-icon">F</span>

                <span>
                    <strong>Fairmont Account</strong>
                    <small>Transfer to another Fairmont customer</small>
                </span>

            </button>

        </div>

    </section>


    <section class="panel">

        <form method="POST" action="{{ url_for('send_money') }}" id="sendMoneyForm">

            <input
                type="hidden"
                name="transfer_type"
                id="transfer_type"
                value="uk"
            >


            <!-- FAIRmont -->

            <div id="fairmontFields" class="transfer-fields hidden">

                <div class="field">
                    <label>Fairmont Account Number</label>

                    <input
                        type="text"
                        name="account_number"
                        id="fairmont_account_number"
                        maxlength="10"
                        inputmode="numeric"
                        placeholder="Enter 10-digit account number"
                    >

                    <small>
                        Use the recipient's Fairmont Account Number, not their Customer ID.
                    </small>
                </div>


                <div class="field">
                    <label>Recipient Name</label>

                    <input
                        type="text"
                        name="recipient_name"
                        id="fairmont_recipient_name"
                        placeholder="Recipient's full name"
                    >
                </div>


                <input
                    type="hidden"
                    name="bank_name"
                    value="Fairmont Bank"
                />

                <input
                    type="hidden"
                    name="sort_code"
                    value=""
                />

            </div>


            <!-- UK BANK -->

            <div id="ukFields">

                <div class="field">

                    <label>Bank</label>

                    <select name="bank_name" id="bank_name">

                        <option value="">
                            Select recipient's bank
                        </option>

                        {% for bank in banks %}

                        <option value="{{ bank.name }}">
                            {{ bank.name }}
                        </option>

                        {% endfor %}

                    </select>

                </div>


                <div class="field">

                    <label>Account Holder Name</label>

                    <input
                        type="text"
                        name="recipient_name"
                        id="recipient_name"
                        placeholder="Full name on the account"
                    >

                </div>


                <div class="field-row">

                    <div class="field">

                        <label>Sort Code</label>

                        <input
                            type="text"
                            name="sort_code"
                            id="sort_code"
                            maxlength="8"
                            inputmode="numeric"
                            placeholder="00-00-00"
                        >

                    </div>


                    <div class="field">

                        <label>Account Number</label>

                        <input
                            type="text"
                            name="account_number"
                            id="account_number"
                            maxlength="8"
                            inputmode="numeric"
                            placeholder="8 digits"
                        >

                    </div>

                </div>

            </div>


            <div class="field">

                <label>Amount</label>

                <div class="money-input">

                    <span>£</span>

                    <input
                        type="number"
                        name="amount"
                        min="0.01"
                        step="0.01"
                        placeholder="0.00"
                        required
                    >

                </div>

            </div>


            <div class="field">

                <label>Payment Reference <span>Optional</span></label>

                <input
                    type="text"
                    name="payment_reference"
                    maxlength="255"
                    placeholder="What is this payment for?"
                >

            </div>


            <div class="notice">

                <strong>Before you send</strong>

                <p>
                    Check the recipient's bank details and amount carefully.
                    Fairmont-to-Fairmont transfers update both accounts immediately.
                    External bank transfers are recorded as transfer requests until
                    a real external payment connection is configured.
                </p>

            </div>


            <button type="submit" class="primary-button">
                Continue
            </button>

        </form>

    </section>


    <a href="{{ url_for('transactions') }}" class="secondary-button">
        View Transaction History
    </a>


    <section class="security-note">

        <span>🔒</span>

        <div>
            <strong>Secure payment</strong>
            <p>Your transfer details are handled within your Fairmont account session.</p>
        </div>

    </section>

</div>


<script src="{{ url_for('static', filename='js/transfer.js') }}"></script>

</body>
</html>
'''


# =========================================================
# INTERNATIONAL TRANSFER PAGE
# =========================================================

international = r'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>International Transfer | Fairmont Bank</title>
    <link rel="stylesheet" href="{{ url_for('static', filename='css/transfer.css') }}">
</head>

<body>

<div class="transfer-page">

    <header class="transfer-header">
        <a href="{{ url_for('dashboard') }}" class="back-button">‹</a>

        <div>
            <div class="eyebrow">GLOBAL PAYMENTS</div>
            <h1>International Transfer</h1>
        </div>
    </header>


    <section class="balance-card">

        <span>AVAILABLE BALANCE</span>

        <strong>
            £{{ "{:,.2f}".format(customer.account_balance or 0) }}
        </strong>

        <div class="account-reference">

            <div>
                <small>Account Number</small>
                <b>{{ customer.account_number or "Not assigned" }}</b>
            </div>

            <div>
                <small>Currency</small>
                <b>GBP</b>
            </div>

        </div>

    </section>


    {% if error %}
    <div class="alert error">
        {{ error }}
    </div>
    {% endif %}


    <section class="panel">

        <div class="section-heading">

            <span class="section-icon">◎</span>

            <div>
                <h2>Beneficiary details</h2>
                <p>Enter the destination bank information.</p>
            </div>

        </div>


        <form method="POST" action="{{ url_for('international_transfer') }}">

            <div class="field">

                <label>Destination Country</label>

                <select name="country" required>

                    <option value="">
                        Select country
                    </option>

                    {% for country in [
                        "Afghanistan","Albania","Algeria","Andorra","Angola",
                        "Argentina","Armenia","Australia","Austria","Azerbaijan",
                        "Bahamas","Bahrain","Bangladesh","Barbados","Belgium",
                        "Belize","Benin","Bhutan","Bolivia","Bosnia and Herzegovina",
                        "Botswana","Brazil","Brunei","Bulgaria","Cambodia",
                        "Cameroon","Canada","Chile","China","Colombia",
                        "Costa Rica","Croatia","Cyprus","Czechia","Denmark",
                        "Dominican Republic","Ecuador","Egypt","Estonia","Ethiopia",
                        "Fiji","Finland","France","Georgia","Germany","Ghana",
                        "Greece","Guatemala","Honduras","Hong Kong","Hungary",
                        "Iceland","India","Indonesia","Ireland","Israel","Italy",
                        "Jamaica","Japan","Jordan","Kazakhstan","Kenya","Kuwait",
                        "Latvia","Lebanon","Lithuania","Luxembourg","Malaysia",
                        "Maldives","Malta","Mauritius","Mexico","Monaco",
                        "Mongolia","Montenegro","Morocco","Mozambique","Namibia",
                        "Nepal","Netherlands","New Zealand","Nigeria","Norway",
                        "Oman","Pakistan","Panama","Peru","Philippines","Poland",
                        "Portugal","Qatar","Romania","Rwanda","Saudi Arabia",
                        "Serbia","Seychelles","Singapore","Slovakia","Slovenia",
                        "South Africa","South Korea","Spain","Sri Lanka","Sweden",
                        "Switzerland","Taiwan","Tanzania","Thailand","Tunisia",
                        "Turkey","Uganda","Ukraine","United Arab Emirates",
                        "United Kingdom","United States","Uruguay","Uzbekistan",
                        "Venezuela","Vietnam","Zambia","Zimbabwe"
                    ] %}

                    <option value="{{ country }}">
                        {{ country }}
                    </option>

                    {% endfor %}

                </select>

            </div>


            <div class="field">

                <label>Beneficiary Name</label>

                <input
                    type="text"
                    name="recipient_name"
                    placeholder="Full legal name"
                    required
                >

            </div>


            <div class="field">

                <label>Beneficiary Address <span>Optional</span></label>

                <textarea
                    name="recipient_address"
                    rows="3"
                    placeholder="Street, city, postal code and country"
                ></textarea>

            </div>


            <div class="field">

                <label>Bank Name</label>

                <input
                    type="text"
                    name="bank_name"
                    placeholder="Beneficiary bank"
                    required
                >

            </div>


            <div class="field">

                <label>Account Number</label>

                <input
                    type="text"
                    name="account_number"
                    placeholder="Local bank account number"
                >

            </div>


            <div class="field">

                <label>IBAN <span>Where applicable</span></label>

                <input
                    type="text"
                    name="iban"
                    placeholder="International Bank Account Number"
                >

            </div>


            <div class="field-row">

                <div class="field">

                    <label>SWIFT / BIC</label>

                    <input
                        type="text"
                        name="bic"
                        maxlength="11"
                        placeholder="AAAA BB CC 123"
                        required
                    >

                </div>


                <div class="field">

                    <label>Local Bank Code <span>Optional</span></label>

                    <input
                        type="text"
                        name="local_bank_code"
                        placeholder="Routing / clearing code"
                    >

                </div>

            </div>


            <div class="field">

                <label>Currency</label>

                <select name="currency" required>

                    <option value="">Select currency</option>
                    <option value="GBP">GBP — Pound Sterling</option>
                    <option value="USD">USD — US Dollar</option>
                    <option value="EUR">EUR — Euro</option>
                    <option value="CAD">CAD — Canadian Dollar</option>
                    <option value="AUD">AUD — Australian Dollar</option>
                    <option value="NZD">NZD — New Zealand Dollar</option>
                    <option value="CHF">CHF — Swiss Franc</option>
                    <option value="JPY">JPY — Japanese Yen</option>
                    <option value="CNY">CNY — Chinese Yuan</option>
                    <option value="HKD">HKD — Hong Kong Dollar</option>
                    <option value="SGD">SGD — Singapore Dollar</option>
                    <option value="AED">AED — UAE Dirham</option>
                    <option value="SAR">SAR — Saudi Riyal</option>
                    <option value="ZAR">ZAR — South African Rand</option>
                    <option value="INR">INR — Indian Rupee</option>
                    <option value="KES">KES — Kenyan Shilling</option>
                    <option value="NGN">NGN — Nigerian Naira</option>
                    <option value="GHS">GHS — Ghanaian Cedi</option>
                    <option value="BRL">BRL — Brazilian Real</option>
                    <option value="MXN">MXN — Mexican Peso</option>
                    <option value="TRY">TRY — Turkish Lira</option>
                    <option value="PLN">PLN — Polish Zloty</option>
                    <option value="NOK">NOK — Norwegian Krone</option>
                    <option value="SEK">SEK — Swedish Krona</option>
                    <option value="DKK">DKK — Danish Krone</option>
                    <option value="THB">THB — Thai Baht</option>
                    <option value="MYR">MYR — Malaysian Ringgit</option>
                    <option value="IDR">IDR — Indonesian Rupiah</option>
                    <option value="PHP">PHP — Philippine Peso</option>
                    <option value="KRW">KRW — South Korean Won</option>

                </select>

            </div>


            <div class="field">

                <label>Amount</label>

                <div class="money-input">

                    <span>¤</span>

                    <input
                        type="number"
                        name="amount"
                        min="0.01"
                        step="0.01"
                        placeholder="0.00"
                        required
                    >

                </div>

            </div>


            <div class="field">

                <label>Payment Reference <span>Optional</span></label>

                <input
                    type="text"
                    name="payment_reference"
                    maxlength="255"
                    placeholder="Reason or reference"
                >

            </div>


            <div class="notice international-notice">

                <strong>International payment information</strong>

                <p>
                    International payments require accurate beneficiary and
                    bank information. The local Fairmont prototype records
                    external transfer requests; it does not claim that funds
                    have been delivered through an external payment network.
                </p>

            </div>


            <button type="submit" class="primary-button">
                Continue
            </button>

        </form>

    </section>


    <a href="{{ url_for('transactions') }}" class="secondary-button">
        View Transaction History
    </a>

</div>

</body>
</html>
'''


# =========================================================
# INTERNATIONAL CONFIRMATION
# =========================================================

international_confirmation = r'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>International Transfer Request | Fairmont Bank</title>
    <link rel="stylesheet" href="{{ url_for('static', filename='css/transfer.css') }}">
</head>

<body>

<div class="transfer-page confirmation-page">

    <div class="success-icon">✓</div>

    <div class="eyebrow">TRANSFER REQUEST</div>

    <h1>Request Recorded</h1>

    <p class="confirmation-text">
        Your international transfer request has been recorded in Fairmont Bank.
    </p>


    <section class="confirmation-card">

        <div class="status-pill pending">
            Pending
        </div>


        <div class="detail-row">
            <span>Reference</span>
            <strong>{{ transfer.transaction_reference }}</strong>
        </div>

        <div class="detail-row">
            <span>Beneficiary</span>
            <strong>{{ transfer.recipient_name }}</strong>
        </div>

        <div class="detail-row">
            <span>Bank</span>
            <strong>{{ transfer.bank_name }}</strong>
        </div>

        <div class="detail-row">
            <span>Country</span>
            <strong>{{ transfer.country }}</strong>
        </div>

        <div class="detail-row">
            <span>Amount</span>
            <strong>{{ transfer.currency }} {{ "{:,.2f}".format(transfer.amount) }}</strong>
        </div>

        <div class="detail-row">
            <span>SWIFT / BIC</span>
            <strong>{{ bic }}</strong>
        </div>

    </section>


    <div class="notice">

        <strong>Important</strong>

        <p>
            This local Fairmont application has recorded the transfer request.
            It has not represented the payment as delivered through an external
            banking network.
        </p>

    </div>


    <a href="{{ url_for('dashboard') }}" class="primary-button">
        Return to Dashboard
    </a>

    <a href="{{ url_for('transactions') }}" class="secondary-button">
        View Transaction History
    </a>

</div>

</body>
</html>
'''


# =========================================================
# TRANSFER CSS
# =========================================================

css = r'''
* {
    box-sizing: border-box;
}

body {
    margin: 0;
    min-height: 100vh;
    background:
        radial-gradient(circle at top right, rgba(40, 85, 150, .25), transparent 35%),
        #071426;
    color: #f5f8ff;
    font-family: Arial, Helvetica, sans-serif;
}

.transfer-page {
    width: min(100%, 760px);
    margin: 0 auto;
    padding: 24px 18px 50px;
}

.transfer-header {
    display: flex;
    align-items: center;
    gap: 15px;
    margin-bottom: 22px;
}

.back-button {
    width: 44px;
    height: 44px;
    display: grid;
    place-items: center;
    border-radius: 14px;
    color: white;
    text-decoration: none;
    font-size: 34px;
    background: rgba(255,255,255,.07);
    border: 1px solid rgba(255,255,255,.08);
}

.eyebrow {
    font-size: 11px;
    letter-spacing: 2px;
    font-weight: 700;
    color: #8ea7c8;
    margin-bottom: 4px;
}

h1 {
    margin: 0;
    font-size: 29px;
}

h2 {
    margin: 0 0 4px;
    font-size: 18px;
}

p {
    color: #9eb0c9;
    line-height: 1.55;
}

.balance-card {
    padding: 23px;
    border-radius: 22px;
    margin-bottom: 18px;
    background: linear-gradient(135deg, #102b4d, #0a1d35);
    border: 1px solid rgba(255,255,255,.09);
    box-shadow: 0 20px 50px rgba(0,0,0,.22);
}

.balance-card > span {
    display: block;
    color: #93a9c4;
    font-size: 11px;
    letter-spacing: 1.6px;
    font-weight: 700;
}

.balance-card > strong {
    display: block;
    font-size: 31px;
    margin-top: 7px;
}

.account-reference {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
    margin-top: 22px;
}

.account-reference div {
    padding: 13px;
    border-radius: 14px;
    background: rgba(0,0,0,.16);
}

.account-reference small {
    display: block;
    color: #8097b5;
    font-size: 11px;
    margin-bottom: 6px;
}

.account-reference b {
    font-size: 13px;
    word-break: break-all;
}

.panel {
    background: rgba(13, 32, 57, .84);
    border: 1px solid rgba(255,255,255,.08);
    border-radius: 22px;
    padding: 20px;
    margin-bottom: 18px;
    box-shadow: 0 18px 45px rgba(0,0,0,.18);
}

.section-heading {
    display: flex;
    align-items: center;
    gap: 13px;
    margin-bottom: 20px;
}

.section-heading p {
    margin: 0;
    font-size: 13px;
}

.section-icon {
    width: 42px;
    height: 42px;
    border-radius: 13px;
    display: grid;
    place-items: center;
    background: rgba(78, 139, 214, .16);
    color: #9fc8ff;
    font-weight: 800;
}

.transfer-types {
    display: grid;
    gap: 10px;
}

.transfer-type {
    width: 100%;
    border: 1px solid rgba(255,255,255,.08);
    background: rgba(255,255,255,.025);
    color: white;
    border-radius: 16px;
    padding: 14px;
    display: flex;
    align-items: center;
    gap: 13px;
    text-align: left;
    cursor: pointer;
}

.transfer-type.active {
    border-color: rgba(111, 173, 245, .65);
    background: rgba(67, 125, 194, .15);
}

.type-icon {
    width: 42px;
    height: 42px;
    flex: 0 0 42px;
    border-radius: 12px;
    display: grid;
    place-items: center;
    background: #173b63;
    color: #b8d8ff;
    font-size: 12px;
    font-weight: 800;
}

.transfer-type strong,
.transfer-type small {
    display: block;
}

.transfer-type small {
    margin-top: 4px;
    color: #8ea2bc;
}

.field {
    margin-bottom: 17px;
}

.field-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 13px;
}

label {
    display: block;
    margin-bottom: 7px;
    font-size: 13px;
    font-weight: 700;
    color: #dce7f6;
}

label span {
    color: #7188a4;
    font-weight: 400;
}

input,
select,
textarea {
    width: 100%;
    border: 1px solid rgba(255,255,255,.1);
    border-radius: 13px;
    background: #091a2e;
    color: #f5f8ff;
    padding: 13px 14px;
    font-size: 14px;
    outline: none;
}

textarea {
    resize: vertical;
}

input:focus,
select:focus,
textarea:focus {
    border-color: rgba(111, 173, 245, .75);
}

.field > small {
    display: block;
    margin-top: 7px;
    color: #7188a4;
    font-size: 11px;
    line-height: 1.5;
}

.money-input {
    display: flex;
    align-items: center;
    background: #091a2e;
    border: 1px solid rgba(255,255,255,.1);
    border-radius: 13px;
    overflow: hidden;
}

.money-input span {
    padding-left: 15px;
    color: #9bb4d1;
    font-weight: 700;
}

.money-input input {
    border: 0;
    background: transparent;
}

.notice {
    padding: 15px;
    border-radius: 15px;
    background: rgba(62, 110, 164, .10);
    border: 1px solid rgba(99, 155, 215, .15);
    margin: 20px 0;
}

.notice strong {
    display: block;
    font-size: 13px;
}

.notice p {
    margin: 7px 0 0;
    font-size: 12px;
}

.primary-button,
.secondary-button {
    display: block;
    width: 100%;
    text-align: center;
    border-radius: 14px;
    padding: 14px 18px;
    text-decoration: none;
    font-weight: 700;
    font-size: 14px;
    cursor: pointer;
}

.primary-button {
    border: 0;
    color: white;
    background: linear-gradient(135deg, #2d71bd, #3f91df);
}

.secondary-button {
    color: #b8d2ef;
    background: rgba(255,255,255,.05);
    border: 1px solid rgba(255,255,255,.08);
    margin-bottom: 16px;
}

.alert {
    padding: 14px 16px;
    border-radius: 14px;
    margin-bottom: 18px;
    font-size: 13px;
}

.alert.error {
    background: rgba(180, 53, 53, .15);
    border: 1px solid rgba(239, 104, 104, .25);
    color: #ffb1b1;
}

.security-note {
    display: flex;
    gap: 11px;
    padding: 13px;
    color: #7f96b3;
    font-size: 11px;
}

.security-note p {
    margin: 3px 0 0;
    font-size: 11px;
}

.hidden {
    display: none;
}

.confirmation-page {
    padding-top: 70px;
    text-align: center;
}

.success-icon {
    width: 70px;
    height: 70px;
    border-radius: 50%;
    display: grid;
    place-items: center;
    margin: 0 auto 20px;
    background: rgba(62, 178, 116, .15);
    border: 1px solid rgba(62, 178, 116, .35);
    color: #7be0a4;
    font-size: 32px;
}

.confirmation-text {
    max-width: 520px;
    margin: 10px auto 24px;
}

.confirmation-card {
    text-align: left;
    background: rgba(13, 32, 57, .84);
    border: 1px solid rgba(255,255,255,.08);
    border-radius: 20px;
    padding: 20px;
    margin-bottom: 18px;
}

.status-pill {
    display: inline-block;
    border-radius: 30px;
    padding: 6px 11px;
    font-size: 11px;
    font-weight: 800;
    margin-bottom: 12px;
}

.status-pill.pending {
    color: #f3d58a;
    background: rgba(202, 157, 45, .14);
}

.detail-row {
    display: flex;
    justify-content: space-between;
    gap: 20px;
    padding: 12px 0;
    border-bottom: 1px solid rgba(255,255,255,.06);
}

.detail-row:last-child {
    border-bottom: 0;
}

.detail-row span {
    color: #8298b4;
    font-size: 12px;
}

.detail-row strong {
    text-align: right;
    font-size: 13px;
    word-break: break-word;
}

@media (max-width: 560px) {

    .transfer-page {
        padding: 18px 13px 40px;
    }

    .field-row {
        grid-template-columns: 1fr;
        gap: 0;
    }

    .account-reference {
        grid-template-columns: 1fr;
    }

    h1 {
        font-size: 25px;
    }
}
'''


# =========================================================
# TRANSFER JAVASCRIPT
# =========================================================

javascript = r'''
function selectTransferType(type) {

    const hiddenType = document.getElementById("transfer_type");

    const ukFields = document.getElementById("ukFields");
    const fairmontFields = document.getElementById("fairmontFields");

    const buttons = document.querySelectorAll(".transfer-type");

    if (hiddenType) {
        hiddenType.value = type;
    }

    buttons.forEach(function(button) {

        if (button.dataset.type === type) {
            button.classList.add("active");
        } else {
            button.classList.remove("active");
        }

    });

    if (type === "fairmont") {

        if (ukFields) {
            ukFields.classList.add("hidden");
        }

        if (fairmontFields) {
            fairmontFields.classList.remove("hidden");
        }

        document
            .getElementById("recipient_name")
            ?.removeAttribute("required");

        document
            .getElementById("bank_name")
            ?.removeAttribute("required");

        document
            .getElementById("sort_code")
            ?.removeAttribute("required");

        document
            .getElementById("account_number")
            ?.removeAttribute("required");

        document
            .getElementById("fairmont_account_number")
            ?.setAttribute("required", "required");

        document
            .getElementById("fairmont_recipient_name")
            ?.setAttribute("required", "required");

    } else {

        if (fairmontFields) {
            fairmontFields.classList.add("hidden");
        }

        if (ukFields) {
            ukFields.classList.remove("hidden");
        }

        document
            .getElementById("fairmont_account_number")
            ?.removeAttribute("required");

        document
            .getElementById("fairmont_recipient_name")
            ?.removeAttribute("required");

        document
            .getElementById("recipient_name")
            ?.setAttribute("required", "required");

        document
            .getElementById("bank_name")
            ?.setAttribute("required", "required");

        document
            .getElementById("sort_code")
            ?.setAttribute("required", "required");

        document
            .getElementById("account_number")
            ?.setAttribute("required", "required");
    }
}


document.addEventListener("DOMContentLoaded", function() {

    if (document.getElementById("sendMoneyForm")) {
        selectTransferType("uk");
    }

});
'''


# =========================================================
# WRITE FILES
# =========================================================

(TEMPLATES / "send_money.html").write_text(
    send_money,
    encoding="utf-8"
)

(TEMPLATES / "international_transfer.html").write_text(
    international,
    encoding="utf-8"
)

(TEMPLATES / "international_confirmation.html").write_text(
    international_confirmation,
    encoding="utf-8"
)

(STATIC_CSS / "transfer.css").write_text(
    css,
    encoding="utf-8"
)

(STATIC_JS / "transfer.js").write_text(
    javascript,
    encoding="utf-8"
)


print("")
print("==============================================")
print("TRANSFER PAGES CREATED")
print("==============================================")
print("send_money.html")
print("international_transfer.html")
print("international_confirmation.html")
print("transfer.css")
print("transfer.js")
print("")