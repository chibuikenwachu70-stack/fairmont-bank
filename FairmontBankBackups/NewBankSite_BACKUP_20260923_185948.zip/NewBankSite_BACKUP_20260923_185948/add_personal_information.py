from pathlib import Path
import re
import shutil
from datetime import datetime

BASE = Path(r"C:\Users\DON J\Documents\NewBankSite")
APP = BASE / "app.py"
SETTINGS = BASE / "templates" / "settings.html"

# ---------------------------------------------------------
# BACKUP
# ---------------------------------------------------------

backup_dir = BASE / "personal_information_backup"
backup_dir.mkdir(exist_ok=True)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

shutil.copy2(
    APP,
    backup_dir / f"app.py_{timestamp}.bak"
)

shutil.copy2(
    SETTINGS,
    backup_dir / f"settings.html_{timestamp}.bak"
)

# ---------------------------------------------------------
# CREATE PERSONAL INFORMATION PAGE
# ---------------------------------------------------------

profile_html = r'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Personal Information - Fairmont Bank</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            background:
                radial-gradient(circle at top left, rgba(35, 76, 125, 0.28), transparent 38%),
                linear-gradient(180deg, #07182d 0%, #061426 100%);
            color: #ffffff;
            font-family: Arial, Helvetica, sans-serif;
        }

        .profile-page {
            width: 100%;
            max-width: 760px;
            margin: 0 auto;
            padding: 22px 18px 45px;
        }

        .profile-header {
            display: flex;
            align-items: center;
            gap: 14px;
            margin-bottom: 25px;
        }

        .back-button {
            width: 42px;
            height: 42px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            color: #ffffff;
            background: rgba(255,255,255,0.07);
            border: 1px solid rgba(255,255,255,0.10);
            font-size: 22px;
        }

        .profile-title {
            margin: 0;
            font-size: 24px;
            font-weight: 700;
        }

        .profile-subtitle {
            margin: 4px 0 0;
            color: rgba(255,255,255,0.60);
            font-size: 13px;
        }

        .profile-card {
            background: rgba(13, 34, 59, 0.84);
            border: 1px solid rgba(255,255,255,0.09);
            border-radius: 18px;
            overflow: hidden;
            box-shadow: 0 12px 30px rgba(0,0,0,0.18);
        }

        .profile-heading {
            padding: 20px 20px 16px;
            border-bottom: 1px solid rgba(255,255,255,0.07);
        }

        .profile-heading-title {
            margin: 0;
            font-size: 16px;
            font-weight: 600;
        }

        .profile-heading-text {
            margin: 5px 0 0;
            color: rgba(255,255,255,0.55);
            font-size: 12px;
        }

        .information-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            padding: 17px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.06);
        }

        .information-row:last-child {
            border-bottom: none;
        }

        .information-label {
            color: rgba(255,255,255,0.52);
            font-size: 12px;
            flex: 0 0 40%;
        }

        .information-value {
            color: #ffffff;
            font-size: 13px;
            font-weight: 600;
            text-align: right;
            word-break: break-word;
        }

        .status {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            color: #8fe0b0;
        }

        .status-dot {
            width: 7px;
            height: 7px;
            border-radius: 50%;
            background: #8fe0b0;
        }

        .notice {
            margin-top: 18px;
            padding: 15px 16px;
            border-radius: 14px;
            background: rgba(255,255,255,0.045);
            border: 1px solid rgba(255,255,255,0.07);
            color: rgba(255,255,255,0.52);
            font-size: 12px;
            line-height: 1.5;
        }

        @media (max-width: 600px) {

            .profile-page {
                padding: 18px 14px 35px;
            }

            .profile-title {
                font-size: 22px;
            }

            .information-row {
                align-items: flex-start;
                flex-direction: column;
                gap: 6px;
                padding: 15px 17px;
            }

            .information-label {
                flex-basis: auto;
            }

            .information-value {
                text-align: left;
            }
        }
    </style>
</head>

<body>

<div class="profile-page">

    <div class="profile-header">

        <a href="{{ url_for('settings') }}" class="back-button">
            ‹
        </a>

        <div>
            <h1 class="profile-title">
                Personal Information
            </h1>

            <p class="profile-subtitle">
                Your Fairmont Bank account information
            </p>
        </div>

    </div>


    <div class="profile-card">

        <div class="profile-heading">

            <p class="profile-heading-title">
                Account Information
            </p>

            <p class="profile-heading-text">
                These details are currently displayed for reference.
            </p>

        </div>


        <div class="information-row">

            <div class="information-label">
                Full Name
            </div>

            <div class="information-value">
                {{ customer.full_name }}
            </div>

        </div>


        <div class="information-row">

            <div class="information-label">
                Customer ID
            </div>

            <div class="information-value">
                {{ customer.customer_id }}
            </div>

        </div>


        <div class="information-row">

            <div class="information-label">
                Account Number
            </div>

            <div class="information-value">
                {{ customer.account_number }}
            </div>

        </div>


        <div class="information-row">

            <div class="information-label">
                Email
            </div>

            <div class="information-value">
                {{ customer.email }}
            </div>

        </div>


        <div class="information-row">

            <div class="information-label">
                Phone
            </div>

            <div class="information-value">
                {{ customer.phone }}
            </div>

        </div>


        <div class="information-row">

            <div class="information-label">
                Account Type
            </div>

            <div class="information-value">
                {{ customer.account_type|title }}
            </div>

        </div>


        <div class="information-row">

            <div class="information-label">
                Country
            </div>

            <div class="information-value">
                {{ customer.country|title }}
            </div>

        </div>


        <div class="information-row">

            <div class="information-label">
                Account Status
            </div>

            <div class="information-value">

                <span class="status">
                    <span class="status-dot"></span>
                    {{ customer.account_status }}
                </span>

            </div>

        </div>

    </div>


    <div class="notice">
        For security, your account information is displayed without providing editing controls here.
    </div>

</div>

</body>
</html>
'''

PROFILE = BASE / "templates" / "personal_information.html"

PROFILE.write_text(profile_html, encoding="utf-8")

# ---------------------------------------------------------
# ADD ROUTE
# ---------------------------------------------------------

app_text = APP.read_text(encoding="utf-8")

route = r'''

@app.route("/personal-information")
@login_required
def personal_information():
    customer = current_user
    return render_template(
        "personal_information.html",
        customer=customer
    )

'''

if "def personal_information()" not in app_text:

    marker = '\nif __name__ == "__main__":'

    if marker not in app_text:
        raise RuntimeError(
            "Could not find the final app.run section in app.py."
        )

    app_text = app_text.replace(
        marker,
        route + marker,
        1
    )

    APP.write_text(app_text, encoding="utf-8")

# ---------------------------------------------------------
# MAKE SETTINGS PERSONAL INFORMATION CLICKABLE
# ---------------------------------------------------------

settings_text = SETTINGS.read_text(encoding="utf-8")

old_block = '''<div class="settings-card">

        <div class="settings-icon">
            👤
        </div>

        <div class="settings-content">

            <p class="settings-name">
                Personal Information
            </p>

            <p class="settings-description">
                Manage your personal and customer account information.
            </p>

        </div>

        <div class="settings-arrow">
            ›
        </div>

    </div>'''

new_block = '''<a
        href="{{ url_for('personal_information') }}"
        class="settings-card"
        style="text-decoration:none; color:inherit;">

        <div class="settings-icon">
            👤
        </div>

        <div class="settings-content">

            <p class="settings-name">
                Personal Information
            </p>

            <p class="settings-description">
                Manage your personal and customer account information.
            </p>

        </div>

        <div class="settings-arrow">
            ›
        </div>

    </a>'''

if old_block in settings_text:

    settings_text = settings_text.replace(
        old_block,
        new_block,
        1
    )

    SETTINGS.write_text(
        settings_text,
        encoding="utf-8"
    )

else:
    print()
    print("WARNING: Personal Information settings card was not found.")
    print("The page and route were still created.")

# ---------------------------------------------------------
# DONE
# ---------------------------------------------------------

print()
print("==============================================")
print("PERSONAL INFORMATION INSTALLED")
print("==============================================")
print()
print("New page:")
print("  /personal-information")
print()
print("Displayed:")
print("  Full Name")
print("  Customer ID")
print("  Account Number")
print("  Email")
print("  Phone")
print("  Account Type")
print("  Country")
print("  Account Status")
print()
print("Existing customer data was not modified.")
print()
print("Backup created in:")
print("  personal_information_backup")
print()