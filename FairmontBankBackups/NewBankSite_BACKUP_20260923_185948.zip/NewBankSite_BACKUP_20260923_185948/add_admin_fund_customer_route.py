from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
APP_FILE = BASE_DIR / "app.py"

if not APP_FILE.exists():
    print("ERROR: app.py was not found.")
    raise SystemExit(1)

app_text = APP_FILE.read_text(encoding="utf-8")

if 'def admin_fund_customer()' in app_text:
    print()
    print("=" * 70)
    print("FUND CUSTOMER ROUTE ALREADY EXISTS")
    print("=" * 70)
    raise SystemExit(0)

route_code = r'''

@app.route("/admin/fund-customer", methods=["GET", "POST"])
def admin_fund_customer():
    admin_id = session.get("admin_id")

    if not admin_id:
        return redirect(url_for("admin_login"))

    admin = db.session.get(AdminUser, admin_id)

    if not admin or not admin.is_active:
        session.pop("admin_id", None)
        return redirect(url_for("admin_login"))

    customers = Customer.query.order_by(Customer.full_name.asc()).all()

    if request.method == "POST":
        receiver_customer_id = request.form.get(
            "customer_id",
            ""
        ).strip()

        amount_text = request.form.get(
            "amount",
            ""
        ).strip()

        funding_reference = request.form.get(
            "funding_reference",
            ""
        ).strip()

        funding_description = request.form.get(
            "funding_description",
            ""
        ).strip()

        if not receiver_customer_id:
            flash("Please select a customer.", "error")

            return render_template(
                "admin_fund_customer.html",
                admin=admin,
                customers=customers
            )

        customer = Customer.query.filter_by(
            customer_id=receiver_customer_id
        ).first()

        if not customer:
            flash("The selected customer could not be found.", "error")

            return render_template(
                "admin_fund_customer.html",
                admin=admin,
                customers=customers
            )

        if customer.account_status != "Active":
            flash(
                "Funds can only be added to an active customer account.",
                "error"
            )

            return render_template(
                "admin_fund_customer.html",
                admin=admin,
                customers=customers
            )

        try:
            amount = float(amount_text)
        except (TypeError, ValueError):
            amount = 0

        if amount <= 0:
            flash(
                "Funding amount must be greater than zero.",
                "error"
            )

            return render_template(
                "admin_fund_customer.html",
                admin=admin,
                customers=customers
            )

        current_balance = float(
            customer.account_balance or 0
        )

        new_balance = current_balance + amount

        transaction_reference = generate_transaction_reference()

        description = (
            funding_description
            if funding_description
            else "Account Funding"
        )

        if funding_reference:
            description = (
                f"{description} "
                f"(Reference: {funding_reference})"
            )

        customer.account_balance = new_balance

        transaction = Transaction(
            transaction_reference=transaction_reference,
            customer_id=customer.customer_id,
            transaction_type="Account Funding",
            direction="Credit",
            amount=amount,
            balance_after=new_balance,
            description=description,
            counterparty="Fairmont Bank",
            status="Completed",
            sender_name="Fairmont Bank",
            sender_account_number="",
            sender_bank="Fairmont Bank",
            sender_country="United Kingdom"
        )

        db.session.add(transaction)
        db.session.commit()

        return render_template(
            "admin_fund_customer_success.html",
            admin=admin,
            customer=customer,
            amount=amount,
            previous_balance=current_balance,
            new_balance=new_balance,
            funding_reference=funding_reference,
            funding_description=funding_description,
            transaction_reference=transaction_reference
        )

    return render_template(
        "admin_fund_customer.html",
        admin=admin,
        customers=customers
    )
'''

# Insert before the main application startup block.
marker = '\nif __name__ == "__main__":'

position = app_text.find(marker)

if position == -1:
    print(
        "ERROR: Could not find the app.py startup block."
    )
    raise SystemExit(1)

app_text = (
    app_text[:position]
    + route_code
    + app_text[position:]
)

APP_FILE.write_text(
    app_text,
    encoding="utf-8"
)

print()
print("=" * 70)
print("ADMIN FUND CUSTOMER ROUTE ADDED")
print("=" * 70)
print()
print("Route:")
print("  /admin/fund-customer")
print()
print("Features:")
print("  - Admin authentication")
print("  - Select any existing customer")
print("  - Active-account validation")
print("  - Add funds to existing balance")
print("  - Balance is increased, never overwritten")
print("  - Account Funding credit transaction")
print("  - Funding reference support")
print("  - Funding description support")
print("  - Previous balance preserved")
print("  - New balance recorded")
print()
print("Existing customer records were not deleted or recreated.")
print()