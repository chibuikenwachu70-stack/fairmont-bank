from pathlib import Path
import shutil

APP_FILE = Path("app.py")

if not APP_FILE.exists():
    print("ERROR: app.py was not found.")
    raise SystemExit(1)

text = APP_FILE.read_text(encoding="utf-8")

if "def admin_bank_email" in text:
    print("Admin Bank Email route already exists.")
    raise SystemExit(0)

backup = Path("app.py.before_admin_bank_email")
shutil.copy2(APP_FILE, backup)

route = r'''

@app.route("/admin/bank-email", methods=["GET", "POST"])
def admin_bank_email():
    admin_id = session.get("admin_id")

    if not admin_id:
        return redirect(url_for("admin_login"))

    admin = db.session.get(AdminUser, admin_id)

    if admin is None or not admin.is_active:
        session.pop("admin_id", None)
        session.pop("admin_username", None)
        return redirect(url_for("admin_login"))

    message_id = request.args.get("message_id", type=int)

    if request.method == "POST":
        message_id = request.form.get("message_id", type=int)
        reply_text = request.form.get("reply", "").strip()

        if not message_id:
            return redirect(url_for("admin_bank_email"))

        bank_message = db.session.get(
            BankMessage,
            message_id
        )

        if bank_message is None:
            return redirect(url_for("admin_bank_email"))

        if not reply_text:
            return redirect(
                url_for(
                    "admin_bank_email",
                    message_id=bank_message.id
                )
            )

        if len(reply_text) > 5000:
            reply_text = reply_text[:5000]

        # Store the administrator reply as a new BankMessage
        # belonging to the same customer.
        reply_message = BankMessage(
            customer_id=bank_message.customer_id,
            subject="Re: " + bank_message.subject,
            message=reply_text,
            status="Unread",
            created_at=datetime.utcnow()
        )

        db.session.add(reply_message)

        # Mark the customer's original message as read.
        bank_message.status = "Read"

        db.session.commit()

        return redirect(
            url_for(
                "admin_bank_email",
                message_id=bank_message.id
            )
        )

    messages = (
        BankMessage.query
        .order_by(BankMessage.created_at.desc())
        .all()
    )

    customers = {}

    for bank_message in messages:
        customer = db.session.get(
            Customer,
            bank_message.customer_id
        )
        customers[bank_message.id] = customer

    selected_message = None
    selected_customer = None

    if message_id:
        selected_message = db.session.get(
            BankMessage,
            message_id
        )

        if selected_message:
            selected_customer = db.session.get(
                Customer,
                selected_message.customer_id
            )

            # Opening a customer's message marks it as read.
            if selected_message.status == "Unread":
                selected_message.status = "Read"
                db.session.commit()

    return render_template(
        "admin_bank_email.html",
        admin=admin,
        messages=messages,
        customers=customers,
        selected_message=selected_message,
        selected_customer=selected_customer
    )
'''

marker = "\nif __name__ == \"__main__\":"

position = text.rfind(marker)

if position == -1:
    print("ERROR: Could not find the final app.run block.")
    print("app.py was not changed.")
    raise SystemExit(1)

new_text = text[:position] + route + text[position:]

APP_FILE.write_text(new_text, encoding="utf-8")

print("=" * 70)
print("ADMIN BANK EMAIL ROUTE ADDED")
print("=" * 70)
print()
print("Backup created:")
print(backup)
print()
print("Management email route:")
print("/admin/bank-email")
print()
print("Uses the existing BankMessage table.")
print("Existing customer messages are not deleted or recreated.")
print()