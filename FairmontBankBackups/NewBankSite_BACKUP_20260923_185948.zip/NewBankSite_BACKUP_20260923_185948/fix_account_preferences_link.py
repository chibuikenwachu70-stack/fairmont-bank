from pathlib import Path
import shutil

BASE = Path(r"C:\Users\DON J\Documents\NewBankSite")
FILE = BASE / "templates" / "settings.html"

backup = FILE.with_suffix(".html.account_preferences_link_backup")
shutil.copy2(FILE, backup)

text = FILE.read_text(encoding="utf-8")

old = '''<a href="#" class="settings-card">
    <div class="settings-card-icon">
        <svg'''

# Find the Account Preferences section specifically
marker = "Account Preferences"

pos = text.find(marker)

if pos == -1:
    print("ERROR: Account Preferences text was not found.")
    raise SystemExit(1)

start = text.rfind("<a", 0, pos)

if start == -1:
    print("ERROR: Account Preferences link was not found.")
    raise SystemExit(1)

href_start = text.find('href="', start)

if href_start == -1 or href_start > pos:
    print("ERROR: Account Preferences href was not found.")
    raise SystemExit(1)

href_value_start = href_start + len('href="')
href_end = text.find('"', href_value_start)

if href_end == -1:
    print("ERROR: Account Preferences href could not be read.")
    raise SystemExit(1)

old_href = text[href_value_start:href_end]

text = (
    text[:href_value_start]
    + "{{ url_for('account_preferences') }}"
    + text[href_end:]
)

FILE.write_text(text, encoding="utf-8")

print("SUCCESS: Account Preferences link fixed.")
print(f"Previous link: {old_href}")
print("New link: {{ url_for('account_preferences') }}")
print(f"Backup created: {backup.name}")