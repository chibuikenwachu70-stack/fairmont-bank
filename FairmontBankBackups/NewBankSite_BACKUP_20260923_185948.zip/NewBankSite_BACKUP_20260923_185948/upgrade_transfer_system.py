from pathlib import Path
import re

BASE_DIR = Path(r"C:\Users\DON J\Documents\NewBankSite")
APP_FILE = BASE_DIR / "app.py"


text = APP_FILE.read_text(encoding="utf-8")


# =========================================================
# 1. ADD ACCOUNT NUMBER TO CUSTOMER MODEL
# =========================================================

account_number_column = '''    account_number = db.Column(
        db.String(12),
        unique=True,
        nullable=True,
        index=True
    )

'''

if "account_number = db.Column(" not in text:

    marker = '''    customer_id = db.Column(
        db.String(20),
        unique=True,
        nullable=False
    )

'''

    if marker not in text:
        raise SystemExit(
            "ERROR: Customer model location could not be found."
        )

    text = text.replace(
        marker,
        marker + "\n" + account_number_column,
        1
    )

    print("SUCCESS: account_number field added to Customer model.")

else:
    print("Account number field already exists.")


# =========================================================
# 2. ADD ACCOUNT NUMBER GENERATOR
# =========================================================

account_generator = '''

def generate_account_number():

    while True:

        number = "".join(
            secrets.choice(string.digits)
            for _ in range(10)
        )

        existing = Customer.query.filter_by(
            account_number=number
        ).first()

        if existing is None:
            return number

'''

if "def generate_account_number():" not in text:

    marker = "def generate_transaction_reference():"

    if marker not in text:
        raise SystemExit(
            "ERROR: Transaction reference generator not found."
        )

    text = text.replace(
        marker,
        account_generator + "\n" + marker,
        1
    )

    print("SUCCESS: Account number generator added.")

else:
    print("Account number generator already exists.")


# =========================================================
# 3. MAKE NEW ACCOUNTS RECEIVE ACCOUNT NUMBERS
# =========================================================

old_customer_creation = '''        customer = Customer(
            customer_id=generate_customer_id(),
            full_name=full_name,
'''

new_customer_creation = '''        customer = Customer(
            customer_id=generate_customer_id(),
            account_number=generate_account_number(),
            full_name=full_name,
'''

if old_customer_creation in text:

    text = text.replace(
        old_customer_creation,
        new_customer_creation,
        1
    )

    print("SUCCESS: New accounts will receive account numbers.")

elif "account_number=generate_account_number()" in text:

    print("New account creation already uses account numbers.")

else:

    print(
        "WARNING: Could not automatically connect account number "
        "generation to the existing account-opening code."
    )


# =========================================================
# 4. ADD UK BANK DIRECTORY
# =========================================================

uk_bank_model = '''

class Bank(db.Model):

    id = db.Column(
        db.Integer,
        primary_key=True
    )

    name = db.Column(
        db.String(150),
        unique=True,
        nullable=False
    )

    country = db.Column(
        db.String(100),
        nullable=False,
        default="United Kingdom"
    )

    active = db.Column(
        db.Boolean,
        nullable=False,
        default=True
    )

'''

if "class Bank(db.Model):" not in text:

    marker = "# CUSTOMER ID GENERATOR"

    if marker not in text:
        raise SystemExit(
            "ERROR: Customer ID generator marker not found."
        )

    text = text.replace(
        marker,
        uk_bank_model + "\n" + marker,
        1
    )

    print("SUCCESS: Bank model added.")

else:
    print("Bank model already exists.")


# =========================================================
# 5. ADD RECIPIENT MODEL
# =========================================================

recipient_model = '''

class Recipient(db.Model):

    id = db.Column(
        db.Integer,
        primary_key=True
    )

    customer_id = db.Column(
        db.String(20),
        nullable=False,
        index=True
    )

    recipient_name = db.Column(
        db.String(150),
        nullable=False
    )

    bank_name = db.Column(
        db.String(150),
        nullable=False
    )

    account_number = db.Column(
        db.String(40),
        nullable=False
    )

    sort_code = db.Column(
        db.String(20),
        nullable=True
    )

    country = db.Column(
        db.String(100),
        nullable=False,
        default="United Kingdom"
    )

    currency = db.Column(
        db.String(10),
        nullable=False,
        default="GBP"
    )

    created_at = db.Column(
        db.DateTime,
        nullable=False,
        default=datetime.utcnow
    )

'''

if "class Recipient(db.Model):" not in text:

    marker = "# CUSTOMER ID GENERATOR"

    text = text.replace(
        marker,
        recipient_model + "\n" + marker,
        1
    )

    print("SUCCESS: Recipient model added.")

else:
    print("Recipient model already exists.")


# =========================================================
# 6. ADD EXTERNAL TRANSFER MODEL
# =========================================================

external_transfer_model = '''

class ExternalTransfer(db.Model):

    id = db.Column(
        db.Integer,
        primary_key=True
    )

    transaction_reference = db.Column(
        db.String(40),
        unique=True,
        nullable=False
    )

    customer_id = db.Column(
        db.String(20),
        nullable=False,
        index=True
    )

    transfer_type = db.Column(
        db.String(30),
        nullable=False
    )

    bank_name = db.Column(
        db.String(150),
        nullable=False
    )

    recipient_name = db.Column(
        db.String(150),
        nullable=False
    )

    account_number = db.Column(
        db.String(40),
        nullable=False
    )

    sort_code = db.Column(
        db.String(20),
        nullable=True
    )

    country = db.Column(
        db.String(100),
        nullable=False
    )

    currency = db.Column(
        db.String(10),
        nullable=False
    )

    amount = db.Column(
        db.Float,
        nullable=False
    )

    fee = db.Column(
        db.Float,
        nullable=False,
        default=0.0
    )

    reference = db.Column(
        db.String(255),
        nullable=True
    )

    status = db.Column(
        db.String(30),
        nullable=False,
        default="Pending"
    )

    created_at = db.Column(
        db.DateTime,
        nullable=False,
        default=datetime.utcnow
    )

'''

if "class ExternalTransfer(db.Model):" not in text:

    marker = "# CUSTOMER ID GENERATOR"

    text = text.replace(
        marker,
        external_transfer_model + "\n" + marker,
        1
    )

    print("SUCCESS: External Transfer model added.")

else:
    print("External Transfer model already exists.")


# =========================================================
# 7. REMOVE OLD SEND MONEY ROUTE
# =========================================================

route_start = text.find('@app.route("/send-money"')

if route_start != -1:

    next_route = text.find(
        '@app.route("/transactions")',
        route_start
    )

    if next_route == -1:
        raise SystemExit(
            "ERROR: Could not find the transaction route after Send Money."
        )

    text = (
        text[:route_start]
        + text[next_route:]
    )

    print("SUCCESS: Old Customer-ID Send Money route removed.")

else:

    print("Old Send Money route was not found.")


# =========================================================
# 8. ADD NEW SEND MONEY ROUTE
# =========================================================

send_money_route = '''

@app.route("/send-money", methods=["GET", "POST"])
def send_money():

    customer_id = session.get("customer_id")

    if not customer_id:

        return render_template(
            "login.html",
            error="Please sign in to send money."
        )

    customer = Customer.query.filter_by(
        customer_id=customer_id
    ).first()

    if customer is None:

        session.clear()

        return render_template(
            "login.html",
            error="Your session could not be verified."
        )

    banks = (
        Bank.query
        .filter_by(
            country="United Kingdom",
            active=True
        )
        .order_by(Bank.name.asc())
        .all()
    )

    if request.method == "GET":

        return render_template(
            "send_money.html",
            customer=customer,
            banks=banks
        )

    transfer_type = request.form.get(
        "transfer_type",
        "uk"
    ).strip().lower()

    if transfer_type == "international":

        return redirect("/international-transfer")

    bank_name = request.form.get(
        "bank_name",
        ""
    ).strip()

    recipient_name = request.form.get(
        "recipient_name",
        ""
    ).strip()

    account_number = request.form.get(
        "account_number",
        ""
    ).strip()

    sort_code = request.form.get(
        "sort_code",
        ""
    ).strip()

    amount_text = request.form.get(
        "amount",
        ""
    ).strip()

    payment_reference = request.form.get(
        "payment_reference",
        ""
    ).strip()

    if not bank_name:

        return render_template(
            "send_money.html",
            customer=customer,
            banks=banks,
            error="Please select a bank.",
            form=request.form
        )

    if not recipient_name:

        return render_template(
            "send_money.html",
            customer=customer,
            banks=banks,
            error="Please enter the recipient's account name.",
            form=request.form
        )

    if not account_number:

        return render_template(
            "send_money.html",
            customer=customer,
            banks=banks,
            error="Please enter the recipient account number.",
            form=request.form
        )

    account_number = re.sub(
        r"\\s+",
        "",
        account_number
    )

    if not account_number.isdigit():

        return render_template(
            "send_money.html",
            customer=customer,
            banks=banks,
            error="Account number must contain digits only.",
            form=request.form
        )

    if len(account_number) != 8:

        return render_template(
            "send_money.html",
            customer=customer,
            banks=banks,
            error="UK account numbers must contain 8 digits.",
            form=request.form
        )

    if not sort_code:

        return render_template(
            "send_money.html",
            customer=customer,
            banks=banks,
            error="Please enter the recipient sort code.",
            form=request.form
        )

    sort_code = re.sub(
        r"[^0-9]",
        "",
        sort_code
    )

    if len(sort_code) != 6:

        return render_template(
            "send_money.html",
            customer=customer,
            banks=banks,
            error="UK sort codes must contain 6 digits.",
            form=request.form
        )

    if not amount_text:

        return render_template(
            "send_money.html",
            customer=customer,
            banks=banks,
            error="Please enter an amount.",
            form=request.form
        )

    try:

        amount = round(
            float(amount_text),
            2
        )

    except ValueError:

        return render_template(
            "send_money.html",
            customer=customer,
            banks=banks,
            error="Please enter a valid amount.",
            form=request.form
        )

    if amount <= 0:

        return render_template(
            "send_money.html",
            customer=customer,
            banks=banks,
            error="The amount must be greater than £0.00.",
            form=request.form
        )

    balance = round(
        float(customer.account_balance or 0),
        2
    )

    if amount > balance:

        return render_template(
            "send_money.html",
            customer=customer,
            banks=banks,
            error=(
                "Insufficient available balance. "
                f"Your available balance is £{balance:,.2f}."
            ),
            form=request.form
        )

    # -----------------------------------------------------
    # Check whether this is an internal Fairmont account.
    # -----------------------------------------------------

    internal_recipient = Customer.query.filter_by(
        account_number=account_number
    ).first()

    if internal_recipient is not None:

        if internal_recipient.customer_id == customer.customer_id:

            return render_template(
                "send_money.html",
                customer=customer,
                banks=banks,
                error="You cannot send money to your own account.",
                form=request.form
            )

        if internal_recipient.account_status.lower() != "active":

            return render_template(
                "send_money.html",
                customer=customer,
                banks=banks,
                error="The recipient account is not active.",
                form=request.form
            )

        new_sender_balance = round(
            balance - amount,
            2
        )

        recipient_balance = round(
            float(internal_recipient.account_balance or 0),
            2
        )

        new_recipient_balance = round(
            recipient_balance + amount,
            2
        )

        reference = generate_transaction_reference()

        sender_transaction = Transaction(
            transaction_reference=reference,
            customer_id=customer.customer_id,
            transaction_type="UK Bank Transfer",
            direction="Debit",
            amount=amount,
            balance_after=new_sender_balance,
            description=payment_reference or "Bank transfer",
            counterparty=recipient_name,
            status="Completed"
        )

        recipient_transaction = Transaction(
            transaction_reference=generate_transaction_reference(),
            customer_id=internal_recipient.customer_id,
            transaction_type="UK Bank Transfer",
            direction="Credit",
            amount=amount,
            balance_after=new_recipient_balance,
            description=payment_reference or "Bank transfer",
            counterparty=customer.full_name,
            status="Completed"
        )

        customer.account_balance = new_sender_balance
        internal_recipient.account_balance = new_recipient_balance

        db.session.add(sender_transaction)
        db.session.add(recipient_transaction)

        try:

            db.session.commit()

        except Exception:

            db.session.rollback()

            return render_template(
                "send_money.html",
                customer=customer,
                banks=banks,
                error="The transfer could not be completed.",
                form=request.form
            )

        return render_template(
            "transfer_confirmation.html",
            customer=customer,
            recipient_name=recipient_name,
            bank_name=bank_name,
            account_number=account_number,
            sort_code=sort_code,
            transaction=sender_transaction,
            transfer_status="Completed"
        )

    # -----------------------------------------------------
    # External UK bank transfer.
    # -----------------------------------------------------

    reference = generate_transaction_reference()

    transfer = ExternalTransfer(
        transaction_reference=reference,
        customer_id=customer.customer_id,
        transfer_type="UK Bank",
        bank_name=bank_name,
        recipient_name=recipient_name,
        account_number=account_number,
        sort_code=sort_code,
        country="United Kingdom",
        currency="GBP",
        amount=amount,
        fee=0.0,
        reference=payment_reference,
        status="Pending"
    )

    db.session.add(transfer)

    try:

        db.session.commit()

    except Exception:

        db.session.rollback()

        return render_template(
            "send_money.html",
            customer=customer,
            banks=banks,
            error="The transfer request could not be created.",
            form=request.form
        )

    return render_template(
        "transfer_confirmation.html",
        customer=customer,
        recipient_name=recipient_name,
        bank_name=bank_name,
        account_number=account_number,
        sort_code=sort_code,
        transaction=transfer,
        transfer_status="Pending"
    )

'''


marker = '@app.route("/transactions")'

if marker not in text:
    raise SystemExit(
        "ERROR: Transaction history route could not be found."
    )

text = text.replace(
    marker,
    send_money_route + "\n" + marker,
    1
)

print("SUCCESS: New account-number Send Money route added.")


# =========================================================
# 9. ADD INTERNATIONAL TRANSFER ROUTES
# =========================================================

international_routes = '''

@app.route("/international-transfer", methods=["GET", "POST"])
def international_transfer():

    customer_id = session.get("customer_id")

    if not customer_id:

        return render_template(
            "login.html",
            error="Please sign in to make an international transfer."
        )

    customer = Customer.query.filter_by(
        customer_id=customer_id
    ).first()

    if customer is None:

        session.clear()

        return render_template(
            "login.html",
            error="Your session could not be verified."
        )

    if request.method == "GET":

        return render_template(
            "international_transfer.html",
            customer=customer
        )

    country = request.form.get(
        "country",
        ""
    ).strip()

    recipient_name = request.form.get(
        "recipient_name",
        ""
    ).strip()

    bank_name = request.form.get(
        "bank_name",
        ""
    ).strip()

    account_number = request.form.get(
        "account_number",
        ""
    ).strip()

    iban = request.form.get(
        "iban",
        ""
    ).strip().upper()

    bic = request.form.get(
        "bic",
        ""
    ).strip().upper()

    currency = request.form.get(
        "currency",
        ""
    ).strip().upper()

    amount_text = request.form.get(
        "amount",
        ""
    ).strip()

    payment_reference = request.form.get(
        "payment_reference",
        ""
    ).strip()

    if not country:

        return render_template(
            "international_transfer.html",
            customer=customer,
            error="Please select the destination country.",
            form=request.form
        )

    if not recipient_name:

        return render_template(
            "international_transfer.html",
            customer=customer,
            error="Please enter the beneficiary name.",
            form=request.form
        )

    if not bank_name:

        return render_template(
            "international_transfer.html",
            customer=customer,
            error="Please enter the beneficiary bank.",
            form=request.form
        )

    if not account_number and not iban:

        return render_template(
            "international_transfer.html",
            customer=customer,
            error="Please enter an account number or IBAN.",
            form=request.form
        )

    if not bic:

        return render_template(
            "international_transfer.html",
            customer=customer,
            error="Please enter the SWIFT/BIC code.",
            form=request.form
        )

    if not currency:

        return render_template(
            "international_transfer.html",
            customer=customer,
            error="Please select a currency.",
            form=request.form
        )

    try:

        amount = round(
            float(amount_text),
            2
        )

    except ValueError:

        return render_template(
            "international_transfer.html",
            customer=customer,
            error="Please enter a valid amount.",
            form=request.form
        )

    if amount <= 0:

        return render_template(
            "international_transfer.html",
            customer=customer,
            error="The amount must be greater than zero.",
            form=request.form
        )

    balance = round(
        float(customer.account_balance or 0),
        2
    )

    if amount > balance:

        return render_template(
            "international_transfer.html",
            customer=customer,
            error=(
                "Insufficient available balance. "
                f"Your available balance is £{balance:,.2f}."
            ),
            form=request.form
        )

    reference = generate_transaction_reference()

    transfer = ExternalTransfer(
        transaction_reference=reference,
        customer_id=customer.customer_id,
        transfer_type="International",
        bank_name=bank_name,
        recipient_name=recipient_name,
        account_number=account_number or iban,
        sort_code=None,
        country=country,
        currency=currency,
        amount=amount,
        fee=0.0,
        reference=payment_reference,
        status="Pending"
    )

    db.session.add(transfer)

    try:

        db.session.commit()

    except Exception:

        db.session.rollback()

        return render_template(
            "international_transfer.html",
            customer=customer,
            error="The international transfer request could not be created.",
            form=request.form
        )

    return render_template(
        "international_confirmation.html",
        customer=customer,
        transfer=transfer,
        iban=iban,
        bic=bic
    )

'''


marker = '@app.route("/transactions")'

text = text.replace(
    marker,
    international_routes + "\n" + marker,
    1
)

print("SUCCESS: International Transfer route added.")


# =========================================================
# 10. SAVE
# =========================================================

APP_FILE.write_text(
    text,
    encoding="utf-8"
)

print("")
print("==============================================")
print("TRANSFER SYSTEM UPGRADE WRITTEN")
print("==============================================")
print("Account numbers")
print("UK bank transfers")
print("Recent recipient foundation")
print("International transfer foundation")
print("Internal Fairmont transfers")
print("External transfer records")
print("")