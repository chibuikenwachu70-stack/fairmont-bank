import sqlite3
import os


DATABASE = os.path.join(
    "instance",
    "fairmont.db"
)


connection = sqlite3.connect(DATABASE)

cursor = connection.cursor()


cursor.execute(
    "PRAGMA table_info(customer)"
)

columns = [
    row[1]
    for row in cursor.fetchall()
]


if "account_balance" not in columns:

    cursor.execute(
        """
        ALTER TABLE customer
        ADD COLUMN account_balance FLOAT NOT NULL DEFAULT 0.0
        """
    )

    print("account_balance column added successfully.")

else:

    print("account_balance column already exists.")


connection.commit()

connection.close()

print("Database migration completed.")