from pathlib import Path

BASE_DIR = Path(r"C:\Users\DON J\Documents\NewBankSite")
CSS_FILE = BASE_DIR / "static" / "css" / "style.css"

css = r'''

/* =========================================================
   FAIRMONT BANK - TRANSACTIONS
   ========================================================= */

.transaction-page {
    min-height: 100vh;
    min-height: 100svh;

    background:
        radial-gradient(
            circle at 90% 0%,
            rgba(72, 143, 173, 0.16),
            transparent 35%
        ),
        linear-gradient(
            145deg,
            #071d30 0%,
            #092a3f 50%,
            #061523 100%
        );

    color: #ffffff;
}

.transaction-shell {
    width: 100%;
    max-width: 620px;

    margin: 0 auto;

    padding: 24px 20px 50px;
}

.transaction-header {
    display: flex;
    align-items: center;

    gap: 15px;

    margin-bottom: 25px;
}

.transaction-back-button {
    width: 42px;
    height: 42px;

    flex: 0 0 42px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 13px;

    background: rgba(255, 255, 255, 0.07);

    border: 1px solid rgba(255, 255, 255, 0.10);

    color: #ffffff;

    font-size: 20px;

    text-decoration: none;
}

.transaction-eyebrow {
    margin-bottom: 4px;

    font-size: 9px;

    font-weight: 700;

    letter-spacing: 1.8px;

    color: rgba(255, 255, 255, 0.42);
}

.transaction-header h1 {
    font-family:
        Georgia,
        "Times New Roman",
        serif;

    font-size: 25px;

    font-weight: 500;

    letter-spacing: -0.4px;
}

.transaction-account-card {
    display: flex;
    align-items: center;
    justify-content: space-between;

    gap: 15px;

    padding: 21px;

    border-radius: 21px;

    background:
        linear-gradient(
            135deg,
            rgba(255, 255, 255, 0.13),
            rgba(255, 255, 255, 0.055)
        );

    border: 1px solid rgba(255, 255, 255, 0.12);

    box-shadow:
        0 18px 45px rgba(0, 0, 0, 0.18);
}

.transaction-account-card p {
    margin-bottom: 7px;

    font-size: 9px;

    font-weight: 700;

    letter-spacing: 1.5px;

    color: rgba(255, 255, 255, 0.42);
}

.transaction-account-card h2 {
    font-size: 27px;

    font-weight: 500;

    letter-spacing: -0.6px;
}

.transaction-customer-reference {
    font-size: 10px;

    color: rgba(255, 255, 255, 0.42);

    text-align: right;
}

.transaction-list-section {
    margin-top: 28px;
}

.transaction-section-heading {
    display: flex;
    align-items: center;
    justify-content: space-between;

    margin-bottom: 12px;
}

.transaction-section-heading h2 {
    font-size: 16px;

    font-weight: 600;
}

.transaction-section-heading span {
    min-width: 25px;

    padding: 4px 7px;

    border-radius: 8px;

    background: rgba(255, 255, 255, 0.07);

    color: rgba(255, 255, 255, 0.55);

    font-size: 9px;

    text-align: center;
}

.transaction-list {
    display: flex;
    flex-direction: column;

    gap: 8px;
}

.transaction-item {
    display: flex;
    align-items: center;

    gap: 12px;

    min-height: 76px;

    padding: 12px 13px;

    border-radius: 17px;

    background:
        rgba(255, 255, 255, 0.055);

    border: 1px solid rgba(255, 255, 255, 0.08);

    color: #ffffff;

    text-decoration: none;

    transition:
        background 0.2s ease,
        transform 0.2s ease;
}

.transaction-item:hover {
    background: rgba(255, 255, 255, 0.085);
}

.transaction-item:active {
    transform: scale(0.985);
}

.transaction-icon {
    width: 40px;
    height: 40px;

    flex: 0 0 40px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 12px;

    font-size: 17px;
    font-weight: 600;
}

.transaction-credit {
    background: rgba(183, 228, 199, 0.10);

    color: #b7e4c7;
}

.transaction-debit {
    background: rgba(255, 255, 255, 0.07);

    color: rgba(255, 255, 255, 0.78);
}

.transaction-main {
    min-width: 0;

    flex: 1;

    display: flex;
    flex-direction: column;

    gap: 3px;
}

.transaction-main strong {
    overflow: hidden;

    text-overflow: ellipsis;

    white-space: nowrap;

    font-size: 11px;

    font-weight: 600;
}

.transaction-main span {
    font-size: 9px;

    color: rgba(255, 255, 255, 0.40);
}

.transaction-main small {
    overflow: hidden;

    text-overflow: ellipsis;

    white-space: nowrap;

    font-size: 9px;

    color: rgba(255, 255, 255, 0.32);
}

.transaction-amount {
    flex: 0 0 auto;

    font-size: 11px;

    font-weight: 600;

    text-align: right;
}

.amount-credit {
    color: #b7e4c7;
}

.amount-debit {
    color: rgba(255, 255, 255, 0.82);
}

.transaction-empty {
    padding: 35px 20px;

    border-radius: 19px;

    background: rgba(255, 255, 255, 0.045);

    border: 1px dashed rgba(255, 255, 255, 0.13);

    text-align: center;
}

.transaction-empty-icon {
    margin-bottom: 10px;

    font-size: 20px;

    color: rgba(255, 255, 255, 0.35);
}

.transaction-empty h3 {
    font-size: 13px;

    font-weight: 600;
}

.transaction-empty p {
    max-width: 280px;

    margin: 8px auto 0;

    font-size: 10px;

    line-height: 1.5;

    color: rgba(255, 255, 255, 0.42);
}

.transaction-dashboard-button {
    display: flex;

    align-items: center;
    justify-content: center;

    width: 100%;

    min-height: 50px;

    margin-top: 30px;

    border-radius: 14px;

    background:
        linear-gradient(
            135deg,
            rgba(255, 255, 255, 0.15),
            rgba(255, 255, 255, 0.07)
        );

    border: 1px solid rgba(255, 255, 255, 0.12);

    color: #ffffff;

    font-size: 12px;

    font-weight: 600;

    text-decoration: none;
}


/* =========================================================
   TRANSACTION DETAILS
   ========================================================= */

.transaction-detail-card {
    padding: 24px 18px;

    border-radius: 21px;

    background:
        linear-gradient(
            135deg,
            rgba(255, 255, 255, 0.11),
            rgba(255, 255, 255, 0.05)
        );

    border: 1px solid rgba(255, 255, 255, 0.10);
}

.transaction-detail-status {
    padding-bottom: 24px;

    text-align: center;

    border-bottom: 1px solid rgba(255, 255, 255, 0.08);
}

.transaction-large-icon {
    width: 52px;
    height: 52px;

    margin: 0 auto 12px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 16px;

    font-size: 21px;
}

.transaction-detail-label {
    margin-bottom: 7px;

    font-size: 9px;

    text-transform: uppercase;

    letter-spacing: 1.2px;

    color: rgba(255, 255, 255, 0.42);
}

.transaction-detail-status h2 {
    font-size: 31px;

    font-weight: 500;

    letter-spacing: -0.7px;
}

.transaction-detail-status > span {
    display: block;

    margin-top: 6px;

    font-size: 11px;

    color: rgba(255, 255, 255, 0.55);
}

.transaction-detail-list {
    margin-top: 5px;
}

.transaction-detail-row {
    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 20px;

    min-height: 58px;

    border-bottom: 1px solid rgba(255, 255, 255, 0.07);
}

.transaction-detail-row:last-child {
    border-bottom: 0;
}

.transaction-detail-row span {
    font-size: 10px;

    color: rgba(255, 255, 255, 0.42);
}

.transaction-detail-row strong {
    max-width: 60%;

    font-size: 10px;

    line-height: 1.4;

    text-align: right;

    overflow-wrap: anywhere;

    color: rgba(255, 255, 255, 0.88);
}

.transaction-status-value {
    color: #b7e4c7 !important;
}


@media (max-width: 430px) {

    .transaction-shell {
        padding-left: 16px;
        padding-right: 16px;
    }

    .transaction-account-card {
        padding: 17px;
    }

    .transaction-account-card h2 {
        font-size: 24px;
    }

}
'''

existing = CSS_FILE.read_text(encoding="utf-8")

if ".transaction-page {" not in existing:

    CSS_FILE.write_text(
        existing + css,
        encoding="utf-8"
    )

    print("SUCCESS: Transaction CSS added.")

else:

    print("Transaction CSS already exists.")