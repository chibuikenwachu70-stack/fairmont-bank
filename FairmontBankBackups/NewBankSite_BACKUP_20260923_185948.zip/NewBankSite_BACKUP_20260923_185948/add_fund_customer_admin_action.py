from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DASHBOARD = BASE_DIR / "templates" / "admin_dashboard.html"

if not DASHBOARD.exists():
    print("ERROR: admin_dashboard.html was not found.")
    raise SystemExit(1)

html = DASHBOARD.read_text(encoding="utf-8")

if 'url_for("admin_fund_customer")' in html:
    print()
    print("=" * 70)
    print("FUND CUSTOMER ACCOUNT ACTION ALREADY EXISTS")
    print("=" * 70)
    raise SystemExit(0)

new_action = '''<a href="{{ url_for("admin_fund_customer") }}" class="action">
    <div class="action-title">
        Fund Customer Account
    </div>
    <div class="action-text">
        Add funds to any existing Fairmont customer account.
    </div>
</a>
'''

# Add after Create Customer Account when possible.
create_position = html.find(
    'url_for("admin_create_customer")'
)

if create_position != -1:
    closing_tag = html.find("</a>", create_position)

    if closing_tag == -1:
        print("ERROR: Could not locate Create Customer Account closing tag.")
        raise SystemExit(1)

    insert_position = closing_tag + len("</a>")

    html = (
        html[:insert_position]
        + "\n\n"
        + new_action
        + html[insert_position:]
    )

else:
    # Fallback: add after Post Incoming Payment.
    payment_position = html.find(
        'url_for("admin_incoming_payment")'
    )

    if payment_position == -1:
        print(
            "ERROR: Could not find Create Customer Account "
            "or Post Incoming Payment."
        )
        raise SystemExit(1)

    closing_tag = html.find("</a>", payment_position)

    if closing_tag == -1:
        print("ERROR: Could not locate Post Incoming Payment closing tag.")
        raise SystemExit(1)

    insert_position = closing_tag + len("</a>")

    html = (
        html[:insert_position]
        + "\n\n"
        + new_action
        + html[insert_position:]
    )

DASHBOARD.write_text(html, encoding="utf-8")

print()
print("=" * 70)
print("FUND CUSTOMER ACCOUNT ACTION ADDED")
print("=" * 70)
print()
print("Administration Portal now includes:")
print("  - Customer Management")
print("  - Transaction Management")
print("  - Account Management")
print("  - Post Incoming Payment")
print("  - Create Customer Account")
print("  - Fund Customer Account")
print()
print("Existing dashboard actions were preserved.")
print()