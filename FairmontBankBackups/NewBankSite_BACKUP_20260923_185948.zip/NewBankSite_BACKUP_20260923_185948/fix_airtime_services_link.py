from pathlib import Path
import re

file = Path("templates/services.html")

if not file.exists():
    raise SystemExit("ERROR: templates/services.html was not found.")

text = file.read_text(encoding="utf-8")

# Find the Airtime service card and change only its link.
pattern = re.compile(
    r'(<a\b[^>]*href=")([^"]*)("[^>]*>.*?Airtime.*?</a>)',
    re.IGNORECASE | re.DOTALL
)

match = pattern.search(text)

if not match:
    raise SystemExit(
        "ERROR: Could not find the Airtime service card in templates/services.html."
    )

old_href = match.group(2)

if old_href == "/airtime":
    print("NOTICE: Airtime link is already correct.")
else:
    updated = (
        text[:match.start()]
        + match.group(1)
        + "/airtime"
        + match.group(3)
        + text[match.end():]
    )

    file.write_text(updated, encoding="utf-8")

    print("SUCCESS: Airtime service link changed.")
    print(f"OLD LINK: {old_href}")
    print("NEW LINK: /airtime")