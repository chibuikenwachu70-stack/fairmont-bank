from pathlib import Path
from datetime import datetime
import shutil

BASE = Path(__file__).resolve().parent

CSS = BASE / "static" / "css" / "welcome.css"
HTML = BASE / "templates" / "index.html"

if not CSS.exists():
    raise SystemExit("ERROR: static\\css\\welcome.css was not found.")

if not HTML.exists():
    raise SystemExit("ERROR: templates\\index.html was not found.")

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

css_backup = CSS.with_name(
    f"welcome_BEFORE_PROFESSIONAL_LAYOUT_{timestamp}.css"
)

html_backup = HTML.with_name(
    f"index_BEFORE_PROFESSIONAL_LAYOUT_{timestamp}.html"
)

shutil.copy2(CSS, css_backup)
shutil.copy2(HTML, html_backup)

# ---------------------------------------------------------
# PROFESSIONAL WELCOME PAGE CSS
# ---------------------------------------------------------

css = r"""
/* =========================================================
   FAIRMONT BANK
   PROFESSIONAL WELCOME PAGE
   ========================================================= */

html,
body {
    margin: 0;
    padding: 0;
    width: 100%;
    min-height: 100%;
}

body {
    background: #071a35;
    font-family:
        Inter,
        -apple-system,
        BlinkMacSystemFont,
        "Segoe UI",
        Arial,
        sans-serif;
}

.welcome-page {
    width: 100%;
    min-height: 100vh;
    min-height: 100dvh;

    position: relative;

    display: flex;
    align-items: center;
    justify-content: center;

    overflow: hidden;

    background:
        radial-gradient(
            circle at 50% 8%,
            rgba(67, 145, 235, 0.22),
            transparent 30%
        ),
        radial-gradient(
            circle at 8% 92%,
            rgba(27, 87, 170, 0.16),
            transparent 32%
        ),
        linear-gradient(
            145deg,
            #06152d 0%,
            #08264d 52%,
            #041226 100%
        );

    color: #ffffff;
}

.welcome-page *,
.welcome-page *::before,
.welcome-page *::after {
    box-sizing: border-box;
}

/* ---------------------------------------------------------
   BACKGROUND DETAILS
   --------------------------------------------------------- */

.welcome-page::before {
    content: "";

    position: absolute;

    width: 560px;
    height: 560px;

    top: -340px;
    right: -180px;

    border-radius: 50%;

    border: 1px solid rgba(130, 190, 255, 0.08);

    box-shadow:
        0 0 100px rgba(38, 117, 210, 0.10);

    pointer-events: none;
}

.welcome-page::after {
    content: "";

    position: absolute;

    width: 520px;
    height: 520px;

    bottom: -360px;
    left: -210px;

    border-radius: 50%;

    border: 1px solid rgba(130, 190, 255, 0.06);

    pointer-events: none;
}

/* Existing overlay remains harmless and subtle */

.welcome-overlay {
    position: absolute;

    inset: 0;

    z-index: 0;

    background:
        linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.015),
            transparent 35%,
            rgba(0, 0, 0, 0.12)
        );

    pointer-events: none;
}

/* ---------------------------------------------------------
   MAIN CONTENT
   --------------------------------------------------------- */

.welcome-content {
    width: min(100%, 620px);

    min-height: 100vh;
    min-height: 100dvh;

    padding:
        54px
        28px
        34px;

    position: relative;
    z-index: 2;

    display: flex;

    flex-direction: column;

    align-items: center;

    justify-content: center;

    text-align: center;
}

/* ---------------------------------------------------------
   BRAND
   --------------------------------------------------------- */

.brand {
    display: flex;

    flex-direction: column;

    align-items: center;

    justify-content: center;

    margin-bottom: 42px;
}

.brand-mark {
    width: 74px;
    height: 74px;

    display: flex;

    align-items: center;
    justify-content: center;

    margin-bottom: 18px;

    border-radius: 21px;

    background:
        linear-gradient(
            145deg,
            #ffffff,
            #e1efff
        );

    color: #0b315f;

    font-size: 34px;

    font-weight: 850;

    letter-spacing: -0.04em;

    box-shadow:
        0 18px 45px rgba(0, 0, 0, 0.28),
        0 0 0 1px rgba(255, 255, 255, 0.16);
}

.brand-name {
    display: flex;

    align-items: center;

    justify-content: center;

    gap: 7px;

    color: #ffffff;

    font-size: 27px;

    line-height: 1;

    font-weight: 800;

    letter-spacing: 0.075em;
}

.brand-name strong {
    font-weight: 850;
}

.brand-name span {
    font-weight: 650;

    opacity: 0.94;
}

/* ---------------------------------------------------------
   WELCOME MESSAGE
   --------------------------------------------------------- */

.welcome-message {
    width: 100%;

    display: flex;

    flex-direction: column;

    align-items: center;

    margin: 0;
}

.eyebrow {
    margin: 0 0 13px;

    color: #79c9ff;

    font-size: 12px;

    line-height: 1.2;

    font-weight: 750;

    letter-spacing: 0.20em;

    text-transform: uppercase;
}

.welcome-message h1 {
    margin: 0;

    color: #ffffff;

    font-size: clamp(44px, 6vw, 62px);

    line-height: 0.98;

    font-weight: 800;

    letter-spacing: -0.055em;
}

.welcome-text {
    max-width: 500px;

    margin: 20px 0 0;

    color: #b4c9e1;

    font-size: 16px;

    line-height: 1.55;

    font-weight: 400;
}

/* ---------------------------------------------------------
   ACTIONS
   --------------------------------------------------------- */

.welcome-actions {
    width: 100%;

    max-width: 500px;

    display: grid;

    grid-template-columns: 1fr 1fr;

    gap: 14px;

    margin-top: 34px;
}

.welcome-actions a {
    min-height: 56px;

    padding:
        0
        20px;

    display: flex;

    align-items: center;
    justify-content: center;

    border-radius: 15px;

    font-size: 15px;

    line-height: 1;

    font-weight: 750;

    text-decoration: none;

    transition:
        transform 0.18s ease,
        box-shadow 0.18s ease,
        border-color 0.18s ease,
        background 0.18s ease;
}

/* Primary */

.welcome-actions .primary-button {
    background:
        linear-gradient(
            135deg,
            #2397e7 0%,
            #40c0ed 100%
        );

    color: #ffffff;

    border: 1px solid rgba(255, 255, 255, 0.08);

    box-shadow:
        0 14px 32px rgba(25, 139, 217, 0.25);
}

/* Secondary */

.welcome-actions .secondary-button {
    background: rgba(255, 255, 255, 0.055);

    color: #e4f2ff;

    border: 1px solid rgba(139, 192, 239, 0.30);

    box-shadow:
        0 10px 25px rgba(0, 0, 0, 0.12);

    backdrop-filter: blur(12px);

    -webkit-backdrop-filter: blur(12px);
}

.welcome-actions a:hover {
    transform: translateY(-2px);
}

.welcome-actions .primary-button:hover {
    box-shadow:
        0 18px 38px rgba(25, 139, 217, 0.34);

    filter: brightness(1.04);
}

.welcome-actions .secondary-button:hover {
    background: rgba(255, 255, 255, 0.085);

    border-color: rgba(139, 202, 250, 0.46);
}

/* ---------------------------------------------------------
   FOOTER
   --------------------------------------------------------- */

.welcome-footer {
    width: 100%;

    margin-top: 32px;

    display: flex;

    align-items: center;
    justify-content: center;

    gap: 9px;

    color: #7894b5;

    font-size: 12px;

    line-height: 1.4;

    font-weight: 500;
}

.footer-dot {
    color: #58bff0;

    font-size: 14px;
}

/* ---------------------------------------------------------
   TABLET / SMALL DESKTOP
   --------------------------------------------------------- */

@media (max-width: 700px) {

    .welcome-content {
        padding:
            44px
            24px
            30px;
    }

    .brand {
        margin-bottom: 36px;
    }

    .brand-mark {
        width: 68px;
        height: 68px;

        font-size: 31px;
    }

    .brand-name {
        font-size: 24px;
    }

    .welcome-message h1 {
        font-size: 48px;
    }
}

/* ---------------------------------------------------------
   MOBILE
   --------------------------------------------------------- */

@media (max-width: 560px) {

    .welcome-content {
        width: 100%;

        min-height: 100dvh;

        padding:
            34px
            18px
            26px;
    }

    .brand {
        margin-bottom: 34px;
    }

    .brand-mark {
        width: 64px;
        height: 64px;

        margin-bottom: 15px;

        border-radius: 19px;

        font-size: 29px;
    }

    .brand-name {
        font-size: 22px;

        letter-spacing: 0.065em;
    }

    .eyebrow {
        font-size: 11px;

        letter-spacing: 0.17em;
    }

    .welcome-message h1 {
        font-size: 43px;

        letter-spacing: -0.05em;
    }

    .welcome-text {
        max-width: 340px;

        margin-top: 17px;

        font-size: 15px;
    }

    .welcome-actions {
        max-width: 390px;

        margin-top: 29px;

        grid-template-columns: 1fr;

        gap: 11px;
    }

    .welcome-actions a {
        min-height: 54px;
    }

    .welcome-footer {
        margin-top: 25px;
    }
}

/* ---------------------------------------------------------
   VERY SMALL PHONES
   --------------------------------------------------------- */

@media (max-width: 390px) {

    .welcome-content {
        padding:
            26px
            14px
            22px;
    }

    .brand {
        margin-bottom: 28px;
    }

    .brand-mark {
        width: 58px;
        height: 58px;

        margin-bottom: 13px;

        border-radius: 17px;

        font-size: 27px;
    }

    .brand-name {
        font-size: 20px;
    }

    .welcome-message h1 {
        font-size: 38px;
    }

    .welcome-text {
        font-size: 14px;
    }

    .welcome-actions {
        margin-top: 25px;
    }

    .welcome-footer {
        margin-top: 21px;

        font-size: 11px;
    }
}

/* ---------------------------------------------------------
   REDUCED MOTION
   --------------------------------------------------------- */

@media (prefers-reduced-motion: reduce) {

    .welcome-page *,
    .welcome-page *::before,
    .welcome-page *::after {
        transition: none !important;
        animation: none !important;
    }
}
"""

CSS.write_text(css, encoding="utf-8")

# ---------------------------------------------------------
# FIX THE BROKEN BULLET CHARACTER
# ---------------------------------------------------------

html = HTML.read_text(encoding="utf-8")

html = html.replace("ΓÇó", "•")

HTML.write_text(html, encoding="utf-8")

print()
print("=" * 64)
print("FAIRMONT WELCOME PAGE - PROFESSIONAL LAYOUT")
print("=" * 64)
print()
print("CSS updated:")
print("  static\\css\\welcome.css")
print()
print("HTML checked:")
print("  templates\\index.html")
print()
print("Backups created:")
print(f"  {css_backup.name}")
print(f"  {html_backup.name}")
print()
print("The layout now uses the actual HTML classes:")
print("  .brand")
print("  .brand-mark")
print("  .brand-name")
print("  .welcome-message")
print("  .welcome-actions")
print("  .welcome-footer")
print()
print("Untouched:")
print("  app.py")
print("  fairmont.db")
print("  dashboard")
print("  login backend")
print("  UK Send Money")
print("  International Transfer")
print()
print("SUCCESS")
print("=" * 64)