from pathlib import Path
import re

BASE = Path(__file__).resolve().parent
APP = BASE / "app.py"
TEMPLATES = BASE / "templates"

# ------------------------------------------------------------
# 1. Remove the /services route from app.py
# ------------------------------------------------------------

app_text = APP.read_text(encoding="utf-8")

route_pattern = re.compile(
    r'@app\.route\("/services"\)\s*'
    r'@login_required\s*'
    r'def services\(\):\s*'
    r'.*?'
    r'(?=\n@app\.route|\nif __name__ == "__main__":)',
    re.DOTALL
)

match = route_pattern.search(app_text)

if match:
    app_text = app_text[:match.start()] + app_text[match.end():]
    APP.write_text(app_text, encoding="utf-8")
    print("SUCCESS: /services route removed from app.py")
else:
    print("NOTICE: /services route was not found in app.py")

# ------------------------------------------------------------
# 2. Change any remaining services-page links to Dashboard
# ------------------------------------------------------------

for template in TEMPLATES.glob("*.html"):
    text = template.read_text(encoding="utf-8")
    original = text

    text = text.replace(
        "{{ url_for('services') }}",
        "{{ url_for('dashboard') }}"
    )

    text = text.replace(
        'href="/services"',
        'href="{{ url_for(\'dashboard\') }}"'
    )

    text = text.replace(
        'href="/services#',
        'href="{{ url_for(\'dashboard\') }}#'
    )

    if text != original:
        template.write_text(text, encoding="utf-8")
        print(f"SUCCESS: Updated services link in {template.name}")

# ------------------------------------------------------------
# 3. Keep a backup of services.html, then remove the hub page
# ------------------------------------------------------------

services_template = TEMPLATES / "services.html"

if services_template.exists():
    backup = TEMPLATES / "services.html.removed_backup"
    backup.write_text(
        services_template.read_text(encoding="utf-8"),
        encoding="utf-8"
    )
    services_template.unlink()
    print("SUCCESS: Services Hub template removed.")
    print(f"BACKUP: {backup}")
else:
    print("NOTICE: services.html was already removed.")

print()
print("==========================================")
print(" SERVICES HUB REMOVAL COMPLETE")
print("==========================================")
print("The separate Services Hub has been removed.")
print("Dashboard service cards remain untouched.")