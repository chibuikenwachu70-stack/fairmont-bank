from pathlib import Path

path = Path("templates/dashboard.html")
text = path.read_text(encoding="utf-8")

old = '''<!-- Pay Bills -->

                    <a
                        href="#"
                        class="service-item">'''

new = '''<!-- Pay Bills -->

                    <a
                        href="/pay-bills"
                        class="service-item">'''

if old not in text:
    print("ERROR: The Pay Bills block was not found.")
    raise SystemExit(1)

text = text.replace(old, new, 1)

path.write_text(text, encoding="utf-8")

print("SUCCESS: Pay Bills dashboard link now points to /pay-bills.")