from pathlib import Path
import re

APP = Path("app.py")

text = APP.read_text(encoding="utf-8-sig")

old = '''    bank = Bank.query.filter_by(
        name=bank_name,
        country="United Kingdom",
        active=True
    ).first()
'''

new = '''    bank = Bank.query.filter(
        Bank.name == bank_name,
        Bank.country.in_([\"UK\", \"United Kingdom\"]),
        Bank.active.is_(True)
    ).first()
'''

if old not in text:
    raise RuntimeError(
        "ERROR: The expected UK bank validation block was not found. "
        "No changes were made."
    )

text = text.replace(old, new, 1)

APP.write_text(text, encoding="utf-8")

print("SUCCESS: UK bank validation fixed.")