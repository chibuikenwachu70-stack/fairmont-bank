from pathlib import Path
import shutil

BASE_DIR = Path(__file__).resolve().parent
LOGIN_FILE = BASE_DIR / "templates" / "login.html"

if not LOGIN_FILE.exists():
    print("ERROR: templates\\login.html was not found.")
    raise SystemExit(1)

text = LOGIN_FILE.read_text(encoding="utf-8")

if 'class="login-live-chat"' in text:
    print("Live Chat login option is already present.")
    raise SystemExit(0)

security_text = "Your connection is protected by secure encryption."

if security_text not in text:
    print("ERROR: The login security message was not found.")
    print("No changes were made.")
    raise SystemExit(1)

backup_file = BASE_DIR / "templates" / "login.html.before_live_chat"
shutil.copy2(LOGIN_FILE, backup_file)

live_chat_block = '''            <div class="login-live-chat">
                <span class="login-live-chat-label">
                    Need help?
                </span>

                <a
                    href="/live-chat"
                    class="login-live-chat-link">
                    Live Chat with Fairmont Bank Support
                </a>
            </div>


'''

# Find the opening div that contains the security message.
security_position = text.find(security_text)

if security_position == -1:
    print("ERROR: Could not locate the security message.")
    print("No changes were made.")
    raise SystemExit(1)

security_div_start = text.rfind("<div", 0, security_position)

if security_div_start == -1:
    print("ERROR: Could not locate the security message container.")
    print("No changes were made.")
    raise SystemExit(1)

# Insert Live Chat immediately before the security message container.
text = (
    text[:security_div_start]
    + live_chat_block
    + text[security_div_start:]
)

# Add the Live Chat styling to the existing first style block.
style_end = text.find("</style>")

if style_end == -1:
    print("ERROR: Could not find the existing login style block.")
    print("No changes were made.")
    raise SystemExit(1)

live_chat_css = '''
.login-live-chat {
    width: 100%;
    margin: 16px 0 14px 0;
    padding: 14px 16px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    border: 1px solid rgba(184, 149, 74, 0.28);
    border-radius: 12px;
    background: rgba(184, 149, 74, 0.07);
}

.login-live-chat-label {
    color: #9fb3cc;
    font-size: 13px;
}

.login-live-chat-link {
    color: #d8b96a;
    text-decoration: none;
    font-size: 13px;
    font-weight: 700;
}

.login-live-chat-link:hover {
    text-decoration: underline;
}

@media (max-width: 600px) {
    .login-live-chat {
        flex-direction: column;
        align-items: flex-start;
    }
}
'''

text = (
    text[:style_end]
    + live_chat_css
    + "\n"
    + text[style_end:]
)

LOGIN_FILE.write_text(text, encoding="utf-8")

print("=" * 70)
print("LIVE CHAT ADDED TO FAIRmont BANK LOGIN PAGE")
print("=" * 70)
print()
print("Added:")
print("  Need help? Live Chat with Fairmont Bank Support")
print()
print("Link:")
print("  /live-chat")
print()
print("The existing login form was preserved.")
print()
print("Backup created:")
print(backup_file)
print("=" * 70)