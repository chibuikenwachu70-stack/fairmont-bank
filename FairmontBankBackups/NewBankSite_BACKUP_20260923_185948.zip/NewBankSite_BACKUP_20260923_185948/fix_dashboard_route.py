from pathlib import Path


BASE_DIR = Path(r"C:\Users\DON J\Documents\NewBankSite")

APP_FILE = BASE_DIR / "app.py"


app_text = APP_FILE.read_text(encoding="utf-8")


dashboard_route = '''

# =========================================================
# CUSTOMER DASHBOARD
# =========================================================

@app.route("/dashboard")
def dashboard():

    customer_id = session.get("customer_id")

    if not customer_id:

        return render_template(
            "login.html",
            error="Please sign in to access your dashboard."
        )

    customer = Customer.query.filter_by(
        customer_id=customer_id
    ).first()

    if customer is None:

        session.clear()

        return render_template(
            "login.html",
            error="Your session could not be verified. Please sign in again."
        )

    return render_template(
        "dashboard.html",
        customer=customer
    )

'''


if '@app.route("/dashboard")' in app_text:

    print("Dashboard route already exists.")

else:

    marker = '@app.route("/my-profile")'

    if marker not in app_text:

        print("ERROR: Could not find the My Profile route.")
        raise SystemExit(1)

    app_text = app_text.replace(
        marker,
        dashboard_route + marker,
        1
    )

    APP_FILE.write_text(
        app_text,
        encoding="utf-8"
    )

    print("SUCCESS: /dashboard route added.")


# =========================================================
# CHANGE LOGIN REDIRECT
# =========================================================

app_text = APP_FILE.read_text(encoding="utf-8")


old_login_return = '''        return render_template(
            "dashboard.html",
            customer=customer
        )
'''


new_login_return = '''        return redirect("/dashboard")
'''


if old_login_return in app_text:

    app_text = app_text.replace(
        old_login_return,
        new_login_return,
        1
    )

    if "from flask import Flask, render_template, request, session, redirect" not in app_text:

        app_text = app_text.replace(
            "from flask import Flask, render_template, request, session",
            "from flask import Flask, render_template, request, session, redirect",
            1
        )

    APP_FILE.write_text(
        app_text,
        encoding="utf-8"
    )

    print("SUCCESS: Login now redirects to /dashboard.")

else:

    print("Login dashboard rendering was already changed or could not be found.")


print()
print("==============================================")
print("DASHBOARD ROUTE FIX COMPLETED")
print("==============================================")