from pathlib import Path

APP_FILE = Path("app.py")

text = APP_FILE.read_text(encoding="utf-8")

marker = '\nif __name__ == "__main__":'

if marker not in text:
    raise SystemExit(
        'ERROR: The if __name__ == "__main__": block was not found.'
    )

route = r'''

# ============================================================
# ADMIN — POST INCOMING PAYMENT
# ============================================================

@app.route("/admin/incoming-payment", methods=["GET", "POST"])
def admin_incoming_payment():

    admin_id = session.get("admin_id")

    if not admin_id:
        return redirect(url_for("admin_login"))

    admin = db.session.get(AdminUser, admin_id)

    if admin is None or not admin.is_active:
        session.pop("admin_id", None)
        return redirect(url_for("admin_login"))

    customers = (
        Customer.query
        .order_by(Customer.full_name.asc())
        .all()
    )

    customer_data = [
        {
            "id": customer.id,
            "customer_id": customer.customer_id,
            "account_number": customer.account_number or "",
            "full_name": customer.full_name or "",
            "balance": float(customer.account_balance or 0)
        }
        for customer in customers
    ]

    form_data = (
        request.form.to_dict()
        if request.method == "POST"
        else {}
    )

    if request.method == "POST":

        receiver_customer_id = (
            request.form.get(
                "receiver_customer_id",
                ""
            ).strip()
        )

        sender_name = (
            request.form.get(
                "sender_name",
                ""
            ).strip()
        )

        sender_account_number = (
            request.form.get(
                "sender_account_number",
                ""
            ).strip()
        )

        sender_bank = (
            request.form.get(
                "sender_bank",
                ""
            ).strip()
        )

        sender_country = (
            request.form.get(
                "sender_country",
                ""
            ).strip()
        )

        payment_reference = (
            request.form.get(
                "payment_reference",
                ""
            ).strip()
        )

        description = (
            request.form.get(
                "description",
                ""
            ).strip()
        )

        amount_text = (
            request.form.get(
                "amount",
                ""
            ).strip()
        )

        if not receiver_customer_id:
            flash(
                "Please select the receiving Fairmont customer.",
                "error"
            )

            return render_template(
                "admin_incoming_payment.html",
                admin=admin,
                customers=customers,
                customer_data=customer_data,
                form_data=form_data
            )

        try:
            receiver_id = int(receiver_customer_id)
        except (TypeError, ValueError):

            flash(
                "Invalid receiving customer selection.",
                "error"
            )

            return render_template(
                "admin_incoming_payment.html",
                admin=admin,
                customers=customers,
                customer_data=customer_data,
                form_data=form_data
            )

        receiver = db.session.get(
            Customer,
            receiver_id
        )

        if receiver is None:

            flash(
                "The selected receiving customer could not be found.",
                "error"
            )

            return render_template(
                "admin_incoming_payment.html",
                admin=admin,
                customers=customers,
                customer_data=customer_data,
                form_data=form_data
            )

        if receiver.account_status != "Active":

            flash(
                "The receiving customer account is not active.",
                "error"
            )

            return render_template(
                "admin_incoming_payment.html",
                admin=admin,
                customers=customers,
                customer_data=customer_data,
                form_data=form_data
            )

        required_fields = [
            (
                sender_name,
                "Please enter the sender name."
            ),
            (
                sender_account_number,
                "Please enter the sender account number."
            ),
            (
                sender_bank,
                "Please enter the sender bank."
            ),
            (
                sender_country,
                "Please enter the sender country."
            ),
            (
                payment_reference,
                "Please enter the payment reference."
            ),
            (
                description,
                "Please enter a payment description."
            ),
        ]

        for value, error_message in required_fields:

            if not value:

                flash(
                    error_message,
                    "error"
                )

                return render_template(
                    "admin_incoming_payment.html",
                    admin=admin,
                    customers=customers,
                    customer_data=customer_data,
                    form_data=form_data
                )

        try:
            amount = float(amount_text)
        except (TypeError, ValueError):
            amount = 0

        if amount <= 0:

            flash(
                "Payment amount must be greater than zero.",
                "error"
            )

            return render_template(
                "admin_incoming_payment.html",
                admin=admin,
                customers=customers,
                customer_data=customer_data,
                form_data=form_data
            )

        current_balance = float(
            receiver.account_balance or 0
        )

        new_balance = current_balance + amount

        transaction_reference = (
            generate_transaction_reference()
        )

        receiver.account_balance = new_balance

        transaction = Transaction(
            transaction_reference=transaction_reference,
            customer_id=receiver.id,
            transaction_type="Payment Received",
            direction="Credit",
            amount=amount,
            balance_after=new_balance,
            description=description,
            counterparty=sender_name,
            status="Completed",
            sender_name=sender_name,
            sender_account_number=sender_account_number,
            sender_bank=sender_bank,
            sender_country=sender_country
        )

        db.session.add(transaction)

        db.session.commit()

        return render_template(
            "admin_incoming_payment_success.html",
            admin=admin,
            receiver=receiver,
            sender_name=sender_name,
            sender_account_number=sender_account_number,
            sender_bank=sender_bank,
            sender_country=sender_country,
            amount=amount,
            payment_reference=payment_reference,
            description=description,
            transaction_reference=transaction_reference,
            new_balance=new_balance
        )

    return render_template(
        "admin_incoming_payment.html",
        admin=admin,
        customers=customers,
        customer_data=customer_data,
        form_data=form_data
    )

'''

text = text.replace(
    marker,
    route + marker,
    1
)

APP_FILE.write_text(
    text,
    encoding="utf-8"
)

print()
print("=" * 70)
print("ADMIN INCOMING PAYMENT ROUTE ADDED")
print("=" * 70)
print()
print("Route:")
print("  /admin/incoming-payment")
print()
print("The route includes:")
print("  - Admin authentication")
print("  - Existing Fairmont customer selection")
print("  - Active-account validation")
print("  - External sender information")
print("  - Payment amount validation")
print("  - Customer balance increase")
print("  - Credit transaction creation")
print("  - Sender information storage")
print("  - Unique transaction reference")
print()
print("Existing database records were not deleted or recreated.")
print()