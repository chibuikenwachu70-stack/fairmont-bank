from pathlib import Path

file = Path("templates/dashboard.html")
text = file.read_text(encoding="utf-8")

marker = "<!-- Airtime -->"

start = text.find(marker)

if start == -1:
    raise SystemExit("ERROR: Airtime section was not found. Nothing was changed.")

end = text.find("</a>", start)

if end == -1:
    raise SystemExit("ERROR: Airtime link closing tag was not found. Nothing was changed.")

section = text[start:end]

if 'href="#"' not in section:
    if 'href="/airtime"' in section:
        print("Airtime card is already linked to /airtime.")
        raise SystemExit(0)

    raise SystemExit(
        "ERROR: Airtime card was found, but its href could not be located. Nothing was changed."
    )

section = section.replace('href="#"', 'href="/airtime"', 1)

text = text[:start] + section + text[end:]

file.write_text(text, encoding="utf-8")

print("SUCCESS: Airtime dashboard card now links to /airtime.")