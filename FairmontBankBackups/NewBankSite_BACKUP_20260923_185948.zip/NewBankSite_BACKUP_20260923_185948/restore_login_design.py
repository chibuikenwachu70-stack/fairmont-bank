from pathlib import Path
from datetime import datetime
import shutil

BASE_DIR = Path(__file__).resolve().parent
CSS_FILE = BASE_DIR / "static" / "css" / "style.css"

if not CSS_FILE.exists():
    print("ERROR: static/css/style.css was not found.")
    raise SystemExit(1)

# ------------------------------------------------------------
# BACKUP CURRENT CSS
# ------------------------------------------------------------

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = CSS_FILE.with_name(
    f"style_BEFORE_LOGIN_DESIGN_{timestamp}.css"
)

shutil.copy2(CSS_FILE, backup)

print()
print("============================================================")
print("RESTORING FAIRMONT LOGIN INTERFACE")
print("============================================================")
print()
print("CSS backup created:")
print(f"  {backup.name}")
print()

# ------------------------------------------------------------
# LOGIN-ONLY CSS
# ------------------------------------------------------------

login_css = r'''

/* ============================================================
   FAIRMONT BANK - LOGIN INTERFACE
   Dedicated login-page styling.
   Does not modify dashboard or transfer page styling.
   ============================================================ */

body:has(.login-page) {
    margin: 0;
    min-height: 100vh;
    background:
        radial-gradient(
            circle at 15% 15%,
            rgba(43, 91, 168, 0.28),
            transparent 34%
        ),
        radial-gradient(
            circle at 85% 85%,
            rgba(20, 56, 110, 0.30),
            transparent 38%
        ),
        linear-gradient(
            135deg,
            #061225 0%,
            #0a1b35 48%,
            #071426 100%
        );
    color: #eef4ff;
    font-family:
        Inter,
        -apple-system,
        BlinkMacSystemFont,
        "Segoe UI",
        Arial,
        sans-serif;
}

/* Main login area */

body:has(.login-page) .login-page {
    min-height: 100vh;
    width: 100%;
    box-sizing: border-box;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 40px 22px;
    position: relative;
    overflow: hidden;
}

/* Decorative background glow */

body:has(.login-page) .login-page::before {
    content: "";
    position: absolute;
    width: 430px;
    height: 430px;
    border-radius: 50%;
    background: rgba(67, 122, 214, 0.12);
    filter: blur(20px);
    top: -180px;
    right: -140px;
    pointer-events: none;
}

body:has(.login-page) .login-page::after {
    content: "";
    position: absolute;
    width: 360px;
    height: 360px;
    border-radius: 50%;
    background: rgba(30, 88, 170, 0.10);
    filter: blur(25px);
    bottom: -180px;
    left: -140px;
    pointer-events: none;
}

/* Main shell */

body:has(.login-page) .login-shell {
    width: min(100%, 1040px);
    min-height: 650px;
    display: grid;
    grid-template-columns: minmax(0, 1.05fr) minmax(380px, 0.95fr);
    position: relative;
    z-index: 2;
    overflow: hidden;
    border: 1px solid rgba(255, 255, 255, 0.13);
    border-radius: 28px;
    background: rgba(8, 24, 47, 0.76);
    box-shadow:
        0 30px 80px rgba(0, 0, 0, 0.45),
        inset 0 1px 0 rgba(255, 255, 255, 0.06);
    backdrop-filter: blur(22px);
    -webkit-backdrop-filter: blur(22px);
}

/* Left branding area */

body:has(.login-page) .login-shell::before {
    content: "FAIRMONT BANK";
    display: flex;
    align-items: center;
    justify-content: center;
    min-width: 0;
    padding: 50px;
    color: #ffffff;
    font-size: clamp(30px, 4vw, 48px);
    font-weight: 700;
    letter-spacing: 0.08em;
    text-align: center;
    background:
        linear-gradient(
            145deg,
            rgba(18, 58, 116, 0.95),
            rgba(6, 24, 50, 0.96)
        );
    border-right: 1px solid rgba(255, 255, 255, 0.09);
    text-shadow: 0 4px 25px rgba(0, 0, 0, 0.30);
}

/* Login content */

body:has(.login-page) .login-shell > * {
    position: relative;
    z-index: 2;
}

body:has(.login-page) .login-shell > div,
body:has(.login-page) .login-shell > section,
body:has(.login-page) .login-shell > form {
    box-sizing: border-box;
}

/* The actual login content is allowed to sit naturally
   in the second column. */

body:has(.login-page) .login-shell {
    align-items: stretch;
}

/* Typography */

body:has(.login-page) .login-shell h1,
body:has(.login-page) .login-shell h2,
body:has(.login-page) .login-shell h3 {
    color: #ffffff;
    margin-top: 0;
}

body:has(.login-page) .login-shell h1 {
    font-size: clamp(34px, 4vw, 48px);
    line-height: 1.05;
    letter-spacing: -0.03em;
    margin-bottom: 14px;
}

body:has(.login-page) .login-shell p {
    color: #aebdd2;
    line-height: 1.6;
}

/* Login labels */

body:has(.login-page) .login-shell label {
    display: block;
    margin: 0 0 8px;
    color: #d9e4f5;
    font-size: 13px;
    font-weight: 600;
    letter-spacing: 0.02em;
}

/* Inputs */

body:has(.login-page) .login-shell input[type="text"],
body:has(.login-page) .login-shell input[type="email"],
body:has(.login-page) .login-shell input[type="password"],
body:has(.login-page) .login-shell input[type="number"] {
    width: 100%;
    min-height: 52px;
    box-sizing: border-box;
    padding: 13px 15px;
    border: 1px solid rgba(159, 181, 213, 0.22);
    border-radius: 12px;
    outline: none;
    background: rgba(255, 255, 255, 0.055);
    color: #ffffff;
    font-size: 15px;
    transition:
        border-color 0.2s ease,
        background 0.2s ease,
        box-shadow 0.2s ease;
}

body:has(.login-page) .login-shell input::placeholder {
    color: #7f91aa;
}

body:has(.login-page) .login-shell input:focus {
    border-color: rgba(91, 148, 235, 0.85);
    background: rgba(255, 255, 255, 0.075);
    box-shadow:
        0 0 0 4px rgba(65, 126, 219, 0.13);
}

/* Form spacing */

body:has(.login-page) .login-shell form {
    width: 100%;
}

body:has(.login-page) .login-shell form > div {
    margin-bottom: 18px;
}

/* Buttons */

body:has(.login-page) .login-shell button,
body:has(.login-page) .login-shell input[type="submit"],
body:has(.login-page) .login-shell button[type="submit"] {
    min-height: 52px;
    border: 0;
    border-radius: 12px;
    padding: 12px 20px;
    background:
        linear-gradient(
            135deg,
            #3e7bd1,
            #2455a2
        );
    color: #ffffff;
    font-size: 15px;
    font-weight: 700;
    cursor: pointer;
    box-shadow:
        0 10px 25px rgba(18, 65, 135, 0.30);
    transition:
        transform 0.18s ease,
        box-shadow 0.18s ease,
        filter 0.18s ease;
}

body:has(.login-page) .login-shell button:hover,
body:has(.login-page) .login-shell input[type="submit"]:hover {
    transform: translateY(-1px);
    filter: brightness(1.08);
    box-shadow:
        0 14px 30px rgba(18, 65, 135, 0.40);
}

body:has(.login-page) .login-shell button:active,
body:has(.login-page) .login-shell input[type="submit"]:active {
    transform: translateY(0);
}

/* Links */

body:has(.login-page) .login-shell a {
    color: #72a8f2;
    text-decoration: none;
    font-weight: 600;
}

body:has(.login-page) .login-shell a:hover {
    color: #a7caff;
    text-decoration: underline;
}

/* Checkbox / remember me */

body:has(.login-page) .login-shell input[type="checkbox"] {
    width: 16px;
    height: 16px;
    accent-color: #3e7bd1;
    vertical-align: middle;
}

/* Small security message */

body:has(.login-page) .login-shell small {
    color: #8496ad;
}

/* Error / alert messages */

body:has(.login-page) .login-shell .error,
body:has(.login-page) .login-shell .alert,
body:has(.login-page) .login-shell [role="alert"] {
    border: 1px solid rgba(248, 113, 113, 0.30);
    border-radius: 11px;
    background: rgba(127, 29, 29, 0.20);
    color: #fecaca;
    padding: 12px 14px;
    margin-bottom: 18px;
}

/* Password show button */

body:has(.login-page) .login-shell button[type="button"] {
    min-height: 42px;
    padding: 8px 14px;
    font-size: 13px;
}

/* Mobile */

@media (max-width: 820px) {

    body:has(.login-page) .login-page {
        padding: 20px 14px;
        align-items: flex-start;
    }

    body:has(.login-page) .login-shell {
        width: 100%;
        min-height: auto;
        margin: 10px 0;
        display: block;
        border-radius: 22px;
    }

    body:has(.login-page) .login-shell::before {
        min-height: 150px;
        padding: 28px 20px;
        border-right: 0;
        border-bottom: 1px solid rgba(255, 255, 255, 0.09);
        font-size: 30px;
    }
}

/* Small phones */

@media (max-width: 480px) {

    body:has(.login-page) .login-page {
        padding: 12px;
    }

    body:has(.login-page) .login-shell {
        border-radius: 18px;
    }

    body:has(.login-page) .login-shell::before {
        min-height: 120px;
        font-size: 25px;
        letter-spacing: 0.06em;
    }

    body:has(.login-page) .login-shell h1 {
        font-size: 34px;
    }
}

'''

# ------------------------------------------------------------
# APPEND LOGIN CSS
# ------------------------------------------------------------

with CSS_FILE.open("a", encoding="utf-8") as f:
    f.write("\n\n")
    f.write(login_css)

print("Login-specific CSS added successfully.")
print()
print("============================================================")
print("SUCCESS")
print("============================================================")
print()
print("The login interface styling has been restored.")
print()
print("Nothing else was changed:")
print("  - app.py: NOT changed")
print("  - fairmont.db: NOT changed")
print("  - dashboard: NOT changed")
print("  - UK Send Money: NOT changed")
print("  - International Transfer: NOT changed")
print("  - login authentication: NOT changed")
print()
print(f"Backup: {backup.name}")
print()