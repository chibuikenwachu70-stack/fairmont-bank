from pathlib import Path
import re

file = Path("templates/dashboard.html")

if not file.exists():
    raise SystemExit("ERROR: dashboard.html was not found.")

text = file.read_text(encoding="utf-8")

# Locate the actual Airtime service card by its visible label.
pattern = re.compile(
    r'(<a\b[^>]*?)'
    r'href\s*=\s*["\']#["\']'
    r'([^>]*>.*?)'
    r'<span\s+class="service-name">\s*Airtime\s*</span>'
    r'(.*?</a>)',
    re.IGNORECASE | re.DOTALL
)

match = pattern.search(text)

if not match:
    raise SystemExit(
        "ERROR: Could not find the Airtime dashboard card with href=\"#\". "
        "No changes were made."
    )

new_card = (
    match.group(1)
    + 'href="{{ url_for(\'airtime\') }}"'
    + match.group(2)
    + '<span class="service-name">\n'
    + '                              Airtime\n'
    + '                          </span>'
    + match.group(3)
)

text = text[:match.start()] + new_card + text[match.end():]

file.write_text(text, encoding="utf-8")

print("SUCCESS: The dashboard Airtime card is now connected to /airtime.")