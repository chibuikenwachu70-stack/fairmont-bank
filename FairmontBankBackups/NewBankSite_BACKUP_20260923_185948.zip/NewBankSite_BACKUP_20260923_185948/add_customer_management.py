from pathlib import Path
import shutil

FILE = Path("app.py")

text = FILE.read_text(encoding="utf-8")

if 'def admin_customers' in text:
    print("=" * 70)
    print("CUSTOMER MANAGEMENT ROUTE ALREADY EXISTS")
    print("=" * 70)
    raise SystemExit(0)

backup = Path("app.py.before_customer_management")
shutil.copy2(FILE, backup)

route = r'''
@app.route("/admin/customers")
def admin_customers():
    admin_id = session.get("admin_id")

    if not admin_id:
        return redirect(url_for("admin_login"))

    admin = db.session.get(AdminUser, admin_id)

    if admin is None or not admin.is_active:
        session.pop("admin_id", None)
        session.pop("admin_username", None)
        return redirect(url_for("admin_login"))

    search = request.args.get("search", "").strip()

    query = Customer.query

    if search:
        pattern = f"%{search}%"

        query = query.filter(
            db.or_(
                Customer.customer_id.ilike(pattern),
                Customer.account_number.ilike(pattern),
                Customer.full_name.ilike(pattern),
                Customer.email.ilike(pattern),
                Customer.phone.ilike(pattern)
            )
        )

    customers = (
        query
        .order_by(Customer.id.desc())
        .all()
    )

    return render_template(
        "admin_customers.html",
        admin=admin,
        customers=customers,
        search=search
    )


@app.route("/admin/customer/<int:customer_id>")
def admin_customer_profile(customer_id):
    admin_id = session.get("admin_id")

    if not admin_id:
        return redirect(url_for("admin_login"))

    admin = db.session.get(AdminUser, admin_id)

    if admin is None or not admin.is_active:
        session.pop("admin_id", None)
        session.pop("admin_username", None)
        return redirect(url_for("admin_login"))

    customer = db.session.get(Customer, customer_id)

    if customer is None:
        return redirect(url_for("admin_customers"))

    customer_transactions = (
        Transaction.query
        .filter_by(customer_id=customer.id)
        .order_by(Transaction.created_at.desc())
        .all()
    )

    customer_bank_messages = (
        BankMessage.query
        .filter_by(customer_id=customer.id)
        .order_by(BankMessage.created_at.desc())
        .all()
    )

    customer_conversations = (
        LiveChatConversation.query
        .filter_by(customer_id=customer.id)
        .order_by(LiveChatConversation.updated_at.desc())
        .all()
    )

    return render_template(
        "admin_customer_profile.html",
        admin=admin,
        customer=customer,
        customer_transactions=customer_transactions,
        customer_bank_messages=customer_bank_messages,
        customer_conversations=customer_conversations
    )
'''

marker = "\nif __name__ == \"__main__\":"

position = text.rfind(marker)

if position == -1:
    print("=" * 70)
    print("ERROR: app.py startup block was not found.")
    print("=" * 70)
    print()
    print("Backup created:")
    print(backup)
    raise SystemExit(1)

text = text[:position] + "\n" + route + text[position:]

FILE.write_text(text, encoding="utf-8")

print("=" * 70)
print("CUSTOMER MANAGEMENT ROUTES ADDED")
print("=" * 70)
print()
print("Customer list:")
print("/admin/customers")
print()
print("Customer profile:")
print("/admin/customer/<customer_id>")
print()
print("Existing customer data was not changed.")
print()
print("Backup created:")
print(backup)