from app import app, db, Bank


UK_BANKS = [
    "Allied Irish Bank (GB)",
    "Bank of Ireland UK",
    "Bank of Scotland",
    "Barclays Bank",
    "Birmingham Bank",
    "Card One Money",
    "Cashplus Bank",
    "Chase UK",
    "Citibank UK",
    "ClearBank",
    "C. Hoare & Co.",
    "Co-operative Bank",
    "Coutts",
    "Danske Bank",
    "First Direct",
    "Halifax",
    "Handelsbanken UK",
    "HSBC UK",
    "Investec Bank",
    "Lloyds Bank",
    "Metro Bank",
    "Monzo Bank",
    "Nationwide Building Society",
    "NatWest",
    "Revolut",
    "Royal Bank of Scotland",
    "Santander UK",
    "Skipton Building Society",
    "Starling Bank",
    "TSB Bank",
    "Ulster Bank",
    "Virgin Money",
    "Yorkshire Building Society",
    "Zopa Bank",
    "Other UK Bank or Building Society"
]


with app.app_context():

    db.create_all()

    added = 0
    existing = 0

    for bank_name in UK_BANKS:

        bank = Bank.query.filter_by(
            name=bank_name
        ).first()

        if bank:

            existing += 1
            continue

        bank = Bank(
            name=bank_name,
            country="United Kingdom",
            active=True
        )

        db.session.add(bank)
        added += 1

    db.session.commit()

    print("")
    print("==============================================")
    print("UK BANK DIRECTORY")
    print("==============================================")
    print(f"Added:     {added}")
    print(f"Existing:  {existing}")
    print(f"Total:     {Bank.query.count()}")
    print("")