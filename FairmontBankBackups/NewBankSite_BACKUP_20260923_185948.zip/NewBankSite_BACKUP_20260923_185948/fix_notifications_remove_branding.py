from pathlib import Path

file = Path("templates/notifications.html")

if not file.exists():
    raise SystemExit("ERROR: templates/notifications.html was not found.")

text = file.read_text(encoding="utf-8")

changes = 0

# 1. Remove the Fairmont Bank eyebrow above "Notifications"
old_eyebrow = """                    <p class="eyebrow">
                        FAIRMONT BANK
                    </p>

                    <h1>
                        Notifications
                    </h1>"""

new_eyebrow = """                    <h1>
                        Notifications
                    </h1>"""

if old_eyebrow in text:
    text = text.replace(old_eyebrow, new_eyebrow, 1)
    changes += 1
else:
    print("WARNING: Notifications eyebrow was not found.")

# 2. Remove Fairmont Bank from the notification hero text
old_hero = """                        Your Fairmont Bank notifications will appear
                        here when there is important account activity,
                        payment information, security notices or
                        messages for you."""

new_hero = """                        Your notifications will appear
                        here when there is important account activity,
                        payment information, security notices or
                        messages for you."""

if old_hero in text:
    text = text.replace(old_hero, new_hero, 1)
    changes += 1
else:
    print("WARNING: Notification hero text was not found.")

# 3. Remove the visible Fairmont Bank brand from the top header
old_brand = """            <div class="brand-area">

                <div class="brand-mark">
                    F
                </div>

                <div>
                    <div class="brand-name">
                        FAIRMONT BANK
                    </div>

                    <div class="brand-subtitle">
                        Banking for a brighter tomorrow
                    </div>
                </div>

            </div>"""

if old_brand in text:
    text = text.replace(old_brand, "", 1)
    changes += 1
else:
    print("WARNING: Top Fairmont Bank brand block was not found.")

# Save only if something was changed
if changes == 0:
    raise SystemExit("ERROR: No matching branding was found. No changes were made.")

file.write_text(text, encoding="utf-8")

print()
print("SUCCESS: Notifications branding cleanup completed.")
print(f"Changes made: {changes}")
print()
print("Removed:")
print("- Fairmont Bank eyebrow above Notifications")
print("- Fairmont Bank wording from notification introduction")
print("- Top Fairmont Bank brand/logo area")
print()
print("The rest of the Notifications page was not changed.")