from app import app, db, Bank


with app.app_context():

    existing = Bank.query.filter_by(
        name="Fairmont Bank",
        country="UK"
    ).first()

    if existing:
        if not existing.active:
            existing.active = True
            db.session.commit()
            print("SUCCESS: Fairmont Bank already existed and has been activated.")
        else:
            print("Fairmont Bank is already in the UK bank list.")
    else:
        bank = Bank(
            name="Fairmont Bank",
            country="UK",
            active=True
        )

        db.session.add(bank)
        db.session.commit()

        print("SUCCESS: Fairmont Bank has been added to the UK bank list.")

    print("No other bank records were changed.")