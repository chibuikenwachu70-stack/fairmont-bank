from pathlib import Path

file = Path("templates/dashboard.html")

if not file.exists():
    raise SystemExit("ERROR: templates/dashboard.html was not found.")

text = file.read_text(encoding="utf-8")

if "fairmont-dashboard-top-spacing-fix" in text:
    raise SystemExit(
        "INFO: The dashboard top-spacing fix is already installed."
    )

css = """
<style id="fairmont-dashboard-top-spacing-fix">

/* Keep the Fairmont logo closer to the top */
.dashboard-greeting {
    margin-top: 0 !important;
    padding-top: 0 !important;
    margin-bottom: 8px !important;
}

/* Reduce the gap between the logo/greeting and balance */
.fairmont-dashboard-brand {
    margin-top: 0 !important;
    margin-bottom: 6px !important;
}

/* Keep the greeting compact */
.dashboard-greeting h1 {
    margin-top: 0 !important;
    margin-bottom: 8px !important;
}

/* Move Available Balance closer to Hello, John */
.balance-card {
    margin-top: 4px !important;
    margin-bottom: 8px !important;
}

/* Move Services closer to Available Balance */
.dashboard-section.services-section {
    margin-top: 4px !important;
}

/* Keep the layout compact on smaller screens */
@media (max-width: 600px) {

    .dashboard-greeting {
        margin-bottom: 6px !important;
    }

    .fairmont-dashboard-brand {
        margin-top: 0 !important;
        margin-bottom: 4px !important;
    }

    .dashboard-greeting h1 {
        margin-bottom: 6px !important;
    }

    .balance-card {
        margin-top: 3px !important;
        margin-bottom: 6px !important;
    }

    .dashboard-section.services-section {
        margin-top: 3px !important;
    }

}

</style>
"""

marker = "</head>"

if marker not in text.lower():
    raise SystemExit(
        "ERROR: </head> was not found. No changes were made."
    )

position = text.lower().find(marker)

text = (
    text[:position]
    + css
    + "\n"
    + text[position:]
)

file.write_text(text, encoding="utf-8")

print()
print("SUCCESS: Dashboard top spacing adjusted.")
print("Logo is closer to the top.")
print("Hello, John is closer to the logo.")
print("Available Balance is closer to the greeting.")
print("Services is closer to Available Balance.")
print("No images were created or changed.")
print()