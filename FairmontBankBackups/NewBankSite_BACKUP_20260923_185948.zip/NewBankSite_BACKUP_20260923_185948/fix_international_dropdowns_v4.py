from pathlib import Path
from datetime import datetime
import re

BASE = Path(__file__).resolve().parent
TEMPLATE = BASE / "templates" / "international_transfer.html"

if not TEMPLATE.exists():
    print("ERROR: international_transfer.html was not found.")
    raise SystemExit(1)

source = TEMPLATE.read_text(encoding="utf-8")

# ---------------------------------------------------------
# BACKUP
# ---------------------------------------------------------

stamp = datetime.now().strftime("%Y%m%d_%H%M%S")

backup = TEMPLATE.with_name(
    f"international_transfer_BEFORE_V4_{stamp}.html"
)

backup.write_text(source, encoding="utf-8")

print("Backup created:", backup.name)


# ---------------------------------------------------------
# FIND A FIELD USING ITS LABEL AND THE NEXT FIELD
# ---------------------------------------------------------

FIELD_OPEN = re.compile(
    r'<div\s+class\s*=\s*["\']field["\']\s*>',
    re.IGNORECASE
)


def find_field(text, label, next_label):

    label_pattern = re.compile(
        r'<label[^>]*>\s*'
        + re.escape(label)
        + r'\s*</label>',
        re.IGNORECASE
    )

    next_label_pattern = re.compile(
        r'<label[^>]*>\s*'
        + re.escape(next_label)
        + r'\s*</label>',
        re.IGNORECASE
    )

    label_match = label_pattern.search(text)

    if not label_match:
        return None

    next_label_match = next_label_pattern.search(
        text,
        label_match.end()
    )

    if not next_label_match:
        return None

    before_label = text[:label_match.start()]

    field_starts = list(
        FIELD_OPEN.finditer(before_label)
    )

    if not field_starts:
        return None

    start = field_starts[-1].start()

    after_label = text[next_label_match.start():]

    next_field_match = FIELD_OPEN.search(
        after_label
    )

    if not next_field_match:
        return None

    end = (
        next_label_match.start()
        + next_field_match.start()
    )

    return start, end


# ---------------------------------------------------------
# CLEAN FIELD HTML
# ---------------------------------------------------------

country_field = r'''
            <div class="field">

                <label>Destination Country</label>

                <div class="fairmont-one-picker">

                    <select
                        id="internationalCountry"
                        name="country"
                        class="fairmont-hidden-select"
                        required
                    >
                        <option value="">Select country</option>
                        <option value="Afghanistan">Afghanistan</option>
                        <option value="Albania">Albania</option>
                        <option value="Algeria">Algeria</option>
                        <option value="Andorra">Andorra</option>
                        <option value="Angola">Angola</option>
                        <option value="Argentina">Argentina</option>
                        <option value="Australia">Australia</option>
                        <option value="Austria">Austria</option>
                        <option value="Belgium">Belgium</option>
                        <option value="Brazil">Brazil</option>
                        <option value="Canada">Canada</option>
                        <option value="Chile">Chile</option>
                        <option value="China">China</option>
                        <option value="Colombia">Colombia</option>
                        <option value="Denmark">Denmark</option>
                        <option value="Egypt">Egypt</option>
                        <option value="Finland">Finland</option>
                        <option value="France">France</option>
                        <option value="Germany">Germany</option>
                        <option value="Ghana">Ghana</option>
                        <option value="Greece">Greece</option>
                        <option value="India">India</option>
                        <option value="Indonesia">Indonesia</option>
                        <option value="Ireland">Ireland</option>
                        <option value="Israel">Israel</option>
                        <option value="Italy">Italy</option>
                        <option value="Japan">Japan</option>
                        <option value="Kenya">Kenya</option>
                        <option value="Malaysia">Malaysia</option>
                        <option value="Mexico">Mexico</option>
                        <option value="Morocco">Morocco</option>
                        <option value="Netherlands">Netherlands</option>
                        <option value="New Zealand">New Zealand</option>
                        <option value="Nigeria">Nigeria</option>
                        <option value="Norway">Norway</option>
                        <option value="Pakistan">Pakistan</option>
                        <option value="Poland">Poland</option>
                        <option value="Portugal">Portugal</option>
                        <option value="Qatar">Qatar</option>
                        <option value="Romania">Romania</option>
                        <option value="Saudi Arabia">Saudi Arabia</option>
                        <option value="Singapore">Singapore</option>
                        <option value="South Africa">South Africa</option>
                        <option value="South Korea">South Korea</option>
                        <option value="Spain">Spain</option>
                        <option value="Sri Lanka">Sri Lanka</option>
                        <option value="Suriname">Suriname</option>
                        <option value="Sweden">Sweden</option>
                        <option value="Switzerland">Switzerland</option>
                        <option value="Tanzania">Tanzania</option>
                        <option value="Thailand">Thailand</option>
                        <option value="Turkey">Turkey</option>
                        <option value="Uganda">Uganda</option>
                        <option value="Ukraine">Ukraine</option>
                        <option value="United Arab Emirates">United Arab Emirates</option>
                        <option value="United Kingdom">United Kingdom</option>
                        <option value="United States">United States</option>
                        <option value="Vietnam">Vietnam</option>
                        <option value="Zambia">Zambia</option>
                        <option value="Zimbabwe">Zimbabwe</option>
                    </select>

                    <button
                        type="button"
                        class="fairmont-one-trigger"
                        data-picker-trigger="country"
                        aria-expanded="false"
                    >
                        <span>Select country</span>
                        <span>▾</span>
                    </button>

                </div>

            </div>
'''


bank_field = r'''
            <div class="field">

                <label>Bank Name</label>

                <div class="fairmont-one-picker">

                    <select
                        id="internationalBank"
                        name="bank_name"
                        class="fairmont-hidden-select"
                        required
                        disabled
                    >
                        <option value="">Select a bank</option>
                    </select>

                    <button
                        type="button"
                        class="fairmont-one-trigger"
                        data-picker-trigger="bank"
                        aria-expanded="false"
                    >
                        <span>Select a bank</span>
                        <span>▾</span>
                    </button>

                </div>

            </div>
'''


currency_field = r'''
            <div class="field">

                <label>Currency</label>

                <div class="fairmont-one-picker">

                    <select
                        id="internationalCurrency"
                        name="currency"
                        class="fairmont-hidden-select"
                        required
                    >
                        <option value="">Select currency</option>
                        <option value="GBP">GBP — Pound Sterling</option>
                        <option value="EUR">EUR — Euro</option>
                        <option value="USD">USD — US Dollar</option>
                        <option value="CAD">CAD — Canadian Dollar</option>
                        <option value="AUD">AUD — Australian Dollar</option>
                        <option value="NZD">NZD — New Zealand Dollar</option>
                        <option value="CHF">CHF — Swiss Franc</option>
                        <option value="JPY">JPY — Japanese Yen</option>
                        <option value="CNY">CNY — Chinese Yuan</option>
                        <option value="SGD">SGD — Singapore Dollar</option>
                        <option value="INR">INR — Indian Rupee</option>
                        <option value="AED">AED — UAE Dirham</option>
                        <option value="SAR">SAR — Saudi Riyal</option>
                        <option value="QAR">QAR — Qatari Riyal</option>
                        <option value="ZAR">ZAR — South African Rand</option>
                        <option value="KES">KES — Kenyan Shilling</option>
                        <option value="NGN">NGN — Nigerian Naira</option>
                        <option value="GHS">GHS — Ghanaian Cedi</option>
                        <option value="TZS">TZS — Tanzanian Shilling</option>
                        <option value="UGX">UGX — Ugandan Shilling</option>
                        <option value="BRL">BRL — Brazilian Real</option>
                        <option value="MXN">MXN — Mexican Peso</option>
                        <option value="SRD">SRD — Surinamese Dollar</option>
                        <option value="THB">THB — Thai Baht</option>
                        <option value="MYR">MYR — Malaysian Ringgit</option>
                        <option value="IDR">IDR — Indonesian Rupiah</option>
                        <option value="KRW">KRW — South Korean Won</option>
                        <option value="TRY">TRY — Turkish Lira</option>
                        <option value="PLN">PLN — Polish Zloty</option>
                        <option value="SEK">SEK — Swedish Krona</option>
                        <option value="NOK">NOK — Norwegian Krone</option>
                        <option value="DKK">DKK — Danish Krone</option>
                        <option value="CZK">CZK — Czech Koruna</option>
                        <option value="HUF">HUF — Hungarian Forint</option>
                        <option value="RON">RON — Romanian Leu</option>
                        <option value="ILS">ILS — Israeli New Shekel</option>
                    </select>

                    <button
                        type="button"
                        class="fairmont-one-trigger"
                        data-picker-trigger="currency"
                        aria-expanded="false"
                    >
                        <span>Select currency</span>
                        <span>▾</span>
                    </button>

                </div>

            </div>
'''


# ---------------------------------------------------------
# LOCATE THE THREE REAL FIELDS
# ---------------------------------------------------------

country_region = find_field(
    source,
    "Destination Country",
    "Beneficiary Name"
)

bank_region = find_field(
    source,
    "Bank Name",
    "Account Number"
)

currency_region = find_field(
    source,
    "Currency",
    "Amount"
)


print()
print("FIELD DETECTION")
print("================")

print(
    "Destination Country:",
    country_region
)

print(
    "Bank Name:",
    bank_region
)

print(
    "Currency:",
    currency_region
)


if not country_region:
    print()
    print("ERROR: Destination Country field was not detected.")
    print("NO FILE WAS CHANGED.")
    raise SystemExit(1)

if not bank_region:
    print()
    print("ERROR: Bank Name field was not detected.")
    print("NO FILE WAS CHANGED.")
    raise SystemExit(1)

if not currency_region:
    print()
    print("ERROR: Currency field was not detected.")
    print("NO FILE WAS CHANGED.")
    raise SystemExit(1)


# ---------------------------------------------------------
# SAFETY: REGIONS MUST NOT OVERLAP
# ---------------------------------------------------------

regions = [
    ("country", country_region),
    ("bank", bank_region),
    ("currency", currency_region),
]

regions_sorted = sorted(
    regions,
    key=lambda item: item[1][0]
)

for i in range(len(regions_sorted) - 1):

    current_name, current_region = regions_sorted[i]
    next_name, next_region = regions_sorted[i + 1]

    if current_region[1] > next_region[0]:

        print()
        print(
            "ERROR: Field regions overlap:",
            current_name,
            next_name
        )

        print("NO FILE WAS CHANGED.")
        raise SystemExit(1)


# ---------------------------------------------------------
# REPLACE FROM BOTTOM TO TOP
# ---------------------------------------------------------

replacements = {
    "country": country_field,
    "bank": bank_field,
    "currency": currency_field,
}

new_source = source

for name, (start, end) in sorted(
    regions,
    key=lambda item: item[1][0],
    reverse=True
):

    replacement = replacements[name]

    new_source = (
        new_source[:start]
        + replacement
        + new_source[end:]
    )


# ---------------------------------------------------------
# REMOVE OLD PICKER JAVASCRIPT
# ---------------------------------------------------------

OLD_SCRIPT_MARKERS = [
    "fairmont-country-bank-selector",
    "FAIRMONT_DROPDOWN_SEARCH_PICKER",
    "fairmont-clean-trigger",
    "fairmont-clean-popup",
    "quick-search-select",
    "countrySearchResults",
    "internationalBankSearchResults",
    "currencySearchResults",
    "fairmont-picker-popup",
    "fairmont-picker-trigger",
]


script_pattern = re.compile(
    r"<script\b[^>]*>.*?</script>",
    re.IGNORECASE | re.DOTALL
)

removed_scripts = 0


def remove_script(match):

    global removed_scripts

    block = match.group(0)

    if any(
        marker in block
        for marker in OLD_SCRIPT_MARKERS
    ):

        removed_scripts += 1
        return ""

    return block


new_source = script_pattern.sub(
    remove_script,
    new_source
)


print()
print(
    "Old picker scripts removed:",
    removed_scripts
)


# ---------------------------------------------------------
# CSS
# ---------------------------------------------------------

css = r'''
<style id="fairmont-one-picker-css">

.fairmont-one-picker {
    position: relative;
    width: 100%;
}

.fairmont-hidden-select {
    position: absolute !important;
    width: 1px !important;
    height: 1px !important;
    opacity: 0 !important;
    pointer-events: none !important;
}

.fairmont-one-trigger {
    width: 100%;
    min-height: 52px;
    padding: 0 16px;
    border-radius: 14px;
    border: 1px solid rgba(255,255,255,0.14);
    background: rgba(255,255,255,0.055);
    color: rgba(255,255,255,0.72);
    display: flex;
    align-items: center;
    justify-content: space-between;
    text-align: left;
    font-size: 15px;
    cursor: pointer;
    box-sizing: border-box;
}

.fairmont-one-trigger.selected {
    color: #ffffff;
}

.fairmont-one-popup {
    position: fixed;
    z-index: 999999;
    display: none;
    background: #101a2d;
    border: 1px solid rgba(255,255,255,0.16);
    border-radius: 15px;
    box-shadow: 0 22px 60px rgba(0,0,0,0.55);
    overflow: hidden;
}

.fairmont-one-popup.open {
    display: block;
}

.fairmont-one-search {
    width: calc(100% - 24px);
    height: 44px;
    margin: 12px;
    padding: 0 13px;
    box-sizing: border-box;
    border-radius: 10px;
    border: 1px solid rgba(255,255,255,0.14);
    background: rgba(255,255,255,0.07);
    color: #ffffff;
    font-size: 14px;
    outline: none;
}

.fairmont-one-search::placeholder {
    color: rgba(255,255,255,0.45);
}

.fairmont-one-list {
    max-height: 340px;
    overflow-y: auto;
}

.fairmont-one-option {
    display: block;
    width: 100%;
    padding: 13px 16px;
    border: 0;
    border-top: 1px solid rgba(255,255,255,0.055);
    background: transparent;
    color: #ffffff;
    text-align: left;
    font-size: 14px;
    cursor: pointer;
}

.fairmont-one-option:hover {
    background: rgba(255,255,255,0.08);
}

.fairmont-one-empty {
    padding: 18px;
    color: rgba(255,255,255,0.5);
    text-align: center;
    font-size: 14px;
}

</style>
'''


# ---------------------------------------------------------
# JAVASCRIPT
# ---------------------------------------------------------

js = r'''
<script id="fairmont-one-picker-js">

(function () {

    "use strict";

    const BANKS = {

        "United Kingdom": [
            "Barclays Bank",
            "HSBC UK",
            "Lloyds Bank",
            "NatWest",
            "Royal Bank of Scotland",
            "Santander UK",
            "Halifax",
            "Nationwide Building Society",
            "TSB Bank",
            "Metro Bank",
            "Monzo Bank",
            "Starling Bank",
            "Virgin Money",
            "First Direct",
            "Bank of Scotland",
            "Other UK Bank"
        ],

        "United States": [
            "JPMorgan Chase Bank",
            "Bank of America",
            "Wells Fargo Bank",
            "Citibank",
            "U.S. Bank",
            "PNC Bank",
            "Truist Bank",
            "Capital One",
            "TD Bank",
            "Other US Bank"
        ],

        "Canada": [
            "Royal Bank of Canada",
            "Toronto-Dominion Bank",
            "Bank of Nova Scotia",
            "Bank of Montreal",
            "Canadian Imperial Bank of Commerce",
            "National Bank of Canada",
            "Desjardins",
            "Other Canadian Bank"
        ],

        "Kenya": [
            "KCB Bank Kenya",
            "Equity Bank Kenya",
            "Co-operative Bank of Kenya",
            "Absa Bank Kenya",
            "NCBA Bank Kenya",
            "Stanbic Bank Kenya",
            "I&M Bank",
            "DTB Kenya",
            "Standard Chartered Kenya",
            "Family Bank",
            "Other Kenyan Bank"
        ],

        "Nigeria": [
            "Access Bank",
            "First Bank of Nigeria",
            "United Bank for Africa",
            "Guaranty Trust Bank",
            "Zenith Bank",
            "Fidelity Bank",
            "Ecobank Nigeria",
            "Stanbic IBTC Bank",
            "Union Bank of Nigeria",
            "Other Nigerian Bank"
        ],

        "Ghana": [
            "GCB Bank",
            "Ecobank Ghana",
            "Absa Bank Ghana",
            "Stanbic Bank Ghana",
            "Standard Chartered Ghana",
            "Fidelity Bank Ghana",
            "CalBank",
            "Republic Bank Ghana",
            "Other Ghanaian Bank"
        ],

        "South Africa": [
            "Standard Bank",
            "First National Bank",
            "Absa Bank",
            "Nedbank",
            "Capitec Bank",
            "Investec Bank",
            "African Bank",
            "Other South African Bank"
        ],

        "Suriname": [
            "De Surinaamsche Bank",
            "Hakrinbank",
            "Republic Bank Suriname",
            "Finabank",
            "Surichange Bank",
            "GODO",
            "Trustbank Amanah",
            "Other Surinamese Bank"
        ],

        "India": [
            "State Bank of India",
            "HDFC Bank",
            "ICICI Bank",
            "Axis Bank",
            "Kotak Mahindra Bank",
            "IndusInd Bank",
            "Punjab National Bank",
            "Bank of Baroda",
            "Canara Bank",
            "Union Bank of India",
            "Other Indian Bank"
        ],

        "Australia": [
            "Commonwealth Bank",
            "Westpac",
            "ANZ Bank",
            "National Australia Bank",
            "Macquarie Bank",
            "Bendigo Bank",
            "Other Australian Bank"
        ],

        "Germany": [
            "Deutsche Bank",
            "Commerzbank",
            "DZ Bank",
            "ING Germany",
            "N26",
            "DKB",
            "Other German Bank"
        ],

        "France": [
            "BNP Paribas",
            "Crédit Agricole",
            "Société Générale",
            "BPCE",
            "Crédit Mutuel",
            "La Banque Postale",
            "Other French Bank"
        ],

        "Netherlands": [
            "ING Bank",
            "ABN AMRO",
            "Rabobank",
            "de Volksbank",
            "Triodos Bank",
            "Other Dutch Bank"
        ],

        "Ireland": [
            "AIB",
            "Bank of Ireland",
            "Permanent TSB",
            "EBS",
            "Other Irish Bank"
        ],

        "Switzerland": [
            "UBS",
            "Zürcher Kantonalbank",
            "Banque Cantonale Vaudoise",
            "Raiffeisen Switzerland",
            "PostFinance",
            "Julius Baer",
            "Other Swiss Bank"
        ],

        "United Arab Emirates": [
            "Emirates NBD",
            "First Abu Dhabi Bank",
            "Abu Dhabi Commercial Bank",
            "Dubai Islamic Bank",
            "Mashreq Bank",
            "Commercial Bank of Dubai",
            "RAKBANK",
            "HSBC UAE",
            "Standard Chartered UAE",
            "Other UAE Bank"
        ],

        "Saudi Arabia": [
            "Saudi National Bank",
            "Al Rajhi Bank",
            "Riyad Bank",
            "Alinma Bank",
            "Bank Albilad",
            "Arab National Bank",
            "Banque Saudi Fransi",
            "Other Saudi Bank"
        ],

        "Qatar": [
            "Qatar National Bank",
            "Qatar Islamic Bank",
            "Doha Bank",
            "Commercial Bank of Qatar",
            "Dukhan Bank",
            "Ahli Bank Qatar",
            "Other Qatari Bank"
        ],

        "Singapore": [
            "DBS Bank",
            "OCBC Bank",
            "United Overseas Bank",
            "Standard Chartered Singapore",
            "HSBC Singapore",
            "Citibank Singapore",
            "Maybank Singapore",
            "Other Singapore Bank"
        ],

        "Japan": [
            "MUFG Bank",
            "Sumitomo Mitsui Banking Corporation",
            "Mizuho Bank",
            "Resona Bank",
            "Japan Post Bank",
            "Other Japanese Bank"
        ],

        "China": [
            "Industrial and Commercial Bank of China",
            "China Construction Bank",
            "Agricultural Bank of China",
            "Bank of China",
            "Bank of Communications",
            "China Merchants Bank",
            "Other Chinese Bank"
        ],

        "Brazil": [
            "Banco do Brasil",
            "Itaú Unibanco",
            "Bradesco",
            "Caixa Econômica Federal",
            "Santander Brasil",
            "BTG Pactual",
            "Other Brazilian Bank"
        ],

        "Mexico": [
            "BBVA México",
            "Banorte",
            "Santander México",
            "Citibanamex",
            "HSBC México",
            "Scotiabank México",
            "Banco Azteca",
            "Other Mexican Bank"
        ]

    };


    const country =
        document.getElementById(
            "internationalCountry"
        );

    const bank =
        document.getElementById(
            "internationalBank"
        );

    const currency =
        document.getElementById(
            "internationalCurrency"
        );


    let popup = null;
    let activeType = null;
    let activeTrigger = null;


    function closePopup() {

        if (popup) {
            popup.remove();
            popup = null;
        }

        if (activeTrigger) {
            activeTrigger.setAttribute(
                "aria-expanded",
                "false"
            );
        }

        activeType = null;
        activeTrigger = null;
    }


    function getOptions(type) {

        if (type === "country") {

            return Array.from(
                country.options
            ).filter(
                option => option.value
            );
        }


        if (type === "currency") {

            return Array.from(
                currency.options
            ).filter(
                option => option.value
            );
        }


        if (type === "bank") {

            if (!country.value) {
                return [];
            }

            const list =
                BANKS[country.value] || [
                    "Other bank in " + country.value
                ];

            return list.map(
                function (name) {

                    return {
                        value: name,
                        text: name
                    };

                }
            );
        }

        return [];
    }


    function render(type, search) {

        const list =
            popup.querySelector(
                ".fairmont-one-list"
            );

        list.innerHTML = "";

        const options =
            getOptions(type);

        const query =
            search.toLowerCase().trim();

        const filtered =
            options.filter(
                function (option) {

                    const text =
                        option.text ||
                        option.textContent;

                    return text
                        .toLowerCase()
                        .includes(query);
                }
            );


        if (!filtered.length) {

            const empty =
                document.createElement("div");

            empty.className =
                "fairmont-one-empty";

            empty.textContent =
                type === "bank" &&
                !country.value
                    ? "Select a country first."
                    : "No results found.";

            list.appendChild(empty);

            return;
        }


        filtered.forEach(
            function (option) {

                const button =
                    document.createElement("button");

                button.type = "button";

                button.className =
                    "fairmont-one-option";

                const text =
                    option.text ||
                    option.textContent;

                button.textContent =
                    text;


                button.addEventListener(
                    "click",
                    function () {

                        if (type === "country") {

                            country.value =
                                option.value;

                            country.dispatchEvent(
                                new Event(
                                    "change",
                                    {
                                        bubbles: true
                                    }
                                )
                            );

                        }


                        if (type === "bank") {

                            bank.value =
                                option.value;

                        }


                        if (type === "currency") {

                            currency.value =
                                option.value;

                        }


                        updateTriggers();

                        closePopup();

                    }
                );


                list.appendChild(button);

            }
        );
    }


    function updateTriggers() {

        const countryTrigger =
            document.querySelector(
                '[data-picker-trigger="country"]'
            );

        const bankTrigger =
            document.querySelector(
                '[data-picker-trigger="bank"]'
            );

        const currencyTrigger =
            document.querySelector(
                '[data-picker-trigger="currency"]'
            );


        if (countryTrigger) {

            const selected =
                country.options[
                    country.selectedIndex
                ];

            countryTrigger.querySelector(
                "span"
            ).textContent =
                selected && selected.value
                    ? selected.textContent
                    : "Select country";

            countryTrigger.classList.toggle(
                "selected",
                !!country.value
            );
        }


        if (bankTrigger) {

            const selected =
                bank.options[
                    bank.selectedIndex
                ];

            bankTrigger.querySelector(
                "span"
            ).textContent =
                selected && selected.value
                    ? selected.textContent
                    : "Select a bank";

            bankTrigger.classList.toggle(
                "selected",
                !!bank.value
            );
        }


        if (currencyTrigger) {

            const selected =
                currency.options[
                    currency.selectedIndex
                ];

            currencyTrigger.querySelector(
                "span"
            ).textContent =
                selected && selected.value
                    ? selected.textContent
                    : "Select currency";

            currencyTrigger.classList.toggle(
                "selected",
                !!currency.value
            );
        }
    }


    function populateBanks() {

        bank.innerHTML =
            '<option value="">Select a bank</option>';

        if (!country.value) {

            bank.disabled = true;

            updateTriggers();

            return;
        }


        const list =
            BANKS[country.value] || [
                "Other bank in " + country.value
            ];


        list.forEach(
            function (name) {

                const option =
                    document.createElement("option");

                option.value = name;
                option.textContent = name;

                bank.appendChild(option);

            }
        );


        bank.disabled = false;

        updateTriggers();
    }


    function openPicker(
        type,
        trigger
    ) {

        if (
            activeType === type
        ) {
            closePopup();
            return;
        }

        closePopup();

        if (
            type === "bank" &&
            !country.value
        ) {
            return;
        }


        popup =
            document.createElement("div");

        popup.className =
            "fairmont-one-popup open";


        const search =
            document.createElement("input");

        search.type = "search";

        search.className =
            "fairmont-one-search";

        search.placeholder =
            type === "country"
                ? "Search country..."
                : type === "bank"
                    ? "Search bank..."
                    : "Search currency...";


        const list =
            document.createElement("div");

        list.className =
            "fairmont-one-list";


        popup.appendChild(search);
        popup.appendChild(list);

        document.body.appendChild(
            popup
        );


        activeType = type;
        activeTrigger = trigger;

        trigger.setAttribute(
            "aria-expanded",
            "true"
        );


        const rect =
            trigger.getBoundingClientRect();

        const width =
            Math.min(
                420,
                window.innerWidth - 28
            );

        popup.style.width =
            width + "px";

        let left = rect.left;

        if (
            left + width >
            window.innerWidth - 14
        ) {
            left =
                window.innerWidth -
                width -
                14;
        }

        if (left < 14) {
            left = 14;
        }

        popup.style.left =
            left + "px";

        popup.style.top =
            Math.min(
                rect.bottom + 8,
                window.innerHeight - 420
            ) + "px";


        render(
            type,
            ""
        );


        search.addEventListener(
            "input",
            function () {

                render(
                    type,
                    search.value
                );

            }
        );


        setTimeout(
            function () {
                search.focus();
            },
            0
        );
    }


    document.querySelectorAll(
        "[data-picker-trigger]"
    ).forEach(
        function (trigger) {

            trigger.addEventListener(
                "click",
                function () {

                    openPicker(
                        trigger.dataset.pickerTrigger,
                        trigger
                    );

                }
            );

        }
    );


    country.addEventListener(
        "change",
        function () {

            bank.value = "";

            populateBanks();

        }
    );


    document.addEventListener(
        "click",
        function (event) {

            if (!popup) {
                return;
            }

            if (
                popup.contains(event.target)
            ) {
                return;
            }

            if (
                activeTrigger &&
                activeTrigger.contains(event.target)
            ) {
                return;
            }

            closePopup();

        }
    );


    document.addEventListener(
        "keydown",
        function (event) {

            if (event.key === "Escape") {
                closePopup();
            }

        }
    );


    window.addEventListener(
        "resize",
        closePopup
    );


    populateBanks();

    updateTriggers();

})();

</script>
'''


# ---------------------------------------------------------
# INSERT CSS + JS
# ---------------------------------------------------------

if (
    "fairmont-one-picker-css" in new_source
    or
    "fairmont-one-picker-js" in new_source
):

    print()
    print("ERROR: V4 picker already exists.")
    print("NO FILE WAS CHANGED.")
    raise SystemExit(1)


new_source = new_source.replace(
    "</head>",
    css + "\n</head>",
    1
)

new_source = new_source.replace(
    "</body>",
    js + "\n</body>",
    1
)


# ---------------------------------------------------------
# FINAL VALIDATION
# ---------------------------------------------------------

def count(pattern):
    return len(
        re.findall(
            pattern,
            new_source,
            re.IGNORECASE
        )
    )


print()
print("FINAL VALIDATION")
print("================")


checks = {
    "Country select":
        count(
            r'<select\b[^>]*\bid\s*=\s*["\']internationalCountry["\']'
        ),

    "Bank select":
        count(
            r'<select\b[^>]*\bid\s*=\s*["\']internationalBank["\']'
        ),

    "Currency select":
        count(
            r'<select\b[^>]*\bid\s*=\s*["\']internationalCurrency["\']'
        ),

    "Country trigger":
        count(
            r'data-picker-trigger\s*=\s*["\']country["\']'
        ),

    "Bank trigger":
        count(
            r'data-picker-trigger\s*=\s*["\']bank["\']'
        ),

    "Currency trigger":
        count(
            r'data-picker-trigger\s*=\s*["\']currency["\']'
        ),
}


for name, value in checks.items():

    print(
        f"{name}: {value}"
    )


if any(
    value != 1
    for value in checks.values()
):

    print()
    print(
        "ERROR: Duplicate or missing control detected."
    )
    print(
        "NO FILE WAS CHANGED."
    )

    raise SystemExit(1)


# Old visible picker HTML must be gone.
old_html = [
    "quick-search-select",
    "search-select-wrapper",
    "fairmont-clean-trigger",
    "fairmont-clean-popup",
    "fairmont-picker-trigger",
]


remaining = [
    marker
    for marker in old_html
    if marker in new_source
]


if remaining:

    print()
    print(
        "ERROR: Old picker markup remains:"
    )

    for marker in remaining:
        print(
            "  " + marker
        )

    print()
    print("NO FILE WAS CHANGED.")

    raise SystemExit(1)


# ---------------------------------------------------------
# WRITE
# ---------------------------------------------------------

TEMPLATE.write_text(
    new_source,
    encoding="utf-8"
)


print()
print("==========================================")
print("SUCCESS - V4 COMPLETED")
print("==========================================")
print()
print("Exactly one Country field.")
print("Exactly one Bank field.")
print("Exactly one Currency field.")
print()
print("Search appears only after opening a field.")
print("Bank list depends on the selected country.")
print("Suriname is included.")
print()
print("Database untouched.")
print("app.py untouched.")
print("Dashboard untouched.")
print()
print("Backup:", backup.name)