from pathlib import Path


# ---------------------------------------------------------
# 1. Add Fairmont Bank to the visible UK bank picker
# ---------------------------------------------------------

template = Path("templates/send_money.html")

if not template.exists():
    raise SystemExit("ERROR: templates/send_money.html was not found.")

text = template.read_text(encoding="utf-8")

if "'Fairmont Bank'" in text:
    print("Fairmont Bank is already present in the UK bank picker.")
else:
    old = "            'Danske Bank',"

    if old not in text:
        raise SystemExit(
            "ERROR: The UK_BANKS list could not be located. "
            "No template changes were made."
        )

    new = (
        "            'Danske Bank',\n"
        "            'Fairmont Bank',"
    )

    text = text.replace(old, new, 1)
    template.write_text(text, encoding="utf-8")

    print("SUCCESS: Fairmont Bank added to the visible UK bank picker.")


# ---------------------------------------------------------
# 2. Make the Flask UK transfer route use the same country
#    value as the bank database: United Kingdom
# ---------------------------------------------------------

app_file = Path("app.py")

if not app_file.exists():
    raise SystemExit("ERROR: app.py was not found.")

app_text = app_file.read_text(encoding="utf-8")

# Only change the exact send-money bank queries.
old_query = '''banks = Bank.query.filter_by(
        country="UK",
        active=True
    ).order_by(Bank.name.asc()).all()'''

new_query = '''banks = Bank.query.filter_by(
        country="United Kingdom",
        active=True
    ).order_by(Bank.name.asc()).all()'''

old_validation = '''bank = Bank.query.filter_by(
        name=bank_name,
        country="UK",
        active=True
    ).first()'''

new_validation = '''bank = Bank.query.filter_by(
        name=bank_name,
        country="United Kingdom",
        active=True
    ).first()'''

changes = 0

if old_query in app_text:
    app_text = app_text.replace(old_query, new_query, 1)
    changes += 1
    print("SUCCESS: UK bank list query now uses United Kingdom.")

if old_validation in app_text:
    app_text = app_text.replace(old_validation, new_validation, 1)
    changes += 1
    print("SUCCESS: UK bank validation now uses United Kingdom.")

if changes == 0:
    print("WARNING: The expected UK country queries were not found.")
else:
    app_file.write_text(app_text, encoding="utf-8")
    print("SUCCESS: UK transfer backend updated.")
    
print("No dashboard design was changed.")
print("No customer or account data was changed.")