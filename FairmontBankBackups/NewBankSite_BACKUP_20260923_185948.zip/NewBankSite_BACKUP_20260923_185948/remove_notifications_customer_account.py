from pathlib import Path

file = Path("templates/notifications.html")

if not file.exists():
    raise SystemExit("ERROR: templates/notifications.html was not found.")

text = file.read_text(encoding="utf-8")

old = """            <!-- ACCOUNT SUMMARY -->

            <section class="notifications-summary">

                <p class="notifications-summary-label">
                    CUSTOMER ACCOUNT
                </p>

                <h2 class="notifications-summary-title">
                    {{ customer.full_name }}
                </h2>

                <p class="notifications-summary-id">
                    Customer ID · {{ customer.customer_id }}
                </p>

            </section>


"""

if old not in text:
    raise SystemExit(
        "ERROR: The Customer Account section was not found exactly. "
        "No changes were made."
    )

text = text.replace(old, "", 1)

file.write_text(text, encoding="utf-8")

print("SUCCESS: Customer Account card removed from Notifications.")
print("Only the Customer Account section was changed.")