from pathlib import Path

path = Path("app.py")
text = path.read_text(encoding="utf-8")

old_block = '''if __name__ == "__main__":

    with app.app_context():

        db.create_all()

    app.run(
        debug=True
    )


'''

if old_block not in text:
    print("ERROR: The existing app.run block was not found.")
    raise SystemExit(1)

text = text.replace(old_block, "", 1)

new_block = '''

# ============================================================
# START APPLICATION
# ============================================================

if __name__ == "__main__":

    with app.app_context():
        db.create_all()

    app.run(
        debug=True
    )
'''

text = text.rstrip() + new_block + "\n"

path.write_text(text, encoding="utf-8")

print("SUCCESS: app.run() moved to the end of app.py.")