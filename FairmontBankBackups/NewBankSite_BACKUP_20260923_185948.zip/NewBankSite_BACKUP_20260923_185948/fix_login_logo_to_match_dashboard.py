from pathlib import Path
import shutil
import re

BASE = Path(r"C:\Users\DON J\Documents\NewBankSite")
FILE = BASE / "templates" / "login.html"

# Backup before changing anything
backup = FILE.with_suffix(".html.before_dashboard_logo_match")
shutil.copy2(FILE, backup)

text = FILE.read_text(encoding="utf-8")

new_css = """
<style id="fairmont-login-logo-match-dashboard">
.login-brand {
    display: flex;
    align-items: center;
    justify-content: flex-start;
    width: 100%;
    margin-top: 0;
    margin-bottom: 6px;
}

.login-fairmont-logo {
    display: block;
    width: 175px;
    height: auto;
    max-width: 100%;
    object-fit: contain;
}

@media (max-width: 600px) {
    .login-fairmont-logo {
        width: 155px;
    }
}
</style>
"""

# Remove the previous dedicated login-logo style block.
text = re.sub(
    r'<style\s+id="fairmont-login-logo">.*?</style>',
    '',
    text,
    flags=re.IGNORECASE | re.DOTALL
)

# Remove any previous dashboard-match block if the script is run again.
text = re.sub(
    r'<style\s+id="fairmont-login-logo-match-dashboard">.*?</style>',
    '',
    text,
    flags=re.IGNORECASE | re.DOTALL
)

# Insert the new styling immediately before </head>.
head_end = re.search(r'</head>', text, flags=re.IGNORECASE)

if not head_end:
    print("ERROR: </head> was not found.")
    raise SystemExit(1)

text = (
    text[:head_end.start()]
    + new_css
    + "\n"
    + text[head_end.start():]
)

FILE.write_text(text, encoding="utf-8")

print()
print("SUCCESS: Login logo styling now matches the dashboard logo.")
print()
print("Desktop width: 175px")
print("Mobile width: 155px")
print("Logo file: static/images/fairmont-bank-logo.png")
print()
print(f"Backup created:")
print(backup)