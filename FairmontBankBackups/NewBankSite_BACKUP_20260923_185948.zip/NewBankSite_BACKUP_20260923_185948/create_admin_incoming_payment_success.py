from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
TEMPLATES = BASE_DIR / "templates"

TEMPLATES.mkdir(exist_ok=True)

template = r'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Payment Receipt | Fairmont Bank</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            font-family: Arial, Helvetica, sans-serif;
            background:
                radial-gradient(
                    circle at top left,
                    rgba(184,149,74,.10),
                    transparent 32%
                ),
                #071525;
            color: #edf3fb;
        }

        .page {
            width: 100%;
            max-width: 850px;
            margin: 0 auto;
            padding: 35px 20px 60px;
        }

        .receipt {
            background: #0c1f33;
            border: 1px solid rgba(184,149,74,.25);
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 25px 70px rgba(0,0,0,.35);
        }

        .receipt-header {
            padding: 30px 32px 25px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,.08);
        }

        .brand {
            color: #ffffff;
            font-size: 22px;
            font-weight: 800;
            letter-spacing: 1.7px;
        }

        .brand span {
            color: #d5b467;
        }

        .receipt-title {
            margin-top: 22px;
            color: #d5b467;
            font-size: 13px;
            font-weight: 800;
            letter-spacing: 2px;
            text-transform: uppercase;
        }

        .success {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin-top: 13px;
            padding: 8px 13px;
            border-radius: 20px;
            background: rgba(70,190,125,.10);
            border: 1px solid rgba(100,220,155,.25);
            color: #9de7bc;
            font-size: 12px;
            font-weight: 700;
        }

        .amount-section {
            padding: 28px 32px;
            text-align: center;
            background: rgba(184,149,74,.045);
            border-bottom: 1px solid rgba(255,255,255,.08);
        }

        .amount-label {
            color: #8197ad;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .amount {
            margin-top: 7px;
            color: #d5b467;
            font-size: 36px;
            font-weight: 800;
        }

        .amount-type {
            margin-top: 6px;
            color: #9eb0c3;
            font-size: 13px;
        }

        .content {
            padding: 28px 32px;
        }

        .section {
            margin-bottom: 28px;
        }

        .section:last-child {
            margin-bottom: 0;
        }

        .section-title {
            margin: 0 0 14px;
            color: #ffffff;
            font-size: 15px;
            font-weight: 800;
        }

        .details {
            display: grid;
            grid-template-columns: repeat(2, minmax(0,1fr));
            border: 1px solid rgba(255,255,255,.07);
            border-radius: 12px;
            overflow: hidden;
            background: rgba(5,18,31,.45);
        }

        .detail {
            padding: 14px 15px;
            border-right: 1px solid rgba(255,255,255,.06);
            border-bottom: 1px solid rgba(255,255,255,.06);
        }

        .detail:nth-child(2n) {
            border-right: 0;
        }

        .label {
            margin-bottom: 6px;
            color: #7188a1;
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .7px;
        }

        .value {
            color: #e8eef5;
            font-size: 13px;
            font-weight: 700;
            line-height: 1.4;
            word-break: break-word;
        }

        .balance-box {
            display: grid;
            grid-template-columns: 1fr auto 1fr;
            align-items: center;
            gap: 12px;
        }

        .balance {
            padding: 17px;
            border-radius: 12px;
            text-align: center;
            background: rgba(5,18,31,.45);
            border: 1px solid rgba(255,255,255,.07);
        }

        .balance-label {
            color: #7188a1;
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .6px;
        }

        .balance-value {
            margin-top: 7px;
            color: #ffffff;
            font-size: 19px;
            font-weight: 800;
        }

        .arrow {
            color: #d5b467;
            font-size: 20px;
            font-weight: 800;
        }

        .footer {
            padding: 22px 32px;
            border-top: 1px solid rgba(255,255,255,.08);
            color: #7188a1;
            font-size: 11px;
            line-height: 1.6;
            text-align: center;
        }

        .actions {
            display: flex;
            justify-content: center;
            gap: 12px;
            flex-wrap: wrap;
            margin-top: 24px;
        }

        .button {
            display: inline-block;
            padding: 12px 19px;
            border-radius: 10px;
            text-decoration: none;
            font-size: 13px;
            font-weight: 800;
            cursor: pointer;
            border: 0;
        }

        .button.primary {
            background: #b8954a;
            color: #081625;
        }

        .button.primary:hover {
            background: #d5b467;
        }

        .button.secondary {
            background: rgba(255,255,255,.06);
            border: 1px solid rgba(255,255,255,.10);
            color: #c8d5e3;
        }

        .button.secondary:hover {
            background: rgba(255,255,255,.10);
        }

        @media print {

            body {
                background: #ffffff;
                color: #111111;
            }

            .page {
                max-width: none;
                padding: 0;
            }

            .receipt {
                border: 1px solid #cccccc;
                box-shadow: none;
                background: #ffffff;
                color: #111111;
            }

            .actions {
                display: none;
            }

            .receipt-header,
            .amount-section,
            .content,
            .footer {
                background: #ffffff;
            }

            .brand,
            .section-title,
            .value,
            .balance-value {
                color: #111111;
            }

            .receipt-title,
            .amount {
                color: #8b6b25;
            }

            .success {
                color: #23754a;
                border-color: #9bc9ae;
                background: #f2faf5;
            }

            .details,
            .balance {
                background: #ffffff;
                border-color: #dddddd;
            }

            .label,
            .balance-label,
            .footer,
            .amount-label,
            .amount-type {
                color: #666666;
            }
        }

        @media (max-width: 650px) {

            .page {
                padding: 15px 10px 35px;
            }

            .receipt-header,
            .amount-section,
            .content,
            .footer {
                padding-left: 18px;
                padding-right: 18px;
            }

            .details {
                grid-template-columns: 1fr;
            }

            .detail {
                border-right: 0;
            }

            .balance-box {
                grid-template-columns: 1fr;
            }

            .arrow {
                text-align: center;
                transform: rotate(90deg);
            }

            .actions {
                flex-direction: column;
            }

            .button {
                width: 100%;
                text-align: center;
            }
        }
    </style>
</head>

<body>

<div class="page">

    <div class="receipt">

        <div class="receipt-header">

            <div class="brand">
                FAIRMONT <span>BANK</span>
            </div>

            <div class="receipt-title">
                Incoming Payment Receipt
            </div>

            <div class="success">
                ✓ Payment Posted Successfully
            </div>

        </div>

        <div class="amount-section">

            <div class="amount-label">
                Payment Received
            </div>

            <div class="amount">
                £{{ "{:,.2f}".format(amount|float) }}
            </div>

            <div class="amount-type">
                Credit to customer account
            </div>

        </div>

        <div class="content">

            <div class="section">

                <h2 class="section-title">
                    Receipt Information
                </h2>

                <div class="details">

                    <div class="detail">
                        <div class="label">
                            Transaction Reference
                        </div>
                        <div class="value">
                            {{ transaction_reference }}
                        </div>
                    </div>

                    <div class="detail">
                        <div class="label">
                            Payment Reference
                        </div>
                        <div class="value">
                            {{ payment_reference or "Not provided" }}
                        </div>
                    </div>

                    <div class="detail">
                        <div class="label">
                            Transaction Type
                        </div>
                        <div class="value">
                            Payment Received
                        </div>
                    </div>

                    <div class="detail">
                        <div class="label">
                            Direction
                        </div>
                        <div class="value">
                            Credit
                        </div>
                    </div>

                    <div class="detail">
                        <div class="label">
                            Status
                        </div>
                        <div class="value">
                            Completed
                        </div>
                    </div>

                    <div class="detail">
                        <div class="label">
                            Posted
                        </div>
                        <div class="value">
                            {{ posted_at }}
                        </div>
                    </div>

                </div>

            </div>

            <div class="section">

                <h2 class="section-title">
                    Receiver
                </h2>

                <div class="details">

                    <div class="detail">
                        <div class="label">
                            Account Holder
                        </div>
                        <div class="value">
                            {{ receiver.full_name }}
                        </div>
                    </div>

                    <div class="detail">
                        <div class="label">
                            Customer ID
                        </div>
                        <div class="value">
                            {{ receiver.customer_id }}
                        </div>
                    </div>

                    <div class="detail">
                        <div class="label">
                            Account Number
                        </div>
                        <div class="value">
                            {{ receiver.account_number or "Not assigned" }}
                        </div>
                    </div>

                    <div class="detail">
                        <div class="label">
                            Account Type
                        </div>
                        <div class="value">
                            {{ receiver.account_type|title }}
                        </div>
                    </div>

                </div>

            </div>

            <div class="section">

                <h2 class="section-title">
                    Sender
                </h2>

                <div class="details">

                    <div class="detail">
                        <div class="label">
                            Sender Name
                        </div>
                        <div class="value">
                            {{ sender_name }}
                        </div>
                    </div>

                    <div class="detail">
                        <div class="label">
                            Sender Account Number
                        </div>
                        <div class="value">
                            {{ sender_account_number or "Not provided" }}
                        </div>
                    </div>

                    <div class="detail">
                        <div class="label">
                            Sender Bank
                        </div>
                        <div class="value">
                            {{ sender_bank or "Not provided" }}
                        </div>
                    </div>

                    <div class="detail">
                        <div class="label">
                            Sender Country
                        </div>
                        <div class="value">
                            {{ sender_country or "Not provided" }}
                        </div>
                    </div>

                    <div class="detail" style="grid-column: 1 / -1;">
                        <div class="label">
                            Payment Description
                        </div>
                        <div class="value">
                            {{ payment_description or "Payment Received" }}
                        </div>
                    </div>

                </div>

            </div>

            <div class="section">

                <h2 class="section-title">
                    Account Balance
                </h2>

                <div class="balance-box">

                    <div class="balance">

                        <div class="balance-label">
                            Previous Balance
                        </div>

                        <div class="balance-value">
                            £{{ "{:,.2f}".format(previous_balance|float) }}
                        </div>

                    </div>

                    <div class="arrow">
                        →
                    </div>

                    <div class="balance">

                        <div class="balance-label">
                            New Balance
                        </div>

                        <div class="balance-value">
                            £{{ "{:,.2f}".format(new_balance|float) }}
                        </div>

                    </div>

                </div>

            </div>

        </div>

        <div class="footer">

            This receipt confirms that the incoming payment shown above
            was posted to the specified Fairmont Bank customer account.
            Keep the transaction reference for your records.

        </div>

    </div>

    <div class="actions">

        <button
            type="button"
            class="button primary"
            onclick="window.print()"
        >
            Print / Save Receipt
        </button>

        <a
            href="{{ url_for('admin_incoming_payment') }}"
            class="button secondary"
        >
            Post Another Payment
        </a>

        <a
            href="{{ url_for('admin_dashboard') }}"
            class="button secondary"
        >
            Administration Portal
        </a>

    </div>

</div>

</body>
</html>
'''

output = TEMPLATES / "admin_incoming_payment_success.html"

output.write_text(
    template,
    encoding="utf-8"
)

print()
print("=" * 70)
print("INCOMING PAYMENT RECEIPT CREATED")
print("=" * 70)
print()
print(output)
print()
print("The existing payment success page was replaced with a")
print("professional printable receipt.")
print()