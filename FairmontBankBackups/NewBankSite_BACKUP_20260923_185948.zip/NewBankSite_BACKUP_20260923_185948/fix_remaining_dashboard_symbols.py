from pathlib import Path

file = Path("templates/dashboard.html")

if not file.exists():
    raise SystemExit("ERROR: dashboard.html was not found.")

text = file.read_text(encoding="utf-8")

replacements = {
    "Â·": "·",
    "â‡„": "↔",
    "â—": "●",
}

changed = False

for bad, good in replacements.items():
    if bad in text:
        text = text.replace(bad, good)
        changed = True
        print(f"Fixed: {bad} -> {good}")

if changed:
    file.write_text(text, encoding="utf-8")
    print("SUCCESS: Remaining dashboard symbols repaired.")
else:
    print("NOTICE: No remaining targeted symbols were found.")