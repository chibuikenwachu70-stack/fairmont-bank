from pathlib import Path
import re

file = Path("templates/dashboard.html")

if not file.exists():
    raise SystemExit("ERROR: templates/dashboard.html was not found.")

text = file.read_text(encoding="utf-8")

# Locate the bottom navigation by its known structure:
# <nav ...>
#     five navigation <a> items
# </nav>
#
# We identify it specifically by the Home / Accounts / Payments /
# Activity / More labels so no other dashboard content is removed.

pattern = r"""
(?P<nav>
    <nav\b[^>]*>
        .*?
        Home
        .*?
        Accounts
        .*?
        Payments
        .*?
        Activity
        .*?
        More
        .*?
    </nav>
)
"""

match = re.search(
    pattern,
    text,
    flags=re.IGNORECASE | re.DOTALL | re.VERBOSE
)

if not match:
    raise SystemExit(
        "ERROR: The Home / Accounts / Payments / Activity / More "
        "navigation was not found. No changes were made."
    )

navigation = match.group("nav")

# Safety check: make absolutely sure this is the intended navigation.
required = ["Home", "Accounts", "Payments", "Activity", "More"]

if not all(item in navigation for item in required):
    raise SystemExit(
        "ERROR: Navigation safety check failed. No changes were made."
    )

text = text[:match.start()] + "\n" + text[match.end():]

file.write_text(text, encoding="utf-8")

print()
print("SUCCESS: Removed the bottom navigation.")
print("Removed: Home")
print("Removed: Accounts")
print("Removed: Payments")
print("Removed: Activity")
print("Removed: More")
print()
print("The Services section was NOT changed.")
print("Email the Bank was NOT changed.")
print("Notifications were NOT changed.")
print("My Profile was NOT changed.")
print("Available Balance was NOT changed.")
print()