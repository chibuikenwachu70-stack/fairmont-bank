from pathlib import Path

APP_FILE = Path(__file__).resolve().parent / "app.py"

if not APP_FILE.exists():
    print("ERROR: app.py was not found.")
    raise SystemExit(1)

text = APP_FILE.read_text(encoding="utf-8")

start_marker = '@app.route("/admin/incoming-payment"'

start = text.find(start_marker)

if start == -1:
    print("ERROR: /admin/incoming-payment route was not found.")
    raise SystemExit(1)

end_marker = '\nif __name__ == "__main__":'

end = text.find(end_marker, start)

if end == -1:
    end = len(text)

route = text[start:end]

print()
print("=" * 80)
print("CURRENT ADMIN INCOMING PAYMENT ROUTE")
print("=" * 80)
print()
print(route)
print()
print("=" * 80)
print("NO CHANGES WERE MADE")
print("=" * 80)