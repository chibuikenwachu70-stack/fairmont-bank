from pathlib import Path
import shutil

BASE = Path(r"C:\Users\DON J\Documents\NewBankSite")
FILE = BASE / "templates" / "settings.html"

backup = FILE.with_suffix(".html.account_preferences_card_backup2")
shutil.copy2(FILE, backup)

text = FILE.read_text(encoding="utf-8")

start_marker = "<!-- ACCOUNT PREFERENCES -->"

start = text.find(start_marker)

if start == -1:
    print("ERROR: ACCOUNT PREFERENCES section was not found.")
    raise SystemExit(1)

# Account Preferences is the final Settings card.
# Preserve everything before it and replace the final card.

new_block = """<!-- ACCOUNT PREFERENCES -->

<a
    href="{{ url_for('account_preferences') }}"
    class="settings-card"
    style="text-decoration:none; color:inherit;"
>

    <div class="settings-icon">
        ⚙
    </div>

    <div class="settings-content">

        <p class="settings-name">
            Account Preferences
        </p>

        <p class="settings-description">
            Manage your account display and general banking preferences.
        </p>

    </div>

    <div class="settings-arrow">
        ›
    </div>

</a>

"""

# Find the final closing body/container area.
# We keep the page structure after the card.
body_end = text.rfind("</body>")

if body_end == -1:
    print("ERROR: </body> was not found.")
    raise SystemExit(1)

# Preserve any closing HTML structure after the Account Preferences card.
# Remove the old Account Preferences block and retain closing tags.
after = text[body_end:]

text = text[:start] + new_block + after

FILE.write_text(text, encoding="utf-8")

print("SUCCESS: Account Preferences is now a clickable Settings card.")
print(f"Backup created: {backup.name}")