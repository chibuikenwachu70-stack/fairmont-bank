from pathlib import Path
import re

BASE_DIR = Path(__file__).resolve().parent
APP_FILE = BASE_DIR / "app.py"
TEMPLATE_FILE = BASE_DIR / "templates" / "notification_preferences.html"

app_text = APP_FILE.read_text(encoding="utf-8")

# ---------------------------------------------------------
# 1. Add the four model fields to Customer
# ---------------------------------------------------------

fields_marker = '    login_otp_enabled = db.Column(db.Boolean, nullable=False, default=False)'

fields_to_add = '''    login_otp_enabled = db.Column(db.Boolean, nullable=False, default=False)

    transaction_notifications = db.Column(
        db.Boolean,
        nullable=False,
        default=True
    )

    security_notifications = db.Column(
        db.Boolean,
        nullable=False,
        default=True
    )

    account_notifications = db.Column(
        db.Boolean,
        nullable=False,
        default=True
    )

    promotional_notifications = db.Column(
        db.Boolean,
        nullable=False,
        default=False
    )'''

if "transaction_notifications = db.Column" not in app_text:
    if fields_marker not in app_text:
        print("ERROR: Customer model location was not found.")
        raise SystemExit(1)

    app_text = app_text.replace(
        fields_marker,
        fields_to_add,
        1
    )
    print("SUCCESS: Customer notification preference fields added to model.")
else:
    print("INFO: Customer notification preference fields already exist in model.")


# ---------------------------------------------------------
# 2. Add Notification Preferences route
# ---------------------------------------------------------

route_marker = '@app.route("/notifications")'

route_code = '''@app.route("/settings/notification-preferences", methods=["GET", "POST"])
@login_required
def notification_preferences():
    customer = current_user

    if request.method == "POST":
        customer.transaction_notifications = (
            request.form.get("transaction_notifications") == "on"
        )

        customer.security_notifications = (
            request.form.get("security_notifications") == "on"
        )

        customer.account_notifications = (
            request.form.get("account_notifications") == "on"
        )

        customer.promotional_notifications = (
            request.form.get("promotional_notifications") == "on"
        )

        db.session.commit()

        return redirect(url_for("notification_preferences"))

    return render_template(
        "notification_preferences.html",
        customer=customer
    )


'''

if 'def notification_preferences():' not in app_text:
    if route_marker not in app_text:
        print("ERROR: Notifications route location was not found.")
        raise SystemExit(1)

    app_text = app_text.replace(
        route_marker,
        route_code + route_marker,
        1
    )
    print("SUCCESS: Notification Preferences route added.")
else:
    print("INFO: Notification Preferences route already exists.")


# ---------------------------------------------------------
# 3. Update Settings page
# ---------------------------------------------------------

settings_file = BASE_DIR / "templates" / "settings.html"

if settings_file.exists():
    settings_text = settings_file.read_text(encoding="utf-8")

    pattern = re.compile(
        r'(<div[^>]*class="settings-card"[^>]*>.*?'
        r'<[^>]*>.*?Notification Preferences.*?</[^>]*>.*?</div>)',
        re.IGNORECASE | re.DOTALL
    )

    match = pattern.search(settings_text)

    if match:
        old_card = match.group(1)

        new_card = '''<a href="{{ url_for('notification_preferences') }}" class="settings-card">
    <div class="settings-card-icon">🔔</div>
    <div class="settings-card-content">
        <h3>Notification Preferences</h3>
        <p>Choose which account notifications you receive.</p>
    </div>
    <div class="settings-card-arrow">›</div>
</a>'''

        settings_text = settings_text[:match.start()] + new_card + settings_text[match.end():]

        settings_file.write_text(settings_text, encoding="utf-8")
        print("SUCCESS: Settings Notification Preferences card connected.")
    else:
        print("INFO: Notification Preferences card was not automatically changed.")
else:
    print("WARNING: templates/settings.html was not found.")


# ---------------------------------------------------------
# 4. Save app.py
# ---------------------------------------------------------

APP_FILE.write_text(app_text, encoding="utf-8")


# ---------------------------------------------------------
# 5. Create Notification Preferences page
# ---------------------------------------------------------

template = r'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Notification Preferences | Fairmont Bank</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            background:
                radial-gradient(circle at top left, rgba(35, 83, 145, 0.22), transparent 32%),
                linear-gradient(145deg, #061426, #0a1c32 55%, #071426);
            color: #ffffff;
            font-family: Arial, Helvetica, sans-serif;
        }

        .page {
            width: 100%;
            max-width: 760px;
            margin: 0 auto;
            padding: 24px 18px 40px;
        }

        .topbar {
            display: flex;
            align-items: center;
            gap: 14px;
            margin-bottom: 24px;
        }

        .back-button {
            width: 42px;
            height: 42px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #ffffff;
            text-decoration: none;
            background: rgba(255,255,255,0.07);
            border: 1px solid rgba(255,255,255,0.10);
            font-size: 24px;
        }

        .topbar-text h1 {
            margin: 0;
            font-size: 22px;
            font-weight: 700;
        }

        .topbar-text p {
            margin: 5px 0 0;
            color: #9fb0c5;
            font-size: 13px;
        }

        .intro {
            margin-bottom: 18px;
        }

        .intro h2 {
            margin: 0 0 7px;
            font-size: 18px;
        }

        .intro p {
            margin: 0;
            color: #9fb0c5;
            font-size: 14px;
            line-height: 1.55;
        }

        .preferences-card {
            background: rgba(15, 35, 59, 0.88);
            border: 1px solid rgba(255,255,255,0.08);
            border-radius: 18px;
            overflow: hidden;
            box-shadow: 0 18px 50px rgba(0,0,0,0.22);
        }

        .preference-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 18px;
            padding: 20px 18px;
            border-bottom: 1px solid rgba(255,255,255,0.07);
        }

        .preference-row:last-child {
            border-bottom: none;
        }

        .preference-info {
            flex: 1;
        }

        .preference-info h3 {
            margin: 0 0 6px;
            font-size: 15px;
            font-weight: 700;
        }

        .preference-info p {
            margin: 0;
            color: #91a3b8;
            font-size: 12px;
            line-height: 1.5;
        }

        .switch {
            position: relative;
            width: 52px;
            height: 30px;
            flex: 0 0 auto;
        }

        .switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .slider {
            position: absolute;
            cursor: pointer;
            inset: 0;
            background: #33465d;
            border-radius: 30px;
            transition: 0.2s;
        }

        .slider:before {
            content: "";
            position: absolute;
            width: 22px;
            height: 22px;
            left: 4px;
            top: 4px;
            background: #ffffff;
            border-radius: 50%;
            transition: 0.2s;
        }

        .switch input:checked + .slider {
            background: #2f8cff;
        }

        .switch input:checked + .slider:before {
            transform: translateX(22px);
        }

        .save-area {
            margin-top: 18px;
        }

        .save-button {
            width: 100%;
            border: 0;
            border-radius: 13px;
            padding: 15px;
            background: #1f78e5;
            color: #ffffff;
            font-size: 15px;
            font-weight: 700;
            cursor: pointer;
        }

        .save-button:hover {
            background: #2787f5;
        }

        .note {
            margin-top: 14px;
            color: #8295aa;
            font-size: 12px;
            line-height: 1.5;
            text-align: center;
        }

        @media (max-width: 520px) {
            .page {
                padding: 18px 14px 32px;
            }

            .preference-row {
                padding: 18px 15px;
            }

            .preference-info h3 {
                font-size: 14px;
            }

            .preference-info p {
                font-size: 11px;
            }
        }
    </style>
</head>

<body>

<div class="page">

    <div class="topbar">
        <a href="{{ url_for('settings') }}" class="back-button" aria-label="Back">
            ‹
        </a>

        <div class="topbar-text">
            <h1>Notification Preferences</h1>
            <p>Manage your Fairmont Bank notifications</p>
        </div>
    </div>

    <div class="intro">
        <h2>Choose your notifications</h2>
        <p>
            Select the types of notifications you would like to receive
            for your account.
        </p>
    </div>

    <form method="POST">

        <div class="preferences-card">

            <div class="preference-row">
                <div class="preference-info">
                    <h3>Transaction Notifications</h3>
                    <p>
                        Receive notifications about payments, transfers,
                        deposits and other account transactions.
                    </p>
                </div>

                <label class="switch">
                    <input
                        type="checkbox"
                        name="transaction_notifications"
                        {% if customer.transaction_notifications %}checked{% endif %}
                    >
                    <span class="slider"></span>
                </label>
            </div>

            <div class="preference-row">
                <div class="preference-info">
                    <h3>Security Notifications</h3>
                    <p>
                        Receive important security and account-access
                        notifications.
                    </p>
                </div>

                <label class="switch">
                    <input
                        type="checkbox"
                        name="security_notifications"
                        {% if customer.security_notifications %}checked{% endif %}
                    >
                    <span class="slider"></span>
                </label>
            </div>

            <div class="preference-row">
                <div class="preference-info">
                    <h3>Account Notifications</h3>
                    <p>
                        Receive important information about your account
                        and banking services.
                    </p>
                </div>

                <label class="switch">
                    <input
                        type="checkbox"
                        name="account_notifications"
                        {% if customer.account_notifications %}checked{% endif %}
                    >
                    <span class="slider"></span>
                </label>
            </div>

            <div class="preference-row">
                <div class="preference-info">
                    <h3>Promotional Notifications</h3>
                    <p>
                        Receive optional information about offers,
                        promotions and new services.
                    </p>
                </div>

                <label class="switch">
                    <input
                        type="checkbox"
                        name="promotional_notifications"
                        {% if customer.promotional_notifications %}checked{% endif %}
                    >
                    <span class="slider"></span>
                </label>
            </div>

        </div>

        <div class="save-area">
            <button type="submit" class="save-button">
                Save Preferences
            </button>
        </div>

        <div class="note">
            Your notification preferences apply to this Fairmont Bank account.
        </div>

    </form>

</div>

</body>
</html>
'''

TEMPLATE_FILE.write_text(template, encoding="utf-8")

print("SUCCESS: templates/notification_preferences.html created.")
print("")
print("Notification Preferences feature has been installed.")