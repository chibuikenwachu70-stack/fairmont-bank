from pathlib import Path
import re

APP = Path("app.py")
text = APP.read_text(encoding="utf-8-sig")


def replace_function_source(source, function_name, new_source):
    pattern = re.compile(
        rf"(?ms)^def {re.escape(function_name)}\(\):.*?(?=^def |\Z)"
    )

    match = pattern.search(source)

    if not match:
        raise RuntimeError(
            f"Could not find function: {function_name}"
        )

    return source[:match.start()] + new_source.rstrip() + "\n\n" + source[match.end():]


# ------------------------------------------------------------
# 1. Replace customer send_money route
# ------------------------------------------------------------

send_money = r'''
def send_money():
    if "customer_id" not in session:
        return redirect(url_for("login"))

    customer = Customer.query.filter_by(
        customer_id=session["customer_id"]
    ).first()

    if not customer:
        session.clear()
        return redirect(url_for("login"))

    banks = Bank.query.filter_by(
        country="United Kingdom",
        active=True
    ).order_by(Bank.name.asc()).all()

    if request.method == "GET":
        return render_template(
            "send_money.html",
            customer=customer,
            banks=banks
        )

    recipient_name = request.form.get(
        "recipient_name", ""
    ).strip()

    bank_name = request.form.get(
        "bank_name", ""
    ).strip()

    account_number = request.form.get(
        "account_number", ""
    ).strip()

    sort_code = request.form.get(
        "sort_code", ""
    ).strip()

    reference = request.form.get(
        "reference", ""
    ).strip()

    amount_text = request.form.get(
        "amount", ""
    ).strip()

    if not recipient_name:
        flash("Please enter the recipient name.", "error")
        return redirect(url_for("send_money"))

    if not bank_name:
        flash("Please select a bank.", "error")
        return redirect(url_for("send_money"))

    if not re.fullmatch(r"\d{8}", account_number):
        flash("Account number must contain exactly 8 digits.", "error")
        return redirect(url_for("send_money"))

    if not re.fullmatch(r"\d{6}", sort_code):
        flash("Sort code must contain exactly 6 digits.", "error")
        return redirect(url_for("send_money"))

    try:
        amount = float(amount_text)
    except (TypeError, ValueError):
        flash("Please enter a valid amount.", "error")
        return redirect(url_for("send_money"))

    if amount <= 0:
        flash("Payment amount must be greater than zero.", "error")
        return redirect(url_for("send_money"))

    if amount > float(customer.account_balance or 0):
        flash("Insufficient available balance.", "error")
        return redirect(url_for("send_money"))

    bank = Bank.query.filter_by(
        name=bank_name,
        country="United Kingdom",
        active=True
    ).first()

    if not bank:
        flash("The selected UK bank is not available.", "error")
        return redirect(url_for("send_money"))

    recipient_customer = Customer.query.filter_by(
        account_number=account_number
    ).first()

    if recipient_customer and recipient_customer.customer_id == customer.customer_id:
        flash(
            "You cannot send a payment to your own account.",
            "error"
        )
        return redirect(url_for("send_money"))

    payment_reference = generate_transaction_reference()

    if recipient_customer:
        if str(recipient_customer.account_status).lower() != "active":
            flash(
                "The recipient account is not active.",
                "error"
            )
            return redirect(url_for("send_money"))

        approval = PaymentApproval(
            payment_reference=payment_reference,
            customer_id=customer.customer_id,
            payment_type="Bank Transfer",
            direction="Debit",
            amount=amount,
            description=reference or "Bank payment",
            counterparty=recipient_customer.full_name,
            status="Pending Approval",
            recipient_customer_id=recipient_customer.customer_id,
            recipient_name=recipient_customer.full_name,
            recipient_account_number=recipient_customer.account_number,
        )

        db.session.add(approval)
        db.session.commit()

        return render_template(
            "payment_pending_confirmation.html",
            customer=customer,
            approval=approval,
            amount=amount,
            recipient_name=recipient_customer.full_name,
            bank_name=bank_name,
            account_number=account_number,
            sort_code=sort_code,
            reference=reference,
        )

    approval = PaymentApproval(
        payment_reference=payment_reference,
        customer_id=customer.customer_id,
        payment_type="UK Bank Payment",
        direction="Debit",
        amount=amount,
        description=reference or "UK Bank payment",
        counterparty=recipient_name,
        status="Pending Approval",
        recipient_name=recipient_name,
        recipient_account_number=account_number,
    )

    db.session.add(approval)
    db.session.commit()

    return render_template(
        "payment_pending_confirmation.html",
        customer=customer,
        approval=approval,
        amount=amount,
        recipient_name=recipient_name,
        bank_name=bank_name,
        account_number=account_number,
        sort_code=sort_code,
        reference=reference,
    )
'''


# ------------------------------------------------------------
# 2. Replace bill payment route
# ------------------------------------------------------------

pay_bills = r'''
def pay_bills():

    customer = current_user

    if request.method == "GET":
        return render_template(
            "pay_bills.html",
            customer=customer
        )

    bill_category = request.form.get(
        "bill_category",
        ""
    ).strip()

    provider = request.form.get(
        "provider",
        ""
    ).strip()

    account_reference = request.form.get(
        "account_reference",
        ""
    ).strip()

    amount_text = request.form.get(
        "amount",
        ""
    ).strip()

    payment_reference = request.form.get(
        "payment_reference",
        ""
    ).strip()

    errors = []

    allowed_categories = {
        "Electricity",
        "Gas",
        "Water",
        "Council Tax",
        "Broadband",
        "Mobile Phone",
        "Landline",
        "TV & Entertainment",
        "Other Bills"
    }

    if bill_category not in allowed_categories:
        errors.append(
            "Please select a valid bill category."
        )

    if not provider:
        errors.append(
            "Please enter or select the bill provider."
        )

    if not account_reference:
        errors.append(
            "Please enter your customer or account reference."
        )

    try:
        amount = float(amount_text)
    except (TypeError, ValueError):
        amount = 0
        errors.append(
            "Please enter a valid payment amount."
        )

    if amount <= 0:
        if "Please enter a valid payment amount." not in errors:
            errors.append(
                "Payment amount must be greater than £0.00."
            )

    if amount > float(customer.account_balance or 0):
        errors.append(
            "Insufficient available balance."
        )

    if errors:
        return render_template(
            "pay_bills.html",
            customer=customer,
            errors=errors,
            form=request.form
        )

    approval = PaymentApproval(
        payment_reference=generate_transaction_reference(),
        customer_id=customer.customer_id,
        payment_type="Bill Payment",
        direction="Debit",
        amount=amount,
        description=(
            f"{bill_category} payment - "
            f"Account: {account_reference}"
            + (
                f" - Ref: {payment_reference}"
                if payment_reference else ""
            )
        ),
        counterparty=provider,
        status="Pending Approval",
    )

    db.session.add(approval)
    db.session.commit()

    return render_template(
        "payment_pending_confirmation.html",
        customer=customer,
        approval=approval,
        amount=amount,
        recipient_name=provider,
        bank_name="Bill Payment",
        account_number=account_reference,
        sort_code="",
        reference=payment_reference,
    )
'''


# ------------------------------------------------------------
# 3. Replace electricity payment route
# ------------------------------------------------------------

electric_bills = r'''
def electric_bills():

    customer = current_user

    if request.method == "GET":
        return render_template(
            "electric_bills.html",
            customer=customer
        )

    provider = request.form.get(
        "provider",
        ""
    ).strip()

    meter_number = request.form.get(
        "meter_number",
        ""
    ).strip()

    amount_text = request.form.get(
        "amount",
        ""
    ).strip()

    payment_reference = request.form.get(
        "payment_reference",
        ""
    ).strip()

    errors = []

    if not provider:
        errors.append("Please enter the electricity provider.")

    if not meter_number:
        errors.append("Please enter the meter or account number.")

    try:
        amount = float(amount_text)
    except (TypeError, ValueError):
        amount = 0

    if amount <= 0:
        errors.append("Please enter a valid payment amount.")

    if amount > float(customer.account_balance or 0):
        errors.append("Insufficient balance for this payment.")

    if errors:
        return render_template(
            "electric_bills.html",
            customer=customer,
            errors=errors,
            provider=provider,
            meter_number=meter_number,
            amount=amount_text,
            payment_reference=payment_reference
        )

    approval = PaymentApproval(
        payment_reference=generate_transaction_reference(),
        customer_id=customer.customer_id,
        payment_type="Electricity Bill",
        direction="Debit",
        amount=amount,
        description=(
            f"Electricity bill payment - Meter: {meter_number}"
            + (
                f" - Ref: {payment_reference}"
                if payment_reference else ""
            )
        ),
        counterparty=provider,
        status="Pending Approval",
    )

    db.session.add(approval)
    db.session.commit()

    return render_template(
        "payment_pending_confirmation.html",
        customer=customer,
        approval=approval,
        amount=amount,
        recipient_name=provider,
        bank_name="Electricity Bill",
        account_number=meter_number,
        sort_code="",
        reference=payment_reference,
    )
'''


# ------------------------------------------------------------
# 4. Replace airtime route
# ------------------------------------------------------------

airtime = r'''
def airtime():

    customer = current_user

    if request.method == "GET":
        return render_template(
            "airtime.html",
            customer=customer
        )

    provider = request.form.get(
        "provider", ""
    ).strip()

    phone_number = request.form.get(
        "phone_number", ""
    ).strip()

    amount_text = request.form.get(
        "amount", ""
    ).strip()

    payment_reference = request.form.get(
        "payment_reference", ""
    ).strip()

    errors = []

    if not provider:
        errors.append("Please select a mobile network.")

    if not phone_number:
        errors.append("Please enter the mobile phone number.")

    try:
        amount = float(amount_text)
    except (TypeError, ValueError):
        amount = 0

    if amount <= 0:
        errors.append("Please enter a valid airtime amount.")

    if amount > float(customer.account_balance or 0):
        errors.append("Insufficient balance for this airtime purchase.")

    if errors:
        return render_template(
            "airtime.html",
            customer=customer,
            errors=errors,
            provider=provider,
            phone_number=phone_number,
            amount=amount_text,
            payment_reference=payment_reference
        )

    approval = PaymentApproval(
        payment_reference=generate_transaction_reference(),
        customer_id=customer.customer_id,
        payment_type="Airtime Purchase",
        direction="Debit",
        amount=amount,
        description=(
            f"Mobile airtime purchase - "
            f"Phone: {phone_number}"
            + (
                f" - Ref: {payment_reference}"
                if payment_reference else ""
            )
        ),
        counterparty=provider,
        status="Pending Approval",
    )

    db.session.add(approval)
    db.session.commit()

    return render_template(
        "payment_pending_confirmation.html",
        customer=customer,
        approval=approval,
        amount=amount,
        recipient_name=provider,
        bank_name="Mobile Airtime",
        account_number=phone_number,
        sort_code="",
        reference=payment_reference,
    )
'''


# ------------------------------------------------------------
# 5. Replace data bundle route
# ------------------------------------------------------------

data_bundles = r'''
def data_bundles():

    customer = current_user

    networks = [
        "EE",
        "O2",
        "Vodafone",
        "Three UK",
        "Tesco Mobile",
        "giffgaff",
        "Lebara",
        "Lycamobile",
        "Other Mobile Network"
    ]

    bundles = [
        {"name": "500 MB", "amount": 2.00},
        {"name": "1 GB", "amount": 5.00},
        {"name": "2 GB", "amount": 8.00},
        {"name": "5 GB", "amount": 12.00},
        {"name": "10 GB", "amount": 18.00},
        {"name": "20 GB", "amount": 25.00},
        {"name": "30 GB", "amount": 30.00},
        {"name": "50 GB", "amount": 40.00},
    ]

    if request.method == "GET":
        return render_template(
            "data_bundles.html",
            customer=customer,
            networks=networks,
            bundles=bundles
        )

    provider = request.form.get(
        "provider", ""
    ).strip()

    phone_number = request.form.get(
        "phone_number", ""
    ).strip()

    bundle_name = request.form.get(
        "bundle_name", ""
    ).strip()

    payment_reference = request.form.get(
        "payment_reference", ""
    ).strip()

    errors = []

    if provider not in networks:
        errors.append("Please select a mobile network.")

    if not phone_number:
        errors.append("Please enter the mobile phone number.")

    selected_bundle = None

    for bundle in bundles:
        if bundle["name"] == bundle_name:
            selected_bundle = bundle
            break

    if selected_bundle is None:
        errors.append("Please select a valid data bundle.")

    amount = selected_bundle["amount"] if selected_bundle else 0.0

    if amount > float(customer.account_balance or 0):
        errors.append(
            "Insufficient balance for this data bundle purchase."
        )

    if errors:
        return render_template(
            "data_bundles.html",
            customer=customer,
            networks=networks,
            bundles=bundles,
            errors=errors,
            provider=provider,
            phone_number=phone_number,
            bundle_name=bundle_name,
            payment_reference=payment_reference
        )

    approval = PaymentApproval(
        payment_reference=generate_transaction_reference(),
        customer_id=customer.customer_id,
        payment_type="Data Bundle Purchase",
        direction="Debit",
        amount=amount,
        description=(
            f"{bundle_name} mobile data bundle - "
            f"Phone: {phone_number}"
            + (
                f" - Ref: {payment_reference}"
                if payment_reference else ""
            )
        ),
        counterparty=provider,
        status="Pending Approval",
    )

    db.session.add(approval)
    db.session.commit()

    return render_template(
        "payment_pending_confirmation.html",
        customer=customer,
        approval=approval,
        amount=amount,
        recipient_name=provider,
        bank_name="Mobile Data",
        account_number=phone_number,
        sort_code="",
        reference=payment_reference,
    )
'''


# ------------------------------------------------------------
# 6. Replace TV subscription route
# ------------------------------------------------------------

tv_subscriptions = r'''
def tv_subscriptions():

    customer = current_user

    providers = [
        "Sky",
        "Virgin Media",
        "NOW TV",
        "BT TV",
        "EE TV",
        "Other TV Provider"
    ]

    packages = {
        "Sky": [
            {"name": "Sky Entertainment", "amount": 26.00},
            {"name": "Sky Cinema", "amount": 13.00},
            {"name": "Sky Sports", "amount": 25.00},
        ],
        "Virgin Media": [
            {"name": "Mixit TV", "amount": 30.00},
            {"name": "Maxit TV", "amount": 50.00},
            {"name": "Sports TV", "amount": 25.00},
        ],
        "NOW TV": [
            {"name": "Entertainment Membership", "amount": 9.99},
            {"name": "Cinema Membership", "amount": 9.99},
            {"name": "Sports Membership", "amount": 34.99},
        ],
        "BT TV": [
            {"name": "Entertainment", "amount": 18.00},
            {"name": "Big Entertainment", "amount": 25.00},
            {"name": "Sports", "amount": 30.00},
        ],
        "EE TV": [
            {"name": "Entertainment", "amount": 20.00},
            {"name": "Sports", "amount": 30.00},
        ],
        "Other TV Provider": [
            {"name": "Standard Subscription", "amount": 20.00},
            {"name": "Premium Subscription", "amount": 35.00},
        ]
    }

    if request.method == "GET":
        return render_template(
            "tv_subscriptions.html",
            customer=customer,
            providers=providers,
            packages=packages
        )

    provider = request.form.get(
        "provider", ""
    ).strip()

    package_name = request.form.get(
        "package_name", ""
    ).strip()

    account_reference = request.form.get(
        "account_reference", ""
    ).strip()

    payment_reference = request.form.get(
        "payment_reference", ""
    ).strip()

    errors = []

    if provider not in providers:
        errors.append("Please select a TV provider.")

    if not account_reference:
        errors.append(
            "Please enter your TV account or customer number."
        )

    selected_package = None

    if provider in packages:
        for package in packages[provider]:
            if package["name"] == package_name:
                selected_package = package
                break

    if selected_package is None:
        errors.append(
            "Please select a valid TV subscription package."
        )

    amount = selected_package["amount"] if selected_package else 0.0

    if amount > float(customer.account_balance or 0):
        errors.append(
            "Insufficient balance for this TV subscription payment."
        )

    if errors:
        return render_template(
            "tv_subscriptions.html",
            customer=customer,
            providers=providers,
            packages=packages,
            errors=errors,
            provider=provider,
            package_name=package_name,
            account_reference=account_reference,
            payment_reference=payment_reference
        )

    approval = PaymentApproval(
        payment_reference=generate_transaction_reference(),
        customer_id=customer.customer_id,
        payment_type="TV Subscription",
        direction="Debit",
        amount=amount,
        description=(
            f"{provider} - {package_name} - "
            f"Account: {account_reference}"
            + (
                f" - Ref: {payment_reference}"
                if payment_reference else ""
            )
        ),
        counterparty=provider,
        status="Pending Approval",
    )

    db.session.add(approval)
    db.session.commit()

    return render_template(
        "payment_pending_confirmation.html",
        customer=customer,
        approval=approval,
        amount=amount,
        recipient_name=provider,
        bank_name="TV Subscription",
        account_number=account_reference,
        sort_code="",
        reference=payment_reference,
    )
'''


# ------------------------------------------------------------
# 7. Replace lifestyle route
# ------------------------------------------------------------

lifestyle = r'''
def lifestyle():

    customer = current_user

    lifestyle_categories = [
        "Restaurants & Dining",
        "Shopping",
        "Entertainment",
        "Fitness & Wellness",
        "Beauty & Personal Care",
        "Travel & Leisure",
        "Events & Tickets",
        "Other Lifestyle"
    ]

    if request.method == "GET":
        return render_template(
            "lifestyle.html",
            customer=customer,
            categories=lifestyle_categories
        )

    category = request.form.get(
        "category", ""
    ).strip()

    merchant = request.form.get(
        "merchant", ""
    ).strip()

    account_reference = request.form.get(
        "account_reference", ""
    ).strip()

    amount_text = request.form.get(
        "amount", ""
    ).strip()

    payment_reference = request.form.get(
        "payment_reference", ""
    ).strip()

    errors = []

    if category not in lifestyle_categories:
        errors.append("Please select a lifestyle category.")

    if not merchant:
        errors.append("Please enter the merchant or service name.")

    if not account_reference:
        errors.append(
            "Please enter the customer or order reference."
        )

    try:
        amount = float(amount_text)
    except (TypeError, ValueError):
        amount = 0

    if amount <= 0:
        errors.append("Please enter a valid payment amount.")

    if amount > float(customer.account_balance or 0):
        errors.append(
            "Insufficient balance for this lifestyle payment."
        )

    if errors:
        return render_template(
            "lifestyle.html",
            customer=customer,
            categories=lifestyle_categories,
            errors=errors,
            category=category,
            merchant=merchant,
            account_reference=account_reference,
            amount=amount_text,
            payment_reference=payment_reference
        )

    approval = PaymentApproval(
        payment_reference=generate_transaction_reference(),
        customer_id=customer.customer_id,
        payment_type="Lifestyle Payment",
        direction="Debit",
        amount=amount,
        description=(
            f"{category} payment - "
            f"Reference: {account_reference}"
            + (
                f" - Ref: {payment_reference}"
                if payment_reference else ""
            )
        ),
        counterparty=merchant,
        status="Pending Approval",
    )

    db.session.add(approval)
    db.session.commit()

    return render_template(
        "payment_pending_confirmation.html",
        customer=customer,
        approval=approval,
        amount=amount,
        recipient_name=merchant,
        bank_name="Lifestyle Payment",
        account_number=account_reference,
        sort_code="",
        reference=payment_reference,
    )
'''


# ------------------------------------------------------------
# 8. Replace flights/travel route
# ------------------------------------------------------------

flights_travel = r'''
def flights_travel():

    customer = current_user

    travel_categories = [
        "Flight Booking",
        "Hotel Booking",
        "Airport Transfer",
        "Travel Insurance",
        "Train & Rail",
        "Bus & Coach",
        "Car Rental",
        "Other Travel"
    ]

    if request.method == "GET":
        return render_template(
            "flights_travel.html",
            customer=customer,
            categories=travel_categories
        )

    category = request.form.get(
        "category", ""
    ).strip()

    provider = request.form.get(
        "provider", ""
    ).strip()

    traveler_name = request.form.get(
        "traveler_name", ""
    ).strip()

    booking_reference = request.form.get(
        "booking_reference", ""
    ).strip()

    amount_text = request.form.get(
        "amount", ""
    ).strip()

    payment_reference = request.form.get(
        "payment_reference", ""
    ).strip()

    errors = []

    if category not in travel_categories:
        errors.append("Please select a travel service.")

    if not provider:
        errors.append(
            "Please enter the airline, hotel, or travel provider."
        )

    if not traveler_name:
        errors.append("Please enter the traveler name.")

    if not booking_reference:
        errors.append(
            "Please enter the booking or travel reference."
        )

    try:
        amount = float(amount_text)
    except (TypeError, ValueError):
        amount = 0

    if amount <= 0:
        errors.append("Please enter a valid payment amount.")

    if amount > float(customer.account_balance or 0):
        errors.append(
            "Insufficient balance for this travel payment."
        )

    if errors:
        return render_template(
            "flights_travel.html",
            customer=customer,
            categories=travel_categories,
            errors=errors,
            category=category,
            provider=provider,
            traveler_name=traveler_name,
            booking_reference=booking_reference,
            amount=amount_text,
            payment_reference=payment_reference
        )

    approval = PaymentApproval(
        payment_reference=generate_transaction_reference(),
        customer_id=customer.customer_id,
        payment_type="Travel Payment",
        direction="Debit",
        amount=amount,
        description=(
            f"{category} payment - "
            f"Traveler: {traveler_name} - "
            f"Booking: {booking_reference}"
            + (
                f" - Ref: {payment_reference}"
                if payment_reference else ""
            )
        ),
        counterparty=provider,
        status="Pending Approval",
    )

    db.session.add(approval)
    db.session.commit()

    return render_template(
        "payment_pending_confirmation.html",
        customer=customer,
        approval=approval,
        amount=amount,
        recipient_name=provider,
        bank_name="Travel Payment",
        account_number=booking_reference,
        sort_code="",
        reference=payment_reference,
    )
'''


# ------------------------------------------------------------
# Replace the selected functions.
# ------------------------------------------------------------

for function_name, function_source in [
    ("send_money", send_money),
    ("pay_bills", pay_bills),
    ("electric_bills", electric_bills),
    ("airtime", airtime),
    ("data_bundles", data_bundles),
    ("tv_subscriptions", tv_subscriptions),
    ("lifestyle", lifestyle),
    ("flights_travel", flights_travel),
]:
    text = replace_function_source(
        text,
        function_name,
        function_source
    )


# ------------------------------------------------------------
# 9. Add approval/rejection routes before admin incoming payment.
# ------------------------------------------------------------

if 'def admin_review_payment():' not in text:

    marker = '\ndef admin_incoming_payment():'

    if marker not in text:
        raise RuntimeError(
            "Could not find admin_incoming_payment route."
        )

    approval_routes = r'''

@app.route(
    "/admin/payment-approval/<int:approval_id>",
    methods=["GET", "POST"]
)
def admin_review_payment(approval_id):

    admin_id = session.get("admin_id")

    if not admin_id:
        return redirect(url_for("admin_login"))

    admin = db.session.get(AdminUser, admin_id)

    if admin is None or not admin.is_active:
        session.pop("admin_id", None)
        session.pop("admin_username", None)
        return redirect(url_for("admin_login"))

    approval = db.session.get(
        PaymentApproval,
        approval_id
    )

    if approval is None:
        return redirect(url_for("admin_payment_approvals"))

    customer = Customer.query.filter_by(
        customer_id=approval.customer_id
    ).first()

    recipient = None

    if approval.recipient_customer_id:
        recipient = Customer.query.filter_by(
            customer_id=approval.recipient_customer_id
        ).first()

    if request.method == "GET":
        return render_template(
            "admin_payment_approval_review.html",
            admin=admin,
            approval=approval,
            customer=customer,
            recipient=recipient
        )

    action = request.form.get(
        "action",
        ""
    ).strip().lower()

    if approval.status != "Pending Approval":
        flash(
            "This payment has already been reviewed.",
            "error"
        )
        return redirect(
            url_for(
                "admin_review_payment",
                approval_id=approval.id
            )
        )

    if action == "reject":

        rejection_reason = request.form.get(
            "rejection_reason",
            ""
        ).strip()

        approval.status = "Rejected"
        approval.reviewed_at = datetime.utcnow()
        approval.reviewed_by = admin.username
        approval.rejection_reason = (
            rejection_reason
            or "Payment rejected by Fairmont Bank Support."
        )

        db.session.commit()

        flash(
            "Payment request rejected. No customer balance was changed.",
            "success"
        )

        return redirect(
            url_for(
                "admin_payment_approvals",
                status="Pending Approval"
            )
        )

    if action != "approve":
        flash("Invalid approval action.", "error")
        return redirect(
            url_for(
                "admin_review_payment",
                approval_id=approval.id
            )
        )

    if customer is None:
        flash(
            "The customer account associated with this payment could not be found.",
            "error"
        )
        return redirect(
            url_for(
                "admin_review_payment",
                approval_id=approval.id
            )
        )

    if str(customer.account_status).lower() != "active":
        flash(
            "The customer account is not active.",
            "error"
        )
        return redirect(
            url_for(
                "admin_review_payment",
                approval_id=approval.id
            )
        )

    amount = float(approval.amount)

    # Internal Fairmont transfer:
    # debit sender and credit recipient in the same database transaction.
    if (
        approval.payment_type == "Bank Transfer"
        and approval.recipient_customer_id
    ):

        if recipient is None:
            flash(
                "The recipient account could not be found.",
                "error"
            )
            return redirect(
                url_for(
                    "admin_review_payment",
                    approval_id=approval.id
                )
            )

        if str(recipient.account_status).lower() != "active":
            flash(
                "The recipient account is not active.",
                "error"
            )
            return redirect(
                url_for(
                    "admin_review_payment",
                    approval_id=approval.id
                )
            )

        current_sender_balance = float(
            customer.account_balance or 0
        )

        if amount > current_sender_balance:
            flash(
                "The sender no longer has sufficient available balance.",
                "error"
            )
            return redirect(
                url_for(
                    "admin_review_payment",
                    approval_id=approval.id
                )
            )

        sender_new_balance = (
            current_sender_balance - amount
        )

        recipient_new_balance = (
            float(recipient.account_balance or 0)
            + amount
        )

        customer.account_balance = sender_new_balance
        recipient.account_balance = recipient_new_balance

        sender_transaction = Transaction(
            transaction_reference=generate_transaction_reference(),
            customer_id=customer.customer_id,
            transaction_type="Bank Transfer",
            direction="Debit",
            amount=amount,
            balance_after=sender_new_balance,
            description=approval.description,
            counterparty=recipient.full_name,
            status="Completed"
        )

        recipient_transaction = Transaction(
            transaction_reference=generate_transaction_reference(),
            customer_id=recipient.customer_id,
            transaction_type="Bank Transfer",
            direction="Credit",
            amount=amount,
            balance_after=recipient_new_balance,
            description=approval.description,
            counterparty=customer.full_name,
            status="Completed"
        )

        db.session.add(sender_transaction)
        db.session.add(recipient_transaction)

    else:

        current_balance = float(
            customer.account_balance or 0
        )

        if approval.direction == "Debit":

            if amount > current_balance:
                flash(
                    "The customer no longer has sufficient available balance.",
                    "error"
                )
                return redirect(
                    url_for(
                        "admin_review_payment",
                        approval_id=approval.id
                    )
                )

            new_balance = current_balance - amount
            customer.account_balance = new_balance

            transaction = Transaction(
                transaction_reference=generate_transaction_reference(),
                customer_id=customer.customer_id,
                transaction_type=approval.payment_type,
                direction="Debit",
                amount=amount,
                balance_after=new_balance,
                description=approval.description,
                counterparty=approval.counterparty,
                status="Completed"
            )

            db.session.add(transaction)

        elif approval.direction == "Credit":

            new_balance = current_balance + amount
            customer.account_balance = new_balance

            transaction = Transaction(
                transaction_reference=generate_transaction_reference(),
                customer_id=customer.customer_id,
                transaction_type=approval.payment_type,
                direction="Credit",
                amount=amount,
                balance_after=new_balance,
                description=approval.description,
                counterparty=approval.counterparty,
                status="Completed",
                sender_name=approval.sender_name,
                sender_account_number=approval.sender_account_number,
                sender_bank=approval.sender_bank,
                sender_country=approval.sender_country
            )

            db.session.add(transaction)

        else:
            flash(
                "Unsupported payment direction.",
                "error"
            )
            return redirect(
                url_for(
                    "admin_review_payment",
                    approval_id=approval.id
                )
            )

    approval.status = "Approved"
    approval.reviewed_at = datetime.utcnow()
    approval.reviewed_by = admin.username

    db.session.commit()

    flash(
        "Payment approved successfully and the account balance has been updated.",
        "success"
    )

    return redirect(
        url_for(
            "admin_payment_approvals",
            status="Pending Approval"
        )
    )


@app.route(
    "/admin/payment-approval/<int:approval_id>/reject",
    methods=["POST"]
)
def admin_reject_payment(approval_id):

    admin_id = session.get("admin_id")

    if not admin_id:
        return redirect(url_for("admin_login"))

    admin = db.session.get(AdminUser, admin_id)

    if admin is None or not admin.is_active:
        session.pop("admin_id", None)
        session.pop("admin_username", None)
        return redirect(url_for("admin_login"))

    approval = db.session.get(
        PaymentApproval,
        approval_id
    )

    if approval is None:
        return redirect(url_for("admin_payment_approvals"))

    if approval.status != "Pending Approval":
        flash(
            "This payment has already been reviewed.",
            "error"
        )
        return redirect(
            url_for(
                "admin_payment_approvals",
                status="Pending Approval"
            )
        )

    approval.status = "Rejected"
    approval.reviewed_at = datetime.utcnow()
    approval.reviewed_by = admin.username
    approval.rejection_reason = (
        request.form.get(
            "rejection_reason",
            ""
        ).strip()
        or "Payment rejected by Fairmont Bank Support."
    )

    db.session.commit()

    flash(
        "Payment request rejected. No customer balance was changed.",
        "success"
    )

    return redirect(
        url_for(
            "admin_payment_approvals",
            status="Pending Approval"
        )
    )
'''

    text = text.replace(
        marker,
        approval_routes + marker,
        1
    )


APP.write_text(text, encoding="utf-8")

print("SUCCESS: Payment approval workflow routes installed.")
print("Existing completed transaction records were not modified.")