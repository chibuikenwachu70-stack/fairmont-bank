from pathlib import Path
from datetime import datetime
import shutil
import zipfile

PROJECT = Path(__file__).resolve().parent
DOCUMENTS = PROJECT.parent

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

BACKUP_ROOT = DOCUMENTS / "FairmontBankBackups"
BACKUP_FOLDER = BACKUP_ROOT / f"NewBankSite_BACKUP_{timestamp}"
ZIP_FILE = BACKUP_ROOT / f"NewBankSite_BACKUP_{timestamp}.zip"

BACKUP_ROOT.mkdir(parents=True, exist_ok=True)
BACKUP_FOLDER.mkdir(parents=True, exist_ok=True)

EXCLUDED_DIRS = {
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
}

EXCLUDED_NAMES = {
    ".DS_Store",
}

# ---------------------------------------------------------
# COPY PROJECT
# ---------------------------------------------------------

for source in PROJECT.rglob("*"):

    if not source.is_file():
        continue

    relative = source.relative_to(PROJECT)

    if any(part in EXCLUDED_DIRS for part in relative.parts):
        continue

    if source.name in EXCLUDED_NAMES:
        continue

    destination = BACKUP_FOLDER / relative
    destination.parent.mkdir(parents=True, exist_ok=True)

    shutil.copy2(source, destination)

# ---------------------------------------------------------
# CREATE ZIP BACKUP
# ---------------------------------------------------------

with zipfile.ZipFile(
    ZIP_FILE,
    "w",
    compression=zipfile.ZIP_DEFLATED
) as archive:

    for file in BACKUP_FOLDER.rglob("*"):

        if file.is_file():

            archive_name = (
                Path(BACKUP_FOLDER.name) /
                file.relative_to(BACKUP_FOLDER)
            )

            archive.write(
                file,
                archive_name
            )

print()
print("=" * 70)
print("FAIRMONT BANK BACKUP COMPLETE")
print("=" * 70)
print()
print("Project:")
print(PROJECT)
print()
print("Backup folder:")
print(BACKUP_FOLDER)
print()
print("ZIP backup:")
print(ZIP_FILE)
print()
print("The backup includes:")
print("  - app.py")
print("  - templates")
print("  - static files")
print("  - Fairmont database")
print("  - customer/account data")
print("  - transfer files")
print("  - migration scripts")
print("  - current welcome page design")
print("  - current login design")
print()
print("Excluded:")
print("  - __pycache__")
print("  - temporary Python cache files")
print()
print("IMPORTANT: The original project was NOT modified.")
print("=" * 70)