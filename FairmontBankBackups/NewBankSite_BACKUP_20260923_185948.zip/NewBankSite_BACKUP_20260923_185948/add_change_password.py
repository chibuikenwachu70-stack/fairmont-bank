from pathlib import Path
import re
import shutil
from datetime import datetime

BASE = Path(r"C:\Users\DON J\Documents\NewBankSite")
APP = BASE / "app.py"
SETTINGS = BASE / "templates" / "settings.html"

# ---------------------------------------------------------
# BACKUP
# ---------------------------------------------------------

backup_dir = BASE / "change_password_backup"
backup_dir.mkdir(exist_ok=True)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

shutil.copy2(
    APP,
    backup_dir / f"app.py_{timestamp}.bak"
)

shutil.copy2(
    SETTINGS,
    backup_dir / f"settings.html_{timestamp}.bak"
)

# ---------------------------------------------------------
# CREATE CHANGE PASSWORD PAGE
# ---------------------------------------------------------

password_html = r'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Change Password - Fairmont Bank</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            background:
                radial-gradient(circle at top left, rgba(35, 76, 125, 0.28), transparent 38%),
                linear-gradient(180deg, #07182d 0%, #061426 100%);
            color: #ffffff;
            font-family: Arial, Helvetica, sans-serif;
        }

        .password-page {
            width: 100%;
            max-width: 620px;
            margin: 0 auto;
            padding: 22px 18px 45px;
        }

        .password-header {
            display: flex;
            align-items: center;
            gap: 14px;
            margin-bottom: 25px;
        }

        .back-button {
            width: 42px;
            height: 42px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            color: #ffffff;
            background: rgba(255,255,255,0.07);
            border: 1px solid rgba(255,255,255,0.10);
            font-size: 22px;
        }

        .password-title {
            margin: 0;
            font-size: 24px;
            font-weight: 700;
        }

        .password-subtitle {
            margin: 4px 0 0;
            color: rgba(255,255,255,0.60);
            font-size: 13px;
        }

        .password-card {
            background: rgba(13, 34, 59, 0.84);
            border: 1px solid rgba(255,255,255,0.09);
            border-radius: 18px;
            padding: 22px;
            box-shadow: 0 12px 30px rgba(0,0,0,0.18);
        }

        .form-group {
            margin-bottom: 18px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            color: rgba(255,255,255,0.70);
            font-size: 12px;
            font-weight: 600;
        }

        .password-input {
            width: 100%;
            height: 48px;
            padding: 0 14px;
            border-radius: 12px;
            border: 1px solid rgba(255,255,255,0.10);
            background: rgba(255,255,255,0.055);
            color: #ffffff;
            outline: none;
            font-size: 14px;
        }

        .password-input:focus {
            border-color: rgba(110,170,230,0.55);
            background: rgba(255,255,255,0.075);
        }

        .password-input::placeholder {
            color: rgba(255,255,255,0.32);
        }

        .requirements {
            margin: 3px 0 20px;
            color: rgba(255,255,255,0.48);
            font-size: 12px;
            line-height: 1.5;
        }

        .submit-button {
            width: 100%;
            height: 48px;
            border: none;
            border-radius: 12px;
            background: #1f5d96;
            color: #ffffff;
            font-size: 14px;
            font-weight: 700;
            cursor: pointer;
        }

        .submit-button:hover {
            background: #276da9;
        }

        .message {
            margin-bottom: 18px;
            padding: 13px 14px;
            border-radius: 11px;
            font-size: 12px;
            line-height: 1.45;
        }

        .error-message {
            background: rgba(180,55,55,0.15);
            border: 1px solid rgba(230,90,90,0.22);
            color: #ffb0b0;
        }

        .success-message {
            background: rgba(65,155,105,0.15);
            border: 1px solid rgba(90,190,130,0.22);
            color: #9de0b7;
        }

        @media (max-width: 600px) {

            .password-page {
                padding: 18px 14px 35px;
            }

            .password-title {
                font-size: 22px;
            }

            .password-card {
                padding: 18px;
            }
        }
    </style>
</head>

<body>

<div class="password-page">

    <div class="password-header">

        <a href="{{ url_for('settings') }}" class="back-button">
            ‹
        </a>

        <div>
            <h1 class="password-title">
                Change Password
            </h1>

            <p class="password-subtitle">
                Update your Fairmont Bank sign-in password
            </p>
        </div>

    </div>


    <div class="password-card">

        {% with messages = get_flashed_messages(with_categories=true) %}

            {% if messages %}

                {% for category, message in messages %}

                    <div class="message
                        {% if category == 'success' %}
                            success-message
                        {% else %}
                            error-message
                        {% endif %}">

                        {{ message }}

                    </div>

                {% endfor %}

            {% endif %}

        {% endwith %}


        <form method="POST" action="{{ url_for('change_password') }}">

            <div class="form-group">

                <label class="form-label" for="current_password">
                    Current Password
                </label>

                <input
                    class="password-input"
                    type="password"
                    id="current_password"
                    name="current_password"
                    placeholder="Enter your current password"
                    required
                    autocomplete="current-password">

            </div>


            <div class="form-group">

                <label class="form-label" for="new_password">
                    New Password
                </label>

                <input
                    class="password-input"
                    type="password"
                    id="new_password"
                    name="new_password"
                    placeholder="Enter your new password"
                    required
                    minlength="8"
                    autocomplete="new-password">

            </div>


            <div class="form-group">

                <label class="form-label" for="confirm_password">
                    Confirm New Password
                </label>

                <input
                    class="password-input"
                    type="password"
                    id="confirm_password"
                    name="confirm_password"
                    placeholder="Confirm your new password"
                    required
                    minlength="8"
                    autocomplete="new-password">

            </div>


            <p class="requirements">
                Your new password must contain at least 8 characters.
            </p>


            <button type="submit" class="submit-button">
                Change Password
            </button>

        </form>

    </div>

</div>

</body>
</html>
'''

PASSWORD_PAGE = BASE / "templates" / "change_password.html"

PASSWORD_PAGE.write_text(
    password_html,
    encoding="utf-8"
)

# ---------------------------------------------------------
# ADD CHANGE PASSWORD ROUTE
# ---------------------------------------------------------

app_text = APP.read_text(encoding="utf-8")

route = r'''

@app.route("/change-password", methods=["GET", "POST"])
@login_required
def change_password():

    customer = current_user

    if request.method == "POST":

        current_password = request.form.get(
            "current_password",
            ""
        )

        new_password = request.form.get(
            "new_password",
            ""
        )

        confirm_password = request.form.get(
            "confirm_password",
            ""
        )

        # Verify current password
        if not check_password_hash(
            customer.password_hash,
            current_password
        ):
            flash(
                "Your current password is incorrect.",
                "error"
            )

            return render_template(
                "change_password.html",
                customer=customer
            )

        # Validate new password length
        if len(new_password) < 8:
            flash(
                "Your new password must contain at least 8 characters.",
                "error"
            )

            return render_template(
                "change_password.html",
                customer=customer
            )

        # Confirm new password
        if new_password != confirm_password:
            flash(
                "The new passwords do not match.",
                "error"
            )

            return render_template(
                "change_password.html",
                customer=customer
            )

        # Do not allow the same password
        if check_password_hash(
            customer.password_hash,
            new_password
        ):
            flash(
                "Your new password must be different from your current password.",
                "error"
            )

            return render_template(
                "change_password.html",
                customer=customer
            )

        # Save the new hashed password
        customer.password_hash = generate_password_hash(
            new_password
        )

        db.session.commit()

        flash(
            "Your password has been changed successfully.",
            "success"
        )

        return redirect(
            url_for("settings")
        )

    return render_template(
        "change_password.html",
        customer=customer
    )

'''

if "def change_password()" not in app_text:

    marker = '\nif __name__ == "__main__":'

    if marker not in app_text:
        raise RuntimeError(
            "Could not find the final app.run section in app.py."
        )

    app_text = app_text.replace(
        marker,
        route + marker,
        1
    )

    APP.write_text(
        app_text,
        encoding="utf-8"
    )

# ---------------------------------------------------------
# MAKE SETTINGS CARD CLICKABLE
# ---------------------------------------------------------

settings_text = SETTINGS.read_text(encoding="utf-8")

old_block = '''<div class="settings-card">

        <div class="settings-icon">
            🔑
        </div>

        <div class="settings-content">

            <p class="settings-name">
                Change Password
            </p>

            <p class="settings-description">
                Change the password used to sign in to your account.
            </p>

        </div>

        <div class="settings-arrow">
            ›
        </div>

    </div>'''

new_block = '''<a
        href="{{ url_for('change_password') }}"
        class="settings-card"
        style="text-decoration:none; color:inherit;">

        <div class="settings-icon">
            🔑
        </div>

        <div class="settings-content">

            <p class="settings-name">
                Change Password
            </p>

            <p class="settings-description">
                Change the password used to sign in to your account.
            </p>

        </div>

        <div class="settings-arrow">
            ›
        </div>

    </a>'''

if old_block in settings_text:

    settings_text = settings_text.replace(
        old_block,
        new_block,
        1
    )

    SETTINGS.write_text(
        settings_text,
        encoding="utf-8"
    )

else:
    print()
    print("WARNING: Change Password settings card was not found.")
    print("The page and route were still created.")

# ---------------------------------------------------------
# DONE
# ---------------------------------------------------------

print()
print("==============================================")
print("CHANGE PASSWORD INSTALLED")
print("==============================================")
print()
print("New page:")
print("  /change-password")
print()
print("Security checks:")
print("  Current password verification")
print("  Minimum 8-character password")
print("  Password confirmation")
print("  Prevents reusing the same password")
print("  New password stored as a secure hash")
print()
print("Existing account data was not modified.")
print()
print("Backup created in:")
print("  change_password_backup")
print()