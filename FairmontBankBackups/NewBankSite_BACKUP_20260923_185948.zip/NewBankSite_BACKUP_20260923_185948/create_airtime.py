from pathlib import Path

BASE = Path(__file__).resolve().parent
APP = BASE / "app.py"
TEMPLATES = BASE / "templates"

app_text = APP.read_text(encoding="utf-8")

if '@app.route("/airtime"' in app_text:
    print("NOTICE: Airtime route already exists. Skipping app.py changes.")
else:
    marker = '# START APPLICATION'

    if marker not in app_text:
        raise SystemExit("ERROR: START APPLICATION marker was not found in app.py.")

    route = r'''

@app.route("/airtime", methods=["GET", "POST"])
@login_required
def airtime():
    customer = current_user

    if request.method == "GET":
        return render_template(
            "airtime.html",
            customer=customer
        )

    provider = request.form.get("provider", "").strip()
    phone_number = request.form.get("phone_number", "").strip()
    amount_text = request.form.get("amount", "").strip()
    payment_reference = request.form.get("payment_reference", "").strip()

    errors = []

    if not provider:
        errors.append("Please select a mobile network.")

    if not phone_number:
        errors.append("Please enter the mobile phone number.")

    try:
        amount = float(amount_text)
    except (TypeError, ValueError):
        amount = 0

    if amount <= 0:
        errors.append("Please enter a valid airtime amount.")

    if amount > float(customer.account_balance):
        errors.append("Insufficient balance for this airtime purchase.")

    if errors:
        return render_template(
            "airtime.html",
            customer=customer,
            errors=errors,
            provider=provider,
            phone_number=phone_number,
            amount=amount_text,
            payment_reference=payment_reference
        )

    new_balance = float(customer.account_balance) - amount
    transaction_reference = generate_transaction_reference()

    customer.account_balance = new_balance

    transaction = Transaction(
        transaction_reference=transaction_reference,
        customer_id=customer.id,
        transaction_type="Airtime Purchase",
        direction="Debit",
        amount=amount,
        balance_after=new_balance,
        description="Mobile airtime purchase",
        counterparty=provider,
        status="Completed"
    )

    db.session.add(transaction)
    db.session.commit()

    return render_template(
        "airtime_confirmation.html",
        customer=customer,
        provider=provider,
        phone_number=phone_number,
        amount=amount,
        payment_reference=payment_reference,
        transaction_reference=transaction_reference,
        new_balance=new_balance
    )
'''

    app_text = app_text.replace(marker, route + "\n" + marker, 1)
    APP.write_text(app_text, encoding="utf-8")
    print("SUCCESS: Airtime route added to app.py.")


TEMPLATES.mkdir(exist_ok=True)

airtime_html = r'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Airtime | Fairmont Bank</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            font-family: Arial, Helvetica, sans-serif;
            background:
                radial-gradient(circle at top right, rgba(47, 104, 180, 0.24), transparent 35%),
                linear-gradient(145deg, #061426, #0a1c34 55%, #061426);
            color: #ffffff;
            padding: 24px 16px 40px;
        }

        .page {
            width: min(720px, 100%);
            margin: 0 auto;
        }

        .top {
            display: flex;
            align-items: center;
            gap: 14px;
            margin-bottom: 24px;
        }

        .back {
            width: 42px;
            height: 42px;
            border-radius: 13px;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            color: #ffffff;
            background: rgba(255,255,255,0.08);
            border: 1px solid rgba(255,255,255,0.10);
            font-size: 22px;
        }

        .brand {
            font-size: 13px;
            letter-spacing: 2px;
            font-weight: 700;
            opacity: 0.72;
        }

        .title {
            font-size: 30px;
            font-weight: 700;
            margin: 5px 0 0;
        }

        .card {
            background: rgba(14, 34, 59, 0.82);
            border: 1px solid rgba(255,255,255,0.09);
            border-radius: 24px;
            padding: 24px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.28);
            backdrop-filter: blur(18px);
        }

        .balance {
            padding: 18px;
            border-radius: 18px;
            background: rgba(255,255,255,0.055);
            margin-bottom: 22px;
        }

        .balance-label {
            font-size: 13px;
            opacity: 0.68;
            margin-bottom: 6px;
        }

        .balance-value {
            font-size: 25px;
            font-weight: 700;
        }

        .field {
            margin-bottom: 18px;
        }

        label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 8px;
            opacity: 0.88;
        }

        input,
        select {
            width: 100%;
            height: 52px;
            border: 1px solid rgba(255,255,255,0.12);
            border-radius: 14px;
            background: rgba(4, 18, 35, 0.78);
            color: #ffffff;
            padding: 0 15px;
            outline: none;
            font-size: 15px;
        }

        input:focus,
        select:focus {
            border-color: rgba(93, 157, 230, 0.7);
        }

        select option {
            background: #0b1c31;
            color: #ffffff;
        }

        .hint {
            margin-top: 7px;
            font-size: 12px;
            opacity: 0.55;
        }

        .errors {
            margin-bottom: 18px;
            padding: 14px 16px;
            border-radius: 14px;
            background: rgba(180, 35, 35, 0.18);
            border: 1px solid rgba(255, 90, 90, 0.25);
            color: #ffd7d7;
        }

        .errors div {
            margin: 3px 0;
        }

        button {
            width: 100%;
            height: 54px;
            border: 0;
            border-radius: 15px;
            background: #ffffff;
            color: #07172a;
            font-size: 15px;
            font-weight: 700;
            cursor: pointer;
            margin-top: 4px;
        }

        button:hover {
            opacity: 0.93;
        }

        .secure {
            text-align: center;
            font-size: 12px;
            opacity: 0.48;
            margin-top: 18px;
        }

        @media (max-width: 480px) {
            body {
                padding: 18px 13px 30px;
            }

            .card {
                padding: 19px;
                border-radius: 20px;
            }

            .title {
                font-size: 26px;
            }
        }
    </style>
</head>

<body>
<div class="page">

    <div class="top">
        <a class="back" href="{{ url_for('services') }}">‹</a>

        <div>
            <div class="brand">FAIRMONT BANK</div>
            <div class="title">Airtime</div>
        </div>
    </div>

    <div class="card">

        <div class="balance">
            <div class="balance-label">Available Balance</div>
            <div class="balance-value">
                £{{ "{:,.2f}".format(customer.account_balance or 0) }}
            </div>
        </div>

        {% if errors %}
        <div class="errors">
            {% for error in errors %}
                <div>{{ error }}</div>
            {% endfor %}
        </div>
        {% endif %}

        <form method="POST" action="{{ url_for('airtime') }}">

            <div class="field">
                <label for="provider">Mobile Network</label>

                <select id="provider" name="provider" required>
                    <option value="">Select mobile network</option>
                    <option value="EE" {% if provider == "EE" %}selected{% endif %}>EE</option>
                    <option value="O2" {% if provider == "O2" %}selected{% endif %}>O2</option>
                    <option value="Vodafone" {% if provider == "Vodafone" %}selected{% endif %}>Vodafone</option>
                    <option value="Three UK" {% if provider == "Three UK" %}selected{% endif %}>Three UK</option>
                    <option value="Tesco Mobile" {% if provider == "Tesco Mobile" %}selected{% endif %}>Tesco Mobile</option>
                    <option value="giffgaff" {% if provider == "giffgaff" %}selected{% endif %}>giffgaff</option>
                    <option value="Lebara" {% if provider == "Lebara" %}selected{% endif %}>Lebara</option>
                    <option value="Lycamobile" {% if provider == "Lycamobile" %}selected{% endif %}>Lycamobile</option>
                    <option value="Other Mobile Network" {% if provider == "Other Mobile Network" %}selected{% endif %}>Other Mobile Network</option>
                </select>
            </div>

            <div class="field">
                <label for="phone_number">Mobile Number</label>

                <input
                    type="tel"
                    id="phone_number"
                    name="phone_number"
                    value="{{ phone_number or '' }}"
                    placeholder="Enter mobile number"
                    autocomplete="tel"
                    required
                >
            </div>

            <div class="field">
                <label for="amount">Airtime Amount</label>

                <input
                    type="number"
                    id="amount"
                    name="amount"
                    value="{{ amount or '' }}"
                    placeholder="0.00"
                    min="0.01"
                    step="0.01"
                    required
                >

                <div class="hint">
                    Enter the amount you want to purchase.
                </div>
            </div>

            <div class="field">
                <label for="payment_reference">Payment Reference (Optional)</label>

                <input
                    type="text"
                    id="payment_reference"
                    name="payment_reference"
                    value="{{ payment_reference or '' }}"
                    placeholder="Optional reference"
                >
            </div>

            <button type="submit">Purchase Airtime</button>

        </form>

        <div class="secure">
            Secure transaction processing
        </div>

    </div>
</div>
</body>
</html>
'''

confirmation_html = r'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Airtime Confirmation | Fairmont Bank</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            font-family: Arial, Helvetica, sans-serif;
            background:
                radial-gradient(circle at top right, rgba(47, 104, 180, 0.24), transparent 35%),
                linear-gradient(145deg, #061426, #0a1c34 55%, #061426);
            color: #ffffff;
            padding: 24px 16px 40px;
        }

        .page {
            width: min(650px, 100%);
            margin: 0 auto;
        }

        .card {
            margin-top: 50px;
            background: rgba(14, 34, 59, 0.84);
            border: 1px solid rgba(255,255,255,0.09);
            border-radius: 24px;
            padding: 30px 24px;
            text-align: center;
            box-shadow: 0 20px 60px rgba(0,0,0,0.28);
            backdrop-filter: blur(18px);
        }

        .success {
            width: 68px;
            height: 68px;
            margin: 0 auto 18px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(63, 185, 130, 0.14);
            border: 1px solid rgba(63, 185, 130, 0.3);
            font-size: 31px;
        }

        h1 {
            margin: 0 0 8px;
            font-size: 27px;
        }

        .subtitle {
            margin: 0 0 25px;
            opacity: 0.65;
            font-size: 14px;
        }

        .details {
            text-align: left;
            border-radius: 18px;
            background: rgba(255,255,255,0.045);
            padding: 7px 17px;
        }

        .row {
            display: flex;
            justify-content: space-between;
            gap: 15px;
            padding: 15px 0;
            border-bottom: 1px solid rgba(255,255,255,0.07);
        }

        .row:last-child {
            border-bottom: 0;
        }

        .label {
            opacity: 0.58;
            font-size: 13px;
        }

        .value {
            text-align: right;
            font-size: 14px;
            font-weight: 600;
            word-break: break-word;
        }

        .amount {
            font-size: 20px;
        }

        .status {
            color: #9ee6c2;
        }

        .buttons {
            display: grid;
            gap: 10px;
            margin-top: 23px;
        }

        a {
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 50px;
            border-radius: 14px;
            text-decoration: none;
            font-size: 14px;
            font-weight: 700;
        }

        .primary {
            background: #ffffff;
            color: #07172a;
        }

        .secondary {
            background: rgba(255,255,255,0.07);
            color: #ffffff;
            border: 1px solid rgba(255,255,255,0.1);
        }

        @media (max-width: 480px) {
            body {
                padding: 15px 12px;
            }

            .card {
                padding: 26px 17px;
            }

            .row {
                flex-direction: column;
                gap: 5px;
            }

            .value {
                text-align: left;
            }
        }
    </style>
</head>

<body>
<div class="page">

    <div class="card">

        <div class="success">✓</div>

        <h1>Airtime Purchase Complete</h1>

        <p class="subtitle">
            Your airtime transaction has been processed successfully.
        </p>

        <div class="details">

            <div class="row">
                <div class="label">Mobile Network</div>
                <div class="value">{{ provider }}</div>
            </div>

            <div class="row">
                <div class="label">Mobile Number</div>
                <div class="value">{{ phone_number }}</div>
            </div>

            <div class="row">
                <div class="label">Amount</div>
                <div class="value amount">
                    £{{ "{:,.2f}".format(amount) }}
                </div>
            </div>

            {% if payment_reference %}
            <div class="row">
                <div class="label">Payment Reference</div>
                <div class="value">{{ payment_reference }}</div>
            </div>
            {% endif %}

            <div class="row">
                <div class="label">Transaction Reference</div>
                <div class="value">{{ transaction_reference }}</div>
            </div>

            <div class="row">
                <div class="label">Status</div>
                <div class="value status">Completed</div>
            </div>

            <div class="row">
                <div class="label">New Balance</div>
                <div class="value">
                    £{{ "{:,.2f}".format(new_balance) }}
                </div>
            </div>

        </div>

        <div class="buttons">
            <a class="primary"
               href="{{ url_for('transaction_details', transaction_reference=transaction_reference) }}">
                View Transaction
            </a>

            <a class="secondary" href="{{ url_for('transactions') }}">
                Transaction History
            </a>

            <a class="secondary" href="{{ url_for('services') }}">
                Back to Services
            </a>
        </div>

    </div>
</div>
</body>
</html>
'''

(TEMPLATES / "airtime.html").write_text(airtime_html, encoding="utf-8")
(TEMPLATES / "airtime_confirmation.html").write_text(
    confirmation_html,
    encoding="utf-8"
)

print("SUCCESS: Airtime templates created.")

# Update Services Hub Airtime link only.
services_file = TEMPLATES / "services.html"

if services_file.exists():
    services_text = services_file.read_text(encoding="utf-8")

    if "/airtime" in services_text:
        print("NOTICE: Services Hub Airtime link already points to /airtime.")
    else:
        replacements = [
            ('href="#"', 'href="/airtime"')
        ]

        if "Airtime" in services_text:
            import re

            pattern = r'(<a\b[^>]*href=")#"([^>]*>.*?Airtime.*?</a>)'
            updated, count = re.subn(
                pattern,
                r'\1/airtime\2',
                services_text,
                count=1,
                flags=re.IGNORECASE | re.DOTALL
            )

            if count:
                services_file.write_text(updated, encoding="utf-8")
                print("SUCCESS: Airtime link updated in templates\\services.html.")
            else:
                print("NOTICE: Airtime link pattern not found in templates\\services.html.")
        else:
            print("NOTICE: Airtime text not found in templates\\services.html.")
else:
    print("NOTICE: templates\\services.html was not found.")

print()
print("Airtime feature installation complete.")
print("Next: run python -m py_compile app.py")