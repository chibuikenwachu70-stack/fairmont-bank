from pathlib import Path
import shutil

FILE = Path("templates/admin_dashboard.html")

if not FILE.exists():
    print("ERROR: templates/admin_dashboard.html was not found.")
    raise SystemExit(1)

text = FILE.read_text(encoding="utf-8")

if "/admin/bank-email" in text:
    print("Bank Email option already exists in the admin dashboard.")
    raise SystemExit(0)

backup = Path("templates/admin_dashboard.html.before_bank_email")
shutil.copy2(FILE, backup)

# Add the option beside the existing Live Chat management option.
live_chat_link = '<a href="/admin/live-chat"'
position = text.find(live_chat_link)

if position == -1:
    print("ERROR: Existing admin Live Chat link was not found.")
    print("Backup created:", backup)
    raise SystemExit(1)

# Find the complete anchor containing the Live Chat link.
start = text.rfind("<a", 0, position)
end = text.find("</a>", position)

if start == -1 or end == -1:
    print("ERROR: Could not locate the Live Chat navigation item.")
    print("Backup created:", backup)
    raise SystemExit(1)

end += len("</a>")

live_chat_item = text[start:end]

bank_email_item = """
<a href="/admin/bank-email" class="admin-nav-link">
    <span class="admin-nav-icon">✉</span>
    <span>Customer Messages</span>
</a>
"""

# Insert directly after Live Chat.
text = text[:end] + bank_email_item + text[end:]

FILE.write_text(text, encoding="utf-8")

print("=" * 70)
print("CUSTOMER MESSAGES OPTION ADDED")
print("=" * 70)
print()
print("Added to:")
print("templates/admin_dashboard.html")
print()
print("Management page:")
print("/admin/bank-email")
print()
print("Backup created:")
print(backup)