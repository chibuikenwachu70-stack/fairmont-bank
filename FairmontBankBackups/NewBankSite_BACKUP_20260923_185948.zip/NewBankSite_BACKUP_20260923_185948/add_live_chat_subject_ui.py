from pathlib import Path
import shutil

FILE = Path("templates/live_chat.html")

text = FILE.read_text(encoding="utf-8")

if 'name="subject"' in text:
    print("=" * 70)
    print("LIVE CHAT SUBJECT FIELD ALREADY EXISTS")
    print("=" * 70)
    raise SystemExit(0)

backup = Path("templates/live_chat.html.before_subject")
shutil.copy2(FILE, backup)

# Add subject field immediately before the message textarea.
marker = '''            <textarea
                name="message"
                class="chat-input"
                placeholder="Type your message..."
                maxlength="2000"
                required
            ></textarea>'''

subject_html = '''            {% if subject_error %}
                <div class="subject-error">
                    {{ subject_error }}
                </div>
            {% endif %}

            {% if not conversation %}
                <div class="subject-field">
                    <label for="chat-subject">
                        Subject / Reason for Contact
                    </label>

                    <input
                        type="text"
                        id="chat-subject"
                        name="subject"
                        class="chat-subject-input"
                        maxlength="200"
                        placeholder="What would you like help with?"
                        required
                    >

                    <div class="subject-help">
                        Please briefly tell us what you need help with.
                    </div>
                </div>
            {% endif %}

''' + marker

if marker not in text:
    print("=" * 70)
    print("ERROR: Live Chat message textarea was not found.")
    print("=" * 70)
    print()
    print("Backup created:")
    print(backup)
    raise SystemExit(1)

text = text.replace(marker, subject_html, 1)

# Add styling before the existing chat-form CSS.
css_marker = '''        .chat-form {'''

subject_css = '''        .subject-field {
            width: 100%;
            margin-bottom: 12px;
        }

        .subject-field label {
            display: block;
            margin-bottom: 7px;
            color: #c5d2df;
            font-size: 12px;
            font-weight: 700;
        }

        .chat-subject-input {
            width: 100%;
            padding: 12px 13px;
            border: 1px solid rgba(159, 179, 204, 0.18);
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.045);
            color: #ffffff;
            outline: none;
            font-family: inherit;
            font-size: 13px;
        }

        .chat-subject-input::placeholder {
            color: #637991;
        }

        .chat-subject-input:focus {
            border-color: rgba(184, 149, 74, 0.65);
            background: rgba(255, 255, 255, 0.06);
        }

        .subject-help {
            margin-top: 6px;
            color: #5f758d;
            font-size: 9px;
        }

        .subject-error {
            width: 100%;
            margin-bottom: 12px;
            padding: 11px 13px;
            border: 1px solid rgba(190, 82, 82, 0.30);
            border-radius: 10px;
            background: rgba(190, 82, 82, 0.08);
            color: #e4a8a8;
            font-size: 11px;
        }

'''

if css_marker not in text:
    print("=" * 70)
    print("ERROR: Chat form CSS section was not found.")
    print("=" * 70)
    print()
    print("Backup created:")
    print(backup)
    raise SystemExit(1)

text = text.replace(css_marker, subject_css + css_marker, 1)

FILE.write_text(text, encoding="utf-8")

print("=" * 70)
print("LIVE CHAT SUBJECT FIELD ADDED")
print("=" * 70)
print()
print("Customers will now enter:")
print("  Subject / Reason for Contact")
print("  What would you like help with?")
print()
print("The subject is required when starting a new conversation.")
print()
print("Backup created:")
print(backup)