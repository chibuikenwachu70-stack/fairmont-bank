from pathlib import Path
from datetime import datetime
import re
import shutil

TEMPLATE = Path("templates/international_transfer.html")

print()
print("=" * 50)
print("CLEAN COUNTRY / BANK / CURRENCY SEARCH FIX")
print("=" * 50)
print()

if not TEMPLATE.exists():
    print("ERROR: templates/international_transfer.html was not found.")
    raise SystemExit(1)

html = TEMPLATE.read_text(encoding="utf-8")

# ---------------------------------------------------------
# 1. VERIFY THE THREE REAL SELECTS EXIST
# ---------------------------------------------------------

print("Checking existing controls...")
print()

country_count = len(re.findall(r'id\s*=\s*"internationalCountry"', html))
bank_count = len(re.findall(r'id\s*=\s*"internationalBank"', html))
currency_count = len(re.findall(r'id\s*=\s*"internationalCurrency"', html))

print("internationalCountry:", country_count)
print("internationalBank:", bank_count)
print("internationalCurrency:", currency_count)

if country_count != 1 or bank_count != 1 or currency_count != 1:
    print()
    print("ERROR: The three required select controls were not found exactly once.")
    print("NO FILE WAS CHANGED.")
    raise SystemExit(1)

# ---------------------------------------------------------
# 2. BACKUP
# ---------------------------------------------------------

stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = TEMPLATE.with_name(
    "international_transfer_BEFORE_SEARCH_CLEAN_" + stamp + ".html"
)

shutil.copy2(TEMPLATE, backup)

print()
print("Backup created:", backup.name)

# ---------------------------------------------------------
# 3. REMOVE OLD PICKER CSS BLOCKS
# ---------------------------------------------------------

style_pattern = re.compile(
    r"<style\b[^>]*>.*?</style>",
    re.IGNORECASE | re.DOTALL
)

styles_removed = 0

old_style_markers = [
    "fairmont-picker",
    "fairmont-final",
    "quick-search-select",
    "search-select-wrapper",
    "picker-popup",
    "picker-trigger"
]

new_html_parts = []

for match in style_pattern.finditer(html):
    block = match.group(0)

    should_remove = False

    for marker in old_style_markers:
        if marker.lower() in block.lower():
            should_remove = True
            break

    if should_remove:
        styles_removed += 1
    else:
        new_html_parts.append(block)

# Do not rebuild the document from style matches.
# Instead remove matching blocks directly.
def remove_old_styles(text):
    def replacement(match):
        block = match.group(0)

        for marker in old_style_markers:
            if marker.lower() in block.lower():
                return ""

        return block

    return style_pattern.sub(replacement, text)


html = remove_old_styles(html)

print("Old picker style blocks removed:", styles_removed)

# ---------------------------------------------------------
# 4. REMOVE OLD PICKER SCRIPT BLOCKS
# ---------------------------------------------------------

script_pattern = re.compile(
    r"<script\b[^>]*>.*?</script>",
    re.IGNORECASE | re.DOTALL
)

old_script_markers = [
    "fairmont-picker",
    "fairmont-final",
    "quick-search-select",
    "search-select-wrapper",
    "picker-popup",
    "picker-trigger",
    "fairmontCountrySearch",
    "fairmontBankSearch",
    "fairmontCurrencySearch"
]

scripts_removed = 0

def remove_old_scripts(text):
    def replacement(match):
        block = match.group(0)

        for marker in old_script_markers:
            if marker.lower() in block.lower():
                return ""

        return block

    return script_pattern.sub(replacement, text)


html = remove_old_scripts(html)

for marker in old_script_markers:
    pass

# Count approximately how many old script blocks remain before cleanup.
# This is informational only.
print("Old picker script cleanup completed.")

# ---------------------------------------------------------
# 5. DATA
# ---------------------------------------------------------

countries = [
    "Afghanistan",
    "Albania",
    "Algeria",
    "Andorra",
    "Angola",
    "Antigua and Barbuda",
    "Argentina",
    "Armenia",
    "Australia",
    "Austria",
    "Azerbaijan",
    "Bahamas",
    "Bahrain",
    "Bangladesh",
    "Barbados",
    "Belarus",
    "Belgium",
    "Belize",
    "Benin",
    "Bhutan",
    "Bolivia",
    "Bosnia and Herzegovina",
    "Botswana",
    "Brazil",
    "Brunei",
    "Bulgaria",
    "Burkina Faso",
    "Burundi",
    "Cambodia",
    "Cameroon",
    "Canada",
    "Cape Verde",
    "Central African Republic",
    "Chad",
    "Chile",
    "China",
    "Colombia",
    "Comoros",
    "Costa Rica",
    "Croatia",
    "Cuba",
    "Cyprus",
    "Czech Republic",
    "Denmark",
    "Djibouti",
    "Dominica",
    "Dominican Republic",
    "Ecuador",
    "Egypt",
    "El Salvador",
    "Estonia",
    "Eswatini",
    "Ethiopia",
    "Fiji",
    "Finland",
    "France",
    "Gabon",
    "Gambia",
    "Georgia",
    "Germany",
    "Ghana",
    "Greece",
    "Grenada",
    "Guatemala",
    "Guinea",
    "Guyana",
    "Haiti",
    "Honduras",
    "Hungary",
    "Iceland",
    "India",
    "Indonesia",
    "Iran",
    "Iraq",
    "Ireland",
    "Israel",
    "Italy",
    "Jamaica",
    "Japan",
    "Jordan",
    "Kazakhstan",
    "Kenya",
    "Kuwait",
    "Latvia",
    "Lebanon",
    "Lesotho",
    "Liberia",
    "Libya",
    "Liechtenstein",
    "Lithuania",
    "Luxembourg",
    "Madagascar",
    "Malawi",
    "Malaysia",
    "Maldives",
    "Mali",
    "Malta",
    "Mauritania",
    "Mauritius",
    "Mexico",
    "Moldova",
    "Monaco",
    "Mongolia",
    "Montenegro",
    "Morocco",
    "Mozambique",
    "Myanmar",
    "Namibia",
    "Nepal",
    "Netherlands",
    "New Zealand",
    "Nicaragua",
    "Niger",
    "Nigeria",
    "North Macedonia",
    "Norway",
    "Oman",
    "Pakistan",
    "Panama",
    "Papua New Guinea",
    "Paraguay",
    "Peru",
    "Philippines",
    "Poland",
    "Portugal",
    "Qatar",
    "Romania",
    "Rwanda",
    "Saint Lucia",
    "Saudi Arabia",
    "Senegal",
    "Serbia",
    "Seychelles",
    "Sierra Leone",
    "Singapore",
    "Slovakia",
    "Slovenia",
    "Somalia",
    "South Africa",
    "South Korea",
    "South Sudan",
    "Spain",
    "Sri Lanka",
    "Sudan",
    "Suriname",
    "Sweden",
    "Switzerland",
    "Syria",
    "Taiwan",
    "Tanzania",
    "Thailand",
    "Togo",
    "Trinidad and Tobago",
    "Tunisia",
    "Turkey",
    "Uganda",
    "Ukraine",
    "United Arab Emirates",
    "United Kingdom",
    "United States",
    "Uruguay",
    "Uzbekistan",
    "Venezuela",
    "Vietnam",
    "Yemen",
    "Zambia",
    "Zimbabwe"
]

banks = {
    "United Kingdom": [
        "Allied Irish Bank (GB)",
        "Bank of Ireland UK",
        "Bank of Scotland",
        "Barclays Bank",
        "Birmingham Bank",
        "Card One Money",
        "Cashplus Bank",
        "Chase UK",
        "Citibank UK",
        "ClearBank",
        "C. Hoare & Co.",
        "Co-operative Bank",
        "Coutts",
        "Danske Bank",
        "First Direct",
        "Halifax",
        "Handelsbanken UK",
        "HSBC UK",
        "Investec Bank",
        "Lloyds Bank",
        "Metro Bank",
        "Monzo Bank",
        "Nationwide Building Society",
        "NatWest",
        "Revolut",
        "Royal Bank of Scotland",
        "Santander UK",
        "Skipton Building Society",
        "Starling Bank",
        "TSB Bank",
        "Ulster Bank",
        "Virgin Money",
        "Yorkshire Building Society",
        "Zopa Bank",
        "Other UK Bank or Building Society"
    ],

    "United States": [
        "Bank of America",
        "JPMorgan Chase Bank",
        "Citibank",
        "Wells Fargo Bank",
        "U.S. Bank",
        "PNC Bank",
        "Truist Bank",
        "Capital One",
        "Goldman Sachs Bank",
        "Morgan Stanley Bank",
        "Other US Bank"
    ],

    "Canada": [
        "Royal Bank of Canada",
        "Toronto-Dominion Bank",
        "Bank of Montreal",
        "Canadian Imperial Bank of Commerce",
        "Scotiabank",
        "National Bank of Canada",
        "Desjardins",
        "Other Canadian Bank"
    ],

    "Kenya": [
        "KCB Bank Kenya",
        "Equity Bank Kenya",
        "Co-operative Bank of Kenya",
        "Absa Bank Kenya",
        "NCBA Bank Kenya",
        "Stanbic Bank Kenya",
        "I&M Bank Kenya",
        "DTB Kenya",
        "Family Bank",
        "Prime Bank",
        "Other Kenyan Bank"
    ],

    "Nigeria": [
        "Access Bank",
        "First Bank of Nigeria",
        "Guaranty Trust Bank",
        "United Bank for Africa",
        "Zenith Bank",
        "Fidelity Bank",
        "First City Monument Bank",
        "Stanbic IBTC Bank",
        "Sterling Bank",
        "Union Bank of Nigeria",
        "Other Nigerian Bank"
    ],

    "Ghana": [
        "GCB Bank",
        "Ecobank Ghana",
        "Absa Bank Ghana",
        "Stanbic Bank Ghana",
        "Standard Chartered Ghana",
        "Fidelity Bank Ghana",
        "CalBank",
        "United Bank for Africa Ghana",
        "Other Ghanaian Bank"
    ],

    "South Africa": [
        "Standard Bank",
        "First National Bank",
        "Absa Bank South Africa",
        "Nedbank",
        "Capitec Bank",
        "Investec Bank South Africa",
        "African Bank",
        "Other South African Bank"
    ],

    "Suriname": [
        "De Surinaamsche Bank (DSB)",
        "Republic Bank Suriname",
        "Hakrinbank",
        "Surinaamse Volkscredietbank",
        "Finabank",
        "Surichange Bank",
        "GODO Coöperatieve Spaar- en Kredietbank",
        "Trustbank Amanah",
        "Other Surinamese Bank"
    ],

    "India": [
        "State Bank of India",
        "HDFC Bank",
        "ICICI Bank",
        "Axis Bank",
        "Kotak Mahindra Bank",
        "IndusInd Bank",
        "Punjab National Bank",
        "Bank of Baroda",
        "Canara Bank",
        "Union Bank of India",
        "Other Indian Bank"
    ],

    "Australia": [
        "Commonwealth Bank",
        "Westpac",
        "ANZ",
        "National Australia Bank",
        "Macquarie Bank",
        "Bank of Queensland",
        "Other Australian Bank"
    ],

    "Germany": [
        "Deutsche Bank",
        "Commerzbank",
        "DZ Bank",
        "KfW",
        "ING Germany",
        "N26",
        "Other German Bank"
    ],

    "France": [
        "BNP Paribas",
        "Crédit Agricole",
        "Société Générale",
        "BPCE",
        "La Banque Postale",
        "Crédit Mutuel",
        "Other French Bank"
    ],

    "Netherlands": [
        "ING Bank",
        "ABN AMRO",
        "Rabobank",
        "de Volksbank",
        "Triodos Bank",
        "Other Dutch Bank"
    ],

    "Ireland": [
        "AIB",
        "Bank of Ireland",
        "Permanent TSB",
        "Revolut Bank Ireland",
        "Other Irish Bank"
    ],

    "Switzerland": [
        "UBS Switzerland",
        "Zürcher Kantonalbank",
        "Banque Cantonale Vaudoise",
        "Raiffeisen Switzerland",
        "Other Swiss Bank"
    ],

    "United Arab Emirates": [
        "Emirates NBD",
        "First Abu Dhabi Bank",
        "Abu Dhabi Commercial Bank",
        "Mashreq",
        "Dubai Islamic Bank",
        "RAKBANK",
        "Other UAE Bank"
    ],

    "Saudi Arabia": [
        "Saudi National Bank",
        "Al Rajhi Bank",
        "Riyad Bank",
        "Saudi Awwal Bank",
        "Bank Albilad",
        "Arab National Bank",
        "Other Saudi Bank"
    ],

    "Qatar": [
        "Qatar National Bank",
        "Qatar Islamic Bank",
        "Commercial Bank Qatar",
        "Doha Bank",
        "Masraf Al Rayan",
        "Other Qatari Bank"
    ],

    "Singapore": [
        "DBS Bank",
        "OCBC Bank",
        "United Overseas Bank",
        "Standard Chartered Singapore",
        "Citibank Singapore",
        "Other Singaporean Bank"
    ],

    "Japan": [
        "MUFG Bank",
        "Sumitomo Mitsui Banking Corporation",
        "Mizuho Bank",
        "Resona Bank",
        "Japan Post Bank",
        "Other Japanese Bank"
    ],

    "China": [
        "Industrial and Commercial Bank of China",
        "China Construction Bank",
        "Bank of China",
        "Agricultural Bank of China",
        "Bank of Communications",
        "China Merchants Bank",
        "Other Chinese Bank"
    ],

    "Brazil": [
        "Banco do Brasil",
        "Itaú Unibanco",
        "Bradesco",
        "Caixa Econômica Federal",
        "Santander Brasil",
        "BTG Pactual",
        "Other Brazilian Bank"
    ],

    "Mexico": [
        "BBVA México",
        "Banorte",
        "Santander México",
        "Citibanamex",
        "HSBC México",
        "Scotiabank México",
        "Other Mexican Bank"
    ]
}

currencies = [
    "GBP",
    "EUR",
    "USD",
    "CAD",
    "AUD",
    "NZD",
    "CHF",
    "JPY",
    "CNY",
    "SGD",
    "INR",
    "AED",
    "SAR",
    "QAR",
    "ZAR",
    "KES",
    "NGN",
    "GHS",
    "TZS",
    "UGX",
    "BRL",
    "MXN",
    "SRD",
    "THB",
    "MYR",
    "IDR",
    "KRW",
    "TRY",
    "PLN",
    "SEK",
    "NOK",
    "DKK",
    "CZK",
    "HUF",
    "RON",
    "ILS"
]

# ---------------------------------------------------------
# 6. BUILD OPTION HTML
# ---------------------------------------------------------

country_options = ['<option value="">Select country</option>']

for country in countries:
    country_options.append(
        '<option value="' + country + '">' + country + '</option>'
    )

country_options_html = "\n".join(country_options)

currency_options = ['<option value="">Select currency</option>']

for currency in currencies:
    currency_options.append(
        '<option value="' + currency + '">' + currency + '</option>'
    )

currency_options_html = "\n".join(currency_options)

# ---------------------------------------------------------
# 7. REPLACE EACH FIELD USING ITS REAL SELECT ID
# ---------------------------------------------------------

def replace_select_field(text, select_id, field_html):
    pattern = re.compile(
        r'<div\b[^>]*class\s*=\s*"[^"]*\bfield\b[^"]*"[^>]*>'
        r'(?:(?!</div>).)*?'
        r'<select\b[^>]*id\s*=\s*"' + re.escape(select_id) + r'"[^>]*>.*?</select>'
        r'(?:(?!</div>).)*?'
        r'</div>',
        re.IGNORECASE | re.DOTALL
    )

    matches = list(pattern.finditer(text))

    if len(matches) != 1:
        print()
        print("ERROR: Could not safely locate", select_id)
        print("Matches found:", len(matches))
        return None

    return (
        text[:matches[0].start()]
        + field_html
        + text[matches[0].end():]
    )

country_field = """
<div class="field fairmont-search-field">

    <label for="internationalCountry">Destination Country</label>

    <select
        id="internationalCountry"
        name="country"
        required
    >
%s
    </select>

    <div class="fairmont-search-box">
        <span class="fairmont-search-icon">⌕</span>
        <input
            type="text"
            id="fairmontCountrySearch"
            placeholder="Search country"
            autocomplete="off"
        >
    </div>

</div>
""" % country_options_html

bank_field = """
<div class="field fairmont-search-field">

    <label for="internationalBank">Bank Name</label>

    <select
        id="internationalBank"
        name="bank_name"
        required
    >
        <option value="">Select a bank</option>
    </select>

    <div class="fairmont-search-box">
        <span class="fairmont-search-icon">⌕</span>
        <input
            type="text"
            id="fairmontBankSearch"
            placeholder="Search bank"
            autocomplete="off"
        >
    </div>

</div>
"""

currency_field = """
<div class="field fairmont-search-field">

    <label for="internationalCurrency">Currency</label>

    <select
        id="internationalCurrency"
        name="currency"
        required
    >
%s
    </select>

    <div class="fairmont-search-box">
        <span class="fairmont-search-icon">⌕</span>
        <input
            type="text"
            id="fairmontCurrencySearch"
            placeholder="Search currency"
            autocomplete="off"
        >
    </div>

</div>
""" % currency_options_html

new_html = replace_select_field(
    html,
    "internationalCountry",
    country_field
)

if new_html is None:
    print()
    print("NO FILE WAS CHANGED.")
    raise SystemExit(1)

html = new_html

new_html = replace_select_field(
    html,
    "internationalBank",
    bank_field
)

if new_html is None:
    print()
    print("NO FILE WAS CHANGED.")
    raise SystemExit(1)

html = new_html

new_html = replace_select_field(
    html,
    "internationalCurrency",
    currency_field
)

if new_html is None:
    print()
    print("NO FILE WAS CHANGED.")
    raise SystemExit(1)

html = new_html

print()
print("Country field replaced.")
print("Bank field replaced.")
print("Currency field replaced.")

# ---------------------------------------------------------
# 8. REMOVE OLD SEARCH INPUTS THAT MAY STILL EXIST
# ---------------------------------------------------------

old_search_ids = [
    "countrySearch",
    "internationalCountrySearch",
    "internationalBankSearch",
    "currencySearch",
    "countrySearchResults",
    "internationalBankSearchResults",
    "currencySearchResults"
]

for old_id in old_search_ids:
    if old_id in [
        "fairmontCountrySearch",
        "fairmontBankSearch",
        "fairmontCurrencySearch"
    ]:
        continue

    input_pattern = re.compile(
        r'<input\b[^>]*id\s*=\s*"' + re.escape(old_id) + r'"[^>]*>',
        re.IGNORECASE | re.DOTALL
    )

    html = input_pattern.sub("", html)

# ---------------------------------------------------------
# 9. ADD NEW CSS
# ---------------------------------------------------------

css = """
<style id="fairmont-search-fields-css">

.fairmont-search-field {
    position: relative;
    width: 100%;
}

.fairmont-search-field select {
    width: 100%;
    box-sizing: border-box;
    display: block;
    min-height: 50px;
    padding: 13px 44px 13px 15px;
    border-radius: 14px;
    border: 1px solid rgba(255,255,255,0.12);
    background: rgba(255,255,255,0.06);
    color: #ffffff;
    outline: none;
    appearance: auto;
}

.fairmont-search-field select option {
    color: #111111;
    background: #ffffff;
}

.fairmont-search-box {
    width: 100%;
    box-sizing: border-box;
    margin-top: 9px;
    display: flex;
    align-items: center;
    gap: 9px;
    min-height: 46px;
    padding: 0 13px;
    border-radius: 13px;
    border: 1px solid rgba(255,255,255,0.12);
    background: rgba(255,255,255,0.045);
}

.fairmont-search-icon {
    font-size: 21px;
    line-height: 1;
    opacity: 0.8;
}

.fairmont-search-box input {
    flex: 1;
    min-width: 0;
    border: 0;
    outline: none;
    background: transparent;
    color: #ffffff;
    font-size: 14px;
    padding: 12px 0;
}

.fairmont-search-box input::placeholder {
    color: rgba(255,255,255,0.55);
}

</style>
"""

if 'id="fairmont-search-fields-css"' in html:
    html = re.sub(
        r'<style\b[^>]*id\s*=\s*"fairmont-search-fields-css"[^>]*>.*?</style>',
        "",
        html,
        flags=re.IGNORECASE | re.DOTALL
    )

if "</head>" in html.lower():
    position = html.lower().rfind("</head>")
    html = html[:position] + css + "\n" + html[position:]
else:
    html = css + "\n" + html

# ---------------------------------------------------------
# 10. JAVASCRIPT
# ---------------------------------------------------------

banks_json = "{\n"

for country, bank_list in banks.items():
    escaped_banks = []

    for bank in bank_list:
        escaped_banks.append(
            '"' + bank.replace("\\", "\\\\").replace('"', '\\"') + '"'
        )

    banks_json += (
        '    "' +
        country.replace("\\", "\\\\").replace('"', '\\"') +
        '": [' +
        ", ".join(escaped_banks) +
        "],\n"
    )

banks_json += "}"

js = """
<script id="fairmont-search-fields-js">
document.addEventListener("DOMContentLoaded", function () {

    const countrySelect = document.getElementById("internationalCountry");
    const bankSelect = document.getElementById("internationalBank");
    const currencySelect = document.getElementById("internationalCurrency");

    const countrySearch = document.getElementById("fairmontCountrySearch");
    const bankSearch = document.getElementById("fairmontBankSearch");
    const currencySearch = document.getElementById("fairmontCurrencySearch");

    if (!countrySelect || !bankSelect || !currencySelect) {
        console.error("Fairmont search fields: required select missing.");
        return;
    }

    const countryBanks = %s;

    function filterSelect(select, searchInput, originalOptions) {
        if (!searchInput) {
            return;
        }

        const term = searchInput.value.trim().toLowerCase();
        const currentValue = select.value;

        while (select.options.length > 0) {
            select.remove(0);
        }

        originalOptions.forEach(function (option) {
            const text = option.text.toLowerCase();

            if (
                term === "" ||
                text.indexOf(term) !== -1 ||
                option.value === ""
            ) {
                select.add(option.cloneNode(true));
            }
        });

        if (
            Array.from(select.options).some(function (option) {
                return option.value === currentValue;
            })
        ) {
            select.value = currentValue;
        }
    }

    function getOptions(select) {
        return Array.from(select.options).map(function (option) {
            return option.cloneNode(true);
        });
    }

    const countryOptions = getOptions(countrySelect);
    const currencyOptions = getOptions(currencySelect);

    function updateBanks() {
        const selectedCountry = countrySelect.value;

        const currentBank = bankSelect.value;

        while (bankSelect.options.length > 0) {
            bankSelect.remove(0);
        }

        const first = document.createElement("option");
        first.value = "";
        first.textContent = "Select a bank";
        bankSelect.add(first);

        if (!selectedCountry) {
            return;
        }

        const list = countryBanks[selectedCountry];

        if (!list) {
            const other = document.createElement("option");
            other.value = "Other bank in " + selectedCountry;
            other.textContent = "Other bank in " + selectedCountry;
            bankSelect.add(other);
            return;
        }

        list.forEach(function (bank) {
            const option = document.createElement("option");
            option.value = bank;
            option.textContent = bank;
            bankSelect.add(option);
        });

        if (
            Array.from(bankSelect.options).some(function (option) {
                return option.value === currentBank;
            })
        ) {
            bankSelect.value = currentBank;
        }
    }

    countrySelect.addEventListener("change", function () {
        if (countrySearch) {
            countrySearch.value = "";
        }

        updateBanks();

        if (bankSearch) {
            bankSearch.value = "";
        }
    });

    if (countrySearch) {
        countrySearch.addEventListener("input", function () {
            filterSelect(
                countrySelect,
                countrySearch,
                countryOptions
            );

            updateBanks();
        });
    }

    if (bankSearch) {
        bankSearch.addEventListener("input", function () {

            const selectedCountry = countrySelect.value;

            const list = countryBanks[selectedCountry] || [];

            const term = bankSearch.value.trim().toLowerCase();

            const currentValue = bankSelect.value;

            while (bankSelect.options.length > 0) {
                bankSelect.remove(0);
            }

            const first = document.createElement("option");
            first.value = "";
            first.textContent = "Select a bank";
            bankSelect.add(first);

            list.forEach(function (bank) {

                if (
                    term === "" ||
                    bank.toLowerCase().indexOf(term) !== -1
                ) {
                    const option = document.createElement("option");
                    option.value = bank;
                    option.textContent = bank;
                    bankSelect.add(option);
                }

            });

            if (
                Array.from(bankSelect.options).some(function (option) {
                    return option.value === currentValue;
                })
            ) {
                bankSelect.value = currentValue;
            }
        });
    }

    if (currencySearch) {
        currencySearch.addEventListener("input", function () {
            filterSelect(
                currencySelect,
                currencySearch,
                currencyOptions
            );
        });
    }

    updateBanks();

});
</script>
""" % banks_json

if 'id="fairmont-search-fields-js"' in html:
    html = re.sub(
        r'<script\b[^>]*id\s*=\s*"fairmont-search-fields-js"[^>]*>.*?</script>',
        "",
        html,
        flags=re.IGNORECASE | re.DOTALL
    )

if "</body>" in html.lower():
    position = html.lower().rfind("</body>")
    html = html[:position] + js + "\n" + html[position:]
else:
    html += "\n" + js

# ---------------------------------------------------------
# 11. FINAL VALIDATION
# ---------------------------------------------------------

print()
print("=" * 50)
print("FINAL VALIDATION")
print("=" * 50)

final_country = len(
    re.findall(r'id\s*=\s*"internationalCountry"', html)
)

final_bank = len(
    re.findall(r'id\s*=\s*"internationalBank"', html)
)

final_currency = len(
    re.findall(r'id\s*=\s*"internationalCurrency"', html)
)

final_country_search = len(
    re.findall(r'id\s*=\s*"fairmontCountrySearch"', html)
)

final_bank_search = len(
    re.findall(r'id\s*=\s*"fairmontBankSearch"', html)
)

final_currency_search = len(
    re.findall(r'id\s*=\s*"fairmontCurrencySearch"', html)
)

print("internationalCountry:", final_country)
print("internationalBank:", final_bank)
print("internationalCurrency:", final_currency)
print("fairmontCountrySearch:", final_country_search)
print("fairmontBankSearch:", final_bank_search)
print("fairmontCurrencySearch:", final_currency_search)

# Actual old visible trigger elements.
old_trigger_patterns = [
    r'<button\b[^>]*class\s*=\s*"[^"]*fairmont-final-trigger[^"]*"[^>]*>',
    r'<button\b[^>]*class\s*=\s*"[^"]*fairmont-picker-trigger[^"]*"[^>]*>',
    r'<button\b[^>]*class\s*=\s*"[^"]*fairmont-clean-trigger[^"]*"[^>]*>'
]

old_visible_triggers = 0

for pattern in old_trigger_patterns:
    old_visible_triggers += len(
        re.findall(pattern, html, flags=re.IGNORECASE)
    )

print("Old visible trigger buttons:", old_visible_triggers)

valid = True

if final_country != 1:
    valid = False

if final_bank != 1:
    valid = False

if final_currency != 1:
    valid = False

if final_country_search != 1:
    valid = False

if final_bank_search != 1:
    valid = False

if final_currency_search != 1:
    valid = False

if old_visible_triggers != 0:
    valid = False

if not valid:
    print()
    print("VALIDATION FAILED.")
    print("NO FILE WAS CHANGED.")
    print("Backup:", backup.name)
    raise SystemExit(1)

# ---------------------------------------------------------
# 12. WRITE FILE
# ---------------------------------------------------------

TEMPLATE.write_text(html, encoding="utf-8")

print()
print("=" * 50)
print("SUCCESS")
print("=" * 50)
print()
print("The international transfer fields were rebuilt.")
print()
print("You now have:")
print("  1. One Country select")
print("  2. One Country search box")
print("  3. One Bank select")
print("  4. One Bank search box")
print("  5. One Currency select")
print("  6. One Currency search box")
print()
print("Bank choices change when the country changes.")
print("Old duplicate trigger buttons were removed.")
print()
print("Backup:", backup.name)
print()