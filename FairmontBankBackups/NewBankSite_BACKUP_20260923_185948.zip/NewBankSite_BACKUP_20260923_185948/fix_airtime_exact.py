from pathlib import Path

file = Path("templates/dashboard.html")

text = file.read_text(encoding="utf-8")

old = """                    <!-- Airtime -->

                    <a
                        href="#"
                        class="service-item">

                        <span class="service-icon">
                            â˜Ž
                        </span>

                        <span class="service-name">
                              Airtime
                          </span>

                    </a>"""

new = """                    <!-- Airtime -->

                    <a
                        href="/airtime"
                        class="service-item">

                        <span class="service-icon">
                            â˜Ž
                        </span>

                        <span class="service-name">
                              Airtime
                          </span>

                    </a>"""

if old not in text:
    raise SystemExit(
        "ERROR: Exact Airtime block was not found. Nothing was changed."
    )

text = text.replace(old, new, 1)

file.write_text(text, encoding="utf-8")

print("SUCCESS: Airtime dashboard card now links directly to /airtime.")