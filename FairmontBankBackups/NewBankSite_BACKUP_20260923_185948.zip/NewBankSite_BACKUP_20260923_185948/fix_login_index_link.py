from pathlib import Path
import shutil
from datetime import datetime

template = Path("templates/login.html")

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = template.with_name(
    f"login_BEFORE_INDEX_LINK_FIX_{timestamp}.html"
)

shutil.copy2(template, backup)

text = template.read_text(encoding="utf-8")

old = """<a href="{{ url_for('index') }}">"""

new = """<a href="{{ url_for('login') }}">"""

if old not in text:
    print("TARGET_NOT_FOUND")
    print("No changes were made.")
    print(f"Backup created: {backup.name}")
    raise SystemExit(1)

text = text.replace(old, new, 1)

template.write_text(text, encoding="utf-8")

print("LOGIN_INDEX_LINK_FIXED")
print(f"Backup: {backup.name}")