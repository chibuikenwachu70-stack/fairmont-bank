from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
APP_FILE = BASE_DIR / "app.py"

if not APP_FILE.exists():
    print("ERROR: app.py was not found.")
    raise SystemExit(1)

text = APP_FILE.read_text(encoding="utf-8")

old = '''        current_balance = float(receiver.account_balance or 0)

        new_balance = current_balance + amount

        receiver.account_balance = new_balance
'''

new = '''        previous_balance = float(receiver.account_balance or 0)

        new_balance = previous_balance + amount

        receiver.account_balance = new_balance

        posted_at = datetime.now().strftime("%d %B %Y, %H:%M:%S")
'''

if old not in text:
    print("ERROR: The expected incoming payment balance block was not found.")
    print("No changes were made.")
    raise SystemExit(1)

text = text.replace(old, new, 1)

old2 = '''        return render_template(
            "admin_incoming_payment_success.html",
            admin=admin,
            receiver=receiver,
            amount=amount,
            sender_name=sender_name,
            sender_account_number=sender_account_number,
            sender_bank=sender_bank,
            sender_country=sender_country,
            payment_description=payment_description,
            transaction_reference=transaction_reference
        )
'''

new2 = '''        return render_template(
            "admin_incoming_payment_success.html",
            admin=admin,
            receiver=receiver,
            amount=amount,
            previous_balance=previous_balance,
            new_balance=new_balance,
            sender_name=sender_name,
            sender_account_number=sender_account_number,
            sender_bank=sender_bank,
            sender_country=sender_country,
            payment_reference=payment_reference,
            payment_description=payment_description,
            transaction_reference=transaction_reference,
            posted_at=posted_at
        )
'''

if old2 not in text:
    print("ERROR: The existing incoming payment success render block was not found.")
    print("No changes were made.")
    raise SystemExit(1)

text = text.replace(old2, new2, 1)

APP_FILE.write_text(text, encoding="utf-8")

print()
print("=" * 70)
print("INCOMING PAYMENT RECEIPT ROUTE UPDATED")
print("=" * 70)
print()
print("Receipt now receives:")
print("  - Receiver information")
print("  - Sender information")
print("  - Payment reference")
print("  - Payment description")
print("  - Payment amount")
print("  - Previous balance")
print("  - New balance")
print("  - Transaction reference")
print("  - Posting date and time")
print()
print("Existing payment posting logic was preserved.")
print()