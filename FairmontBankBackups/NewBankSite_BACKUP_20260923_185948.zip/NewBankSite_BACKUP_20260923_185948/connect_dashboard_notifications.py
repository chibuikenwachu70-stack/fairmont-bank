from pathlib import Path

APP_FILE = Path("app.py")

if not APP_FILE.exists():
    raise SystemExit("ERROR: app.py was not found.")

text = APP_FILE.read_text(encoding="utf-8")

old_block = '''    return render_template(
        "dashboard.html",
        customer=customer
    )
'''

new_block = '''    notification_unread_count = (
        Notification.query
        .filter_by(
            customer_id=customer.customer_id,
            is_read=False
        )
        .count()
    )

    return render_template(
        "dashboard.html",
        customer=customer,
        notification_unread_count=notification_unread_count
    )
'''

if old_block not in text:
    raise SystemExit(
        "ERROR: The dashboard render block was not found exactly. "
        "No changes were made."
    )

text = text.replace(old_block, new_block, 1)

APP_FILE.write_text(text, encoding="utf-8")

print("SUCCESS: Dashboard now receives the unread notification count.")
print("Only the /dashboard route was changed.")