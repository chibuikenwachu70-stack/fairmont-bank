from pathlib import Path
import shutil
import re

BASE_DIR = Path(__file__).resolve().parent
APP_FILE = BASE_DIR / "app.py"

if not APP_FILE.exists():
    print("ERROR: app.py was not found.")
    raise SystemExit(1)

text = APP_FILE.read_text(encoding="utf-8")

if "class AdminUser(db.Model):" in text:
    print("Admin authentication model is already present.")
    raise SystemExit(0)

backup_file = BASE_DIR / "app.py.before_admin_auth"
shutil.copy2(APP_FILE, backup_file)

admin_model = r'''

# ============================================================
# FAIRMONT BANK ADMINISTRATION
# Admin authentication model
# ============================================================

class AdminUser(db.Model):
    __tablename__ = "admin_users"

    id = db.Column(db.Integer, primary_key=True)

    username = db.Column(
        db.String(80),
        unique=True,
        nullable=False,
        index=True
    )

    password_hash = db.Column(
        db.String(255),
        nullable=False
    )

    is_active = db.Column(
        db.Boolean,
        nullable=False,
        default=True
    )

    created_at = db.Column(
        db.DateTime,
        nullable=False,
        default=datetime.utcnow
    )


'''

match = re.search(r'(?m)^class\s+Customer\s*\(', text)

if not match:
    print("ERROR: Could not find the Customer model.")
    print("No changes were made.")
    raise SystemExit(1)

text = text[:match.start()] + admin_model + text[match.start():]

admin_routes = r'''

# ============================================================
# FAIRMONT BANK ADMINISTRATION
# Admin authentication
# ============================================================

@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():

    if request.method == "POST":

        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        if not username or not password:
            return render_template(
                "admin_login.html",
                error="Please enter your username and password."
            )

        admin = AdminUser.query.filter_by(
            username=username
        ).first()

        if (
            admin is None
            or not admin.is_active
            or not check_password_hash(
                admin.password_hash,
                password
            )
        ):
            return render_template(
                "admin_login.html",
                error="Invalid administrator credentials."
            )

        session["admin_id"] = admin.id
        session["admin_username"] = admin.username

        return redirect(url_for("admin_dashboard"))

    return render_template("admin_login.html")


@app.route("/admin/logout")
def admin_logout():

    session.pop("admin_id", None)
    session.pop("admin_username", None)

    return redirect(url_for("admin_login"))


@app.route("/admin")
def admin_dashboard():

    admin_id = session.get("admin_id")

    if not admin_id:
        return redirect(url_for("admin_login"))

    admin = db.session.get(AdminUser, admin_id)

    if admin is None or not admin.is_active:
        session.pop("admin_id", None)
        session.pop("admin_username", None)

        return redirect(url_for("admin_login"))

    return render_template(
        "admin_dashboard.html",
        admin=admin
    )


'''

run_pattern = re.compile(
    r'\nif\s+__name__\s*==\s*[\'"]__main__[\'"]\s*:\s*\n',
    re.MULTILINE
)

run_match = run_pattern.search(text)

if not run_match:
    print("ERROR: Could not find the final app.run block.")
    print("No changes were made.")
    raise SystemExit(1)

text = (
    text[:run_match.start()]
    + admin_routes
    + text[run_match.start():]
)

APP_FILE.write_text(text, encoding="utf-8")

print("=" * 70)
print("FAIRMONT BANK ADMIN AUTHENTICATION ADDED")
print("=" * 70)
print()
print("Added:")
print("  AdminUser database model")
print("  /admin/login")
print("  /admin/logout")
print("  /admin")
print()
print("Customer authentication was not changed.")
print()
print("Backup created:")
print(backup_file)
print()
print("Next step: create the admin account and admin templates.")
print("=" * 70)