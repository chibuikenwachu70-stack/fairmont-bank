from pathlib import Path
import re

BASE_DIR = Path(__file__).resolve().parent
FILE = BASE_DIR / "templates" / "admin_dashboard.html"

text = FILE.read_text(encoding="utf-8")

pattern = r'(<a\s+href=")#("\s+class="nav-link">\s*<span\s+class="nav-icon">.*?</span>\s*Accounts\s*</a>)'

match = re.search(
    pattern,
    text,
    flags=re.IGNORECASE | re.DOTALL
)

if not match:
    print("ERROR: Accounts sidebar link could not be located.")
    print("No changes were made.")
    raise SystemExit(1)

new_text = re.sub(
    pattern,
    r'\1/admin/accounts\2',
    text,
    count=1,
    flags=re.IGNORECASE | re.DOTALL
)

FILE.write_text(new_text, encoding="utf-8")

print("Accounts sidebar link connected successfully.")