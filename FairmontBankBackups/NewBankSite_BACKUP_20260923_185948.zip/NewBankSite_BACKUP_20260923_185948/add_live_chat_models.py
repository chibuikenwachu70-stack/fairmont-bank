from pathlib import Path
import shutil
import re

BASE_DIR = Path(__file__).resolve().parent
APP_FILE = BASE_DIR / "app.py"

if not APP_FILE.exists():
    print("ERROR: app.py was not found.")
    raise SystemExit(1)

text = APP_FILE.read_text(encoding="utf-8")

# Prevent accidental duplicate installation
if "class LiveChatConversation(db.Model):" in text:
    print("Live Chat database models are already present.")
    raise SystemExit(0)

# Create a safety backup of app.py
backup_file = BASE_DIR / "app.py.before_live_chat_models"
shutil.copy2(APP_FILE, backup_file)

live_chat_models = r'''

# ============================================================
# FAIRmont BANK LIVE CHAT
# Customer-to-Bank Support Chat Models
# ============================================================

class LiveChatConversation(db.Model):
    __tablename__ = "live_chat_conversations"

    id = db.Column(db.Integer, primary_key=True)

    customer_id = db.Column(
        db.Integer,
        db.ForeignKey("customer.id"),
        nullable=False,
        index=True
    )

    status = db.Column(
        db.String(30),
        nullable=False,
        default="Open"
    )

    subject = db.Column(
        db.String(200),
        nullable=False,
        default="Bank Support"
    )

    created_at = db.Column(
        db.DateTime,
        nullable=False,
        default=datetime.utcnow
    )

    updated_at = db.Column(
        db.DateTime,
        nullable=False,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )


class LiveChatMessage(db.Model):
    __tablename__ = "live_chat_messages"

    id = db.Column(db.Integer, primary_key=True)

    conversation_id = db.Column(
        db.Integer,
        db.ForeignKey("live_chat_conversations.id"),
        nullable=False,
        index=True
    )

    sender_type = db.Column(
        db.String(20),
        nullable=False
    )

    sender_id = db.Column(
        db.Integer,
        nullable=True
    )

    message = db.Column(
        db.Text,
        nullable=False
    )

    is_read = db.Column(
        db.Boolean,
        nullable=False,
        default=False
    )

    created_at = db.Column(
        db.DateTime,
        nullable=False,
        default=datetime.utcnow
    )

'''

# Insert the models immediately before Customer
match = re.search(r'(?m)^class\s+Customer\s*\(', text)

if not match:
    print("ERROR: Could not find the Customer model in app.py.")
    print("No changes were made.")
    raise SystemExit(1)

insert_position = match.start()

new_text = (
    text[:insert_position]
    + live_chat_models
    + "\n"
    + text[insert_position:]
)

APP_FILE.write_text(new_text, encoding="utf-8")

print("=" * 70)
print("LIVE CHAT DATABASE MODELS ADDED")
print("=" * 70)
print()
print("Updated:")
print(APP_FILE)
print()
print("Backup created:")
print(backup_file)
print()
print("Added tables:")
print("  - live_chat_conversations")
print("  - live_chat_messages")
print()
print("Existing customer/account data was not deleted or reset.")
print("Existing dashboard and login pages were not changed.")
print()
print("Next: test app.py syntax before starting the server.")
print("=" * 70)