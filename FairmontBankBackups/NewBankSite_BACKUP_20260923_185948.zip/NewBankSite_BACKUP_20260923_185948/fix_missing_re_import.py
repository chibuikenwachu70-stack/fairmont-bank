from pathlib import Path

APP = Path("app.py")

text = APP.read_text(encoding="utf-8-sig")

if "import re" in text:
    print("INFO: re is already imported.")
else:
    lines = text.splitlines()

    insert_at = 0

    for i, line in enumerate(lines):
        if line.startswith("import ") or line.startswith("from "):
            insert_at = i + 1

    lines.insert(insert_at, "import re")

    APP.write_text(
        "\n".join(lines) + "\n",
        encoding="utf-8"
    )

    print("SUCCESS: Added 'import re' to app.py.")