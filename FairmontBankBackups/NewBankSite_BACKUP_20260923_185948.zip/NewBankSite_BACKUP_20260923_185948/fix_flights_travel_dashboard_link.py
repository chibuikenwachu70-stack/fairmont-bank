from pathlib import Path

file = Path("templates/dashboard.html")

if not file.exists():
    raise SystemExit("ERROR: templates/dashboard.html was not found.")

text = file.read_text(encoding="utf-8")

old = """<!-- Flights and Travels -->

                    <a
                        href="#"
                        class="service-item">

                        <span class="service-icon">
                            ✈
                        </span>

                        <span class="service-name">
                            Flights &<br>
                            Travels
                        </span>

                    </a>"""

new = """<!-- Flights and Travels -->

                    <a
                        href="/flights-travel"
                        class="service-item">

                        <span class="service-icon">
                            ✈
                        </span>

                        <span class="service-name">
                            Flights &<br>
                            Travels
                        </span>

                    </a>"""

if old not in text:
    raise SystemExit(
        "ERROR: The exact Flights & Travels card was not found. "
        "No changes were made."
    )

text = text.replace(old, new, 1)

file.write_text(text, encoding="utf-8")

print("SUCCESS: Flights & Travels dashboard card now opens /flights-travel.")
print("Only the Flights & Travels card was changed.")