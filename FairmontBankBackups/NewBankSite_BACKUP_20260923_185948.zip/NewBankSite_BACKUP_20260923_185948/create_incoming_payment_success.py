from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
TEMPLATES = BASE_DIR / "templates"

TEMPLATES.mkdir(exist_ok=True)

template = r'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Payment Posted | Fairmont Bank</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            font-family: Arial, Helvetica, sans-serif;
            background:
                radial-gradient(
                    circle at top left,
                    rgba(184,149,74,.10),
                    transparent 32%
                ),
                #071525;
            color: #edf3fb;
        }

        .page {
            width: 100%;
            max-width: 850px;
            margin: 0 auto;
            padding: 40px 20px 60px;
        }

        .card {
            background: rgba(12, 31, 51, .94);
            border: 1px solid rgba(184,149,74,.20);
            border-radius: 22px;
            padding: 34px;
            box-shadow: 0 25px 70px rgba(0,0,0,.30);
        }

        .brand {
            text-align: center;
            color: #ffffff;
            font-size: 20px;
            font-weight: 800;
            letter-spacing: 1.5px;
            margin-bottom: 30px;
        }

        .brand span {
            color: #d5b467;
        }

        .success-icon {
            width: 64px;
            height: 64px;
            margin: 0 auto 20px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(70,190,125,.12);
            border: 1px solid rgba(100,220,155,.30);
            color: #9de7bc;
            font-size: 30px;
            font-weight: 800;
        }

        h1 {
            text-align: center;
            margin: 0 0 9px;
            font-size: 29px;
        }

        .intro {
            text-align: center;
            margin: 0 auto 30px;
            max-width: 600px;
            color: #8fa5bd;
            line-height: 1.6;
            font-size: 14px;
        }

        .amount {
            text-align: center;
            margin-bottom: 30px;
        }

        .amount-label {
            color: #8298b0;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 7px;
        }

        .amount-value {
            color: #d5b467;
            font-size: 36px;
            font-weight: 800;
        }

        .section {
            border-top: 1px solid rgba(255,255,255,.08);
            padding-top: 24px;
            margin-top: 24px;
        }

        .section h2 {
            margin: 0 0 16px;
            font-size: 16px;
            color: #ffffff;
        }

        .details {
            display: grid;
            grid-template-columns: repeat(2, minmax(0,1fr));
            gap: 1px;
            background: rgba(255,255,255,.06);
            border: 1px solid rgba(255,255,255,.07);
            border-radius: 13px;
            overflow: hidden;
        }

        .detail {
            padding: 15px;
            background: rgba(7,21,37,.55);
        }

        .label {
            color: #7188a1;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: .7px;
            margin-bottom: 6px;
        }

        .value {
            color: #f1f5f9;
            font-size: 14px;
            font-weight: 700;
            word-break: break-word;
        }

        .balance {
            margin-top: 20px;
            padding: 18px;
            border-radius: 13px;
            background: rgba(184,149,74,.07);
            border: 1px solid rgba(184,149,74,.18);
        }

        .balance-label {
            color: #8499b0;
            font-size: 12px;
            margin-bottom: 7px;
        }

        .balance-value {
            color: #ffffff;
            font-size: 24px;
            font-weight: 800;
        }

        .actions {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 12px;
            margin-top: 30px;
        }

        .button {
            display: inline-block;
            text-decoration: none;
            border-radius: 11px;
            padding: 13px 20px;
            background: #b8954a;
            color: #081625;
            font-size: 14px;
            font-weight: 800;
        }

        .button:hover {
            background: #d5b467;
        }

        .button.secondary {
            background: rgba(255,255,255,.06);
            border: 1px solid rgba(255,255,255,.10);
            color: #c8d5e3;
        }

        .button.secondary:hover {
            background: rgba(255,255,255,.10);
        }

        @media (max-width: 650px) {

            .page {
                padding: 20px 12px 40px;
            }

            .card {
                padding: 24px 17px;
            }

            .details {
                grid-template-columns: 1fr;
            }

            .amount-value {
                font-size: 31px;
            }

            .actions {
                flex-direction: column;
            }

            .button {
                width: 100%;
                text-align: center;
            }
        }
    </style>
</head>

<body>

<div class="page">

    <div class="card">

        <div class="brand">
            FAIRMONT <span>BANK</span>
        </div>

        <div class="success-icon">
            ✓
        </div>

        <h1>Incoming Payment Posted</h1>

        <p class="intro">
            The payment has been successfully credited to the selected
            Fairmont Bank customer's account and recorded in the transaction
            history.
        </p>

        <div class="amount">

            <div class="amount-label">
                Amount Received
            </div>

            <div class="amount-value">
                £{{ "{:,.2f}".format(amount|float) }}
            </div>

        </div>

        <div class="section">

            <h2>Receiving Customer</h2>

            <div class="details">

                <div class="detail">
                    <div class="label">
                        Account Holder
                    </div>

                    <div class="value">
                        {{ receiver.full_name }}
                    </div>
                </div>

                <div class="detail">
                    <div class="label">
                        Customer ID
                    </div>

                    <div class="value">
                        {{ receiver.customer_id }}
                    </div>
                </div>

                <div class="detail">
                    <div class="label">
                        Account Number
                    </div>

                    <div class="value">
                        {{ receiver.account_number or "Not assigned" }}
                    </div>
                </div>

                <div class="detail">
                    <div class="label">
                        Payment Reference
                    </div>

                    <div class="value">
                        {{ payment_reference }}
                    </div>
                </div>

            </div>

            <div class="balance">

                <div class="balance-label">
                    New Available Balance
                </div>

                <div class="balance-value">
                    £{{ "{:,.2f}".format(new_balance|float) }}
                </div>

            </div>

        </div>

        <div class="section">

            <h2>Sender Information</h2>

            <div class="details">

                <div class="detail">
                    <div class="label">
                        Sender Name
                    </div>

                    <div class="value">
                        {{ sender_name }}
                    </div>
                </div>

                <div class="detail">
                    <div class="label">
                        Sender Account
                    </div>

                    <div class="value">
                        {{ sender_account_number }}
                    </div>
                </div>

                <div class="detail">
                    <div class="label">
                        Sender Bank
                    </div>

                    <div class="value">
                        {{ sender_bank }}
                    </div>
                </div>

                <div class="detail">
                    <div class="label">
                        Sender Country
                    </div>

                    <div class="value">
                        {{ sender_country }}
                    </div>
                </div>

            </div>

        </div>

        <div class="section">

            <h2>Transaction Information</h2>

            <div class="details">

                <div class="detail">
                    <div class="label">
                        Transaction Type
                    </div>

                    <div class="value">
                        Payment Received
                    </div>
                </div>

                <div class="detail">
                    <div class="label">
                        Direction
                    </div>

                    <div class="value">
                        Credit
                    </div>
                </div>

                <div class="detail">
                    <div class="label">
                        Transaction Reference
                    </div>

                    <div class="value">
                        {{ transaction_reference }}
                    </div>
                </div>

                <div class="detail">
                    <div class="label">
                        Status
                    </div>

                    <div class="value">
                        Completed
                    </div>
                </div>

                <div class="detail" style="grid-column: 1 / -1;">
                    <div class="label">
                        Description
                    </div>

                    <div class="value">
                        {{ description }}
                    </div>
                </div>

            </div>

        </div>

        <div class="actions">

            <a
                href="{{ url_for('admin_incoming_payment') }}"
                class="button"
            >
                Post Another Payment
            </a>

            <a
                href="{{ url_for('admin_transactions') }}"
                class="button secondary"
            >
                Transaction Management
            </a>

            <a
                href="{{ url_for('admin_customer_profile', customer_id=receiver.id) }}"
                class="button secondary"
            >
                View Customer
            </a>

        </div>

    </div>

</div>

</body>
</html>
'''

output = TEMPLATES / "admin_incoming_payment_success.html"

output.write_text(
    template,
    encoding="utf-8"
)

print()
print("=" * 70)
print("INCOMING PAYMENT SUCCESS PAGE CREATED")
print("=" * 70)
print()
print(output)
print()
print("Existing database and customer records were not changed.")
print()