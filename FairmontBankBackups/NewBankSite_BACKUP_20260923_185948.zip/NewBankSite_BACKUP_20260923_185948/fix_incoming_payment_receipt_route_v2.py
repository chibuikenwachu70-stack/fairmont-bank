from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
APP_FILE = BASE_DIR / "app.py"

if not APP_FILE.exists():
    print("ERROR: app.py was not found.")
    raise SystemExit(1)

text = APP_FILE.read_text(encoding="utf-8")

# ------------------------------------------------------------
# 1. Add previous balance immediately before the balance update.
# ------------------------------------------------------------

old_balance = '''          receiver.account_balance = new_balance
'''

new_balance = '''          previous_balance = float(
              receiver.account_balance or 0
          )

          receiver.account_balance = new_balance

          posted_at = datetime.now().strftime(
              "%d %B %Y, %H:%M:%S"
          )
'''

if old_balance not in text:
    print("ERROR: Could not find the receiver balance update.")
    print("No changes were made.")
    raise SystemExit(1)

# Only modify the occurrence inside the incoming-payment area.
payment_start = text.find(
    '@app.route("/admin/incoming-payment", methods=["GET", "POST"])'
)

if payment_start == -1:
    print("ERROR: Incoming payment route was not found.")
    raise SystemExit(1)

payment_end = text.find(
    '\n  if __name__ == "__main__":',
    payment_start
)

if payment_end == -1:
    print("ERROR: Could not find the end of the incoming payment route.")
    raise SystemExit(1)

route = text[payment_start:payment_end]

if "previous_balance = float(" not in route:
    route = route.replace(
        old_balance,
        new_balance,
        1
    )

# ------------------------------------------------------------
# 2. Add previous_balance and posted_at to the receipt.
# ------------------------------------------------------------

old_render = '''              transaction_reference=transaction_reference,
              new_balance=new_balance
'''

new_render = '''              transaction_reference=transaction_reference,
              previous_balance=previous_balance,
              new_balance=new_balance,
              posted_at=posted_at
'''

if old_render not in route:
    print(
        "ERROR: Could not find the incoming payment receipt "
        "render block."
    )
    print("No changes were made.")
    raise SystemExit(1)

route = route.replace(
    old_render,
    new_render,
    1
)

# ------------------------------------------------------------
# 3. Add the corrected route back into app.py.
# ------------------------------------------------------------

text = (
    text[:payment_start]
    + route
    + text[payment_end:]
)

APP_FILE.write_text(
    text,
    encoding="utf-8"
)

print()
print("=" * 70)
print("INCOMING PAYMENT RECEIPT ROUTE UPDATED")
print("=" * 70)
print()
print("Receipt now receives:")
print("  - Receiver information")
print("  - Sender information")
print("  - Payment reference")
print("  - Payment description")
print("  - Payment amount")
print("  - Previous balance")
print("  - New balance")
print("  - Transaction reference")
print("  - Posting date and time")
print()
print("Existing payment posting logic was preserved.")
print()