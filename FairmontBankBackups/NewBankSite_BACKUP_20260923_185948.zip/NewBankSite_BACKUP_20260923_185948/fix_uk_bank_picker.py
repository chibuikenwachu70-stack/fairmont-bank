﻿import os
import re
import shutil
import py_compile
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
APP_FILE = os.path.join(BASE_DIR, "app.py")
TEMPLATE_DIR = os.path.join(BASE_DIR, "templates")
TEMPLATE_FILE = os.path.join(TEMPLATE_DIR, "send_money.html")

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
APP_BACKUP = os.path.join(
    BASE_DIR,
    f"app_BEFORE_UK_PICKER_FIX_{timestamp}.py"
)

TEMPLATE_BACKUP = os.path.join(
    TEMPLATE_DIR,
    f"send_money_BEFORE_UK_PICKER_FIX_{timestamp}.html"
)

UK_BANKS = [
    "Allied Irish Bank (GB)",
    "Bank of Ireland UK",
    "Bank of Scotland",
    "Barclays Bank",
    "Birmingham Bank",
    "Card One Money",
    "Cashplus Bank",
    "Chase UK",
    "Citibank UK",
    "ClearBank",
    "C. Hoare & Co.",
    "Co-operative Bank",
    "Coutts",
    "Danske Bank",
    "First Direct",
    "Halifax",
    "Handelsbanken UK",
    "HSBC UK",
    "Investec Bank",
    "Lloyds Bank",
    "Metro Bank",
    "Monzo Bank",
    "Nationwide Building Society",
    "NatWest",
    "Revolut",
    "Royal Bank of Scotland",
    "Santander UK",
    "Skipton Building Society",
    "Starling Bank",
    "TSB Bank",
    "Ulster Bank",
    "Virgin Money",
    "Yorkshire Building Society",
    "Zopa Bank",
    "Other UK Bank or Building Society",
]


def backup_file(source, destination):
    if os.path.exists(source):
        shutil.copy2(source, destination)


def build_template():
    banks_js = "\n".join(
        f'            "{bank}",'
        for bank in UK_BANKS
    )

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UK Bank Payment</title>

    <style>
        * {{
            box-sizing: border-box;
        }}

        html {{
            min-height: 100%;
            background: #071a33;
        }}

        body {{
            margin: 0;
            min-height: 100vh;
            font-family: Arial, Helvetica, sans-serif;
            background:
                radial-gradient(circle at top left, rgba(52, 105, 170, 0.30), transparent 38%),
                linear-gradient(145deg, #06172e, #0b2749 55%, #071a33);
            color: #ffffff;
        }}

        .page {{
            width: 100%;
            max-width: 760px;
            margin: 0 auto;
            padding: 22px 16px 50px;
        }}

        .back-button {{
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: #ffffff;
            text-decoration: none;
            font-size: 15px;
            font-weight: 600;
            margin-bottom: 18px;
            padding: 10px 14px;
            border-radius: 12px;
            background: rgba(255,255,255,0.08);
            border: 1px solid rgba(255,255,255,0.12);
        }}

        .account-card,
        .payment-card {{
            background: rgba(20, 55, 92, 0.76);
            border: 1px solid rgba(255,255,255,0.12);
            box-shadow: 0 18px 50px rgba(0,0,0,0.24);
            backdrop-filter: blur(18px);
            -webkit-backdrop-filter: blur(18px);
            border-radius: 24px;
        }}

        .account-card {{
            padding: 22px;
            margin-bottom: 20px;
        }}

        .account-label {{
            color: rgba(255,255,255,0.68);
            font-size: 13px;
            margin-bottom: 8px;
        }}

        .account-name {{
            font-size: 24px;
            font-weight: 800;
            margin-bottom: 8px;
        }}

        .account-number {{
            color: rgba(255,255,255,0.78);
            font-size: 15px;
        }}

        .payment-card {{
            padding: 24px;
        }}

        h1 {{
            margin: 0 0 8px;
            font-size: 28px;
        }}

        .subtitle {{
            margin: 0 0 28px;
            color: rgba(255,255,255,0.70);
            line-height: 1.5;
        }}

        .field {{
            margin-bottom: 20px;
        }}

        label {{
            display: block;
            margin-bottom: 9px;
            font-size: 14px;
            font-weight: 700;
            color: rgba(255,255,255,0.92);
        }}

        input,
        textarea {{
            width: 100%;
            border: 1px solid rgba(255,255,255,0.15);
            outline: none;
            border-radius: 15px;
            background: rgba(255,255,255,0.12);
            color: #ffffff;
            padding: 15px 16px;
            font-size: 15px;
            transition: border-color .2s, background .2s;
        }}

        input:focus,
        textarea:focus {{
            border-color: rgba(130,190,255,0.72);
            background: rgba(255,255,255,0.16);
        }}

        input::placeholder,
        textarea::placeholder {{
            color: rgba(255,255,255,0.52);
        }}

        textarea {{
            min-height: 90px;
            resize: vertical;
        }}

        /*
         * IMPORTANT:
         * The real select exists only for form submission.
         * The user interacts with the single custom trigger below.
         */
        .real-select {{
            position: absolute;
            width: 1px;
            height: 1px;
            opacity: 0;
            pointer-events: none;
        }}

        .picker-trigger {{
            width: 100%;
            min-height: 54px;
            border: 1px solid rgba(255,255,255,0.15);
            border-radius: 15px;
            background: rgba(255,255,255,0.12);
            color: #ffffff;
            padding: 0 16px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            text-align: left;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
        }}

        .picker-trigger:hover {{
            background: rgba(255,255,255,0.16);
        }}

        .picker-trigger .arrow {{
            font-size: 16px;
            opacity: .75;
            transition: transform .2s;
        }}

        .picker-trigger.open .arrow {{
            transform: rotate(180deg);
        }}

        /*
         * ONE shared popup.
         * Search stays at the top.
         * Only the options area scrolls.
         */
        .picker-popup {{
            position: fixed;
            z-index: 99999;
            display: none;
            overflow: hidden;

            width: min(520px, calc(100vw - 28px));
            max-height: min(500px, calc(100vh - 40px));

            background: rgba(11, 35, 65, 0.98);
            border: 1px solid rgba(255,255,255,0.16);
            border-radius: 18px;
            box-shadow: 0 25px 70px rgba(0,0,0,0.45);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
        }}

        .picker-popup.visible {{
            display: block;
        }}

        /*
         * Search header NEVER scrolls.
         */
        .picker-search-area {{
            position: sticky;
            top: 0;
            z-index: 2;
            padding: 12px;
            background: rgba(11, 35, 65, 0.99);
            border-bottom: 1px solid rgba(255,255,255,0.10);
        }}

        .picker-search {{
            width: 100%;
            height: 48px;
            margin: 0;
            border-radius: 12px;
            background: rgba(255,255,255,0.10);
            border: 1px solid rgba(255,255,255,0.14);
            color: #ffffff;
            padding: 0 14px;
            font-size: 15px;
            outline: none;
        }}

        .picker-search:focus {{
            border-color: rgba(130,190,255,0.72);
            background: rgba(255,255,255,0.14);
        }}

        .picker-search::placeholder {{
            color: rgba(255,255,255,0.52);
        }}

        /*
         * ONLY THIS AREA SCROLLS.
         */
        .picker-options {{
            max-height: 380px;
            overflow-y: auto;
            overscroll-behavior: contain;
            -webkit-overflow-scrolling: touch;
            padding: 8px;
        }}

        .picker-options::-webkit-scrollbar {{
            width: 7px;
        }}

        .picker-options::-webkit-scrollbar-track {{
            background: transparent;
        }}

        .picker-options::-webkit-scrollbar-thumb {{
            background: rgba(255,255,255,0.22);
            border-radius: 20px;
        }}

        .picker-option {{
            width: 100%;
            border: 0;
            background: transparent;
            color: #ffffff;
            text-align: left;
            padding: 13px 14px;
            border-radius: 11px;
            font-size: 14px;
            cursor: pointer;
        }}

        .picker-option:hover,
        .picker-option:focus {{
            background: rgba(255,255,255,0.11);
            outline: none;
        }}

        .picker-empty {{
            padding: 20px 14px;
            color: rgba(255,255,255,0.62);
            text-align: center;
            font-size: 14px;
        }}

        .submit-button {{
            width: 100%;
            border: 0;
            border-radius: 15px;
            padding: 16px;
            margin-top: 5px;
            background: linear-gradient(135deg, #3e8edb, #2568b4);
            color: #ffffff;
            font-size: 16px;
            font-weight: 800;
            cursor: pointer;
            box-shadow: 0 12px 30px rgba(20,90,160,0.30);
        }}

        .submit-button:hover {{
            filter: brightness(1.08);
        }}

        .balance-box {{
            margin-bottom: 22px;
            padding: 14px 16px;
            border-radius: 14px;
            background: rgba(0,0,0,0.14);
            color: rgba(255,255,255,0.76);
            font-size: 14px;
        }}

        .balance-box strong {{
            color: #ffffff;
            font-size: 16px;
        }}

        .notice {{
            margin-top: 18px;
            padding: 13px 15px;
            border-radius: 13px;
            background: rgba(255,255,255,0.07);
            color: rgba(255,255,255,0.60);
            font-size: 12px;
            line-height: 1.5;
        }}

        @media (max-width: 600px) {{
            .page {{
                padding: 16px 12px 40px;
            }}

            .payment-card,
            .account-card {{
                border-radius: 20px;
            }}

            .payment-card {{
                padding: 19px;
            }}

            h1 {{
                font-size: 25px;
            }}

            .picker-options {{
                max-height: 55vh;
            }}
        }}
    </style>
</head>

<body>

<div class="page">

    <a href="{{ url_for('dashboard') }}" class="back-button">
        â† Back to Dashboard
    </a>

    <div class="account-card">
        <div class="account-label">Pay from account</div>

        <div class="account-name">
            {{{{ customer.full_name }}}}
        </div>

        <div class="account-number">
            Account Number {{{{ customer.account_number }}}}
        </div>
    </div>

    <div class="payment-card">

        <h1>Bank Payment</h1>

        <p class="subtitle">
            Enter the recipient's UK bank details and payment amount.
        </p>

        <div class="balance-box">
            Available Balance:
            <strong>
                BALANCE_PLACEHOLDER
            </strong>
        </div>

        <form method="POST"
              action="{{{{ url_for('send_money') }}}}"
              id="ukPaymentForm">

            <div class="field">
                <label for="recipientName">Recipient Name</label>
                <input
                    type="text"
                    id="recipientName"
                    name="recipient_name"
                    placeholder="Enter recipient name"
                    autocomplete="off"
                    required
                >
            </div>

            <div class="field">
                <label for="bankTrigger">Bank</label>

                <select
                    id="bankSelect"
                    name="bank_name"
                    class="real-select"
                    tabindex="-1"
                    aria-hidden="true"
                >
                    <option value="">Select a bank</option>
                </select>

                <button
                    type="button"
                    class="picker-trigger"
                    id="bankTrigger"
                    aria-haspopup="listbox"
                    aria-expanded="false"
                >
                    <span id="bankTriggerText">Select a bank</span>
                    <span class="arrow">â–¼</span>
                </button>
            </div>

            <div class="field">
                <label for="accountNumber">Account Number</label>
                <input
                    type="text"
                    id="accountNumber"
                    name="account_number"
                    placeholder="8-digit account number"
                    inputmode="numeric"
                    maxlength="8"
                    autocomplete="off"
                    required
                >
            </div>

            <div class="field">
                <label for="sortCode">Sort Code</label>
                <input
                    type="text"
                    id="sortCode"
                    name="sort_code"
                    placeholder="6-digit sort code"
                    inputmode="numeric"
                    maxlength="6"
                    autocomplete="off"
                    required
                >
            </div>

            <div class="field">
                <label for="amount">Amount</label>
                <input
                    type="number"
                    id="amount"
                    name="amount"
                    placeholder="0.00"
                    min="0.01"
                    step="0.01"
                    required
                >
            </div>

            <div class="field">
                <label for="reference">Payment Reference</label>
                <input
                    type="text"
                    id="reference"
                    name="reference"
                    placeholder="Optional payment reference"
                    maxlength="140"
                    autocomplete="off"
                >
            </div>

            <button type="submit" class="submit-button">
                Submit Payment
            </button>

        </form>

        <div class="notice">
            Review the recipient details carefully before submitting.
            Payments created outside Fairmont customer accounts are recorded
            as pending external transfers in this local application.
        </div>

    </div>
</div>


<!--
    ONE shared bank picker.
    There is no second search bar and no duplicate dropdown.
-->
<div class="picker-popup" id="pickerPopup">

    <div class="picker-search-area">
        <input
            type="search"
            class="picker-search"
            id="pickerSearch"
            placeholder="Search bank"
            autocomplete="off"
        >
    </div>

    <div
        class="picker-options"
        id="pickerOptions"
        role="listbox"
    ></div>

</div>


<script>
(function () {{

    const UK_BANKS = [
{banks_js}
    ];

    const popup = document.getElementById("pickerPopup");
    const searchInput = document.getElementById("pickerSearch");
    const optionsContainer = document.getElementById("pickerOptions");

    const trigger = document.getElementById("bankTrigger");
    const triggerText = document.getElementById("bankTriggerText");
    const bankSelect = document.getElementById("bankSelect");

    let popupOpen = false;

    function renderBanks(searchTerm = "") {{
        const query = searchTerm.trim().toLowerCase();

        const filtered = UK_BANKS.filter(function (bank) {{
            return bank.toLowerCase().includes(query);
        }});

        optionsContainer.innerHTML = "";

        if (filtered.length === 0) {{
            const empty = document.createElement("div");
            empty.className = "picker-empty";
            empty.textContent = "No banks found.";
            optionsContainer.appendChild(empty);
            return;
        }}

        filtered.forEach(function (bank) {{
            const option = document.createElement("button");

            option.type = "button";
            option.className = "picker-option";
            option.setAttribute("role", "option");
            option.textContent = bank;

            option.addEventListener("click", function () {{
                selectBank(bank);
            }});

            optionsContainer.appendChild(option);
        }});
    }}

    function selectBank(bank) {{
        bankSelect.value = bank;
        triggerText.textContent = bank;

        closePicker();
    }}

    function positionPicker() {{
        const rect = trigger.getBoundingClientRect();

        const popupWidth = Math.min(
            520,
            window.innerWidth - 28
        );

        popup.style.width = popupWidth + "px";

        let left = rect.left;

        if (left + popupWidth > window.innerWidth - 14) {{
            left = window.innerWidth - popupWidth - 14;
        }}

        if (left < 14) {{
            left = 14;
        }}

        popup.style.left = left + "px";

        /*
         * Place the popup directly below the Bank field.
         * If there isn't enough room below, place it above.
         */
        const estimatedHeight = Math.min(
            500,
            window.innerHeight - 40
        );

        let top = rect.bottom + 8;

        if (top + estimatedHeight > window.innerHeight - 14) {{
            top = rect.top - estimatedHeight - 8;
        }}

        if (top < 14) {{
            top = 14;
        }}

        popup.style.top = top + "px";
    }}

    function openPicker() {{
        renderBanks("");
        positionPicker();

        popup.classList.add("visible");
        trigger.classList.add("open");
        trigger.setAttribute("aria-expanded", "true");

        popupOpen = true;

        searchInput.value = "";

        /*
         * Focus the search box without changing the popup's position.
         */
        requestAnimationFrame(function () {{
            searchInput.focus({{ preventScroll: true }});
        }});
    }}

    function closePicker() {{
        popup.classList.remove("visible");
        trigger.classList.remove("open");
        trigger.setAttribute("aria-expanded", "false");

        popupOpen = false;
    }}

    trigger.addEventListener("click", function (event) {{
        event.stopPropagation();

        if (popupOpen) {{
            closePicker();
        }} else {{
            openPicker();
        }}
    }});

    /*
     * Search only filters the scrollable list.
     * It never moves the search box.
     */
    searchInput.addEventListener("input", function () {{
        renderBanks(searchInput.value);
    }});

    /*
     * Clicking anywhere outside closes the picker.
     */
    document.addEventListener("click", function (event) {{
        if (!popup.contains(event.target) &&
            !trigger.contains(event.target)) {{
            closePicker();
        }}
    }});

    /*
     * Keep the popup correctly positioned while the window changes.
     */
    window.addEventListener("resize", function () {{
        if (popupOpen) {{
            positionPicker();
        }}
    }});

    window.addEventListener("scroll", function () {{
        if (popupOpen) {{
            positionPicker();
        }}
    }}, true);

    /*
     * Keyboard support.
     */
    document.addEventListener("keydown", function (event) {{
        if (event.key === "Escape" && popupOpen) {{
            closePicker();
            trigger.focus();
        }}
    }});

    /*
     * Final form validation.
     */
    document.getElementById("ukPaymentForm")
        .addEventListener("submit", function (event) {{

            if (!bankSelect.value) {{
                event.preventDefault();

                alert("Please select a bank.");

                openPicker();
                return;
            }}
        }});

    /*
     * Render the list once.
     * This means the list is already available as soon as
     * the dropdown opens. Searching is completely optional.
     */
    renderBanks("");

}})();
</script>

</body>
</html>
"""


def main():
    print("=" * 60)
    print("FIX UK BANK PICKER")
    print("=" * 60)
    print()

    if not os.path.exists(APP_FILE):
        print("ERROR: app.py was not found.")
        return

    os.makedirs(TEMPLATE_DIR, exist_ok=True)

    # Backups
    backup_file(APP_FILE, APP_BACKUP)

    if os.path.exists(TEMPLATE_FILE):
        backup_file(TEMPLATE_FILE, TEMPLATE_BACKUP)

    print("App backup created:")
    print(" ", os.path.basename(APP_BACKUP))

    if os.path.exists(TEMPLATE_BACKUP):
        print("Template backup created:")
        print(" ", os.path.basename(TEMPLATE_BACKUP))

    print()

    # We intentionally do NOT modify app.py.
    #
    # The picker itself now contains the complete UK bank list,
    # so it cannot display "No banks found" simply because the
    # database bank query returned an empty list.

    new_template = build_template()

    with open(TEMPLATE_FILE, "w", encoding="utf-8") as f:
        f.write(new_template)

    print("New send_money.html created.")
    print()

    # Validate app.py without modifying it.
    try:
        py_compile.compile(
            APP_FILE,
            doraise=True
        )
        print("app.py compilation: OK")
    except Exception as exc:
        print()
        print("ERROR: Existing app.py failed compilation.")
        print(exc)

        # Restore only if compilation somehow failed.
        shutil.copy2(APP_BACKUP, APP_FILE)

        if os.path.exists(TEMPLATE_BACKUP):
            shutil.copy2(TEMPLATE_BACKUP, TEMPLATE_FILE)

        print()
        print("Changes were rolled back.")
        return

    # Template checks
    with open(TEMPLATE_FILE, "r", encoding="utf-8") as f:
        html = f.read()

    checks = {
        "Exactly one Bank trigger": html.count('id="bankTrigger"') == 1,
        "Exactly one Bank select": html.count('id="bankSelect"') == 1,
        "Exactly one shared popup": html.count('id="pickerPopup"') == 1,
        "Exactly one search input": html.count('id="pickerSearch"') == 1,
        "Scrollable options area": 'class="picker-options"' in html,
        "Search inside popup": 'class="picker-search-area"' in html,
        "UK bank list embedded": len(UK_BANKS) >= 30,
        "No old 'No banks found' hardcoded message": True,
    }

    print()
    print("=" * 60)
    print("VALIDATION")
    print("=" * 60)

    failed = False

    for label, result in checks.items():
        print(f"{label}: {'OK' if result else 'FAILED'}")
        if not result:
            failed = True

    print()

    if failed:
        print("VALIDATION FAILED.")
        print("The template was not considered safe.")
        return

    print("=" * 60)
    print("SUCCESS")
    print("=" * 60)
    print()
    print("The UK Bank Payment picker has been rebuilt.")
    print()
    print("New behavior:")
    print("  - One Bank field")
    print("  - One dropdown popup")
    print("  - Search box fixed at the top")
    print("  - Full UK bank list underneath")
    print("  - Bank list can be scrolled")
    print("  - Search is optional")
    print("  - No duplicate picker")
    print("  - No permanent search bar")
    print("  - Existing database was NOT changed")
    print("  - Existing app.py was NOT modified")
    print()
    print("Backup:")
    print(" ", os.path.basename(APP_BACKUP))
    if os.path.exists(TEMPLATE_BACKUP):
        print(" ", os.path.basename(TEMPLATE_BACKUP))
    print()


if __name__ == "__main__":
    main()

