from pathlib import Path
import shutil

FILE = Path("templates/admin_dashboard.html")

text = FILE.read_text(encoding="utf-8")

backup = Path("templates/admin_dashboard.html.before_customer_management_link")
shutil.copy2(FILE, backup)

# Find the Customer Management heading/card.
marker = "Customer Management"

position = text.find(marker)

if position == -1:
    print("ERROR: Customer Management text was not found.")
    print("Backup created:", backup)
    raise SystemExit(1)

# Find the nearest opening anchor before the heading.
start = text.rfind("<a", 0, position)
end = text.find("</a>", position)

if start == -1 or end == -1:
    print("ERROR: Customer Management link/card could not be located.")
    print("Backup created:", backup)
    raise SystemExit(1)

end += len("</a>")

block = text[start:end]

# Replace only the href in this specific Customer Management block.
updated_block = block

if 'href="/admin/customers"' not in updated_block:
    import re

    updated_block, replacements = re.subn(
        r'href\s*=\s*["\'][^"\']*["\']',
        'href="/admin/customers"',
        updated_block,
        count=1
    )

    if replacements == 0:
        print("ERROR: No href was found in the Customer Management block.")
        print("Backup created:", backup)
        raise SystemExit(1)

text = text[:start] + updated_block + text[end:]

FILE.write_text(text, encoding="utf-8")

print("=" * 70)
print("CUSTOMER MANAGEMENT LINK CONNECTED")
print("=" * 70)
print()
print("Customer Management now opens:")
print("/admin/customers")
print()
print("Backup created:")
print(backup)