from pathlib import Path
from datetime import datetime
import shutil
import re

BASE = Path(".")
APP = BASE / "app.py"
TEMPLATES = BASE / "templates"

print()
print("=" * 60)
print("CLEAN UK BANK + INTERNATIONAL TRANSFER SECTIONS")
print("=" * 60)
print()

if not APP.exists():
    print("ERROR: app.py was not found.")
    raise SystemExit(1)

if not TEMPLATES.exists():
    print("ERROR: templates folder was not found.")
    raise SystemExit(1)

app_text = APP.read_text(encoding="utf-8")

stamp = datetime.now().strftime("%Y%m%d_%H%M%S")

# ---------------------------------------------------------
# BACKUP APP
# ---------------------------------------------------------

app_backup = APP.with_name(
    "app_BEFORE_TRANSFER_CLEAN_" + stamp + ".py"
)

shutil.copy2(APP, app_backup)

print("App backup created:")
print(" ", app_backup.name)

# ---------------------------------------------------------
# BACKUP RELEVANT TEMPLATES
# ---------------------------------------------------------

template_names = [
    "international_transfer.html",
    "send_money.html",
]

backups = []

for name in template_names:
    path = TEMPLATES / name

    if path.exists():
        backup = TEMPLATES / (
            Path(name).stem
            + "_BEFORE_TRANSFER_CLEAN_"
            + stamp
            + Path(name).suffix
        )

        shutil.copy2(path, backup)
        backups.append(backup)

        print("Template backup created:")
        print(" ", backup.name)

# ---------------------------------------------------------
# REMOVE INTERNATIONAL TRANSFER ROUTE
# ---------------------------------------------------------

international_pattern = re.compile(
    r"""
    ^@app\.route\(
        \s*['"]/international-transfer['"]
        [^)]*
    \)
    \s*
    .*?
    (?=
        ^@app\.route\(
        |
        ^if __name__\s*==\s*['"]__main__['"]
    )
    """,
    re.IGNORECASE | re.MULTILINE | re.DOTALL | re.VERBOSE
)

international_match = international_pattern.search(app_text)

if international_match:
    app_text = (
        app_text[:international_match.start()]
        + app_text[international_match.end():]
    )

    print()
    print("International Transfer route: REMOVED")
else:
    print()
    print("International Transfer route: NOT FOUND")

# ---------------------------------------------------------
# REMOVE SEND MONEY ROUTE
#
# This removes the current UK/Fairmont transfer route so
# it can be rebuilt cleanly.
# ---------------------------------------------------------

send_money_pattern = re.compile(
    r"""
    ^@app\.route\(
        \s*['"]/send-money['"]
        [^)]*
    \)
    \s*
    .*?
    (?=
        ^@app\.route\(
        |
        ^if __name__\s*==\s*['"]__main__['"]
    )
    """,
    re.IGNORECASE | re.MULTILINE | re.DOTALL | re.VERBOSE
)

send_money_match = send_money_pattern.search(app_text)

if send_money_match:
    app_text = (
        app_text[:send_money_match.start()]
        + app_text[send_money_match.end():]
    )

    print("UK Send Money route: REMOVED")
else:
    print("UK Send Money route: NOT FOUND")

# ---------------------------------------------------------
# DELETE OLD TEMPLATES
# ---------------------------------------------------------

for name in template_names:
    path = TEMPLATES / name

    if path.exists():
        path.unlink()
        print("Old template removed:", name)

# ---------------------------------------------------------
# VERIFY ROUTES ARE GONE
# ---------------------------------------------------------

remaining_international = len(
    re.findall(
        r"@app\.route\(\s*['\"]/international-transfer['\"]",
        app_text,
        re.IGNORECASE
    )
)

remaining_send_money = len(
    re.findall(
        r"@app\.route\(\s*['\"]/send-money['\"]",
        app_text,
        re.IGNORECASE
    )
)

# ---------------------------------------------------------
# VERIFY OLD TEMPLATES ARE GONE
# ---------------------------------------------------------

international_exists = (
    TEMPLATES / "international_transfer.html"
).exists()

send_money_exists = (
    TEMPLATES / "send_money.html"
).exists()

print()
print("=" * 60)
print("CLEANUP VALIDATION")
print("=" * 60)
print()

print(
    "Remaining /international-transfer routes:",
    remaining_international
)

print(
    "Remaining /send-money routes:",
    remaining_send_money
)

print(
    "international_transfer.html exists:",
    international_exists
)

print(
    "send_money.html exists:",
    send_money_exists
)

if remaining_international != 0:
    print()
    print("ERROR: International Transfer route still exists.")
    print("NO FILE WAS CHANGED.")
    raise SystemExit(1)

if remaining_send_money != 0:
    print()
    print("ERROR: Send Money route still exists.")
    print("NO FILE WAS CHANGED.")
    raise SystemExit(1)

if international_exists:
    print()
    print("ERROR: International Transfer template still exists.")
    print("NO FILE WAS CHANGED.")
    raise SystemExit(1)

if send_money_exists:
    print()
    print("ERROR: Send Money template still exists.")
    print("NO FILE WAS CHANGED.")
    raise SystemExit(1)

# ---------------------------------------------------------
# WRITE APP ONLY AFTER VALIDATION
# ---------------------------------------------------------

APP.write_text(app_text, encoding="utf-8")

print()
print("=" * 60)
print("SUCCESS")
print("=" * 60)
print()
print("The old transfer routes have been removed.")
print("The old transfer templates have been removed.")
print()
print("Everything else in the application was left untouched.")
print()
print("Backups:")
print(" ", app_backup.name)

for backup in backups:
    print(" ", backup.name)

print()
print("The next step is to rebuild both transfer sections")
print("from clean templates and clean routes.")
print()