from pathlib import Path

path = Path("app.py")
html_path = Path("templates/settings.html")

app = path.read_text(encoding="utf-8")
settings = html_path.read_text(encoding="utf-8")

# Add the Settings route for Bank Statements Lock/Unlock
marker = '@app.route("/bank-statements")'

route = '''@app.route("/settings/bank-statements-lock", methods=["GET", "POST"])
@login_required
def bank_statements_lock_settings():
    customer = current_user

    if request.method == "POST":
        customer.bank_statements_locked = not customer.bank_statements_locked
        db.session.commit()

        return redirect(url_for("bank_statements_lock_settings"))

    return render_template(
        "bank_statements_lock.html",
        customer=customer
    )


'''

if 'def bank_statements_lock_settings():' not in app:
    position = app.find(marker)

    if position == -1:
        print("ERROR: /bank-statements route was not found.")
        raise SystemExit(1)

    app = app[:position] + route + app[position:]
else:
    print("INFO: Bank Statements Lock route already exists.")

# Connect the existing Settings card to the new page.
old_text = '''    <!-- BANK STATEMENTS -->

    <div class="settings-card">'''

new_text = '''    <!-- BANK STATEMENTS -->

    <a
        href="{{ url_for('bank_statements_lock_settings') }}"
        class="settings-card"
        style="text-decoration:none; color:inherit;">'''

if old_text in settings:
    settings = settings.replace(old_text, new_text, 1)

    # Close the converted card with </a> instead of </div>
    bank_start = settings.find(new_text)

    if bank_start != -1:
        bank_end = settings.find("    <!-- NOTIFICATIONS -->", bank_start)

        if bank_end != -1:
            section = settings[bank_start:bank_end]

            # Replace only the final card closing div.
            last_div = section.rfind("    </div>")

            if last_div != -1:
                section = section[:last_div] + "    </a>\n\n"
                settings = settings[:bank_start] + section + settings[bank_end:]

elif 'url_for(\'bank_statements_lock_settings\')' in settings:
    print("INFO: Settings card is already connected.")
else:
    print("ERROR: Bank Statements Settings card was not found.")
    raise SystemExit(1)

path.write_text(app, encoding="utf-8")
html_path.write_text(settings, encoding="utf-8")

print("SUCCESS: Bank Statements Lock & Unlock is connected.")
print("Settings card now opens the lock/unlock page.")
print("The existing bank statement page has not been changed yet.")