from pathlib import Path
import re

FILE = Path("templates/send_money.html")

if not FILE.exists():
    raise RuntimeError("ERROR: templates/send_money.html was not found.")

text = FILE.read_text(encoding="utf-8")

old = '''            button.addEventListener("click", function () {

                bankSelect.value = bank;
                triggerText.textContent = bank;

                closePicker();

            });
'''

new = '''            button.addEventListener("click", function () {

                /*
                 * The visible picker contains the full UK bank list,
                 * while the real form select initially contains only
                 * the placeholder option. Add the selected bank as a
                 * real option before assigning its value.
                 */

                let existingOption = Array.from(
                    bankSelect.options
                ).find(function (option) {
                    return option.value === bank;
                });

                if (!existingOption) {

                    existingOption =
                        document.createElement("option");

                    existingOption.value = bank;
                    existingOption.textContent = bank;

                    bankSelect.appendChild(
                        existingOption
                    );
                }

                bankSelect.value = bank;

                triggerText.textContent = bank;

                closePicker();

            });
'''

if old not in text:
    raise RuntimeError(
        "ERROR: The bank picker selection block was not found. "
        "No changes were made."
    )

text = text.replace(old, new, 1)

FILE.write_text(text, encoding="utf-8")

print("SUCCESS: Bank picker now submits the selected UK bank correctly.")