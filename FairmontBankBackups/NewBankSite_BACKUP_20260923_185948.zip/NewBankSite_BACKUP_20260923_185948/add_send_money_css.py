from pathlib import Path

BASE_DIR = Path(r"C:\Users\DON J\Documents\NewBankSite")
CSS_FILE = BASE_DIR / "static" / "css" / "style.css"

css = r'''

/* =========================================================
   FAIRMONT BANK - SEND MONEY
   ========================================================= */

.send-money-form {
    margin-top: 25px;
}

.send-money-field {
    margin-bottom: 19px;
}

.send-money-field label {
    display: block;

    margin-bottom: 8px;

    font-size: 10px;

    font-weight: 600;

    color: rgba(255, 255, 255, 0.72);
}

.send-money-field label span {
    color: rgba(255, 255, 255, 0.35);

    font-weight: 400;
}

.send-money-field input {
    width: 100%;

    min-height: 51px;

    padding: 0 15px;

    border-radius: 14px;

    border: 1px solid rgba(255, 255, 255, 0.10);

    outline: none;

    background: rgba(255, 255, 255, 0.055);

    color: #ffffff;

    font-family: inherit;

    font-size: 12px;

    box-sizing: border-box;

    transition:
        border-color 0.2s ease,
        background 0.2s ease;
}

.send-money-field input::placeholder {
    color: rgba(255, 255, 255, 0.25);
}

.send-money-field input:focus {
    border-color: rgba(255, 255, 255, 0.25);

    background: rgba(255, 255, 255, 0.08);
}

.send-money-field small {
    display: block;

    margin-top: 7px;

    font-size: 9px;

    line-height: 1.45;

    color: rgba(255, 255, 255, 0.34);
}

.send-money-amount {
    position: relative;
}

.send-money-amount > span {
    position: absolute;

    left: 15px;

    top: 50%;

    transform: translateY(-50%);

    font-size: 14px;

    color: rgba(255, 255, 255, 0.55);

    pointer-events: none;
}

.send-money-amount input {
    padding-left: 34px;
}

.send-money-error {
    margin-top: 18px;

    padding: 13px 14px;

    border-radius: 13px;

    background: rgba(150, 50, 50, 0.14);

    border: 1px solid rgba(255, 120, 120, 0.14);

    color: rgba(255, 220, 220, 0.90);

    font-size: 10px;

    line-height: 1.5;
}

.send-money-notice {
    margin: 23px 0 18px;

    padding: 16px;

    border-radius: 16px;

    background: rgba(255, 255, 255, 0.045);

    border: 1px solid rgba(255, 255, 255, 0.075);
}

.send-money-notice strong {
    display: block;

    margin-bottom: 6px;

    font-size: 10px;

    color: rgba(255, 255, 255, 0.72);
}

.send-money-notice p {
    margin: 0;

    font-size: 9px;

    line-height: 1.55;

    color: rgba(255, 255, 255, 0.40);
}

.send-money-button {
    width: 100%;

    min-height: 52px;

    border: 0;

    border-radius: 14px;

    background:
        linear-gradient(
            135deg,
            rgba(255, 255, 255, 0.17),
            rgba(255, 255, 255, 0.08)
        );

    border: 1px solid rgba(255, 255, 255, 0.12);

    color: #ffffff;

    font-family: inherit;

    font-size: 12px;

    font-weight: 600;

    cursor: pointer;

    transition:
        background 0.2s ease,
        transform 0.2s ease;
}

.send-money-button:hover {
    background:
        linear-gradient(
            135deg,
            rgba(255, 255, 255, 0.22),
            rgba(255, 255, 255, 0.10)
        );
}

.send-money-button:active {
    transform: scale(0.985);
}

'''


existing = CSS_FILE.read_text(encoding="utf-8")

if ".send-money-form {" not in existing:

    CSS_FILE.write_text(
        existing + css,
        encoding="utf-8"
    )

    print("SUCCESS: Send Money CSS added.")

else:

    print("Send Money CSS already exists.")