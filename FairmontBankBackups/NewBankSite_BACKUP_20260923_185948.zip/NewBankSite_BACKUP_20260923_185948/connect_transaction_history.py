from pathlib import Path

BASE_DIR = Path(r"C:\Users\DON J\Documents\NewBankSite")

DASHBOARD_FILE = BASE_DIR / "templates" / "dashboard.html"

text = DASHBOARD_FILE.read_text(encoding="utf-8")


old_link = '''<a
                        href="#"
                        class="service-item">

                        <span class="service-icon">
                            ≡
                        </span>

                        <span class="service-name">
                            Transaction<br>
                            History
                        </span>

                    </a>'''


new_link = '''<a
                        href="/transactions"
                        class="service-item">

                        <span class="service-icon">
                            ≡
                        </span>

                        <span class="service-name">
                            Transaction<br>
                            History
                        </span>

                    </a>'''


if old_link in text:

    text = text.replace(
        old_link,
        new_link,
        1
    )

    DASHBOARD_FILE.write_text(
        text,
        encoding="utf-8"
    )

    print("SUCCESS: Transaction History now opens /transactions.")

else:

    print("Transaction History link was not found in the expected format.")