from pathlib import Path

BASE_DIR = Path(r"C:\Users\DON J\Documents\NewBankSite")

PROFILE_FILE = BASE_DIR / "templates" / "my_profile.html"

text = PROFILE_FILE.read_text(encoding="utf-8")

# Fix the top-left back arrow
text = text.replace(
    '<a href="/" class="profile-back-button">',
    '<a href="/dashboard" class="profile-back-button">'
)

text = text.replace(
    '<a href="/login" class="profile-back-button">',
    '<a href="/dashboard" class="profile-back-button">'
)

# Fix the Return to dashboard button
text = text.replace(
    '<a href="/login" class="profile-dashboard-button">',
    '<a href="/dashboard" class="profile-dashboard-button">'
)

PROFILE_FILE.write_text(
    text,
    encoding="utf-8"
)

print()
print("==============================================")
print("PROFILE NAVIGATION FIXED")
print("==============================================")
print()
print("Back arrow:          /dashboard")
print("Return to dashboard: /dashboard")
print()