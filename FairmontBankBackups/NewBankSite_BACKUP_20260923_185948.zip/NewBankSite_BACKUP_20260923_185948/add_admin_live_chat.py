from pathlib import Path
import shutil

APP_FILE = Path("app.py")

if not APP_FILE.exists():
    print("ERROR: app.py was not found.")
    raise SystemExit(1)

text = APP_FILE.read_text(encoding="utf-8")

if "def admin_live_chat" in text:
    print("Admin Live Chat route already exists.")
    raise SystemExit(0)

backup = Path("app.py.before_admin_live_chat")
shutil.copy2(APP_FILE, backup)

route = r'''

@app.route("/admin/live-chat", methods=["GET", "POST"])
def admin_live_chat():
    admin_id = session.get("admin_id")

    if not admin_id:
        return redirect(url_for("admin_login"))

    admin = db.session.get(AdminUser, admin_id)

    if admin is None or not admin.is_active:
        session.pop("admin_id", None)
        session.pop("admin_username", None)
        return redirect(url_for("admin_login"))

    conversation_id = request.args.get("conversation_id", type=int)

    if request.method == "POST":
        conversation_id = request.form.get("conversation_id", type=int)
        message_text = request.form.get("message", "").strip()

        if not conversation_id:
            return redirect(url_for("admin_live_chat"))

        conversation = db.session.get(
            LiveChatConversation,
            conversation_id
        )

        if conversation is None:
            return redirect(url_for("admin_live_chat"))

        if not message_text:
            return redirect(
                url_for(
                    "admin_live_chat",
                    conversation_id=conversation.id
                )
            )

        if len(message_text) > 2000:
            message_text = message_text[:2000]

        message = LiveChatMessage(
            conversation_id=conversation.id,
            sender_type="support",
            sender_id=admin.id,
            message=message_text,
            is_read=False
        )

        conversation.status = "Open"
        conversation.updated_at = datetime.utcnow()

        db.session.add(message)
        db.session.commit()

        return redirect(
            url_for(
                "admin_live_chat",
                conversation_id=conversation.id
            )
        )

    conversations = (
        LiveChatConversation.query
        .order_by(LiveChatConversation.updated_at.desc())
        .all()
    )

    selected_conversation = None
    messages = []

    if conversation_id:
        selected_conversation = db.session.get(
            LiveChatConversation,
            conversation_id
        )

        if selected_conversation:
            messages = (
                LiveChatMessage.query
                .filter_by(
                    conversation_id=selected_conversation.id
                )
                .order_by(LiveChatMessage.created_at.asc())
                .all()
            )

            unread_customer_messages = (
                LiveChatMessage.query
                .filter_by(
                    conversation_id=selected_conversation.id,
                    sender_type="customer",
                    is_read=False
                )
                .all()
            )

            for customer_message in unread_customer_messages:
                customer_message.is_read = True

            if unread_customer_messages:
                db.session.commit()

    customers = {}

    for conversation in conversations:
        customer = db.session.get(
            Customer,
            conversation.customer_id
        )

        customers[conversation.id] = customer

    return render_template(
        "admin_live_chat.html",
        admin=admin,
        conversations=conversations,
        selected_conversation=selected_conversation,
        messages=messages,
        customers=customers
    )
'''

# Insert immediately before the final app.run block.
marker = '\nif __name__ == "__main__":'

position = text.rfind(marker)

if position == -1:
    print("ERROR: Could not find the final app.run block.")
    print("Your app.py was not changed.")
    raise SystemExit(1)

new_text = text[:position] + route + text[position:]

APP_FILE.write_text(new_text, encoding="utf-8")

print("=" * 70)
print("ADMIN LIVE CHAT ROUTE ADDED")
print("=" * 70)
print()
print("Backup created:")
print(backup)
print()
print("Route added:")
print("/admin/live-chat")
print()
print("Customer and administrator authentication remain separate.")
print()