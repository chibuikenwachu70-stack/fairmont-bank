from pathlib import Path
import sqlite3

DB_FILE = Path("instance/fairmont.db")

if not DB_FILE.exists():
    print("ERROR: instance/fairmont.db was not found.")
    raise SystemExit(1)

connection = sqlite3.connect(DB_FILE)
cursor = connection.cursor()

columns = cursor.execute(
    "PRAGMA table_info(bank_messages)"
).fetchall()

column_names = [column[1] for column in columns]

if "sender_type" not in column_names:
    cursor.execute(
        """
        ALTER TABLE bank_messages
        ADD COLUMN sender_type VARCHAR(20)
        NOT NULL
        DEFAULT 'customer'
        """
    )

    connection.commit()

    print("sender_type column added successfully.")
else:
    print("sender_type column already exists.")

# Existing records:
# Customer messages normally have their original subject.
# Administrator replies created by our current system use "Re:"
# followed by the customer's original subject.
cursor.execute(
    """
    UPDATE bank_messages
    SET sender_type = 'support'
    WHERE subject LIKE 'Re:%'
    """
)

cursor.execute(
    """
    UPDATE bank_messages
    SET sender_type = 'customer'
    WHERE sender_type IS NULL
       OR sender_type = ''
    """
)

connection.commit()

total = cursor.execute(
    "SELECT COUNT(*) FROM bank_messages"
).fetchone()[0]

customers = cursor.execute(
    """
    SELECT COUNT(*)
    FROM bank_messages
    WHERE sender_type = 'customer'
    """
).fetchone()[0]

support = cursor.execute(
    """
    SELECT COUNT(*)
    FROM bank_messages
    WHERE sender_type = 'support'
    """
).fetchone()[0]

connection.close()

print("=" * 70)
print("BANK MESSAGE SENDER MIGRATION COMPLETE")
print("=" * 70)
print()
print("Total messages:", total)
print("Customer messages:", customers)
print("Support messages:", support)
print()
print("Existing messages were preserved.")