from pathlib import Path

file = Path("app.py")

if not file.exists():
    raise SystemExit("ERROR: app.py was not found.")

text = file.read_text(encoding="utf-8")

# Add Fairmont Bank to the UK bank list only if it is not already present.
if '"Fairmont Bank"' in text:
    print("Fairmont Bank is already present in app.py.")
    raise SystemExit(0)

# Look for the existing UK bank list and add Fairmont Bank immediately
# before the final "Other UK Bank or Building Society" option.
old = '"Other UK Bank or Building Society"'

if old not in text:
    raise SystemExit(
        'ERROR: The UK bank list could not be located. No changes were made.'
    )

text = text.replace(
    old,
    '"Fairmont Bank",\n        ' + old,
    1
)

file.write_text(text, encoding="utf-8")

print("SUCCESS: Fairmont Bank has been added to the UK bank list.")
print("Only the UK bank list was changed.")